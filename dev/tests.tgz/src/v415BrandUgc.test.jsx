// v415 — brand Instant UGC polish round (area C).
import React from "react";
import fs from "fs";
import path from "path";
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, fireEvent, act, cleanup, waitFor } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";

vi.mock("./lib/api", () => ({ api: { get: vi.fn(), post: vi.fn() } }));
vi.mock("./lib/sharedSocket", () => ({ acquireSocket: () => ({ on: () => {}, release: () => {} }) }));
vi.mock("./contexts/LoadingContext", () => ({ useLoading: () => ({ startLoading: () => {}, stopLoading: () => {} }) }));
vi.mock("./contexts/AuthContext", () => ({ useAuth: () => ({ user: { user_id: "u_brand", name: "QA Foods" } }) }));
vi.mock("./hooks/useIsMobile", () => ({ default: () => false }));
vi.mock("./components/ugc/CreatorClaimStats", () => ({
  loadCreator: () => Promise.resolve({}),
  summarizeCreator: () => ({ niches: [], platformList: [], tiles: [], tilesTotal: 0 }),
}));

import { api } from "./lib/api";
import { payoutSuffix, firstPositiveAmount } from "./pages/brand/BrandUGCOrders";
import BrandUGCPayments, { ugcOrderAmount, ugcOrderMoneyState } from "./pages/brand/BrandUGCPayments";
import { ugcOrderAmountOf, claimStatusWords } from "./pages/brand/BrandUGCMobile";
import { useBriefExplainer, hasSeenBriefExplainer } from "./components/ugc/BriefSafetyExplainer";
import ApprovedPayoutModal from "./pages/brand/brandUgc/ApprovedPayoutModal";
import RevisionModal from "./pages/brand/brandUgc/RevisionModal";
import AiPromptSheet from "./pages/brand/brandUgc/AiPromptSheet";

const read = (p) => fs.readFileSync(path.resolve(process.cwd(), p), "utf8");

beforeEach(() => {
  try { localStorage.clear(); } catch { /* jsdom */ }
  if (!window.matchMedia) {
    window.matchMedia = () => ({ matches: true, addListener() {}, removeListener() {}, addEventListener() {}, removeEventListener() {} });
  }
});
afterEach(() => { cleanup(); vi.clearAllMocks(); });

describe("v415 amounts — never ₹0", () => {
  it("payoutSuffix hides unknown amounts", () => {
    expect(payoutSuffix(3000)).toBe(" (₹3,000)");
    expect(payoutSuffix(0)).toBe("");
    expect(payoutSuffix(undefined)).toBe("");
    expect(payoutSuffix("abc")).toBe("");
  });
  it("firstPositiveAmount skips 0 placeholders", () => {
    expect(firstPositiveAmount(null, 0, undefined, 3000)).toBe(3000);
    expect(firstPositiveAmount(0, null)).toBe(0);
  });
  it("order amount reads every field the server may use", () => {
    expect(ugcOrderAmount({ amount: 3000 })).toBe(3000);
    expect(ugcOrderAmount({ agreed_amount: 0, brief: { budget: 2500 } })).toBe(2500);
    expect(ugcOrderAmountOf({ escrow_amount: 1200 })).toBe(1200);
    expect(ugcOrderAmountOf({ brief: { budget: 900 } })).toBe(900);
    expect(ugcOrderAmountOf({})).toBe(0);
  });
  it("an open order with PENDING / empty payment status counts as held", () => {
    expect(ugcOrderMoneyState({ status: "in_progress" })).toBe("held");
    expect(ugcOrderMoneyState({ status: "IN_PROGRESS", payment_status: "PENDING" })).toBe("held");
    expect(ugcOrderMoneyState({ payment_status: "ESCROW_HELD" })).toBe("held");
    expect(ugcOrderMoneyState({ payment_status: "RELEASED" })).toBe("released");
    expect(ugcOrderMoneyState({ status: "CANCELLED" })).toBe("refunded");
  });
  it("claim statuses are plain words", () => {
    expect(claimStatusWords("IN_PROGRESS")).toBe("Working on it");
    expect(claimStatusWords("in_progress")).toBe("Working on it");
    expect(claimStatusWords("")).toBe("Claimed");
    expect(claimStatusWords("SOMETHING_NEW")).toBe("Something new");
  });
});

describe("v415 UGC payments page", () => {
  it("shows the held amount of an order in production (was ₹0 / ₹0) and the creator name", async () => {
    api.get.mockResolvedValue({ data: [{ id: "ugc1", brief: { title: "Unboxing video" }, creator: { name: "Creator 2 Khan" }, creator_id: "u_cr2", status: "in_progress", amount: 3000, created_at: "2026-10-31T09:00:00Z" }] });
    render(<MemoryRouter><BrandUGCPayments /></MemoryRouter>);
    await waitFor(() => expect(screen.getAllByText("₹3,000").length).toBeGreaterThan(0));
    expect(screen.getByText("Creator 2 Khan")).toBeTruthy();
    expect(screen.queryByText(/u_cr2/)).toBeNull();
    expect(screen.getByText("Held")).toBeTruthy();
  });
});

describe("v415 'Your money stays safe' shows once", () => {
  function Host({ userId }) {
    const [open, , close] = useBriefExplainer(userId, true);
    return <div>{open ? <button onClick={close}>open</button> : "closed"}</div>;
  }
  it("waits for the user, opens once, and never again", () => {
    const { rerender, unmount } = render(<Host userId={undefined} />);
    expect(screen.getByText("closed")).toBeTruthy(); // no "anon" popup before auth is ready
    rerender(<Host userId="u_brand" />);
    expect(screen.getByText("open")).toBeTruthy();
    expect(hasSeenBriefExplainer("u_brand")).toBe(true); // remembered as soon as it is shown
    unmount();
    render(<Host userId="u_brand" />);
    expect(screen.getByText("closed")).toBeTruthy();
  });
});

describe("v415 sheets and modals", () => {
  it("payout released modal never says ₹0", () => {
    render(<ApprovedPayoutModal amount={0} deliverableUrl={null} selectedOrder={{ creator_name: "Asha" }} showApprovedModal setActiveTab={() => {}} setSelectedOrderId={() => {}} setShowApprovedModal={() => {}} setView={() => {}} />);
    expect(screen.getByRole("dialog")).toBeTruthy();
    expect(document.body.textContent).not.toMatch(/₹0/);
    expect(document.body.textContent).toMatch(/The payment is released to Asha/);
  });
  it("revision sheet: dialog, Escape closes, send disabled while empty", () => {
    const setShow = vi.fn();
    render(<RevisionModal showRevisionModal revisionNotes="" setRevisionNotes={() => {}} setShowRevisionModal={setShow} handleSubmitRevision={() => {}} submittingRevision={false} />);
    expect(screen.getByRole("dialog")).toBeTruthy();
    expect(screen.getByText("Send request").closest("button").disabled).toBe(true);
    act(() => { fireEvent.keyDown(window, { key: "Escape" }); });
    expect(setShow).toHaveBeenCalledWith(false);
  });
  it("AI sheet sits above the bottom nav and closes on Escape", () => {
    const setShow = vi.fn();
    const { container } = render(<AiPromptSheet showAiAssist aiGenerating={false} handleGenerateWithAi={() => {}} postData={{}} setShowAiAssist={setShow} />);
    expect(container.innerHTML).toMatch(/z-\[1000\]/);
    act(() => { fireEvent.keyDown(window, { key: "Escape" }); });
    expect(setShow).toHaveBeenCalledWith(false);
  });
});

describe("v415 source checks", () => {
  it("no ₹0 approve labels left in the orders screens", () => {
    const orders = read("src/pages/brand/BrandUGCOrders.jsx");
    expect(orders).not.toMatch(/Release Payout \(₹\{formatAmount/);
    expect(orders).not.toMatch(/Release Payout \(₹\$\{formatAmount/);
    const mobile = read("src/pages/brand/BrandUGCMobile.jsx");
    expect(mobile).not.toMatch(/Approve & Release ₹\{amount\.toLocaleString/);
    expect(mobile).not.toMatch(/payout of ₹\$\{amount\.toLocaleString/);
  });
  it("desktop orders auto-opens the first order and the filter chips wrap", () => {
    const orders = read("src/pages/brand/BrandUGCOrders.jsx");
    expect(orders).toMatch(/autoPickedRef/);
    expect(orders).toMatch(/flex-wrap" role="group" aria-label="Filter orders"/);
  });
  it("no endless ping on waiting states", () => {
    for (const f of ["src/pages/brand/brandUgcOrders/AwaitingLiveLinkPanel.jsx", "src/components/deals/DealProgressStepper.jsx"]) {
      expect(read(f)).not.toMatch(/animate-ping/);
    }
  });
});

describe("v415 pages render (smoke)", () => {
  const order = { id: "ugc1", brief_id: "brief1", brief: { id: "brief1", title: "Unboxing video for masala range", budget: 3000 }, creator_id: "u_cr2", creator_name: "Creator 2 Khan", status: "SUBMITTED", stage: "IN_REVIEW", deliverable_type: "ugc_video_edited", requires_live_link: false, submission_link: "https://drive.google.com/x", created_at: "2026-10-31T09:00:00Z" };
  const brief = { id: "brief1", title: "Unboxing video for masala range", product_name: "Masala Box", budget: 3000, max_creators: 5, claimed_count: 1, status: "active", deliverable_type: "video", created_at: "2026-10-28T09:00:00Z" };
  beforeEach(() => {
    api.get.mockImplementation((url) => Promise.resolve({ data: String(url).includes("orders") ? [order] : String(url).includes("briefs/my") ? [brief] : {} }));
  });

  it("desktop UGC orders opens the only order and shows the real payout amount", async () => {
    const { default: BrandUGCOrders } = await import("./pages/brand/BrandUGCOrders");
    render(<MemoryRouter><BrandUGCOrders /></MemoryRouter>);
    await waitFor(() => expect(screen.getAllByText(/Approve & Release Payout \(₹3,000\)/).length).toBeGreaterThan(0));
    expect(document.body.textContent).not.toMatch(/Select an order from the list/);
  });

  it("desktop Instant UGC brief card says Creators (1), not Applicants", async () => {
    const { default: BrandInstantUGC } = await import("./pages/brand/BrandInstantUGC");
    render(<MemoryRouter initialEntries={["/brand/ugc/briefs"]}><BrandInstantUGC /></MemoryRouter>);
    await waitFor(() => expect(screen.getByText("Creators (1)")).toBeTruthy());
    expect(screen.getByText("Cancel & refund")).toBeTruthy();
    expect(document.body.textContent).not.toMatch(/View Applicants/);
  });

  it("desktop post wizard renders without the blinking ₹ placeholder", async () => {
    const { default: BrandUGCPost } = await import("./pages/brand/BrandUGCPost");
    render(<MemoryRouter><BrandUGCPost /></MemoryRouter>);
    expect(screen.getByText("Post UGC Brief")).toBeTruthy();
    expect(screen.getByText("You set this in step 4")).toBeTruthy();
  });

  it("phone UGC home: Creators (1) from the order when the brief has no applicant list", async () => {
    const { default: BrandUGCMobile } = await import("./pages/brand/BrandUGCMobile");
    render(<MemoryRouter><BrandUGCMobile initialTab="briefs" initialView="main" /></MemoryRouter>);
    await waitFor(() => expect(screen.getByText("Creators (1)")).toBeTruthy());
    fireEvent.click(screen.getByText("Creators (1)"));
    await waitFor(() => expect(screen.getByRole("dialog", { name: "Claimed by" })).toBeTruthy());
    expect(screen.queryByText("No creator has claimed this brief yet.")).toBeNull();
  });
});
