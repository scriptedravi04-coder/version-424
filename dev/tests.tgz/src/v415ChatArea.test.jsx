// v415: deal chat leftovers (Area E) — countdown, staff sender, contract resend, revision text,
// stage chips, cancelled strip, completed chat stays open, popup polish.
import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";
import { getChatStage, getInboxChip } from "./components/chat/mobile/chatStageMap";

const read = (p) => fs.readFileSync(path.resolve(process.cwd(), p), "utf8");

describe("v415 chat area E", () => {
  it("1: countdown shows minutes in the last hour", () => {
    const src = read("src/components/chat/mobile/MobileBriefCards.jsx");
    expect(src).toMatch(/min left/);
    expect(src).toMatch(/hrs > 0 \?/);
  });

  it("2: staff who aren't a party post as admin; bubbles label Ybex Support", () => {
    const be = read("backend/chat_routes.ts");
    expect(be).toMatch(/isThreadCreator \? 'creator' : isThreadBrand \? 'brand' : 'admin'/);
    expect(be).not.toMatch(/req\.body\.sender_role \|\|/);
    expect(read("src/components/chat/MessageBubble.jsx")).toMatch(/Ybex Support/);
    expect(read("src/components/chat/mobile/MobileMessageRow.jsx")).toMatch(/sender_role === "admin"[\s\S]*Ybex Support/);
  });

  it("3: resend cooldown starts at 0; already_signed says Already signed", () => {
    const src = read("src/components/chat/UGCContractModal.jsx");
    expect(src).toMatch(/useState\(0\); \/\/ v415/);
    expect(src).toMatch(/already_signed/);
    expect(src).toMatch(/Already signed/);
  });

  it("4: revision limit message no longer suggests cancelling", () => {
    const src = read("backend/services/ugcLifecycleService.ts");
    expect(src).not.toMatch(/or cancel this order/);
    // v417: the copy moved to one shared constant (campaignGuards.ts) that points to Support
    expect(src).toMatch(/REVISION_LIMIT_MESSAGE/);
    expect(read("backend/campaignGuards.ts")).toMatch(/Contact Ybex Support from the deal menu/);
  });

  it("5a: 'Review live link' (capital R) counts as needing action for the brand", () => {
    const thread = { id: "t1", is_ugc: true, ugc_order_id: "o1", status: "LINKS_UNDER_REVIEW", flow_state: "LINKS_UNDER_REVIEW" };
    const chip = getInboxChip(thread, true);
    expect(chip.needsAction).toBe(true);
  });

  it("5b: DECLINED_REVISION / RESUBMISSION_DECLINED are not shown as a declined deal", () => {
    for (const st of ["DECLINED_REVISION", "RESUBMISSION_DECLINED"]) {
      const thread = { id: "t2", status: "ACTIVE", flow_state: st, payment_funded: true, agreement_signed_brand: true, agreement_signed_creator: true };
      const chip = getInboxChip(thread, true);
      expect(chip.label).not.toBe("Declined by creator");
      const stage = getChatStage({ thread, isBrand: true, isUgcOrder: false, isMySignatureSigned: true, isOtherPartySigned: true });
      expect(stage.key).toBe("changes_declined");
    }
  });

  it("6: cancelled deal strip is grey with no pulse", () => {
    const src = read("src/components/chat/chatBox/ChatBoxDealStrip.jsx");
    expect(src).toMatch(/isCancelled \? "grey"/);
    expect(src).toMatch(/tone === "grey"\s*\? "bg-slate-400"/);
  });

  it("7: completed chat keeps the composer with a small note (desktop + mobile)", () => {
    const d = read("src/components/chat/ChatBox.jsx");
    const m = read("src/components/chat/mobile/ChatBoxMobile.jsx");
    expect(d).not.toMatch(/Deal Completed — Chat is closed/);
    expect(m).not.toMatch(/Deal Completed · Chat Closed/);
    expect(d).toMatch(/deal-completed-note/);
    expect(m).toMatch(/deal-completed-note/);
  });

  it("review: popups polished (safety once per user, z-index, escape, no endless ping)", () => {
    expect(read("src/components/chat/ChatBox.jsx")).toMatch(/safety_accepted_\$\{user\?\.user_id \|\| user\?\.id \|\| 'anon'\}`, 'true'\)/);
    const safety = read("src/components/chat/SafetyModal.jsx");
    expect(safety).toMatch(/useScrollLock/);
    expect(safety).toMatch(/Escape/);
    expect(safety).not.toMatch(/⚠️/);
    expect(read("src/components/chat/chatBox/ChatBoxPaymentSheet.jsx")).toMatch(/z-\[1000\]/);
    expect(read("src/components/chat/chatBox/ChatBoxPaymentSheet.jsx")).toMatch(/if \(paid\) setShowPaymentSheet\(false\)/);
    expect(read("src/components/chat/NegotiationTable.jsx")).not.toMatch(/ACTIVE FEED/);
    expect(read("src/components/chat/ContractModal.jsx")).toMatch(/modalMotion/);
    expect(read("src/components/chat/BurgerMenuSupport.jsx")).not.toMatch(/Ybex Suite Menu/);
  });
});
