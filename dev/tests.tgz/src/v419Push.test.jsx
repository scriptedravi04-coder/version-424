// v419: Android push turns on only when the native build says Firebase is there (old builds via live update: off, no crash).
import { describe, it, expect, vi, beforeEach } from "vitest";
import { readFileSync } from "fs";
const setCap = (meta, push) => {
  window.Capacitor = { isNativePlatform: () => true, getPlatform: () => "android", Plugins: { ...(meta ? { MetaEvents: meta } : {}), PushNotifications: push } };
};
const push = () => ({ checkPermissions: vi.fn(async () => ({ receive: "granted" })), requestPermissions: vi.fn(async () => ({ receive: "granted" })), register: vi.fn(async () => {}), addListener: vi.fn() });
describe("v419 · Android FCM gate", () => {
  beforeEach(() => { vi.resetModules(); });
  it("old build (no hasFirebase) → push unsupported, register never called", async () => {
    const P = push(); setCap({ logEvent: vi.fn() }, P);
    const m = await import("./lib/nativePush.js");
    expect(await m.nativePushState()).toBe("unsupported");
    expect(await m.askNativePush()).toBe("unsupported");
    expect(P.register).not.toHaveBeenCalled();
  });
  it("build without google-services.json (ready:false) → off", async () => {
    const P = push(); setCap({ hasFirebase: vi.fn(async () => ({ ready: false })) }, P);
    const m = await import("./lib/nativePush.js");
    expect(await m.nativePushState()).toBe("unsupported");
    expect(P.register).not.toHaveBeenCalled();
  });
  it("1.0.12 with Firebase → push works", async () => {
    const P = push(); setCap({ hasFirebase: vi.fn(async () => ({ ready: true })) }, P);
    const m = await import("./lib/nativePush.js");
    expect(await m.nativePushState()).toBe("granted");
    expect(m.nativePushAvailable()).toBe(true);
    expect(await m.askNativePush()).toBe("granted");
    expect(P.register).toHaveBeenCalled();
  });
  it("native plugin has hasFirebase; Firebase file present for the build", () => {
    expect(readFileSync("android-overrides/app/src/main/java/com/ybex/app/MetaEventsPlugin.java", "utf8")).toContain("public void hasFirebase(PluginCall call)");
  });
});
