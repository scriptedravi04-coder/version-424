// v397 (Ravi): creators under 500 Instagram followers see a clean page with one work-link box.
import { describe, it, expect, afterEach } from "vitest";
import React from "react";
import { render, screen, fireEvent, waitFor, cleanup } from "@testing-library/react";
afterEach(() => cleanup());
import fs from "fs";
import FollowerGate from "./components/onboarding/FollowerGate";
import { onboardingGated, belowMinFollowers, cleanWorkLink, MIN_FOLLOWERS, _setMinForTests, subLine, gateReason } from "./lib/followerGate";
import { waitlistChipMatch, isLowFollowerWork } from "./components/admin/WaitlistManager";
import { validateCreatorForm } from "./utils/creatorFormValidation";

describe("v397 gate rules", () => {
  it("only numbers that came from Instagram, and only under 500", () => {
    expect(MIN_FOLLOWERS).toBe(500);
    expect(onboardingGated({ instagramHandle: "riya", followerCount: 312, instagramConnectedVia: "instagram_fetch" })).toBe(true);
    expect(onboardingGated({ instagramHandle: "riya", followerCount: 0, instagramConnectedVia: "oauth" })).toBe(true);
    expect(onboardingGated({ instagramHandle: "riya", followerCount: 500, instagramConnectedVia: "instagram_fetch" })).toBe(false);
    // requirement changed (Ravi, 3 Nov): Instagram not read (private / personal / typed numbers) → no access either
    expect(onboardingGated({ instagramHandle: "riya", followerCount: 312, instagramConnectedVia: "manual" })).toBe(true);
    expect(onboardingGated({ instagramHandle: "riya", followerCount: "", instagramConnectedVia: "instagram_fetch" })).toBe(true);
    expect(onboardingGated({ instagramHandle: "riya", followerCount: 312, instagramConnectedVia: "instagram_fetch", followerGateExempt: true })).toBe(false);
    expect(belowMinFollowers(499)).toBe(true);
    expect(cleanWorkLink("behance.net/riya")).toBe("https://behance.net/riya");
  });
  it("the apply form lets small accounts through to the work-link page", () => {
    const f = { photo: "data:image/png;base64,x", name: "Asha", gender: "Female", email: "a@b.in", mobile: "9876543210", social_handle: "@asha", city: "Jaipur", followers: "250", avg_reach: "200", charges: "500", niche: "Beauty" };
    expect(validateCreatorForm(f).errors.followers).toBeUndefined();
  });
});

describe("v397 FollowerGate screen", () => {
  it("shows Ravi's lines, refuses a non-link and sends a link", async () => {
    const sent = [];
    render(<FollowerGate handle="riya" onSend={async (l) => { sent.push(l); }} onChangeAccount={() => {}} />);
    expect(screen.getByText("Every big creator started small.")).toBeTruthy();
    expect(screen.getByText(/Brands on Ybex look for 500\+ followers\. You're closer than you think\./)).toBeTruthy();
    expect(screen.getByText("Drop your best work link below.")).toBeTruthy();
    expect(screen.getByText(/someone from the Ybex team will personally message you/)).toBeTruthy();
    expect(screen.getByText(/Use another account/)).toBeTruthy();
    fireEvent.change(screen.getByTestId("gate-work-link"), { target: { value: "hello" } });
    fireEvent.click(screen.getByTestId("gate-send"));
    expect(await screen.findByRole("alert")).toBeTruthy();
    fireEvent.change(screen.getByTestId("gate-work-link"), { target: { value: "instagram.com/reel/abc" } });
    fireEvent.click(screen.getByTestId("gate-send"));
    await waitFor(() => expect(screen.getByTestId("gate-done")).toBeTruthy());
    expect(sent).toEqual(["https://instagram.com/reel/abc"]);
    expect(screen.getByText(/Someone from the Ybex team will personally message you if your work is a fit/)).toBeTruthy();
  });
  it("comes back on the 'Got it' state when the link was already sent", () => {
    render(<FollowerGate handle="riya" sent onSend={async () => {}} />);
    expect(screen.getByTestId("gate-done")).toBeTruthy();
  });
});

describe("v397 wiring", () => {
  it("onboarding (mobile + desktop) opens the gate on Next; the apply form and admin know about it", () => {
    const ob = fs.readFileSync("src/pages/auth/Onboarding.jsx", "utf8");
    expect(ob).toContain("<FollowerGate");
    expect(ob).toContain("creator/follower-gate/work");
    expect(fs.readFileSync("src/pages/onboarding/CreatorOnboardingMobile.jsx", "utf8")).toContain('store.updateField("followerGateOpen", true)');
    expect(fs.readFileSync("src/pages/onboarding/CreatorOnboarding.tsx", "utf8")).toContain('updateField("followerGateOpen" as any, true)');
    const apply = fs.readFileSync("src/pages/creator/PublicCreatorApply.jsx", "utf8");
    expect(apply).toContain("belowMinFollowers(parseCount(followersInput))");
    expect(waitlistChipMatch({ source: "low_followers_work" }, "lowwork")).toBe(true);
    expect(waitlistChipMatch({ source: "creator_apply_form" }, "lowwork")).toBe(false);
    expect(isLowFollowerWork({ source: "low_followers_work" })).toBe(true);
  });
});

describe("v397 admin-set minimum on the screens", () => {
  it("the gate and its line follow the number the admin set; 0 = off", () => {
    _setMinForTests(300);
    expect(onboardingGated({ instagramHandle: "riya", followerCount: 312, instagramConnectedVia: "instagram_fetch" })).toBe(false);
    expect(onboardingGated({ instagramHandle: "riya", followerCount: 250, instagramConnectedVia: "instagram_fetch" })).toBe(true);
    expect(subLine()).toBe("Brands on Ybex look for 300+ followers. You're closer than you think.");
    _setMinForTests(0);
    expect(belowMinFollowers(3)).toBe(false);
    _setMinForTests(500);
    render(<FollowerGate handle="riya" min={1000} onSend={async () => {}} />);
    expect(screen.getByText(/look for 1,000\+ followers/)).toBeTruthy();
  });
  it("admin setting lives in Platform Settings → Creator sign-up (not on the Waitlist page) and in the admin search", async () => {
    // Ravi, 3 Nov: "setting mai platform setting mai do iska option, yaha se hata kr"
    expect(fs.readFileSync("src/components/admin/WaitlistManager.jsx", "utf8")).not.toContain("FollowerLimitCard");
    const pt = fs.readFileSync("src/components/admin/PlatformTools.jsx", "utf8");
    expect(pt).toContain("{ id: 'signup', label: 'Creator sign-up'");
    expect(pt).toContain("<FollowerLimitCard />");
    const { PLATFORM_SETTINGS_SUBS, allowedSettingsTabs } = await import("./lib/adminPermissions");
    expect(PLATFORM_SETTINGS_SUBS.find((s) => s.tab === "signup")?.key).toBe("settings_signup");
    expect(allowedSettingsTabs({ role: "admin" })).toContain("signup");
    expect(allowedSettingsTabs({ role: "admin", team_role: "sub_admin", permissions: ["settings_banners"] })).not.toContain("signup");
    expect(fs.readFileSync("src/lib/adminSearch.js", "utf8")).toContain('"/admin?tab=settings&view=signup"');
  });
});

describe("v397 Instagram not readable → no access (Ravi, 3 Nov)", () => {
  it("check again that works → no link box, the page is told it's fixed", async () => {
    render(<FollowerGate handle="riya.pro" reason="unverified" onRetry={async () => true} onSend={async () => {}} />);
    fireEvent.click(screen.getByTestId("gate-retry"));
    await new Promise((r) => setTimeout(r, 50));
    expect(screen.queryByTestId("gate-work-box")).toBeNull();
  });
  it("reason: unverified when Instagram wasn't fetched, low when under the minimum, none when fine", () => {
    _setMinForTests(500);
    expect(gateReason({ instagramHandle: "riya", followerCount: "", instagramConnectedVia: "" })).toBe("unverified");
    expect(gateReason({ instagramHandle: "riya", followerCount: 312, instagramConnectedVia: "instagram_fetch" })).toBe("low");
    expect(gateReason({ instagramHandle: "riya", followerCount: 900, instagramConnectedVia: "instagram_fetch" })).toBe(null);
    expect(gateReason({ instagramHandle: "riya", followerCount: "", instagramConnectedVia: "", followerGateExempt: true })).toBe(null);
  });
  it("the page asks for a public Professional account, shows the steps, a check-again button and the work link", async () => {
    let retried = 0; const sent = [];
    render(<FollowerGate handle="riya.home" reason="unverified" onRetry={async () => { retried++; return false; }} onSend={async (l) => { sent.push(l); }} />);
    expect(screen.getByText("We couldn't open your Instagram.")).toBeTruthy();
    expect(screen.getByText(/Is @riya.home a public Professional \(Creator\) account\?/)).toBeTruthy();
    expect(screen.getByTestId("gate-steps").textContent).toContain("Switch to professional account");
    // Ravi (3 Nov): no link box at first — only after "check again" still can't read Instagram
    expect(screen.queryByTestId("gate-work-box")).toBeNull();
    fireEvent.click(screen.getByTestId("gate-retry"));
    await waitFor(() => expect(screen.getByTestId("gate-work-box")).toBeTruthy());
    expect(retried).toBe(1);
    expect(screen.getByTestId("gate-still-failed").textContent).toContain("Still can't open @riya.home");
    expect(screen.getByText("Still a creator? Paste your best reel link.")).toBeTruthy();
    fireEvent.change(screen.getByTestId("gate-work-link"), { target: { value: "instagram.com/reel/x1" } });
    fireEvent.click(screen.getByTestId("gate-send"));
    await waitFor(() => expect(screen.getByTestId("gate-done")).toBeTruthy());
    expect(screen.getByText(/personally open your account for you/)).toBeTruthy();
  });
});
