// v417 (agent C): delete draft, desktop pitch player, neutral route fallback, Eva never covers bottom bars.
import { describe, it, expect, vi, beforeEach } from "vitest";
import React from "react";
import fs from "fs";
import path from "path";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";

vi.mock("./lib/api", () => ({ api: { get: vi.fn(() => Promise.resolve({ data: {} })), post: vi.fn(), delete: vi.fn() } }));
vi.mock("sonner", () => ({ toast: { success: vi.fn(), error: vi.fn() } }));

import BrandCampaignsMobile, { DeleteDraftConfirm } from "./components/campaigns/mobile/BrandCampaignsMobile";
import CampaignCard from "./components/campaigns/CampaignCard";
import { PitchPlayer, pitchLinks } from "./components/campaigns/mobile/BrandCampaignDetailMobile";
import { bottomBarHeight } from "./components/feedback/FeedbackBot";

const read = (p) => fs.readFileSync(path.join(process.cwd(), p), "utf8");
const draft = { campaign_id: "d1", title: "Monsoon push", status: "draft" };
const live = { campaign_id: "c1", title: "Summer Glow", status: "live", applicants: [] };

describe("v417 C1: delete draft", () => {
  beforeEach(() => cleanup());

  it("mobile draft card has a Delete button that calls the page handler", () => {
    const onDeleteDraft = vi.fn();
    render(<MemoryRouter><BrandCampaignsMobile campaigns={[draft, live]} filtered={[draft, live]} tabs={[{ id: "all", label: "All", count: 2 }, { id: "draft", label: "Drafts", count: 1 }]}
      activeTab="all" setActiveTab={() => {}} isUnderReview={() => false} onCreate={() => {}} onEdit={() => {}} onSubmitDraft={() => {}} onManage={() => {}} onDeleteDraft={onDeleteDraft} /></MemoryRouter>);
    const btns = screen.getAllByTestId("campaign-delete-draft");
    expect(btns).toHaveLength(1); // only the draft
    fireEvent.click(btns[0]);
    expect(onDeleteDraft).toHaveBeenCalledWith(draft);
  });

  it("desktop card: Delete only on drafts, does not open the card", () => {
    const onDelete = vi.fn(); const onEdit = vi.fn();
    const { rerender } = render(<CampaignCard campaign={draft} onDelete={onDelete} onEdit={onEdit} />);
    fireEvent.click(screen.getByTestId("campaign-delete-draft"));
    expect(onDelete).toHaveBeenCalledWith(draft);
    expect(onEdit).not.toHaveBeenCalled();
    rerender(<CampaignCard campaign={live} onDelete={onDelete} />);
    expect(screen.queryByTestId("campaign-delete-draft")).toBeNull();
  });

  it("styled confirm with the agreed copy runs onConfirm", () => {
    const onConfirm = vi.fn(); const onClose = vi.fn();
    render(<DeleteDraftConfirm sheet={{ title: "Delete this draft?", body: "This can't be undone.", confirmLabel: "Delete", onConfirm }} onClose={onClose} />);
    expect(screen.getByText("Delete this draft?")).toBeTruthy();
    expect(screen.getByText("This can't be undone.")).toBeTruthy();
    fireEvent.click(screen.getByTestId("delete-draft-confirm-yes"));
    expect(onClose).toHaveBeenCalled();
    expect(onConfirm).toHaveBeenCalled();
  });

  it("page calls DELETE /campaigns/:id, removes it from the list, never window.confirm; device draft removed locally", () => {
    const src = read("src/pages/brand/BrandCampaigns.jsx");
    expect(src).toContain("api.delete(`/campaigns/${id}`)");
    expect(src).toContain("setCampaigns((list) => list.filter(");
    expect(src).toContain('title: "Delete this draft?", body: "This can\'t be undone."');
    expect(src).toContain('draftRemove("campaign_draft")');
    expect(src).not.toMatch(/window\.confirm\(/);
    expect(src).toContain("onDeleteDraft={handleDeleteDraft}");
    expect(src).toContain("onDelete={handleDeleteDraft}");
  });
});

describe("v417 C2: pitch player shared with desktop", () => {
  beforeEach(() => cleanup());

  it("plays a pitch video and says Decline (not Reject)", () => {
    const list = [{ application_id: "a1", full_name: "Asha Rao", status: "pending", pitch_video_url: "https://x.test/p.mp4" }];
    const { container } = render(<PitchPlayer list={list} index={0} onIndex={() => {}} />);
    expect(container.ownerDocument.querySelector("video")?.getAttribute("src")).toBe("https://x.test/p.mp4");
    expect(screen.getByText(/Decline/)).toBeTruthy();
    expect(screen.queryByText(/Reject/)).toBeNull();
  });

  it("links in a pitch open in a new tab; chat / phone links are dropped", () => {
    expect(pitchLinks("See https://youtu.be/abc. Or wa.me https://wa.me/919876543210")).toEqual(["https://youtu.be/abc"]);
    const list = [{ application_id: "a1", full_name: "Asha Rao", status: "pending", pitch_text: "My reel: https://www.instagram.com/reel/xyz" }];
    render(<PitchPlayer list={list} index={0} onIndex={() => {}} />);
    const a = screen.getByTestId("pitch-links").querySelector("a");
    expect(a.getAttribute("href")).toBe("https://www.instagram.com/reel/xyz");
    expect(a.getAttribute("target")).toBe("_blank");
  });

  it("desktop applicants page opens the same player", () => {
    const src = read("src/pages/brand/BrandCampaignApplicants.jsx");
    expect(src).toContain("PitchPlayer");
    expect(src).toContain('data-testid="open-pitch-player"');
  });
});

describe("v417 C3: neutral route fallback", () => {
  it("lazy pages wait on a light spinner, not the generic skeleton", () => {
    const src = read("src/App.jsx");
    expect(src).toContain("<Suspense fallback={<RouteNeutralFallback />}>");
    expect(src).toMatch(/function RouteLoaderFallback\(\)[\s\S]*?return <RouteNeutralFallback \/>/);
  });
});

describe("v417 C4: Eva never covers bottom bars", () => {
  it("measures a bar pinned to the bottom edge and ignores other fixed layers", () => {
    document.body.innerHTML = `<div id="bar" class="fixed bottom-0"></div><div id="full" class="fixed inset-0"></div><div id="top" class="fixed top-0"></div>`;
    const rects = { bar: { top: 820, bottom: 900, width: 1440, height: 80 }, full: { top: 0, bottom: 900, width: 1440, height: 900 }, top: { top: 0, bottom: 64, width: 1440, height: 64 } };
    for (const el of document.querySelectorAll("div")) el.getBoundingClientRect = () => rects[el.id];
    const win = { innerHeight: 900, getComputedStyle: () => ({ position: "fixed", display: "block", visibility: "visible", opacity: "1", pointerEvents: "auto" }) };
    expect(bottomBarHeight(document, win)).toBe(80);
    document.body.innerHTML = "";
    expect(bottomBarHeight(document, win)).toBe(0);
  });

  it("the greeting shrinks to the launcher after 4 s and hides over bottom bars; closed panel has no dialog role", () => {
    const src = read("src/components/feedback/FeedbackBot.jsx");
    expect(src).toContain("Math.max(4000, startTyping + text.length * PEEK_TYPE_MS + 1000)");
    expect(src).toContain("const showBubble = bubble && !chat && !barBlocksBubble;");
    expect(src).toContain("marginBottom: lift");
    expect(src).toContain('role={chat ? "dialog" : undefined}');
  });
});
