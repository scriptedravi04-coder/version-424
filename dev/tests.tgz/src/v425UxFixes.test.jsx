// v425: the "Developer Fixes – UX Bugs" list (blog, leaderboard, help tickets, auth, account).
import React from "react";
import fs from "node:fs";
import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, fireEvent, cleanup, waitFor, act } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";

vi.mock("./lib/api", () => ({ api: { get: vi.fn(), post: vi.fn() } }));
vi.mock("sonner", () => ({ toast: { success: vi.fn(), error: vi.fn() } }));
import { api } from "./lib/api";
import { readTime } from "./utils/readTime";
import { pageList } from "./pages/blog/BlogIndex";
import TicketThread from "./components/help/TicketThread";
import AccountStatus from "./pages/auth/AccountStatus";

const src = (p) => fs.readFileSync(new URL(p, import.meta.url), "utf8");
afterEach(() => { cleanup(); vi.clearAllMocks(); vi.useRealTimers(); });

describe("v425 blog", () => {
  it("B3: read time is words / 200, at least 1 min", () => {
    expect(readTime("")).toBe("1 min read");
    expect(readTime("<p>" + "word ".repeat(401) + "</p>")).toBe("3 min read");
  });
  it("B6: page list keeps first/last and puts … in gaps", () => {
    expect(pageList(1, 3)).toEqual([1, 2, 3]);
    const l = pageList(10, 20);
    expect(l[0]).toBe(1); expect(l[l.length - 1]).toBe(20); expect(l).toContain("…"); expect(l).toContain(10);
  });
  it("B1/B4/B7/B8 are wired", () => {
    const d = src("./pages/blog/BlogPostDetail.jsx"), i = src("./pages/blog/BlogIndex.jsx");
    expect(d).toContain("In this article");
    expect(d).toContain("Get brand deals with safe escrow payments");
    expect(i).toContain('data-testid="blog-hero-dots"');
    expect(i).toContain('data-testid="blog-search-clear"');
    expect(i).toMatch(/document\.hidden/);
  });
});

describe("v425 leaderboard", () => {
  // v445 (requirement change, Ravi: unused-code report): the leaderboard page + API were removed; the URL goes Home.
  it("removed: /leaderboard redirects Home and the API is gone", () => {
    expect(src("./App.jsx")).toContain('<Route path="/leaderboard" element={<Navigate to="/" replace />} />');
    expect(src("../backend/misc_routes.ts")).not.toMatch(/router\.get\("\/leaderboard/);
  });
});

describe("v425 help tickets", () => {
  const msgs = [{ message_id: "m1", sender_type: "user", message: "hello", created_at: "2026-11-01T10:00:00Z" }];
  it("T3: once messages are shown, a failed refresh says Offline instead of a red error", async () => {
    vi.useFakeTimers({ shouldAdvanceTime: true });
    api.get.mockResolvedValueOnce({ data: msgs }).mockRejectedValue(new Error("net"));
    render(<TicketThread ticket={{ ticket_id: "t1", status: "OPEN" }} />);
    await screen.findByText("hello");
    await act(async () => { vi.advanceTimersByTime(30500); });
    await screen.findByTestId("ticket-offline");
    expect(screen.queryByRole("alert")).toBeNull();
  });
  it("T3: with no messages at all, the red error shows", async () => {
    api.get.mockRejectedValue(new Error("net"));
    render(<TicketThread ticket={{ ticket_id: "t1", status: "OPEN" }} />);
    expect(await screen.findByRole("alert")).toBeTruthy();
  });
  it("T4: a resolved ticket warns that replying reopens it", async () => {
    api.get.mockResolvedValue({ data: msgs });
    render(<TicketThread ticket={{ ticket_id: "t1", status: "RESOLVED" }} />);
    expect(await screen.findByTestId("ticket-reopen-note")).toBeTruthy();
  });
  it("T6: Shift+Enter does not send", async () => {
    api.get.mockResolvedValue({ data: msgs });
    render(<TicketThread ticket={{ ticket_id: "t1", status: "OPEN" }} />);
    const box = await screen.findByTestId("ticket-reply-input");
    fireEvent.change(box, { target: { value: "hi" } });
    fireEvent.keyDown(box, { key: "Enter", shiftKey: true });
    expect(api.post).not.toHaveBeenCalled();
    fireEvent.keyDown(box, { key: "Enter", ctrlKey: true });
    await waitFor(() => expect(api.post).toHaveBeenCalled());
  });
  it("T1/T5: ticket route + reload only on create + 44px chips", () => {
    expect(src("./App.jsx")).toContain('path="/help/tickets/:ticketId"');
    const h = src("./pages/help/HelpTickets.jsx");
    expect(h).toContain("navigate(`/help/tickets/${t.ticket_id}`)");
    expect(h).toMatch(/onCreated=\{\(\) => fetchTickets\(\)/);
    expect(h).toContain("min-h-[44px]");
  });
});

describe("v425 auth + account", () => {
  it("A1-A4 are wired", () => {
    const f = src("./pages/auth/ForgotPassword.jsx");
    expect(f).not.toMatch(/setTimeout\(\(\) => navigate/);
    expect(f).toContain("We sent a 6-digit code to");
    const r = src("./pages/auth/ResetPassword.jsx");
    expect(r).toContain("Resend code in");
    expect(r).toContain("8+ characters");
    expect(r).toContain("Both match");
    const v = src("./pages/auth/VerifyEmail.jsx");
    expect(v).toContain("Leave sign-up?");
    expect(v).toContain("You'll need to log in again to finish.");
  });
  it("A5: a deleted account shows no warning banner or reasons", () => {
    render(<MemoryRouter initialEntries={[{ pathname: "/account-status", state: { status: "ACCOUNT_DELETED" } }]}><AccountStatus /></MemoryRouter>);
    expect(screen.queryByText("Official Notice")).toBeNull();
    expect(screen.queryByText("Why this happened")).toBeNull();
    expect(screen.queryByText(/Common reasons/)).toBeNull();
    expect(screen.getByText(/no longer active/)).toBeTruthy();
  });
  it("A5: a suspended account still shows the notice", () => {
    render(<MemoryRouter initialEntries={[{ pathname: "/account-status", state: { status: "ACCOUNT_BANNED" } }]}><AccountStatus /></MemoryRouter>);
    expect(screen.getByText("Official Notice")).toBeTruthy();
  });
  it("D1-D3: failed check blocks delete, resend + back, flat violet", () => {
    const a = src("./components/account/AccountPanel.jsx");
    expect(a).toContain(".catch(() => setCheckFailed(true))");
    expect(a).toContain("disabled={busy || checkFailed");
    expect(a).toContain("Resend code in");
    expect(a).toContain('onClick={() => setStep("intro")}');
    expect(a).not.toContain("linear-gradient(135deg,#9B00FF");
  });
});
