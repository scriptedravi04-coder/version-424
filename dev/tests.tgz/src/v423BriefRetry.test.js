// v423 — P7 / P8 / P9: paid UGC brief retries
import { describe, it, expect, beforeEach } from "vitest";
import { savePendingBriefOrder, savePaidBriefOrder, paidBriefTerms, recoverPendingBriefOrder, isFinalBriefError, clearPaidBriefOrder, getPaidBriefOrder } from "./lib/briefPaymentRetry";

describe("v423 brief payment retry", () => {
  beforeEach(() => { localStorage.clear(); localStorage.setItem("ybex_user", JSON.stringify({ user_id: "b1" })); });
  it("P7: the paid budget / creators travel with the order", async () => {
    savePendingBriefOrder("order_1", 6000, { budget: 3000, max_creators: 2 });
    const id = await recoverPendingBriefOrder(async () => true);
    expect(id).toBe("order_1");
    expect(paidBriefTerms()).toEqual({ budget: 3000, max_creators: 2 });
    clearPaidBriefOrder();
    savePaidBriefOrder("order_2", 2000, { budget: 2000, max_creators: 1 });
    expect(paidBriefTerms()).toEqual({ budget: 2000, max_creators: 1 });
  });
  it("P7 (QA): a failed save that re-saves the order without terms keeps the paid terms", () => {
    savePaidBriefOrder("order_9", 10000, { budget: 5000, max_creators: 2 });
    savePaidBriefOrder("order_9", 10000);
    expect(paidBriefTerms()).toEqual({ budget: 5000, max_creators: 2 });
  });
  it("P8: nothing on this device → a paid order of the SAME amount from the server is used", async () => {
    const server = async () => [{ order_id: "order_x", amount: 5000 }, { order_id: "order_y", amount: 4000 }];
    expect(await recoverPendingBriefOrder(async () => true, Date.now(), server, 4000)).toBe("order_y");
    expect(getPaidBriefOrder()?.order_id).toBe("order_y");
    clearPaidBriefOrder();
    expect(await recoverPendingBriefOrder(async () => true, Date.now(), server, 9999)).toBeNull();
    expect(await recoverPendingBriefOrder(async () => true, Date.now(), server)).toBeNull();
  });
  it("P9: validation refusals are final, network / server errors are not", () => {
    expect(isFinalBriefError({ response: { status: 400, data: { code: "BUDGET_OUT_OF_RANGE" } } })).toBe(true);
    expect(isFinalBriefError({ response: { status: 400, data: {} } })).toBe(true);
    expect(isFinalBriefError({ response: { status: 503, data: {} } })).toBe(false);
    expect(isFinalBriefError({ message: "Network Error" })).toBe(false);
    expect(isFinalBriefError({ response: { status: 401 } })).toBe(false);
  });
});
