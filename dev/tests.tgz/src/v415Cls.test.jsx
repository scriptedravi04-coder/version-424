// v415: layout-shift (CLS) fixes in the brand panel — source checks.
import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";

const read = (p) => fs.readFileSync(path.resolve(__dirname, p), "utf8");

describe("v415 CLS: /brand/profile desktop skeleton", () => {
  const src = read("pages/brand/BrandProfile.jsx");
  const skeleton = src.slice(src.indexOf('data-testid="brand-profile-skeleton"'), src.indexOf('data-testid="brand-profile-page"'));
  it("skeleton starts with the same glow div as the page so boxes line up", () => {
    const glow = 'absolute top-0 left-1/2 -translate-x-1/2 w-[500px] h-[500px]';
    expect(skeleton).toContain(glow);
    expect(skeleton.indexOf(glow)).toBeLessThan(skeleton.indexOf("h-4 w-80"));
  });
  it("skeleton uses the real cover, logo and header sizes", () => {
    expect(skeleton).toContain("relative mb-14 sm:mb-16");
    expect(skeleton).toContain("h-48 md:h-64");
    expect(skeleton).toContain("w-24 h-24 md:w-32 md:h-32");
    expect(skeleton).toContain("flex flex-col md:flex-row justify-between items-start md:items-center gap-6 px-2 sm:px-4 md:px-6 mb-8 sm:mb-10");
    expect(skeleton).toMatch(/h-10 w-72[\s\S]*h-6 w-48 mt-1\.5/);
  });
});

describe("v415 CLS: /brand/ugc/orders desktop", () => {
  const src = read("pages/brand/BrandUGCOrders.jsx");
  it("header row is shared by the loading skeleton and the page", () => {
    expect(src).toMatch(/const headerRow = !embedded \?/);
    const sk = src.slice(src.indexOf("if (loading && orders.length === 0) {"), src.indexOf("if (orders.length === 0 && ordersFailed)"));
    expect(sk).toContain("{headerRow}");
    expect(sk).toContain("space-y-6");
    expect(sk).toContain("gap-6 items-start");
    expect(src).toMatch(/\{headerRow \/\* v415/);
  });
  it("no '0 active' flash while loading", () => {
    expect(src).toMatch(/className=\{firstLoad \? "invisible" : ""\}/);
  });
  it("first order is auto-picked before the briefs request (same render as the list)", () => {
    const fetchFn = src.slice(src.indexOf("const fetchOrders = async"), src.indexOf("const fetchOrders = async") + 2500);
    expect(fetchFn.indexOf("autoPickedRef.current = true")).toBeGreaterThan(0);
    expect(fetchFn.indexOf("autoPickedRef.current = true")).toBeLessThan(fetchFn.indexOf('api.get("ugc/briefs/my"')); // v416: the call now passes { bypassCache }
  });
});

describe("v415 CLS: /brands/:id mobile footer", () => {
  const src = read("pages/brand/BrandPublicView.jsx");
  it("mobile loading screen is a full screen tall", () => {
    expect(src).toMatch(/isMobile \? "min-h-screen min-h-\[100dvh\]" : "min-h-\[60vh\]"/);
  });
});

describe("v415 CLS: desktop Eva bubble", () => {
  const src = read("components/feedback/FeedbackBot.jsx");
  it("desktop bubble is sized by a hidden copy of the full line (no growing width)", () => {
    expect(src).toContain('data-testid="feedback-bubble-sized"');
    expect(src).toMatch(/visibility: "hidden"[^}]*\}\}>\{peek\.text\}/);
  });
  it("Eva entrance stays transform/opacity only", () => {
    const css = read("components/feedback/DesktopEva.jsx");
    expect(css).toMatch(/transition:transform [^;]*,opacity/);
  });
});
