import { describe, it, expect, vi, beforeEach } from "vitest";
import { playStoreUrl, isAndroidBrowser } from "./components/common/PlayStoreBanner";
import { saveInstallReferrer, getSignupSource } from "./lib/signupSource";

describe("v418 · Play Store button + install referrer", () => {
  beforeEach(() => { localStorage.clear(); document.cookie = "yb_src=; max-age=0; path=/"; });
  it("only Android browsers (not iPhone, not installed app)", () => {
    expect(isAndroidBrowser("Mozilla/5.0 (Linux; Android 14; Pixel 7)")).toBe(true);
    expect(isAndroidBrowser("Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)")).toBe(false);
    expect(isAndroidBrowser("Mozilla/5.0 (Linux; Android 14)", true)).toBe(false);
  });
  it("the Play link carries the ad tags as the install referrer", () => {
    const u = playStoreUrl({ utm_source: "meta", utm_medium: "paid", utm_campaign: "diwali" }, "offer");
    expect(u).toContain("id=com.ybex.app&referrer=");
    expect(decodeURIComponent(u.split("referrer=")[1])).toBe("utm_source=meta&utm_medium=paid&utm_campaign=diwali");
    const d = decodeURIComponent(playStoreUrl(null, "signup").split("referrer=")[1]);
    expect(d).toBe("utm_source=website&utm_medium=play_button&utm_campaign=web_signup");
  });
  it("the app's install referrer becomes the sign-up source", () => {
    expect(saveInstallReferrer("utm_source=meta&utm_campaign=diwali")).toBe(true);
    const s = getSignupSource();
    expect(s.utm_source).toBe("meta");
    expect(s.utm_campaign).toBe("diwali");
    expect(s.app).toBe(1);
  });
});
