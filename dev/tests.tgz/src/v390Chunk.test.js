import { describe, it, expect } from "vitest";
import fs from "node:fs";

// v390: logout showed "undefined is not an object (D._result.default)" — a stale chunk resolved to nothing.
const read = (p) => fs.readFileSync(new URL(p, import.meta.url), "utf8");

describe("v390 stale chunk after deploy", () => {
  it("preloadError is only swallowed when the page is reloading", () => {
    const s = read("./index.jsx");
    expect(s).toMatch(/if \(handleChunkError\("failed to fetch dynamically imported module"\)\) event\.preventDefault\(\)/);
  });
  it("lazy pages treat an empty chunk as a failed load", () => {
    expect(read("./App.jsx")).toMatch(/!m \|\| !m\.default/);
    expect(read("./pages/dashboard/Landing.jsx")).toMatch(/lazyView/);
  });
});

describe("v390 Google: one tap + choose another account", () => {
  it("has a 'Use a different Google account' link that skips the remembered e-mail", () => {
    const s = read("./pages/app/AppContinue.jsx");
    expect(s).toMatch(/chooseAccount: true/);
    expect(s).toMatch(/!opts\.chooseAccount/);
    expect(s).toMatch(/Use a different Google account/);
  });
});
