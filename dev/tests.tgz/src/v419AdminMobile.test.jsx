// v419: phone admin (Admin Mobile design) — routing + data rules + Eva QA fixes.
import { describe, it, expect } from "vitest";
import { readFileSync } from "fs";
import { screenFor } from "./components/admin/mobile/AdminMobile";
import { normKyc, normUser, isPayoutReady, payQueues, maskAcc, ageShort, isCampaignInReview, isTicketOpen } from "./components/admin/mobile/adminMobileData";
import { classify } from "./components/feedback/assistBrain";

const P = (s) => new URLSearchParams(s);
describe("v419 · phone admin routing", () => {
  it("root tabs and pushed screens", () => {
    expect(screenFor(P(""))).toEqual({ kind: "root", tab: "dashboard" });
    expect(screenFor(P("tab=users"))).toEqual({ kind: "root", tab: "users" });
    expect(screenFor(P("tab=users&open=u1"))).toEqual({ kind: "user", id: "u1" });
    expect(screenFor(P("tab=users&open=u1&full=1"))).toEqual({ kind: "section", tab: "users" });
    expect(screenFor(P("tab=verifications&kyc=k1"))).toEqual({ kind: "kyc", id: "k1" });
    expect(screenFor(P("tab=waitlist")).kind).toBe("waitlist");
    expect(screenFor(P("tab=campaigns")).kind).toBe("campaigns");
    expect(screenFor(P("tab=settings")).kind).toBe("settings");
    expect(screenFor(P("tab=settings&view=fees"))).toEqual({ kind: "section", tab: "settings" });
    expect(screenFor(P("tab=escrow&full=1"))).toEqual({ kind: "section", tab: "escrow" });
    expect(screenFor(P("tab=helpdesk"))).toEqual({ kind: "section", tab: "helpdesk" });
  });
});

describe("v419 · phone admin data", () => {
  it("KYC row: docs from real fields, bank number masked, aadhaar last 4", () => {
    const r = normKyc({ verification_id: "v1", user_id: "u1", kind: "creator", full_name: "Asha", instagram_handle: "https://instagram.com/asha.k/", follower_count: 1000, avg_reach: 200,
      pan_card_url: "kyc-documents/a.jpg", aadhaar_front_url: "", documents: { aadhaar_back_url: "kyc-documents/b.jpg", aadhaar_number: "1234 5678 9012" }, bank_account_number: "000123456789", status: "under_review" });
    expect(r.handle).toBe("asha.k");
    expect(r.docs.map((d) => d.label)).toEqual(["PAN card", "Aadhaar back"]);
    expect(r.bankAcc).toBe("XXXXXX6789");
    expect(r.aadhaar).toBe("XXXX XXXX 9012");
    expect(r.status).toBe("PENDING");
    const b = normKyc({ id: "b1", kind: "brand", company_name: "Kinara", gst_certificate_url: "x.pdf", website: "kinara.in" });
    expect(b.type).toBe("brand"); expect(b.docs[0].label).toBe("GST certificate"); expect(b.website).toBe("kinara.in");
  });
  it("users: brand name from the company, agency / unclaimed / admin kinds", () => {
    expect(normUser({ user_id: "1", role: "brand", name: "Ankit", brand_profile: { company_name: "Kinara" } }).name).toBe("Kinara");
    expect(normUser({ user_id: "2", role: "brand", is_agency: true }).kind).toBe("agency");
    expect(normUser({ user_id: "3", role: "creator", is_unclaimed: true }).kind).toBe("unclaimed");
    expect(normUser({ user_id: "4", role: "admin" }).kind).toBe("admin");
  });
  it("payout queue: requested + unpaid only; paid, refunded and brief deposits never show", () => {
    expect(isPayoutReady({ status: "SUCCESS", payout_requested: true })).toBe(true);
    expect(isPayoutReady({ status: "SUCCESS", payout_status: "PROCESSING" })).toBe(true);
    expect(isPayoutReady({ status: "SUCCESS", payout_requested: true, payout_status: "PAID", payout_reference: "UTR1" })).toBe(false);
    expect(isPayoutReady({ status: "REFUNDED", payout_requested: true })).toBe(false);
    expect(isPayoutReady({ status: "SUCCESS", payout_requested: true, is_brief_deposit: true })).toBe(false);
    expect(isPayoutReady({ status: "SUCCESS" })).toBe(false);
    const q = payQueues({ escrow: [{ id: "t1", status: "SUCCESS", payout_requested: true, creator_net_amount: 900, gross_amount: 1000, upi_id: "a@ok" }],
      refunds: [{ id: "r1", status: "PENDING", amount: 500, refund_account_snapshot: { account_number: "99887766", ifsc: "HDFC0001" } }, { id: "r2", status: "PROCESSED" }],
      referral: [{ id: "w1", status: "requested", amount: 250 }, { id: "w2", status: "paid" }] });
    expect(q.payouts[0]).toMatchObject({ amount: 900, method: "UPI", dest: "a@ok" });
    expect(q.refunds).toHaveLength(1); expect(q.refunds[0].dest).toContain("••••7766");
    expect(q.referral).toHaveLength(1);
  });
  it("helpers", () => {
    expect(maskAcc("12")).toBe("12");
    expect(ageShort(new Date(Date.now() - 3 * 86400e3).toISOString())).toBe("3d");
    expect(isCampaignInReview({ status: "under_review" })).toBe(true);
    expect(isCampaignInReview({ status: "live" })).toBe(false);
    expect(isTicketOpen({ status: "OPEN" })).toBe(true);
    expect(isTicketOpen({ status: "OPEN", page_context: "/feedback-bot" })).toBe(false);
  });
  it("KYC badge counts the same tables the KYC list reads", () => {
    const src = readFileSync("backend/admin_system_maintenance_routes.ts", "utf8");
    expect(src).toContain("['creator_kyc', 'brand_kyc'].map");
  });
  it("Layout hands /admin on phones to the phone admin (no greeting bar, no second nav)", () => {
    const l = readFileSync("src/components/layout/Layout.jsx", "utf8");
    expect(l).toContain("the phone admin (AdminMobile) draws its own search + notifications header");
    expect(l).toContain("location.pathname.startsWith('/admin')) return null;");
  });
});

describe("v419 · Eva QA fixes", () => {
  it("a question mark alone is not a report", () => {
    expect(classify("whats my earnigns this mnth??").type).not.toBe("feedback");
    expect(classify("payment page not working, error aa raha hai").type).toBe("feedback");
  });
  it("one failed save no longer switches off Eva's history", () => {
    const m = readFileSync("src/components/assist/brand/memory.js", "utf8");
    expect(m).not.toMatch(/status >= 500 \|\|/);
  });
  it("open chat survives a remount; fallback answers are saved", () => {
    const f = readFileSync("src/components/feedback/FeedbackBot.jsx", "utf8");
    expect(f).toContain("yb_eva_sess_");
    expect(f).toContain("brandMod.saveTurn(chatIdRef.current, t, p.reply)");
  });
});

import { getInboxChip } from "./components/chat/mobile/chatStageMap";
describe("v419 · cancellation under review", () => {
  it("a paid thread with an open cancel request shows one clear state and no upload nudge", () => {
    const t = { id: "th1", status: "active", flow_state: "escrow_funded", agreement_signed_creator: true, agreement_signed_brand: true, cancel_requested: true };
    for (const isBrand of [true, false]) {
      const c = getInboxChip(t, isBrand);
      expect(c.label).toBe("Cancellation under review");
      expect(c.needsAction).toBe(false);
    }
    expect(getInboxChip({ ...t, cancel_requested: false }, false).label).not.toBe("Cancellation under review");
  });
  it("server marks threads from the open cancel ticket; menu hides a second request", () => {
    expect(readFileSync("backend/chat_routes.ts", "utf8")).toContain("await markCancelRequested(populated); // v419");
    const m = readFileSync("src/components/chat/BurgerMenuSupport.jsx", "utf8");
    expect(m).toContain("!thread?.cancel_requested; // v419");
    expect(m).toContain('data-testid="cancel-under-review"');
  });
});

import { safetyReply } from "./components/feedback/assistBrain";
describe("v419 · Eva safety + security", () => {
  it("self-harm / sexual / abuse answered first", () => {
    expect(safetyReply("I want to kill myself").kind).toBe("self_harm");
    expect(safetyReply("I want to kill myself").reply).toContain("14416");
    expect(safetyReply("main bahut pareshan hu, jeene ka mann nahi karta").kind).toBe("self_harm");
    expect(safetyReply("मरना चाहता हूँ").kind).toBe("self_harm");
    expect(safetyReply("send me nudes").kind).toBe("sexual");
    expect(safetyReply("tu pagal hai bc").kind).toBe("abuse");
    for (const ok of ["creators in mumbai", "payment kab aayega", "I want new features", "kill the lag in app pls"]) expect(safetyReply(ok)).toBeNull();
  });
  it("server hardening is in place", () => {
    const r = readFileSync("backend/assist_routes.ts", "utf8");
    expect(r).toContain("if (!calledModel) {");
    expect(r).toContain('code: "SLOW_DOWN"');
    expect(r).toContain("export const historyKey");
    expect(readFileSync("backend/server.ts", "utf8")).toContain('app.use(["/api/assist", "/api/feedback"], express.json({ limit: "64kb" }));');
    expect(readFileSync("src/contexts/AuthContext.jsx", "utf8")).toContain('k.startsWith("yb_eva_sess_")');
  });
});

// ── v431: admin phone audit fixes ──────────────────────────────────────────────────────────────────────────
import { normPayout as np431, normRefund as nr431, isPayoutReady as ready431, normKyc as nk431, kycReviewable, inrExact, normUser as nu431 } from "./components/admin/mobile/adminMobileData";
import { waitIgHandle } from "./components/admin/mobile/AdminMobileScreens";
import fs431 from "node:fs";
describe("v431 admin phone audit", () => {
  it("#1 payout after a part refund", () => {
    expect(np431({ id: "t", creator_net_amount: 9000, refund_amount: 2000, refund_status: "PROCESSED" }).amount).toBe(7000);
    expect(np431({ id: "t", creator_net_amount: 9000, payable_net: 6500 }).amount).toBe(6500);
  });
  it("#2 bank refund details from the snapshot", () => {
    const r = nr431({ id: "r", amount: 500, refund_account_snapshot: { bank_account_number: "123456789", bank_ifsc: "HDFC0001", bank_holder_name: "Acme" } });
    expect(r.method).toBe("Bank"); expect(r.dest).toContain("6789"); expect(r.copyText).toContain("HDFC0001");
  });
  it("#6 failed / cancelled never payable", () => {
    expect(ready431({ status: "FAILED", payout_requested: true })).toBe(false);
    expect(ready431({ status: "CANCELLED", payout_requested: true })).toBe(false);
  });
  it("#8 / #9 KYC statuses and empty KYC", () => {
    expect(nk431({ id: "k", status: "VERIFIED" }).status).toBe("APPROVED");
    expect(nk431({ id: "k", status: "SUBMITTED" }).status).toBe("PENDING");
    expect(kycReviewable(nk431({ id: "k", status: "UNDER_REVIEW" }))).toBe(false);
    expect(kycReviewable(nk431({ id: "k", status: "UNDER_REVIEW", pan_card_url: "x.jpg" }))).toBe(true);
    expect(nk431({ id: "k", bio: "QA creator profile" }).bio).toBe("");
  });
  it("#16 suspended_until shows suspended; #56 paise kept", () => {
    expect(nu431({ user_id: "u", suspended_until: new Date(Date.now() + 86400000).toISOString() }).suspended).toBe(true);
    expect(inrExact(8999.5)).toBe("₹8,999.50");
  });
  it("#27 real Instagram handle only", () => {
    expect(waitIgHandle({ instagram_link: "https://youtube.com/@abc", handle: "Made Up" })).toBe("");
    expect(waitIgHandle({ instagram_link: "https://instagram.com/real.one/" })).toBe("real.one");
  });
  it("money / access wiring", () => {
    const sc = fs431.readFileSync("src/components/admin/mobile/AdminMobileScreens.jsx", "utf8");
    expect(sc).toContain("admin/escrow/payout-check");
    expect(sc).toContain("Mark this refund as failed?");
    expect(fs431.readFileSync("backend/admin_users_enforcement_routes.ts", "utf8")).toContain('"/admin/escrow/payout-check"');
    expect(fs431.readFileSync("src/components/admin/mobile/AdminMobile.jsx", "utf8")).toContain("/^[A-Za-z0-9-]{6,40}$/");
    expect(fs431.readFileSync("backend/media_routes.ts", "utf8")).toContain("You need the KYC permission");
  });
});

describe("v431 admin audit round 2", () => {
  it("#30 menu aliases match the server, #60/#62 sheet errors, #61 stale decisions, #64 tables", () => {
    const perms = fs431.readFileSync("src/lib/adminPermissions.js", "utf8");
    expect(perms).not.toContain("manage_waitlist: ['manage_waitlist', 'manage_users']");
    const shell = fs431.readFileSync("src/components/admin/mobile/AdminMobile.jsx", "utf8");
    expect(shell).toContain("Not sure it went through");
    expect(shell).toContain("st === 409");
    expect(fs431.readFileSync("backend/admin_kyc_verification_routes.ts", "utf8").match(/ALREADY_DECIDED/g).length).toBe(2);
    expect(fs431.readFileSync("backend/admin_waitlist_routes.ts", "utf8").match(/ALREADY_DECIDED/g).length).toBe(2);
    expect(fs431.readFileSync("backend/admin_campaigns_settings_routes.ts", "utf8")).toContain("ALREADY_DECIDED");
    const sc = fs431.readFileSync("src/components/admin/mobile/AdminMobileScreens.jsx", "utf8");
    expect(sc).toContain('expect_status: "PENDING"');
    expect(sc).toContain("position:sticky;right:0");
  });
});

describe("v431 native app never shows the website landing", () => {
  it("/ → /app inside the installed app, query kept", () => {
    const app = fs431.readFileSync("src/App.jsx", "utf8");
    expect(app).toContain('if (isStandalone()) return <Navigate to={"/app" + (location.search || "")} replace />;');
  });
});

// v434: the Users panel shows "PENDING ADMIN APPROVAL" only when an ID number or a proof file was sent
import { kycHasRealData as v434Has } from "./components/admin/UserEnforcementPanel";
describe("v434 KYC pending needs real data", () => {
  it("name + DOB + phone is not pending; a PAN or a file is", () => {
    expect(v434Has({ status: "PENDING", full_name: "Bibhu Das", documents: { legal_name: "Bibhu Das", dob: "2006-05-08", phone: "+918000000000", company_name: "X" } })).toBe(false);
    expect(v434Has({ pan_number: "ABCDE1234F" })).toBe(true);
    expect(v434Has({ documents: { pan_photo_url: "kyc/p.jpg" } })).toBe(true);
    expect(v434Has(null)).toBe(false);
  });
});

// v436: Admin › Developer › "How it works" videos
import { ADMIN_NAV as v436Nav } from "./lib/adminSearch";
import { HiwVideosManager as V436Hiw, isYoutubeLink as v436Yt } from "./components/admin/WhatsNewManager";
import { hiwVideosForRole as v436ForRole } from "./components/whatsNew/WhatsNewPopup";
import { vi as v436vi, afterEach as v436After } from "vitest";
import { render, screen, fireEvent, cleanup as v436Clean } from "@testing-library/react";
import * as apiMod from "./lib/api";
describe("v436 How it works videos", () => {
  v436After(() => { v436Clean(); v436vi.restoreAllMocks(); });
  it("is the 2nd pill in Developer, full admins only", () => {
    const dev = v436Nav.find((g) => g.hub === "developer");
    expect(dev.items[1].id).toBe("hiw-videos");
    expect(dev.items[1].label).toBe("How it works");
    expect(dev.items[1].full).toBe(true);
  });
  it("YouTube link check and the role list for the app", () => {
    expect(v436Yt("https://youtu.be/abc123")).toBe(true);
    expect(v436Yt("https://vimeo.com/123")).toBe(false);
    const data = { videos: { B1: { url: "u1" }, B3: { url: "u3" }, C1: { url: "c1" } } };
    expect(v436ForRole(data, "brand").length).toBe(2);
    expect(v436ForRole({ videos: {} }, "creator").length).toBe(0);
  });
  it("shows 10 rows with their status and the playlist box", async () => {
    v436vi.spyOn(apiMod.api, "get").mockResolvedValue({ data: { videos: { B1: { source: "youtube", youtube_url: "https://youtu.be/abc123" }, C2: { source: "file", file_url: "https://x/banners/hiw/C2.mp4" } }, playlist_url: null } });
    render(<V436Hiw />);
    await screen.findByTestId("hiw-videos");
    expect(screen.getAllByTestId(/^hiw-row-/).length).toBe(10);
    const st = screen.getAllByTestId("hiw-status").map((x) => x.textContent);
    expect(st[0]).toBe("YouTube");
    expect(st[6]).toBe("Uploaded file");
    expect(st[1]).toMatch(/Not set/);
    expect(screen.getByTestId("hiw-playlist")).toBeTruthy();
    fireEvent.click(screen.getByTestId("hiw-row-B2").querySelector("button"));
    expect(screen.getByTestId("hiw-willuse-B2").textContent).toMatch(/Not set/);
  });
});

// v437: App tour + section "How it works" popup / reminder
import { shouldShowHiwTooltip as v437Tip, tourWanted as v437Tour, TOUR_STEPS as v437Steps, hiwCodeFor as v437Code, HIW_COPY as v437Copy } from "./components/whatsNew/WhatsNewPopup";
describe("v437 tour + reminder", () => {
  const now = Date.parse("2026-11-20T12:00:00+05:30");
  const ok = { popupDismissed: true, visitCount: 3, popupSeenAt: "2026-11-15T10:00:00+05:30", tooltipCount: 0 };
  it("reminder only when every rule holds", () => {
    expect(v437Tip({ section: "chat", p: ok, videoSet: true, now })).toBe(true);
    expect(v437Tip({ section: "eva", p: ok, videoSet: true, now })).toBe(false);
    expect(v437Tip({ section: "chat", p: ok, videoSet: false, now })).toBe(false);
    expect(v437Tip({ section: "chat", p: { ...ok, videoWatched: true }, videoSet: true, now })).toBe(false);
    expect(v437Tip({ section: "chat", p: { ...ok, dontShowAgain: true }, videoSet: true, now })).toBe(false);
    expect(v437Tip({ section: "chat", p: { ...ok, visitCount: 2 }, videoSet: true, now })).toBe(false);
    expect(v437Tip({ section: "chat", p: { ...ok, popupSeenAt: "2026-11-20T09:00:00+05:30" }, videoSet: true, now })).toBe(false);
    expect(v437Tip({ section: "chat", p: { ...ok, tooltipCount: 2 }, videoSet: true, now })).toBe(false);
    expect(v437Tip({ section: "chat", p: { ...ok, tooltipCount: 1, lastTooltipAt: "2026-11-18T12:00:00+05:30" }, videoSet: true, now })).toBe(false);
    expect(v437Tip({ section: "chat", p: ok, user: { lastAnyTooltipAt: "2026-11-20T08:00:00+05:30" }, videoSet: true, now })).toBe(false);
    expect(v437Tip({ section: "chat", p: ok, session: { overlayShown: true }, videoSet: true, now })).toBe(false);
    expect(v437Tip({ section: "chat", p: ok, videoSet: true, busy: true, now })).toBe(false);
  });
  it("tour: new accounts only, once, real targets", () => {
    localStorage.removeItem("yb_tour_done_u1");
    expect(v437Tour({ user_id: "u1", role: "brand", created_at: "2026-11-14T10:00:00Z" }, now)).toBe(true);
    expect(v437Tour({ user_id: "u1", role: "brand", created_at: "2026-10-01T10:00:00Z" }, now)).toBe(false);
    localStorage.setItem("yb_tour_done_u1", "1");
    expect(v437Tour({ user_id: "u1", role: "brand", created_at: "2026-11-14T10:00:00Z" }, now)).toBe(false);
    expect(v437Steps.brand.map((s) => s.target)).toEqual(["bottom-nav-tab-discover", "bottom-nav-tab-manage", "brand-hub-menu-modal", "bottom-nav-tab-inbox", "quickbar-how-it-works"]);
    expect(v437Steps.creator.map((s) => s.target)).toEqual(["bottom-nav-tab-campaigns", "bottom-nav-tab-explore_ugc", "bottom-nav-tab-inbox", "quickbar-earnings", "quickbar-how-it-works"]);
  });
  it("8 tooltips map to the right videos; headers carry the button", () => {
    expect(v437Code("chat", "brand")).toBe("B1");
    expect(v437Code("payments", "creator")).toBe("C4");
    expect(Object.keys(v437Copy).sort()).toEqual(["B1", "B2", "B3", "B4", "C1", "C2", "C3", "C4"]);
    for (const f of ["src/components/inbox/mobile/InboxMobile.jsx", "src/components/payments/BrandPaymentsMobile.jsx", "src/components/payments/CreatorEarningsMobile.jsx", "src/components/campaigns/mobile/BrandCampaignsMobile.jsx", "src/components/campaigns/mobile/CampaignsListMobile.jsx", "src/pages/brand/brandUgc/UgcHomeHeader.jsx", "src/pages/creator/creatorUgc/UgcTopHeader.jsx"]) expect(fs431.readFileSync(f, "utf8"), f).toMatch(/<HiwSectionHelp section="/);
    expect(fs431.readFileSync("src/components/layout/BottomNav.jsx", "utf8")).toMatch(/ybex:tour-menu/);
    expect(fs431.readFileSync("src/pages/creator/CreatorHomeMobile.jsx", "utf8")).toMatch(/id="quickbar-earnings"/);
  });
});

// ── v439: How it works — Home tile + stories, section popups (design handoffs) ──
import { youtubeEmbed as v439Yt, hiwAllWatched as v439All, HIW_CTA as v439Cta, HIW_LINE1 as v439Line, HiwStories as V439Stories } from "./components/whatsNew/WhatsNewPopup";
import { HIW_ILL as v439Ill, HIW_ILL_CSS as v439Css } from "./components/whatsNew/hiwIllustrations";
import { MemoryRouter as V439Router } from "react-router-dom";
describe("v439 How it works tile, stories and popups", () => {
  v436After(() => v436Clean());
  it("YouTube links become inline embeds; ring greys only when every video is watched", () => {
    expect(v439Yt("https://youtu.be/abcdefghijk")).toMatch(/embed\/abcdefghijk\?autoplay=1/);
    expect(v439Yt("https://www.youtube.com/shorts/abcdefghijk")).toMatch(/embed\/abcdefghijk/);
    expect(v439Yt("https://example.com/x.mp4")).toBe("");
    const list = [{ code: "C1" }, { code: "C2" }];
    expect(v439All(list, { storySeen: ["C1"] })).toBe(false);
    expect(v439All(list, { storySeen: ["C1"], sections: { ugc: { videoWatched: true } } })).toBe(true);
    expect(v439All([], {})).toBe(false);
  });
  it("every code has a CTA, a headline and an illustration; keyframes are prefixed", () => {
    for (const c of ["B1", "B2", "B3", "B4", "B5", "C1", "C2", "C3", "C4", "C5"]) { expect(v439Cta[c], c).toBeTruthy(); expect(v439Line[c], c).toBeTruthy(); }
    for (const c of ["B1", "B2", "B3", "B4", "C1", "C2", "C3", "C4", "EVA"]) expect(v439Ill[c], c).toBeTruthy();
    expect(v439Css).toMatch(/@keyframes yh_q1\{/);
    expect(Object.values(v439Ill).join("")).not.toMatch(/\{\{|<script|on\w+=/i);
  });
  it("stories: next / previous, CTA deep link, closes after the last one", () => {
    const onClose = v436vi.fn();
    const list = [{ code: "C1", title: "Chat and deal", url: "https://x/1.mp4", source: "upload" }, { code: "C2", title: "UGC", url: "https://youtu.be/abcdefghijk", source: "youtube" }];
    render(<V439Router><V439Stories list={list} playlist="https://youtube.com/playlist?list=1" uid="u1" onClose={onClose} /></V439Router>);
    expect(screen.getByText("Chat and deal")).toBeTruthy();
    expect(screen.queryByTestId("hiw-stories-playlist")).toBeNull();
    fireEvent.click(screen.getByTestId("hiw-stories-next"));
    expect(screen.getByText("UGC")).toBeTruthy();
    expect(screen.getByTestId("hiw-stories-playlist")).toBeTruthy(); // last story → "Watch all on YouTube"
    expect(JSON.parse(localStorage.getItem("yb_hiw_u1")).storySeen).toEqual(["C1", "C2"]);
    fireEvent.click(screen.getByTestId("hiw-stories-next"));
    expect(onClose).toHaveBeenCalled();
  });
  it("homes: the tile replaces Media kit / Refer & Earn and falls back when no video is set; Eva has its popup", () => {
    expect(fs431.readFileSync("src/pages/creator/CreatorHomeMobile.jsx", "utf8")).toMatch(/<HiwTile role="creator" fallback=\{\(/);
    expect(fs431.readFileSync("src/pages/brand/BrandHomeMobile.jsx", "utf8")).toMatch(/<HiwTile role="brand" fallback=\{\(/);
    expect(fs431.readFileSync("src/components/feedback/FeedbackBot.jsx", "utf8")).toMatch(/<EvaHiwPopup open=\{chat\} role=\{role\} \/>/);
    expect(fs431.existsSync("public/assets/hiw-tile-loop.webp")).toBe(true);
  });
});
describe("v441 Guide label + tip after the popup", () => {
  it("every header button says Guide; closing the popup points at it once", () => {
    const w = fs431.readFileSync("src/components/whatsNew/WhatsNewPopup.jsx", "utf8");
    expect(w).toMatch(/label = "Guide"/);
    expect(w).toMatch(/pointerTipShown: true/);
  });
});
