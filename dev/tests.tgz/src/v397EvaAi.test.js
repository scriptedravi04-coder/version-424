// v397 (Ravi: "Eva bina AI ke kisi kaam ki nahi" — AI Studio connected Google's Gemini): when no rule matches, Eva
// answers with the real AI ("chat" task) instead of "didn't get that"; never two waits when the first AI call failed.
import { describe, it, expect, vi, beforeEach } from "vitest";
import fs from "fs";

const calls = [];
let answers = {};
vi.mock("./components/assist/creator/tools", async (orig) => ({ ...(await orig()), askAi: vi.fn(async (task) => { calls.push(task); return answers[task] ?? null; }) }));
vi.mock("./components/assist/brand/tools", async (orig) => ({ ...(await orig()), askAi: vi.fn(async (task) => { calls.push(task); return answers[task] ?? null; }) }));

import { handleCreatorMessage } from "./components/assist/creator/brain";
import { handleBrandMessage } from "./components/assist/brand/brain";
import { TASKS } from "../backend/assist_routes";

beforeEach(() => { calls.length = 0; answers = {}; });

describe("v397 Eva real-AI answers", () => {
  it("creator: an unmatched question gets the AI's chat reply", async () => {
    answers = { creator_understand: { intent: "other" }, chat: { reply: "Reels ke pehle 2 second mein hook do — face + bold text." } };
    const r = await handleCreatorMessage("meri reels pe views kyu kam aa rahe hain yaar");
    expect(calls).toEqual(["creator_understand", "chat"]);
    expect(r.reply).toContain("hook");
  });
  it("creator: the first AI call failed → no second wait", async () => {
    answers = {};
    const r = await handleCreatorMessage("meri reels pe views kyu kam aa rahe hain yaar");
    expect(calls).toEqual(["creator_understand"]);
    expect(r).toBeNull();
  });
  it("brand: an unmatched question gets a reply; failed first call → no second call", async () => {
    answers = { understand: { intent: "other" }, chat: { reply: "Micro creators usually give better engagement for local brands." } };
    const r = await handleBrandMessage("local bakery ke liye kaunse creators ache rahenge socho");
    expect(r?.reply).toBeTruthy();
    calls.length = 0; answers = {};
    const r2 = await handleBrandMessage("monsoon season mein kis type ka content zyada chalta hai batao");
    expect(calls).toContain("understand");
    expect(calls.filter((c) => c === "chat")).toHaveLength(0);
    expect(r2?.reply || "").not.toContain("Micro creators");
  });
  it("server: 'chat' task, Gemini 3.8 Flash first with a different fallback, no temperature", () => {
    expect(TASKS).toContain("chat");
    const src = fs.readFileSync("backend/assist_routes.ts", "utf8");
    expect(src).toContain('Return JSON only: {"reply": string}');
    expect(src).toContain('"gemini-3.8-flash", "gemini-3.8-flash", "gemini-3.1-flash-lite"');
    expect(src).not.toMatch(/temperature: *[\d(]/);
    expect(src).toContain("process.env.GEMINI_API_KEY || process.env.API_KEY || process.env.GOOGLE_API_KEY");
  });
  it("AI Studio preview uses port 3000; the built server keeps the platform's PORT", async () => {
    const { devPortFor } = await import("../backend/devPort");
    expect(devPortFor("/app/server.ts", { PORT: "8080" })).toBe("3000");
    expect(devPortFor("/app/dist/server.cjs", { PORT: "8080" })).toBe("8080");
    expect(devPortFor("/app/dist/server.cjs", {})).toBeUndefined();
    const s = fs.readFileSync("server.ts", "utf8");
    expect(s.indexOf('import "./backend/devPort"')).toBeLessThan(s.indexOf('import "./backend/server.ts"'));
  });
});

describe("v397 blog covers are 1200 x 630 everywhere", () => {
  it("40:21 frames, title below the hero image, Ybex default cover, admin hint + preview", () => {
    const idx = fs.readFileSync("src/pages/blog/BlogIndex.jsx", "utf8");
    const det = fs.readFileSync("src/pages/blog/BlogPostDetail.jsx", "utf8");
    const ed = fs.readFileSync("src/components/admin/blog/BlogEditor.jsx", "utf8");
    for (const s of [idx, det]) { expect(s).not.toContain("aspect-[16/10]"); expect(s).toContain("aspect-[40/21]"); expect(s).not.toContain("unsplash"); }
    expect(idx).toContain('const DEFAULT_BLOG_COVER = "/og-image.jpg"');
    expect(idx).not.toContain("bg-gradient-to-t from-[#0F172A]/90");
    expect(idx).toContain("w-28 aspect-[40/21]");
    expect(ed).toContain("1200 x 630 px");
    expect(ed).toContain('aspect-[40/21] bg-[#F2F2F7]" data-testid="blog-cover-preview"');
  });
});

describe("v397 Meet the Creators keeps the iPhone size on every phone", () => {
  it("the card columns are capped at 390 px and centred", async () => {
    const m = await import("./components/dashboard/MeetCreatorsGrid");
    expect(m.GRID_MAX_W).toBe(390);
    const src = fs.readFileSync("src/components/dashboard/MeetCreatorsGrid.jsx", "utf8");
    expect(src).toContain('maxWidth: GRID_MAX_W, margin: "0 auto"');
  });
});
