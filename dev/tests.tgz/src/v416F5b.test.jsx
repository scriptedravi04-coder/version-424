import { describe, it, expect, vi } from "vitest";
import fs from "fs";
import React from "react";
import { render, screen, cleanup } from "@testing-library/react";

const read = (p) => fs.readFileSync(p, "utf8");

describe("v416 F5b · api.js helpers", () => {
  it("isBrandLike: brand, agency and talent manager are brands (CR4)", async () => {
    const { isBrandLike } = await import("./lib/api");
    expect(isBrandLike("brand")).toBe(true);
    expect(isBrandLike("agency")).toBe(true);
    expect(isBrandLike("talent_manager")).toBe(true);
    expect(isBrandLike({ role: "agency" })).toBe(true);
    expect(isBrandLike("creator")).toBe(false);
    expect(isBrandLike(undefined)).toBe(false);
  });

  it("5xx raw text becomes the friendly line; hand-written 5xx and 4xx detail stay", async () => {
    const { friendlyServerErrorBody, SERVER_SIDE_ERROR, isRawServerMessage } = await import("./lib/api");
    const raw = { status: 500, data: { error: "x" } };
    friendlyServerErrorBody(raw);
    expect(raw.data.error).toBe(SERVER_SIDE_ERROR);
    const db = { status: 500, data: { detail: 'duplicate key value violates unique constraint "x_pkey"' } };
    friendlyServerErrorBody(db);
    expect(db.data.detail).toBe(SERVER_SIDE_ERROR);
    const human = { status: 502, data: { error: "Your payment is safe, but the brief couldn't be saved. Press Post again — you won't be charged again." } };
    friendlyServerErrorBody(human);
    expect(human.data.error).toMatch(/Your payment is safe/);
    const bad = { status: 400, data: { detail: "x" } };
    friendlyServerErrorBody(bad);
    expect(bad.data.detail).toBe("x");
    const empty = { status: 503, data: "" };
    friendlyServerErrorBody(empty);
    expect(empty.data.detail).toBe(SERVER_SIDE_ERROR);
    expect(isRawServerMessage("Internal server error")).toBe(true);
    expect(isRawServerMessage("Couldn't save. Please try again.")).toBe(false);
  });

  it("SERVER_SIDE_ERROR wording", async () => {
    const { SERVER_SIDE_ERROR } = await import("./lib/api");
    expect(SERVER_SIDE_ERROR).toBe("Something went wrong on our side. Please try again.");
  });
});

describe("v416 F5b · live refresh reads fresh data (CR11)", () => {
  it("drops the 10 s GET cache before a live reload and passes fresh", () => {
    const src = read("src/lib/liveRefresh.js");
    expect(src).toMatch(/clearApiCache\(\)/);
    expect(src).toMatch(/silent: true, fresh: true/);
  });
});

describe("v416 F5b · Layout", () => {
  it("per-route tab titles (M12)", async () => {
    const { pageTitleFor } = await import("./components/layout/Layout");
    expect(pageTitleFor("/brand/campaigns")).toBe("Campaigns");
    expect(pageTitleFor("/brand/campaigns/abc/applicants")).toBe("Applicants");
    expect(pageTitleFor("/brand/inbox/123")).toBe("Inbox");
    expect(pageTitleFor("/dashboard")).toBe("Home");
    expect(pageTitleFor("/help/tickets")).toBe("Help Center");
    expect(pageTitleFor("/blog/some-post")).toBe(null);
  });
  it("desktop Log Out asks first (M1) and brand dead ends get a back bar (M13)", () => {
    const src = read("src/components/layout/Layout.jsx");
    expect(src).toMatch(/Log out of Ybex\?/);
    expect(src).not.toMatch(/onClick=\{onLogout\}/);
    expect(src).toMatch(/MOBILE_DEAD_ENDS = \["\/help", "\/refer", "\/brand\/settings", "\/brand\/account"\]/);
    expect(src).toMatch(/aria-label="Go back"/);
  });
  it("BrandRoute uses the shared helper (CR4)", () => {
    expect(read("src/App.jsx")).toMatch(/if \(!isBrandLike\(user\.role\)\)/);
  });
});

describe("v416 F5b · brand settings (CR1, CR10, CR16, H4)", () => {
  const src = read("src/pages/brand/BrandSettings.jsx");
  it("refuses to save when the profile didn't load and loads agency_type", () => {
    expect(src).toMatch(/if \(profileLoadFailed \|\| profileLoading\)/);
    expect(src).toMatch(/agency_type: data\.agency_type/);
  });
  it("no browser upsert; uploads go through prepareUpload", () => {
    expect(src).not.toMatch(/ownDb\.from\('brand_profiles'\)\.upsert/);
    expect(src).toMatch(/await prepareUpload\(picked\)/);
    const hook = read("src/components/profile/mobile/brand/useBrandProfileData.js");
    expect(hook).not.toMatch(/brand_profiles"\)\.upsert/);
    expect(hook).toMatch(/await prepareUpload\(picked\)/);
  });
  it("side-by-side only from lg; card can shrink", () => {
    expect(src).toMatch(/flex flex-col lg:flex-row/);
    expect(src).toMatch(/flex-1 min-w-0 bg-white/);
  });
});

describe("v416 F5b · dashboard", () => {
  const src = read("src/components/dashboard/BrandDashboard.jsx");
  it("loads in parallel and shows an error state instead of fake zeros (M5, M6)", () => {
    expect(src).toMatch(/brand-dashboard-error/);
    expect(src).toMatch(/Couldn't load your dashboard/);
    expect(src).toMatch(/campaignsCount: null/);
    expect(src).not.toMatch(/KYC Unverified/);
  });
  it("tour: skips established accounts and waits for the notifications drawer (M2)", async () => {
    const { isEstablishedAccount, blockingModalOpen } = await import("./components/dashboard/TourRunner");
    const now = Date.parse("2026-11-07T00:00:00Z");
    expect(isEstablishedAccount({ created_at: "2026-10-01T00:00:00Z" }, now)).toBe(true);
    expect(isEstablishedAccount({ created_at: "2026-11-06T00:00:00Z" }, now)).toBe(false);
    document.body.innerHTML = '<button aria-label="Close notifications"></button>';
    expect(blockingModalOpen(document)).toBe(true);
    document.body.innerHTML = "";
    expect(blockingModalOpen(document)).toBe(false);
    const tr = read("src/components/dashboard/TourRunner.jsx");
    expect(tr).not.toMatch(/team access, billing preferences/);
    expect(tr).not.toMatch(/seamlessly/);
  });
  it("quick actions copy (no 'Gate', no 'secured secure payment hold')", () => {
    const qa = read("src/components/dashboard/QuickActions.jsx");
    expect(qa).not.toMatch(/Quick Actions Gate/);
    expect(qa).not.toMatch(/secured secure payment hold/);
  });
  it("Important for you: the CTA is never clipped (H5)", async () => {
    vi.useFakeTimers();
    const { default: ImportantForYou } = await import("./components/dashboard/ImportantForYou");
    const tasks = [{ id: "k", kicker: "KYC", brand: "You", title: "Verify your brand", m1l: "Status", m1v: "Pending", m2l: "Unlocks", m2v: "Not verified yet — payments locked", cta: "Verify now", initial: "K", theme: {} }];
    render(<ImportantForYou tasks={tasks} onAction={() => {}} />);
    expect(screen.getByText("Verify now")).toBeTruthy();
    const box = screen.getByTestId("important-for-you").querySelector(".min-h-\\[220px\\]");
    expect(box).toBeTruthy();
    cleanup();
    vi.useRealTimers();
  });
});

describe("v416 F5b · brand home mobile (CR20, CR21, CR22, M5)", () => {
  const src = read("src/pages/brand/BrandHomeMobile.jsx");
  it("days left in IST via campaignDaysLeft; spent unknown on failure; ticket mark per user after success", () => {
    expect(src).toMatch(/const d = campaignDaysLeft\(c\.deadline\)/);
    expect(src).toMatch(/let totalSpentAmount = null/);
    expect(src).toMatch(/ybex_cm_ticket_\$\{user\?\.user_id/);
    expect(src).toMatch(/\.then\(\(\) => \{ try \{ sessionStorage\.setItem\(ticketKey, "1"\)/);
    expect(src).toMatch(/if \(feedFailed\) return "Couldn't refresh"/);
    expect(src).not.toMatch(/"KYC PENDING"/);
  });
});

describe("v416 F5b · onboarding + terms", () => {
  it("brand terms box says 18+ and authorised (M14)", async () => {
    const { default: TermsAgreeBox } = await import("./components/legal/TermsAgreeBox");
    render(<TermsAgreeBox role="brand" checked={false} onChange={() => {}} />);
    expect(screen.getByTestId("onboarding-terms-box").textContent).toMatch(/18 or older, authorised to act for this business/);
    cleanup();
    render(<TermsAgreeBox role="creator" checked={false} onChange={() => {}} />);
    expect(screen.getByTestId("onboarding-terms-box").textContent).toMatch(/14 or older/);
    cleanup();
  });
  it("mobile success card: real campaign types, no fake Connect, KYC copy matches (M15)", () => {
    const src = read("src/pages/onboarding/BrandOnboardingMobile.jsx");
    expect(src).not.toMatch(/"Paid \+ UGC" : "Barter"/);
    expect(src).not.toMatch(/>Connect<\/div>/);
    expect(src).not.toMatch(/complete KYC to create your first campaign/);
    expect(src).not.toMatch(/Fill this from your audience research/);
    expect(src).not.toMatch(/Secure payment hold for every payment/);
  });
  it("desktop: page count, exit always there, pincode + publish feedback", () => {
    const src = read("src/components/Onboarding/BrandOnboardingFlow.jsx");
    expect(src).toMatch(/Step \{pageNum\} of \{pageTotal\}/);
    expect(src).toMatch(/label=\{basicsDone \? "Finish later" : "Exit"\}/);
    expect(src).toMatch(/We couldn't find that pincode/);
    expect(src).toMatch(/Your brand profile is live/);
  });
  it("Eva greets the person, not the company's first word", async () => {
    const { peekLines } = await import("./components/feedback/evaUi");
    expect(peekLines("brand", "")[0][0]).toBe("Hello!");
    expect(peekLines("brand", "Riya")[0][0]).toBe("Hello Riya!");
  });
});
