// v415 — Area D1 (discover creators + brand account pages) fixes.
import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";
import React from "react";
import { render, screen } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import CreatorCard, { softTint } from "./components/creators/CreatorCard";
import { withTimeout, openCampaignsFor } from "./pages/brand/BrandPublicView";
import { verificationLabel } from "./pages/brand/BrandSettings";
import { showChallengeRibbon } from "./components/publicProfile/PortfolioCoversMobile";
import { ENTRIES_CLOSE_AT } from "./lib/diwaliChallenge";
import KYCStatusBanner from "./components/kyc/KYCStatusBanner";

const read = (f) => fs.readFileSync(path.join(process.cwd(), f), "utf8");

describe("v415 · creator cards without a photo", () => {
  it("softTint keeps the colour, changes the alpha", () => {
    expect(softTint("rgba(56,132,255,0.65)", 0.2)).toBe("rgba(56,132,255,0.2)");
    expect(softTint("bad", 0.1)).toBe("rgba(124,58,237,0.1)");
  });
  it("renders a small monogram, not the 72px letters", () => {
    render(<MemoryRouter><CreatorCard c={{ user_id: "u0", name: "Unclaimed 0" }} /></MemoryRouter>);
    const mono = screen.getByTestId("creator-card-monogram");
    expect(mono.style.display).toBe("flex");
    expect(mono.querySelector("span").style.fontSize).toBe("22px");
  });
  it("mobile grid card uses the monogram too", () => {
    expect(read("src/components/explore/mobile/ExploreMobile.jsx")).toContain('data-testid="explore-card-monogram"');
  });
});

describe("v415 · public brand page never spins forever", () => {
  it("withTimeout rejects a request that never answers", async () => {
    await expect(withTimeout(new Promise(() => {}), 20)).rejects.toThrow("timeout");
    await expect(withTimeout(Promise.resolve(5), 50)).resolves.toBe(5);
  });
  it("open campaigns come from the API list, only this brand's, only open", () => {
    const list = [
      { campaign_id: "a", brand_user_id: "b1", status: "live" },
      { campaign_id: "b", brand_user_id: "b1", status: "draft" },
      { campaign_id: "c", brand_user_id: "b2", status: "live", brand_name: "Same Name" },
      { campaign_id: "d", brand_user_id: "b1", status: "live", closed_at: "2026-01-01" },
    ];
    expect(openCampaignsFor(list, "b1").map((c) => c.campaign_id)).toEqual(["a"]);
    expect(openCampaignsFor(list, "")).toEqual([]);
  });
  it("no direct Supabase read on the public brand page", () => {
    const s = read("src/pages/brand/BrandPublicView.jsx");
    expect(s).not.toContain("supabase");
    expect(s).toContain('withTimeout(api.get("campaigns"))');
  });
});

describe("v415 · verification wording", () => {
  it("friendly status words", () => {
    expect(verificationLabel("APPROVED")).toBe("Verified");
    expect(verificationLabel("under_review")).toBe("Under review");
    expect(verificationLabel("MORE_INFO_NEEDED")).toBe("More info needed");
    expect(verificationLabel("NOT_SUBMITTED")).toBe("Verification pending");
  });
  it("KYC banner: no caps jargon, no emoji", () => {
    const { container } = render(<KYCStatusBanner status="PENDING" />);
    expect(container.textContent).toContain("Under review");
    expect(container.textContent).not.toMatch(/⏳|queue phase|KYC Compliance/);
    const { container: c2 } = render(<KYCStatusBanner status={null} />);
    expect(c2.textContent).toContain("Verification pending");
  });
  it("brand pages use the same words", () => {
    expect(read("src/pages/brand/BrandProfile.jsx")).toContain('"Verification pending"');
    expect(read("src/pages/brand/BrandKycMobile.jsx")).toContain('"Verification pending"');
    expect(read("src/pages/brand/BrandPublicView.jsx")).toContain('"Verification pending"');
  });
});

describe("v415 · settings / payments polish", () => {
  it("settings: labelled logo button, clear tab names, popups lock scroll", () => {
    const s = read("src/pages/brand/BrandSettings.jsx");
    expect(s).toContain('aria-label="Change company logo"');
    expect(s).not.toContain(">Settings Hub<");
    expect(s).toContain("useScrollLock(anyPopupOpen)");
    expect(s).not.toContain("placehold.co");
  });
  it("payments: plain title, no 'secure payment hold' jargon, refunds card below the list", () => {
    const s = read("src/pages/brand/BrandPayments.jsx");
    expect(s).not.toContain("Secure Payouts Ledger");
    expect(s).not.toMatch(/secure payment hold/i);
    // v416 (QA U1): the desktop list now comes from the payments overview (PaymentsOverviewList), refunds still below it
    expect(s.indexOf("<PaymentsOverviewList")).toBeGreaterThan(-1);
    expect(s.indexOf("<PaymentsOverviewList")).toBeLessThan(s.indexOf("<BrandRefundsCard className"));
    expect(read("src/components/payments/BrandPaymentsMobile.jsx")).toContain("brand-payments-mobile-skeleton");
  });
  it("Diwali ribbon hides after entries close", () => {
    expect(showChallengeRibbon(ENTRIES_CLOSE_AT - 1)).toBe(true);
    expect(showChallengeRibbon(ENTRIES_CLOSE_AT + 1)).toBe(false);
  });
});
