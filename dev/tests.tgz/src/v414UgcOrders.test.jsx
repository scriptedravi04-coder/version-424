// v414: UGC order tracker / amounts / poll / sign-button fixes (items 11, 12, 13, 14, 15, 24).
import { describe, it, expect, afterEach } from "vitest";
import React from "react";
import { render, screen, cleanup } from "@testing-library/react";
import fs from "fs";
import path from "path";
import DealProgressStepper from "./components/deals/DealProgressStepper";

const read = (p) => fs.readFileSync(path.resolve(process.cwd(), p), "utf8");

afterEach(() => cleanup());

describe("v414 #11 DealProgressStepper", () => {
  it("collab orders: step 3 reads 'Live link', never 'Payment Cleared'", () => {
    render(<DealProgressStepper stage="AWAITING_LIVE_LINK" isCollab />);
    expect(screen.getByText("Waiting for Live Link")).toBeTruthy();
    expect(screen.getByText("Live link")).toBeTruthy();
    expect(screen.queryByText(/payment cleared/i)).toBeNull();
  });

  it("raw UGC orders: step 3 reads 'Approved' without a UTR", () => {
    render(<DealProgressStepper stage="IN_REVIEW" isCollab={false} />);
    expect(screen.getByText("Approved")).toBeTruthy();
    expect(screen.queryByText(/payment cleared/i)).toBeNull();
  });

  it("raw UGC orders: 'Payment cleared' only with a UTR", () => {
    render(<DealProgressStepper stage="IN_REVIEW" isCollab={false} utrNumber="UTR123" />);
    expect(screen.getByText("Payment cleared")).toBeTruthy();
  });

  it("APPROVED without a UTR is not 'Payment Cleared'", () => {
    render(<DealProgressStepper stage="APPROVED" isCollab={false} />);
    expect(screen.queryByText(/payment cleared/i)).toBeNull();
  });

  it("PENDING_SIGNATURE shows agreement pending, not In Production", () => {
    render(<DealProgressStepper stage="PENDING_SIGNATURE" />);
    expect(screen.getByText("Agreement pending")).toBeTruthy();
    expect(screen.getByText(/sign the agreement/i)).toBeTruthy();
    expect(screen.queryByText(/filming & editing/i)).toBeNull();
  });

  it.each(["EXPIRED", "CANCELLED", "CLOSED", "REFUNDED"])("%s shows 'Order closed'", (stage) => {
    render(<DealProgressStepper stage={stage} />);
    expect(screen.getByText("Order closed")).toBeTruthy();
    expect(screen.queryByText(/filming & editing/i)).toBeNull();
  });
});

describe("v414 source checks", () => {
  it("#11/#12 BrandUGCOrders: closed orders → CLOSED stage in stepper, excluded from In Production", () => {
    const src = read("src/pages/brand/BrandUGCOrders.jsx");
    expect(src).toMatch(/stage=\{\(selectedOrder\.closedNoDraft \|\| selectedOrder\.isClosed\) \? "CLOSED" : selectedOrder\.stage\}/);
    expect(src).toMatch(/activeFilter === "in_production"\) return !o\.closedNoDraft && !o\.isClosed &&/);
  });

  it("#13 no ₹0 for unknown amounts", () => {
    const brand = read("src/pages/brand/BrandUGCOrders.jsx");
    expect(brand).toMatch(/formatINROrDash\(o\.amount > 0 \? o\.amount : null\)/);
    expect(brand).toMatch(/formatINROrDash\(selectedOrder\.amount > 0 \? selectedOrder\.amount : null\)/);
    const brandMobile = read("src/pages/brand/BrandUGCMobile.jsx");
    expect(brandMobile).toMatch(/formatINROrDash\(amount > 0 \? amount : null\)/);
    const creatorMobile = read("src/pages/creator/CreatorUGCMobile.jsx");
    expect(creatorMobile).toMatch(/toNumber\(amount, 0\) > 0 \? formatINROrDash\(amount\) : "—"/);
  });

  it("#14 silent poll doesn't set loading", () => {
    const src = read("src/pages/creator/ManageUGCOrdersView.jsx");
    expect(src).toMatch(/if \(!silent\) setLoading\(true\)/);
  });

  it("#15 unsigned order card asks to sign instead of upload", () => {
    const src = read("src/pages/creator/CreatorUGCMobile.jsx");
    expect(src).toMatch(/order\.isUnsigned \? "Sign agreement" : "Upload video deliverable"/);
    expect(src).toMatch(/if \(order\.isUnsigned\) \{ setSigningReservation\(order\); return; \}/);
    expect(src).toMatch(/<UGCContractModal[\s\S]*orderId=\{signingReservation\.id\}/);
  });

  it("#24 DealsMobile counts PROOF_SUBMITTED as under review", () => {
    const src = read("src/components/deals/mobile/DealsMobile.jsx");
    expect(src).toMatch(/"LIVE_LINKS_SUBMITTED", "PROOF_SUBMITTED"\]/);
  });
});
