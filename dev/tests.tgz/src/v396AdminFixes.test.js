// v396 (Ravi, 2 Nov): Explore-style filters on Admin → Users → Creators, waitlist approve moves people out,
// admin alerts never come back as a blocking pop-up.
import { describe, it, expect, beforeEach } from "vitest";
import fs from "fs";
import { applyCreatorFilters, countCreatorFilters, EMPTY_CREATOR_FILTERS, parseCount, igStateOf, kycOf } from "./lib/adminCreatorFilters";
import { approvedWhere } from "./components/admin/WaitlistManager";
import { isAdminSystemAlert } from "./components/NotificationPopup";
import { waitlistNeedsShadowRow } from "../backend/admin_users_enforcement_routes";

const read = (p) => fs.readFileSync(p, "utf8");
const u = (id, cp = {}, extra = {}) => ({ user_id: id, role: "creator", creator_profile: { created_at: "2026-10-30T00:00:00Z", ...cp }, ...extra }); // new sign-ups (after the Explore gate)
const rows = [
  u("a", { followers_instagram: 500, city: "Jaipur", state: "Rajasthan", primary_niche: "Fashion", gender: "Female", languages: ["Hindi"], rate_reel: 2000, instagram_handle: "a" }),
  u("b", { followers_instagram: "12.5k", city: "Mumbai", state: "Maharashtra", category: "Tech & Gadgets", gender: "Male", rate_card: { reels: 20000 }, instagram_handle: "b", instagram_stats: { followers: 12500 } }, { kyc_status: "APPROVED" }),
  u("c", { followers: 2500000, city: "New Delhi", primary_niche: "Comedy & Memes", barter: true, instagram_handle: "c", instagram_stats: { error: "not_professional" }, profile_status: "approved", reviewed_at: "2026-10-31T00:00:00Z" }),
  u("d", { followers_instagram: 50000, city: "jaipur", primary_niche: "Food & Cooking", collab_preference: "paid" }),
];
const f = (patch) => ({ ...EMPTY_CREATOR_FILTERS, ...patch });
const ids = (list) => list.map((x) => x.user_id);

describe("admin creator filters (Explore-style)", () => {
  it("parses counts like the Explore page (k / L / M / commas)", () => {
    expect(parseCount("12.5k")).toBe(12500);
    expect(parseCount("1.2L")).toBe(120000);
    expect(parseCount("3M")).toBe(3000000);
    expect(parseCount("1,50,000")).toBe(150000);
    expect(parseCount(null)).toBe(0);
  });
  it("follower tiers and min / max", () => {
    expect(ids(applyCreatorFilters(rows, f({ followerRanges: ["micro"] })))).toEqual(["b", "d"]);
    expect(ids(applyCreatorFilters(rows, f({ followerRanges: ["under_1k", "mega"] })))).toEqual(["a", "c"]);
    expect(ids(applyCreatorFilters(rows, f({ minFollowers: "10k", maxFollowers: "1L" })))).toEqual(["b", "d"]);
  });
  it("city (any case), state, niche, gender, language", () => {
    expect(ids(applyCreatorFilters(rows, f({ cities: ["Jaipur"] })))).toEqual(["a", "d"]);
    expect(ids(applyCreatorFilters(rows, f({ states: ["Maharashtra"] })))).toEqual(["b"]);
    expect(ids(applyCreatorFilters(rows, f({ niches: ["Food & Cooking", "Comedy & Memes"] })))).toEqual(["c", "d"]);
    expect(ids(applyCreatorFilters(rows, f({ gender: "Female" })))).toEqual(["a"]);
    expect(ids(applyCreatorFilters(rows, f({ languages: ["Hindi"] })))).toEqual(["a"]);
  });
  it("rate, paid / barter, KYC, Instagram state, profile status", () => {
    expect(ids(applyCreatorFilters(rows, f({ rateRanges: ["15k_30k"] })))).toEqual(["b"]);
    expect(ids(applyCreatorFilters(rows, f({ collabMode: "Barter" })))).toEqual(["c"]);
    expect(ids(applyCreatorFilters(rows, f({ kyc: ["APPROVED"] })))).toEqual(["b"]);
    expect(igStateOf(rows[2])).toBe("failed");
    expect(ids(applyCreatorFilters(rows, f({ ig: ["fetched"] })))).toEqual(["b"]);
    expect(ids(applyCreatorFilters(rows, f({ ig: ["no_handle"] })))).toEqual(["d"]);
    expect(ids(applyCreatorFilters(rows, f({ profileStatus: ["live"] })))).toEqual(["c"]);
    expect(ids(applyCreatorFilters(rows, f({ profileStatus: ["waiting"] })))).toEqual(["a", "b", "d"]);
    expect(kycOf({ kyc_status: "under_review" })).toBe("PENDING");
  });
  it("sort keeps the original order by default; most followers first on request", () => {
    expect(ids(applyCreatorFilters(rows, EMPTY_CREATOR_FILTERS))).toEqual(["a", "b", "c", "d"]);
    expect(ids(applyCreatorFilters(rows, f({ sortBy: "followers" })))).toEqual(["c", "d", "b", "a"]);
  });
  it("counts active groups for the badge", () => {
    expect(countCreatorFilters(EMPTY_CREATOR_FILTERS)).toBe(0);
    expect(countCreatorFilters(f({ cities: ["Jaipur"], followerRanges: ["nano"], minFollowers: "5k", gender: "Male" }))).toBe(4);
  });
  it("Users tab shows the Filters button only on Creators / Unclaimed", () => {
    const s = read("src/components/admin/AdminUsersTab.jsx");
    expect(s).toContain("const showCreatorFilters = activeRole === 'creator' || activeRole === 'unclaimed';");
    expect(s).toContain("<AdminCreatorFilters value={creatorFilters}");
  });
});

describe("waitlist approve moves the person out", () => {
  it("opens on Pending, approved ones are under 'Approved (moved to Users)'", () => {
    const s = read("src/components/admin/WaitlistManager.jsx");
    expect(s).toContain(`get("q") ? "All" : "Pending"`); // opens on Pending (All when a search link brings a name)
    expect(s).toContain("Approved (moved to Users)");
  });
  it("Users list no longer shows pending / rejected / already-linked waitlist rows as unclaimed creators", () => {
    const profs = [{ user_id: "CRTR_UNCLAIMED_1", instagram_handle: "riya" }];
    expect(waitlistNeedsShadowRow({ status: "Pending", handle: "x" }, profs)).toBe(false);
    expect(waitlistNeedsShadowRow({ status: "Rejected", handle: "x" }, profs)).toBe(false);
    expect(waitlistNeedsShadowRow({ status: "Approved", handle: "x", linked_user_id: "CRTR_UNCLAIMED_9" }, profs)).toBe(false);
    expect(waitlistNeedsShadowRow({ status: "Approved", handle: "@Riya" }, profs)).toBe(false);
    expect(waitlistNeedsShadowRow({ status: "Approved", handle: "old_one" }, profs)).toBe(true); // old approval without a profile
  });
  it("toast says where they went", () => {
    expect(approvedWhere({ ok: true, shadowUserId: "CRTR_UNCLAIMED_1" })).toMatch(/Unclaimed Creators/);
    expect(approvedWhere({ ok: true, message: "This email already has a Ybex account — marked approved, their own profile stays as it is." })).toMatch(/Users → Creators/);
    expect(approvedWhere({ ok: true, message: "Creator approved successfully" })).toMatch(/Users → Creators/);
  });
});

describe("admin alerts are bell-only (no repeating pop-up)", () => {
  beforeEach(() => { try { localStorage.clear(); } catch { /* none */ } });
  it("KYC-submitted style alerts are not blocking", () => {
    expect(isAdminSystemAlert({ user_id: "admin", type: "kyc_submitted", is_admin_message: true })).toBe(true);
    expect(isAdminSystemAlert({ user_id: "u1", type: "kyc_submitted", is_admin_message: true })).toBe(true);
    expect(isAdminSystemAlert({ user_id: "u1", type: "admin_notification" })).toBe(false);
  });
  it("server copy carries event_type; dismissed ids are remembered on the device", () => {
    expect(read("backend/notificationService.ts")).toContain("event_type: type || 'admin_system_alert',");
    const p = read("src/components/NotificationPopup.jsx");
    expect(p).toContain("if (isAdminSystemAlert(notif)) return false;");
    expect(p).toContain('const DISMISSED_KEY = "ybex_dismissed_popups";');
    expect(p.indexOf("rememberDismissed([...blockingQueue")).toBeLessThan(p.indexOf('await api.post("/notifications/read-all");'));
  });
});

// v396 (Ravi: entries without the hashtags were counted; add "follows @ybex.in")
import { entryStatus, liveEntries, rechargeOrder } from "../backend/challenge_routes";
describe("challenge entries: missing tags / early post / not following → auto rejected", () => {
  const ok = { found: true, caption_ok: true, posted_ok: true };
  it("auto rejects only on a real failed check; manual review wins", () => {
    expect(entryStatus(null, "k", null)).toEqual({ status: "pending", auto: false, reason: "" }); // not refreshed yet
    expect(entryStatus(null, "k", ok).status).toBe("pending");
    expect(entryStatus(null, "k", { found: false }).status).toBe("pending"); // reel not found → admin decides
    expect(entryStatus(null, "k", { ...ok, caption_ok: false })).toEqual({ status: "rejected", auto: true, reason: "tags missing" });
    expect(entryStatus(null, "k", { ...ok, posted_ok: false }).reason).toBe("posted before the start");
    expect(entryStatus(null, "k", ok, false).reason).toBe("doesn't follow @ybex.in");
    expect(entryStatus({ review: { k: "approved" } }, "k", { ...ok, caption_ok: false })).toEqual({ status: "approved", auto: false, reason: "" });
  });
  it("auto-rejected entries leave the count and the ₹50 line", () => {
    const list = [{ user_id: "a", item_id: "1", at: "2026-11-01T00:00:00Z", status: "rejected" }, { user_id: "b", item_id: "1", at: "2026-11-01T01:00:00Z", status: "pending" }];
    expect(liveEntries(list).map((e) => e.user_id)).toEqual(["b"]);
    expect([...rechargeOrder(list).keys()]).toEqual(["b"]);
  });
  it("admin screen shows the follow tick and the auto reason", () => {
    const s = read("src/components/admin/AdminChallengeEntries.jsx");
    expect(s).toContain('data-testid="follow-cell"');
    expect(s).toContain("Auto: {e.auto_reason}");
  });
});

// v396 (Ravi: Samsung, Android app — Eva's typing bar under the keyboard)
import { __test as kb, nativeKeyboardHeight } from "./lib/keyboardAware";
describe("Android app keyboard (edge-to-edge, page doesn't shrink)", () => {
  it("uses the app / WebView keyboard height only when the page didn't shrink", () => {
    expect(kb.nativeKbOpen({ focused: true, nativeH: 300, layoutShrunk: false })).toBe(true);
    expect(kb.nativeKbOpen({ focused: true, nativeH: 300, layoutShrunk: true })).toBe(false); // old way works
    expect(kb.nativeKbOpen({ focused: false, nativeH: 300, layoutShrunk: false })).toBe(false);
    expect(kb.nativeKbOpen({ focused: true, nativeH: 40, layoutShrunk: false })).toBe(false);
    kb.setNativeKb(312.4); expect(nativeKeyboardHeight()).toBe(312); kb.setNativeKb(0);
  });
  it("Eva listens to it; the app build carries the Keyboard plugin", () => {
    const f = read("src/components/feedback/FeedbackBot.jsx");
    expect(f).toContain('window.addEventListener("ybex:native-kb", schedule);');
    const cfg = JSON.parse(read("android-app/capacitor.config.json"));
    expect(cfg.plugins.Keyboard).toEqual({ resizeOnFullScreen: true });
    expect(JSON.parse(read("android-app/package.json")).dependencies["@capacitor/keyboard"]).toBeTruthy();
  });
});

// v396 (Ravi): admin universal search + waitlist chips + campaign "View brand details" + KYC PAN only
import { searchAdmin, userKind } from "./lib/adminSearch";
import { waitlistChipMatch } from "./components/admin/WaitlistManager";
describe("admin universal search", () => {
  const data = {
    users: [
      { user_id: "c1", role: "creator", name: "Ankit Sharma", email: "ankit@x.in", creator_profile: { instagram_handle: "ankit.reels", followers_instagram: 12000 } },
      { user_id: "b1", role: "brand", name: "Owner", email: "o@pro.in", brand_profile: { company_name: "ProRewards" } },
      { user_id: "b2", role: "brand", name: "Owner2", email: "o2@pro.in", brand_profile: { company_name: "ProRewards", is_agency: true } },
      { user_id: "u1", role: "creator", auth_method: "unclaimed", name: "Ankita", creator_profile: { is_claimed: false } },
    ],
    waitlist: [{ id: "w1", name: "Ankit Waitlist", email: "aw@x.in", status: "Pending" }, { id: "w2", name: "Ankit Old", status: "Approved" }],
    campaigns: [{ campaign_id: "k1", title: "ProRewards Diwali Dhamaka Reel", brand_name: "Prorewards" }],
  };
  it("finds people with their kind and a link that opens them", () => {
    const r = searchAdmin("ankit", data);
    const kinds = r.map((x) => `${x.kind}:${x.id}`);
    expect(kinds).toContain("creator:c1");
    expect(kinds).toContain("unclaimed:u1");
    expect(kinds).toContain("waitlist:w1");
    expect(kinds).not.toContain("waitlist:w2"); // approved people live under Users
    expect(r.find((x) => x.id === "c1").to).toBe("/admin?tab=users&role=all&open=c1");
    expect(r.find((x) => x.id === "w1").to).toBe("/admin?tab=waitlist&q=aw%40x.in");
  });
  it("two brands with the same name are both there (brand vs agency), plus the campaign", () => {
    const r = searchAdmin("prorewards", data);
    expect(r.filter((x) => x.kind === "brand" || x.kind === "agency").map((x) => x.id).sort()).toEqual(["b1", "b2"]);
    expect(r.find((x) => x.kind === "campaign").to).toBe("/admin?tab=campaigns&open=k1");
  });
  it("sections and settings by name or by the words people use", () => {
    expect(searchAdmin("popup", null)[0]).toMatchObject({ kind: "setting", to: "/admin?tab=settings&view=promos" });
    expect(searchAdmin("waitlist", null)[0]).toMatchObject({ kind: "section", to: "/admin?tab=waitlist" });
    expect(searchAdmin("kyc", null).some((x) => x.to === "/admin?tab=verifications")).toBe(true);
    expect(userKind({ role: "admin" })).toBe("admin");
  });
  it("waitlist quick chips", () => {
    expect(waitlistChipMatch({ ig_followers: 1500 }, "1k")).toBe(true);
    expect(waitlistChipMatch({ followers: 800 }, "under1k")).toBe(true);
    expect(waitlistChipMatch({ followers: 800, photo: "x.jpg" }, "nophoto")).toBe(false);
    expect(waitlistChipMatch({ followers: 150000 }, "1l")).toBe(true);
  });
  it("campaign review has View brand details; KYC creators show only PAN / Not submitted", () => {
    expect(read("src/components/admin/CampaignReviewQueue.jsx")).toContain('data-testid="view-brand-details"');
    expect(read("src/components/admin/KYCManager.jsx")).toContain("Not submitted");
    expect(read("src/pages/admin/Admin.jsx")).toContain("<AdminUniversalSearch />");
  });
});

// v396 (QA M-1): creator sees the after-refund net (never subtracted twice)
import { creatorShownNet, applyCreatorNetAfterRefund, idsMissingRefund } from "../backend/adminMoney";
describe("creator net after a part refund", () => {
  const tx = { id: "t1", gross_amount: 25000, platform_fee_amount: 1250, gst_amount: 225, creator_net_amount: 23525, refund_amount: 5000, refund_status: "PROCESSED" };
  it("takes the refund off the full net only", () => {
    expect(creatorShownNet(tx)).toBe(18525);
    expect(creatorShownNet({ ...tx, creator_net_amount: 18525 })).toBe(null); // already reduced (campaign_lifecycle) → as is
    expect(creatorShownNet({ ...tx, refund_status: "PENDING" })).toBe(null);
  });
  it("fixes rows in an answer, also trimmed rows with the refund looked up", () => {
    const body = { items: [{ ...tx }] };
    expect(applyCreatorNetAfterRefund(body).items[0]).toMatchObject({ creator_net_amount: 18525, creator_net_amount_before_refund: 23525 });
    const trimmed = [{ id: "t1", gross_amount: 25000, creator_net_amount: 23525, amount: 25000 }];
    expect([...idsMissingRefund(trimmed)]).toEqual(["t1"]);
    applyCreatorNetAfterRefund(trimmed, 0, new Map([["t1", tx]]));
    expect(trimmed[0].creator_net_amount).toBe(18525);
  });
});

// v396 (Ravi OK 2 Nov): S-8 quote ownership, admin escrow campaign names, bigger search boxes
describe("v396 small locked fixes", () => {

  const pay = fs.readFileSync("backend/payment_routes.ts", "utf8");
  it("quote refuses another account's deal", () => {
    expect(pay).toContain("NOT_YOUR_DEAL");
    expect(pay).toContain("select('agreed_amount, brand_id, creator_id')");
  });
  it("admin escrow maps campaigns by id and campaign_id", () => {
    expect(pay).toMatch(/campaignsMap\.set\(String\(c\.id\)/);
    expect(pay).toMatch(/campaignsMap\.set\(String\(c\.campaign_id\)/);
  });
  it("chat and UGC search boxes are at least 40px tall", () => {
    for (const f of ["src/pages/dashboard/Chat.jsx", "src/pages/creator/CreatorUGCOrders.jsx", "src/pages/creator/ManageUGCOrdersView.jsx", "src/pages/brand/BrandUGCOrders.jsx", "src/pages/creator/CreatorUGCBrowse.jsx", "src/pages/brand/BrandInstantUGC.jsx"]) {
      expect(fs.readFileSync(f, "utf8")).toContain("min-h-[40px]");
    }
  });
});
