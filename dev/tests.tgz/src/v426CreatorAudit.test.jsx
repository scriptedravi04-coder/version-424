// v426: creator-panel audit fixes (rate card wipe, Back closes sheets, scroll restore, chat skeleton,
// popup timing, smaller fixes).
import React from "react";
import fs from "node:fs";
import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, fireEvent, cleanup, act, waitFor } from "@testing-library/react";

vi.mock("sonner", () => ({ toast: { success: vi.fn(), error: vi.fn() } }));
import RatesScreen from "./pages/creator/profileScreens/RatesScreen";
import useBackToClose from "./lib/popupRules";
import { claimAppOpenPopup, waitForHomeReady, markHomeReady } from "./lib/popupRules";

const src = (p) => fs.readFileSync(new URL(p, import.meta.url), "utf8");
afterEach(() => { cleanup(); vi.useRealTimers(); });

const header = (t) => <div>{t}</div>;

describe("v426 rate card", () => {
  it("Save waits for the profile, then keeps every rate that wasn't edited", async () => {
    const save = vi.fn(async () => true);
    const setRateCard = vi.fn();
    const props = { renderBackHeader: header, saveProfileChanges: save, setMobileScreen: vi.fn(), setRateCard };
    const { rerender } = render(<RatesScreen {...props} rateCard={{}} profileState="loading" />);
    const btn = screen.getByTestId("save-rate-cards");
    expect(btn.disabled).toBe(true);
    rerender(<RatesScreen {...props} rateCard={{ reels: 5000, stories: 3000, ugc: 2500 }} profileState="ready" />);
    const inputs = Array.from(document.querySelectorAll("input"));
    const reels = inputs.find((i) => i.value === "5000");
    expect(reels).toBeTruthy(); // the loaded rates appear (they were blank before)
    fireEvent.change(reels, { target: { value: "6000" } });
    await act(async () => { fireEvent.click(screen.getByTestId("save-rate-cards")); });
    expect(save).toHaveBeenCalledWith({ rateCard: expect.objectContaining({ reels: 6000, stories: 3000, ugc: 2500 }) }, { silent: true });
  });
});

function Sheet({ onClose }) { useBackToClose(true, onClose); return <div>sheet</div>; }
describe("v426 Back closes sheets", () => {
  it("adds a history entry; Back (popstate) closes the sheet", () => {
    const onClose = vi.fn();
    const before = window.history.length;
    render(<Sheet onClose={onClose} />);
    expect(window.history.length).toBe(before + 1);
    window.history.replaceState({}, ""); // what the browser shows after Back
    window.dispatchEvent(new PopStateEvent("popstate"));
    expect(onClose).toHaveBeenCalledTimes(1);
  });
  it("MobileSheet, PopupPanel and the UGC brief screen use it; native Back does not background the app over a sheet", () => {
    expect(src("./components/chat/mobile/MobileSheet.jsx")).toContain("useBackToClose(");
    expect(src("./components/common/Popup.jsx")).toContain("useBackToClose(");
    expect(src("./pages/creator/CreatorUGCMobile.jsx")).toMatch(/useBackToClose\(activeView === "brief_details"/);
    expect(src("./lib/native.js")).toContain("st.ybexSheets");
  });
});

describe("v426 app-open popups", () => {
  it("only one popup claims an app open", () => {
    delete window.__ybOpenPopupUsed;
    expect(claimAppOpenPopup("diwali")).toBe(true);
    expect(claimAppOpenPopup("diwali")).toBe(true);
    expect(claimAppOpenPopup("promo")).toBe(false);
    delete window.__ybOpenPopupUsed;
  });
  it("waits for Home's data", async () => {
    delete window.__ybHomeReady;
    let done = false;
    waitForHomeReady(10000).then(() => { done = true; });
    await new Promise((r) => setTimeout(r, 20));
    expect(done).toBe(false);
    markHomeReady();
    await waitFor(() => expect(done).toBe(true));
  });
  it("Diwali / promo / quick actions / What's New / push all use the gate; TabWarmup waits", () => {
    for (const f of ["./components/challenge/DiwaliEntryScreen.jsx", "./components/promo/PromoPopup.jsx", "./components/quickActions/QuickActionsMobile.jsx", "./components/whatsNew/WhatsNewPopup.jsx", "./components/push/PushPermissionScreen.jsx"]) {
      expect(src(f)).toContain("claimAppOpenPopup(");
    }
    expect(src("./App.jsx")).toMatch(/anyPopupOnScreen\(\)/);
  });
  it("Diwali poster: only the button navigates, no blur, bar uses transform", () => {
    const d = src("./components/challenge/DiwaliEntryScreen.jsx");
    expect(d).not.toMatch(/onClick=\{join\}\s*\n\s*style=\{\{ position: "fixed"/);
    expect(d).not.toContain("blur(24px)");
    expect(d).toContain("scaleX(0)");
  });
  it("promo: no blur, no bounce; quick actions: no spring; trust line has its own component", () => {
    const p = src("./components/promo/PromoPopup.jsx");
    expect(p).not.toContain("blur(3px)");
    expect(p).not.toContain("1.56");
    expect(src("./components/quickActions/QuickActionsMobile.jsx")).not.toContain("stiffness: 420");
    expect(src("./pages/creator/CreatorHomeMobile.jsx")).toContain("function TrustLineRotator()");
  });
  it("desktop chat and jsPDF are not pulled in by the phone Inbox / screens", () => {
    expect(src("./pages/creator/CreatorInbox.jsx")).toContain('lazyRetry(() => import("../dashboard/Chat"))');
    expect(src("./utils/invoicePdf.js")).not.toMatch(/^import \{ jsPDF \}/m);
  });
});

describe("v426 smaller fixes", () => {
  it("chat skeleton gives up after 8s", () => {
    expect(src("./components/chat/mobile/ChatBoxMobile.jsx")).toContain("loadStuck");
  });
  it("scroll position comes back on Back", () => {
    expect(src("./components/layout/Layout.jsx")).toMatch(/navType === "POP" \? savedScroll\.get/);
  });
  it("campaign detail budget uses the list's words; quote above budget is flagged", () => {
    const d = src("./components/campaigns/mobile/CampaignDetailMobile.jsx");
    expect(d).toContain("campaignBudgetText(c");
    expect(d).toContain('data-testid="quote-above-budget"');
  });
  it("misc", () => {
    expect(src("./pages/creator/CreatorSettings.jsx")).not.toContain("Number(data.avg_views_30d) || 0");
    expect(src("./components/legal/TermsUpdateGate.jsx")).not.toContain("4f46e5");
    expect(src("./components/common/PWAInstallPrompt.jsx")).not.toMatch(/setInterval\(\(\) => \{ if \(window\.location\.pathname/);
    expect(src("./components/challenge/ChallengeUi.jsx")).toContain("!me || me.is_creator === false");
    expect(src("./components/feedback/FeedbackBot.jsx")).toContain("[data-eva-avoid]");
    expect(src("../vite.config.js")).not.toContain("'gsap'");
  });
});

import { ugcAgreement, ugcDeliverableText, agreementPlainText } from "./lib/agreementTerms";
describe("v427 UGC agreement deliverable follows the brief format", () => {
  it("edited (default) keeps the old wording", () => {
    expect(ugcDeliverableText("")).toBe("One 30–60 second, 9:16 edited video with clear audio and subtitles, made to the brief. The Creator does not need to post it.");
  });
  it("raw: no editing, not posted", () => {
    const t = ugcDeliverableText("ugc_raw", "30–45 sec");
    expect(t).toContain("Raw, unedited 30–45 sec");
    expect(t).not.toContain("subtitles,");
  });
  it("collab: the creator posts it", () => {
    const t = agreementPlainText(ugcAgreement({ deliverableType: "collab_reel", payout: 2000 }));
    expect(t).toContain("Collab post");
    expect(t).not.toContain("does not need to post");
  });
});

// v429: creator profile — full details load on open; phones see a photo-led skeleton (photo + name from Explore at once)
import { ProfileSkeletonMobile } from "./components/common/ContentSkeletons";
describe("v429 profile skeleton", () => {
  it("shows the known name while loading", () => {
    render(<ProfileSkeletonMobile name="Aanya" photo="" />);
    expect(screen.getByTestId("profile-skeleton-mobile")).toBeTruthy();
    expect(screen.getByText("Aanya")).toBeTruthy();
    cleanup();
  });
  it("profile page uses it on phones and Explore passes the preview", () => {
    expect(fs.readFileSync("src/pages/creator/CreatorPublicView.jsx", "utf8")).toContain("<ProfileSkeletonMobile");
    expect(fs.readFileSync("src/components/explore/mobile/ExploreMobile.jsx", "utf8")).toContain("state: { preview:");
  });
});

// v430: theme clean-up + Drive / YouTube draft preview on the brand's UGC order screen
import DeliverablePreviewCard from "./pages/brand/brandUgc/DeliverablePreviewCard";
import { appConfirm } from "./components/common/Popup";
describe("v430 theme + draft preview", () => {
  it("a Google Drive draft plays inside the card", () => {
    render(<DeliverablePreviewCard deliverableUrl="https://drive.google.com/file/d/abc123XYZ/view?usp=drive" isCompleted={false}
      isPlayableDeliverable={() => false} selectedOrder={{ id: "o1" }} isCollabOrder={false} />);
    const frame = screen.getByTestId("brand-ugc-draft-embed").querySelector("iframe");
    expect(frame.getAttribute("src")).toBe("https://drive.google.com/file/d/abc123XYZ/preview");
    cleanup();
  });
  it("app confirm sheet resolves with the choice", async () => {
    const p = appConfirm("Remove this?", { ok: "Remove" });
    fireEvent.click(await screen.findByTestId("app-confirm-ok"));
    await expect(p).resolves.toBe(true);
  });
  it("one purple: no indigo / purple-600 / #5438FF left on user screens", () => {
    const f = ["src/components/chat/ChatBox.jsx", "src/components/campaigns/CampaignCard.jsx", "src/components/profile/mobile/brand/KycScreen.jsx"];
    for (const x of f) expect(fs.readFileSync(x, "utf8")).not.toMatch(/bg-indigo-600|bg-purple-600|#5438FF/);
  });
});

import { buildBrandApplicationActions, buildCreatorInviteActions } from "./components/quickActions/quickActionsData";
describe("v430 quick actions", () => {
  it("cards link to the Ybex profile", () => {
    const [a] = buildBrandApplicationActions([{ c: { id: "c1", title: "T" }, apps: [{ application_id: "a1", status: "pending", creator_id: "u9", full_name: "Bhumzi" }] }]);
    expect(a.profileHref).toBe("/creator/u9");
    const [i] = buildCreatorInviteActions({ pending: [{ id: "i1", brand_id: "b2", brand_name: "Pro" }] });
    expect(i.profileHref).toBe("/brand/b2");
  });
  it("auto-slides every 4 s until touched", () => {
    const s = fs.readFileSync("src/components/quickActions/QuickActionsMobile.jsx", "utf8");
    expect(s).toContain("AUTO_SLIDE_MS = 4000");
    expect(s).toContain("onPointerDown={() => setPaused(true)}");
    expect(s).toContain('data-testid="quick-actions-profile"');
  });
});

import { MobileBriefCard } from "./components/chat/mobile/MobileBriefCards";
import { instagramUrlOf } from "./components/publicProfile/PhotoLedHeaderMobile";
import { RATES_PUBLIC } from "./utils/rateCardQuote";
describe("v430 profile / chat / admin fixes", () => {
  it("an empty brief card is not shown", () => {
    const { container } = render(<MobileBriefCard brief={{}} timeText="" />);
    expect(container.textContent).toBe("");
    cleanup();
  });
  it("Instagram link from the handle", () => {
    expect(instagramUrlOf({ instagram_handle: "@hellofrom_bhumzi" })).toBe("https://www.instagram.com/hellofrom_bhumzi/");
    expect(instagramUrlOf({ instagram: "https://instagram.com/abc.def?igsh=1" })).toBe("https://www.instagram.com/abc.def/");
    expect(instagramUrlOf({})).toBe("");
  });
  it("rates stay private to brands for now", () => {
    expect(RATES_PUBLIC).toBe(false);
    const s = fs.readFileSync("src/pages/creator/CreatorPublicView.jsx", "utf8");
    expect(s).toContain('data-testid="rates-coming-soon"');
  });
  it("admin phone tabs follow the sub-admin's permissions", () => {
    const s = fs.readFileSync("src/components/admin/mobile/AdminMobile.jsx", "utf8");
    expect(s).toContain('can("manage_users") ? <UsersScreen');
    expect(s).toContain(".filter((t) => !t[4] || can(t[4]))");
  });
});

// ── v431: Eva audit (creator side) + stale-build version watch ─────────────────────────────────────────
import { detectCreatorIntent as v431Intent, rankOpportunities as v431Rank, captionFor as v431Caption, hashtagsFor as v431Tags } from "./components/assist/creator/creatorLogic";
import { isOlderVersion as v431Older } from "./lib/staleBuild";
describe("v431 Eva audit — creator", () => {
  const camps = [{ id: 1, title: "Glow", brand_name: "Nykaa", status: "live", categories: ["Beauty"] }, { id: 2, title: "Chai", brand_name: "Tata", status: "live", categories: ["Food"] }];
  it("a niche named in the message wins over the profile niche (#5)", () => {
    expect(v431Rank({ campaigns: camps }, { category: "Food" }).map((o) => o.id)).toEqual(["2"]);
    expect(v431Rank({ campaigns: camps }, { category: "Food" }, { niches: ["Beauty"] }).map((o) => o.id)).toEqual(["1"]);
    expect(fs.readFileSync("src/components/assist/creator/brain.js", "utf8")).toMatch(/const askedNiche = nichesIn\(text\)/);
  });
  it("'write a pitch for …' is a pitch, 'apply to boAt' stays apply (#6)", () => {
    expect(v431Intent("Write a pitch for Nykaa Diwali campaign")).toEqual({ intent: "pitch" });
    expect(v431Intent("apply to boAt")).toEqual({ intent: "apply" });
    expect(v431Intent("show me beauty campaigns")).toEqual({ intent: "campaigns" });
  });
  it("no niche on the profile → every live campaign, not none (#7)", () => {
    expect(v431Rank({ campaigns: camps }, {}).length).toBe(2);
  });
  it("festival captions don't read like a product, no food tags on a Diwali reel (#8)", () => {
    expect(v431Caption("diwali")).not.toMatch(/Tried diwali/i);
    expect(v431Caption("diwali")).toMatch(/Diwali/);
    const tags = v431Tags("diwali", "food");
    expect(tags).toContain("#diwali");
    expect(tags).not.toContain("#foodie");
    expect(v431Tags("masala chai", "food")).toContain("#foodie");
  });
  it("Eva's small system lines have a Hindi version (#10)", () => {
    const src = fs.readFileSync("src/components/feedback/FeedbackBot.jsx", "utf8");
    expect(src).toMatch(/Abhi ye chat khul nahi payi/);
    expect(src).not.toMatch(/reply\("I couldn't open that chat/);
  });
});
describe("v431 stale build — version watch", () => {
  it("compares versions by number", () => {
    expect(v431Older("v430", "v431")).toBe(true);
    expect(v431Older("v431", "v431")).toBe(false);
    expect(v431Older("v432", "v431")).toBe(false);
  });
  it("the server tells the version and the web app watches it (not the native app)", () => {
    expect(fs.readFileSync("backend/misc_routes.ts", "utf8")).toMatch(/\/app-version/);
    expect(fs.readFileSync("src/index.jsx", "utf8")).toMatch(/!isNative\(\)\) startVersionWatch\(APP_VERSION\)/);
  });
});

// ── v432: creator profile redesign (one page, tap-to-Instagram, rates coming soon) ───────────────────────
import CreatorProfileMobile, { aboutRows as v432About, activeSectionAt as v432Active, barterLabel as v432Barter } from "./components/publicProfile/PhotoLedHeaderMobile";
describe("v432 creator profile — one page", () => {
  afterEach(cleanup);
  const c = { name: "Aanya Sharma", instagram_handle: "@aanyacreates", category: "Skincare", city: "Mumbai", ig_followers: 52000, engagement_rate: 4.6, bio: "Skincare reels", languages: ["Hindi", "English"], gender: "", payment_terms: "", rate_reel: 1500 };
  const reviews = [1, 2, 3].map((i) => ({ id: i, brand_name: `Brand ${i}`, rating: 5, comment: `Great ${i}` }));
  const base = { c, theme: null, photoUrl: "", onBack: () => {}, onShare: () => {}, reviews, scores: { overall: "4.8", quality: "4.9", time: "4.7", comm: "4.8" } };
  it("handle opens Instagram, numbers sit on the page, four jump chips, sticky CTA with the escrow line", () => {
    render(<CreatorProfileMobile {...base} viewer={{ isBrand: true, loggedIn: true }} cta={{ label: "Send collab request", onClick: () => {} }} onAskQuote={() => {}} onNotifyRates={() => {}} />);
    expect(screen.getByTestId("public-profile-ig-link").getAttribute("href")).toBe("https://www.instagram.com/aanyacreates/");
    expect(screen.getByTestId("public-profile-stats").textContent).toMatch(/52K/);
    for (const k of ["Work", "Reviews", "About", "Rates"]) expect(screen.getAllByRole("button", { name: k }).length).toBeGreaterThan(0);
    expect(screen.getByTestId("public-profile-cta-bar").textContent).toMatch(/You pay into escrow/);
    expect(screen.getByTestId("rates-coming-soon-mobile").textContent).toMatch(/Ybex Pro/);
    expect(screen.queryByText("₹1,500")).toBeNull(); // brands never see the price
  });
  it("reviews: summary + two cards, 'See all 3' shows the rest", () => {
    render(<CreatorProfileMobile {...base} viewer={{ isBrand: true, loggedIn: true }} />);
    expect(screen.getAllByText("4.8").length).toBeGreaterThan(0);
    expect(screen.getByTestId("public-profile-ig-line").textContent).toMatch(/4.8 \(3 reviews\)/);
    expect(screen.queryByText("Great 3")).toBeNull();
    fireEvent.click(screen.getByRole("button", { name: "See all 3" }));
    expect(screen.getByText("Great 3")).toBeTruthy();
  });
  it("the creator sees her own rates (private)", () => {
    render(<CreatorProfileMobile {...base} viewer={{ isOwner: true, loggedIn: true }} cta={{ label: "Edit profile", icon: "edit", onClick: () => {} }} />);
    expect(screen.getByTestId("rates-owner-note").textContent).toMatch(/₹1,500/);
    expect(screen.queryByTestId("rates-coming-soon-mobile")).toBeNull();
  });
  it("About leaves out empty fields and payment terms", () => {
    const rows = v432About({ ...c, barter: "cash_only" }).map(([k]) => k);
    expect(rows).toEqual(["Niche", "Based in", "Languages", "Collab type"]);
    expect(v432About({}).length).toBe(0);
    expect(v432Barter("partial_barter")).toBe("Paid + product");
  });
  it("the chip of the section under the bar lights up", () => {
    expect(v432Active({ work: 300, reviews: 900, about: 1500, rates: 2000 })).toBe("work");
    expect(v432Active({ work: -800, reviews: -200, about: 100, rates: 700 })).toBe("about");
  });
  it("phones render only the one-page profile (no old tabs)", () => {
    const s = fs.readFileSync("src/pages/creator/CreatorPublicView.jsx", "utf8");
    expect(s).toMatch(/\{!photoLed && \(<>\{\/\* v432/);
    expect(s).toMatch(/onNotifyRates=\{isOwner \? null : notifyRates\}/);
  });
});

// ── v435: Eva question test fixes ─────────────────────────────────────────────────────────────────────
import { plan as v435Plan, initialState as v435Init, detectLang as v435Lang } from "./components/feedback/assistBrain";
import { detectCreatorIntent as v435C, campaignFiltersIn as v435Cf, applyTarget as v435Target, splitRequests as v435Split } from "./components/assist/creator/creatorLogic";
import { detectBrandIntent as v435B, parseCreatorQuery as v435Q } from "./components/assist/brand/brandLogic";
describe("v435 Eva question test", () => {
  const ask = (q) => v435Plan(q, v435Init(), { askFirst: true, role: "creator" });
  it("FAQs are answered, never filed (#2 #4)", () => {
    for (const [q, rx] of [["what is escrow", /Escrow/], ["how do I contact support", /Support/], ["how do i delete my account", /Delete account/], ["add my team member", /Team members/], ["is my money safe", /safe/], ["where is my refund", /Refund/], ["how long does payout take", /Payout/], ["cancel my campaign", /Cancel/]]) {
      const p = ask(q);
      expect(p.send, q).toBeNull();
      expect(p.reply, q).toMatch(rx);
    }
  });
  it("small talk keeps its answers; other languages get an honest line (#2 #3)", () => {
    expect(ask("namaste").reply).toMatch(/Eva/);
    expect(ask("who are you").reply).toMatch(/Eva/);
    expect(ask("வணக்கம்").reply).toMatch(/English, Hindi and Hinglish/);
    expect(fs.readFileSync("src/components/feedback/FeedbackBot.jsx", "utf8")).toMatch(/ANSWERED_TYPES\.has\(classify\(t\)\.type\)/);
  });
  it("a bug from Eva asks first; yes files it (#4)", () => {
    const a = ask("the app crashes when I upload");
    expect(a.send).toBeNull();
    expect(a.next.pendingTicket).toBeTruthy();
    expect(v435Plan("yes", a.next, { askFirst: true }).send.category).toBe("bug");
    expect(v435Plan("no", a.next, { askFirst: true }).send).toBeNull();
  });
  it("keyword traps (#10) and Hinglish (#15)", () => {
    expect(v435C("my friend is threatening me")).toBeNull();
    expect(ask("my friend is threatening me").reply).toMatch(/112/);
    expect(v435C("are you a bot or human?")).toBeNull();
    expect(v435B("are you a bot or human?")).toBeNull();
    expect(v435C("how long does payout take")).toEqual({ intent: "payWhen" });
    expect(v435B("cancel my campaign")).toBeNull();
    expect(v435Lang("kitna charge karu 10k followers pe")).toBe("hi");
  });
  it("campaign search filters and apply-by-name (#6 #7)", () => {
    expect(v435Cf("campaigns in Mumbai").city).toBe("Mumbai");
    expect(v435Cf("campaigns above 10000").min).toBe(10000);
    expect(v435Cf("barter collabs").barter).toBe("barter");
    expect(v435Target("Apply to Nykaa with 5000")).toBe("Nykaa");
    expect(v435Target("apply kar do sab pe")).toBe("");
  });
  it("brand search parse (#9) and several requests in one message (#12)", () => {
    const f = v435Q("food bloggers under 5000 rupees");
    expect(f.minEr).toBe(0);
    expect(f.maxRate).toBe(5000);
    expect(v435Split("show my earnings and also find new campaigns and write my bio")?.length).toBe(3);
    expect(v435Split("find fashion and beauty creators", v435B)).toBeNull();
  });
  it("Eva and her cards have an error boundary; AI first try is capped (#1 #13)", () => {
    const fb = fs.readFileSync("src/components/feedback/FeedbackBot.jsx", "utf8");
    expect(fb).toMatch(/export class EvaBoundary/);
    expect(fb).toMatch(/<EvaBoundary resetKey=\{m\.id\}>/);
    const be = fs.readFileSync("backend/assist_routes.ts", "utf8");
    expect(be).toMatch(/AI_FIRST_MS = 8000/);
    expect(be).toMatch(/thinkingLevel: "LOW"/);
  });
});

// ── v438: Eva deep test ───────────────────────────────────────────────────────────────────────────────────
import { editRequest as v438Edit, editFallback as v438Fb, detectCreatorIntent as v438C } from "./components/assist/creator/creatorLogic";
describe("v438 Eva deep test", () => {
  it("messages typed before Eva loads wait for her (never a ticket); a failed load retries (#1)", () => {
    const fb = fs.readFileSync("src/components/feedback/FeedbackBot.jsx", "utf8");
    expect(fb).toMatch(/evaQueueRef\.current\.push/);
    expect(fb).toMatch(/if \(usesEva && !attach\?\.url\) \{ setInput\(""\); evaNotReady\(t, t\); return; \}/);
    expect(fb).toMatch(/recoverFromStaleBuild/);
    expect(fb).not.toMatch(/setBrandMod\(m\); \} \}\)\.catch\(\(\) => \{\}\)/);
  });
  it("follow-up edits are recognised (#6)", () => {
    for (const q of ["make it shorter", "make it funnier", "more polite", "hindi mein likho", "for Nykaa vitamin C serum"]) expect(v438Edit(q), q).toBe(true);
    for (const q of ["show campaigns for me", "what is escrow", "find fashion creators in Jaipur"]) expect(v438Edit(q), q).toBe(false);
    expect(v438Fb("One. Two. Three. Four.", "make it shorter")).toBe("One. Two.");
  });
  it("apply checks the profile first (#7), offline is said (#8), traps (#9)", () => {
    expect(fs.readFileSync("src/components/assist/creator/brain.js", "utf8")).toMatch(/Eva deep test #7/);
    expect(fs.readFileSync("src/components/feedback/FeedbackBot.jsx", "utf8")).toMatch(/You're offline — I'll answer as soon as you're back online/);
    expect(v438C("explain how ybex payments protect me")).toBeNull();
    expect(v438C("brand is offering 2000 for a reel, what should I reply")).toEqual({ intent: "brandReply" });
  });
});
describe("v443 shorter caption without AI", () => {
  it("keeps the first sentence and 4 hashtags", () => {
    const t = "Tried skincare so you don't have to 👀 Honest take in the reel — would you try it? Tell me below 👇\n#skincare #ootd #fashionreels #styleinspo #indianfashion #reels";
    const o = v438Fb(t, "make it shorter");
    expect(o.length).toBeLessThan(t.length);
    expect(o).toMatch(/#skincare #ootd #fashionreels #styleinspo$/);
  });
});
describe("v444 caption only + tour after Diwali screen", () => {
  it("a caption request asks for a caption only, and a kit is never shown as a caption", () => {
    const b = fs.readFileSync("src/components/assist/creator/brain.js", "utf8");
    expect(b).toMatch(/const capOnly = mode === "caption"/);
    expect(b).toMatch(/Write ONE Instagram caption/);
    expect(b).toMatch(/aiText && !refused && !kit \? aiText : fb/);
  });
  it("the tour waits for another app-open screen instead of giving up", () => {
    const w = fs.readFileSync("src/components/whatsNew/WhatsNewPopup.jsx", "utf8");
    expect(w).toMatch(/waitForNoPopup\(60000\)/);
    expect(w).not.toMatch(/if \(!live \|\| !claimAppOpenPopup\("tour"\)\) return giveUp\(\);/);
  });
});
