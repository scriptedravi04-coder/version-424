// v366 (Ravi: "baaki jo pending hai unhe bhi work karo"): the admin refund screens after the money fixes.
// RefundModal: a second refund after a fee-only refund ("Already refunded ₹800 · can still refund ₹10,000").
// UGC Refunds queue: brand paid / service fee / coupon on each row + a manual service-fee refund.
import { describe, it, expect, vi, beforeEach } from "vitest";
import React from "react";
import { render, screen, cleanup, fireEvent, waitFor } from "@testing-library/react";
const apiMock = vi.hoisted(() => ({ get: vi.fn(), post: vi.fn(), put: vi.fn() }));
vi.mock("../../lib/api", () => ({ api: apiMock }));
const toastMock = vi.hoisted(() => ({ success: vi.fn(), error: vi.fn() }));
vi.mock("sonner", () => ({ toast: toastMock }));
import RefundModal from "./RefundModal";
import AdminUgcRefundsTab from "./AdminUgcRefundsTab";

beforeEach(() => { cleanup(); apiMock.get.mockReset(); apiMock.post.mockReset(); toastMock.error.mockReset(); apiMock.get.mockResolvedValue({ data: {} }); });

const paid = { id: "t1", status: "SUCCESS", brand_id: "b1", gross_amount: 10000, platform_fee_amount: 0, creator_net_amount: 10000, brand_fee_pct: 8, brand_fee_amount: 800, brand_fee_gst: 0, brand_paid_amount: 10800 };

describe("v366 UI · RefundModal after an earlier refund", () => {
  it("fee refunded ₹800 → shows what is left, starts at ₹10,000 with empty reason / UTR, quick fills capped", () => {
    const tx = { ...paid, refund_status: "PROCESSED", refund_amount: 800, refund_reason: "goodwill", refund_reference: "UTR111111", fee_correction_note: "[service-fee refund] fee ₹800 · goodwill" };
    const { container } = render(<RefundModal transaction={tx} onClose={() => {}} />);
    expect(screen.getByTestId("refund-left").textContent).toContain("Already refunded ₹800 · can still refund ₹10,000");
    expect(screen.getByTestId("refund-left").textContent).toContain("₹800 of that was the service fee");
    expect(screen.getByText("Add another refund")).toBeTruthy();
    expect(container.querySelector("input[type=number]").value).toBe("10000");
    expect(container.querySelector("textarea").value).toBe("");
    expect(screen.getByPlaceholderText(/UPI\/602910481234/).value).toBe("");
    const qf = screen.getByTestId("refund-quick-fill").textContent;
    expect(qf).toContain("Everything still left · ₹10,000");
    expect(qf).toContain("Deal amount only · ₹10,000");
    expect(qf).not.toContain("Service fee only"); // the fee is used up
  });
  it("typing more than is left is stopped before anything is sent", async () => {
    const tx = { ...paid, refund_status: "PROCESSED", refund_amount: 800, fee_correction_note: "[service-fee refund] fee ₹800" };
    const { container } = render(<RefundModal transaction={tx} onClose={() => {}} />);
    fireEvent.change(container.querySelector("input[type=number]"), { target: { value: "10001" } });
    fireEvent.change(screen.getByPlaceholderText(/UPI\/602910481234/), { target: { value: "UTR222222" } });
    fireEvent.submit(container.querySelector("form"));
    expect(toastMock.error).toHaveBeenCalledWith("Already refunded ₹800 · only ₹10,000 can still be refunded.");
    expect(apiMock.post).not.toHaveBeenCalledWith("admin/transactions/t1/refund", expect.anything());
  });
  it("the deal part goes through as a new refund of ₹10,000", async () => {
    apiMock.post.mockResolvedValue({ data: { success: true, transaction: {} } });
    const tx = { ...paid, refund_status: "PROCESSED", refund_amount: 800, fee_correction_note: "[service-fee refund] fee ₹800" };
    const { container } = render(<RefundModal transaction={tx} onClose={() => {}} />);
    fireEvent.change(screen.getByPlaceholderText(/UPI\/602910481234/), { target: { value: "UTR333333" } });
    fireEvent.submit(container.querySelector("form"));
    fireEvent.click(await screen.findByText(/Confirm & mark as paid/));
    await waitFor(() => expect(apiMock.post).toHaveBeenCalledWith("admin/transactions/t1/refund", expect.objectContaining({ refund_amount: 10000, refund_from: "deal", refund_reference: "UTR333333", refund_status: "PROCESSED" })));
  });
  it("fully refunded → says so and the button is off", () => {
    const tx = { ...paid, status: "REFUNDED", refund_status: "PROCESSED", refund_amount: 10800, fee_correction_note: "[service-fee refund] fee ₹800" };
    render(<RefundModal transaction={tx} onClose={() => {}} />);
    expect(screen.getByTestId("refund-left").textContent).toMatch(/Fully refunded/);
    expect(screen.getByText(/Review & Process Refund/).closest("button").disabled).toBe(true);
  });
  it("nothing refunded yet → unchanged v365 screen", () => {
    render(<RefundModal transaction={paid} onClose={() => {}} />);
    expect(screen.queryByTestId("refund-left")).toBeNull();
    expect(screen.getByTestId("refund-quick-fill").textContent).toContain("Everything the brand paid · ₹10,800");
    expect(screen.getByText("Issue Manual Refund")).toBeTruthy();
  });
});

const queueRow = {
  id: "ugcref_1", brief_id: "brief1", brand_id: "b1", amount: 2000, slots: 1, status: "PENDING", reason: "Brand cancelled unused brief slots",
  refund_account_snapshot: { method_type: "UPI", upi_id: "brand@upi" }, requested_at: new Date().toISOString(), brief_title: "Serum video", brand_name: "Glow Co",
  is_fee_refund: false,
  fee_view: { brand_paid: 6240, deal_amount: 6000, service_fee: 240, fee_pct: 4, coupon_code: "DIWALI4", fee_refunded: 0, total_refunded: 2000, fee_left: 240, total_left: 4240 },
};

describe("v366 UI · Admin → UGC Refunds", () => {
  it("shows brand paid / service fee / coupon and adds a fee refund (amount + reason)", async () => {
    apiMock.get.mockResolvedValue({ data: [queueRow] });
    apiMock.post.mockResolvedValue({ data: { ok: true } });
    render(<AdminUgcRefundsTab />);
    const view = await screen.findByTestId("ugc-refund-fee-view");
    expect(view.textContent.replace(/\s+/g, " ")).toContain("Brand paid ₹6,240 · Service fee 4% ₹240 · Coupon DIWALI4");
    fireEvent.click(screen.getByTestId("ugc-fee-refund-open"));
    expect(screen.getByTestId("ugc-fee-refund-summary").textContent).toContain("Can still refund ₹240 of the fee");
    const amount = document.querySelector('input[max="240"]');
    expect(amount.value).toBe("240");
    fireEvent.change(amount, { target: { value: "300" } });
    fireEvent.submit(screen.getByText("Add fee refund").closest("form"));
    expect(toastMock.error).toHaveBeenCalledWith("Only ₹240 of the service fee can still be refunded.");
    fireEvent.change(amount, { target: { value: "140" } });
    fireEvent.change(screen.getByPlaceholderText(/Creator never delivered/), { target: { value: "creator late" } });
    fireEvent.submit(screen.getByText("Add fee refund").closest("form"));
    await waitFor(() => expect(apiMock.post).toHaveBeenCalledWith("/admin/ugc-refunds/fee", { brief_id: "brief1", amount: 140, reason: "creator late" }));
  });
  it("a fee refund row says so (not '1 open slot'); no button once the fee is used up", async () => {
    apiMock.get.mockResolvedValue({ data: [{ ...queueRow, id: "ugcref_fee_1", amount: 240, slots: 0, is_fee_refund: true, reason: "[service-fee refund] goodwill", fee_view: { ...queueRow.fee_view, fee_refunded: 240, fee_left: 0 } }] });
    render(<AdminUgcRefundsTab />);
    expect(await screen.findByText("Service fee refund")).toBeTruthy();
    expect(screen.getByText("goodwill")).toBeTruthy();
    expect(screen.queryByTestId("ugc-fee-refund-open")).toBeNull();
  });
});
