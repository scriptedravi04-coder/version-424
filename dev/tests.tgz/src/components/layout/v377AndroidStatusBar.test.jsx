// v377 (Ravi, Android screenshots: headers stuck under the clock; Home's string of lights squeezed).
import { describe, it, expect, vi, afterEach } from "vitest";
import fs from "fs";
import path from "path";
import { applyStatusBarColor } from "./StatusBarSync";
import { androidTopGap } from "../../lib/native";

const root = path.resolve(__dirname, "../../..");
const read = (p) => fs.readFileSync(path.join(root, p), "utf8");

afterEach(() => { delete window.Capacitor; });

describe("v377 · Android app status bar", () => {
  it("the Android app stops drawing the page under the clock", () => {
    const src = read("src/lib/native.js");
    expect(src).toMatch(/nativePlatform\(\) === "android"[\s\S]{0,200}setOverlaysWebView\?\.\(\{ overlay: false \}\)/);
  });
  it("the strip takes the page colour, with dark icons on a light page and light icons on a dark one", () => {
    const SB = { setBackgroundColor: vi.fn(), setStyle: vi.fn() };
    window.Capacitor = { isNativePlatform: () => true, getPlatform: () => "android", Plugins: { StatusBar: SB } };
    applyStatusBarColor("#ffffff");
    expect(SB.setBackgroundColor).toHaveBeenLastCalledWith({ color: "#ffffff" });
    expect(SB.setStyle).toHaveBeenLastCalledWith({ style: "LIGHT" });
    applyStatusBarColor("#7E00DC");
    expect(SB.setStyle).toHaveBeenLastCalledWith({ style: "DARK" });
  });
  it("website and iPhone: no status-bar plugin calls", () => {
    const SB = { setBackgroundColor: vi.fn(), setStyle: vi.fn() };
    window.Capacitor = { isNativePlatform: () => true, getPlatform: () => "ios", Plugins: { StatusBar: SB } };
    applyStatusBarColor("#ffffff");
    expect(SB.setBackgroundColor).not.toHaveBeenCalled();
  });
  it("Android 15+ (page still under the clock) → the app moves down; otherwise nothing moves", () => {
    expect(androidTopGap({ envTop: 0, innerHeight: 915, screenHeight: 915 })).toBe(28);
    expect(androidTopGap({ envTop: 0, innerHeight: 860, screenHeight: 915 })).toBe(0); // already below the strip
    expect(androidTopGap({ envTop: 32, innerHeight: 915, screenHeight: 915 })).toBe(0); // env() paddings work
    expect(read("src/index.css")).toMatch(/html\.yb-sb-fallback body \{ padding-top: var\(--yb-android-top/);
    const cfg = JSON.parse(read("android-app/capacitor.config.json"));
    expect(cfg.plugins.StatusBar.overlaysWebView).toBe(false); // next Play Store build: page below the clock from launch
  });
  it("Home's Diwali header has no string of lights", () => {
    expect(read("src/components/challenge/DiwaliHome.jsx")).not.toMatch(/<StringLights/);
  });
});
