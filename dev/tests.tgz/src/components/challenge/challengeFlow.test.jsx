// v367 deep test: the creator's taps, start to finish, with the server calls mocked.
import React from "react";
import { describe, it, expect, vi, afterEach, beforeEach } from "vitest";
import { render, screen, fireEvent, cleanup, waitFor, act } from "@testing-library/react";
import { MemoryRouter, Routes, Route, useLocation } from "react-router-dom";
import { STARTS_AT, ENTRIES_CLOSE_AT, RESULTS_AT } from "../../lib/diwaliChallenge";

const api = vi.hoisted(() => ({ me: null, pub: {}, stamps: {}, stampError: null, stampCalls: [] }));
vi.mock("../../lib/challengeApi", () => ({
  getMyChallenge: vi.fn(async () => api.me),
  getChallengePublic: vi.fn(async () => api.pub),
  remindMe: vi.fn(async () => { api.reminded = true; return true; }),
  getAdminReminders: vi.fn(async () => [{ name: "A", email: "a@x.com", phone: "", handle: "a", at: "" }]),
  stampEntries: vi.fn(async (items) => { api.stampCalls.push(items); if (api.stampError) throw api.stampError; return api.stamps; }),
  getAdminEntries: vi.fn(async () => []),
  getAdminEntriesData: vi.fn(async () => ({ entries: [], recharge_left: 300 })), // v377
  getNoReelCreators: vi.fn(async () => []), // v377
  reviewEntry: vi.fn(async () => ({ ok: true })), // v377
  setRechargeSent: vi.fn(async () => ({ ok: true })), // v377
  markWinner: vi.fn(async () => ({ ok: true })),
  getAdminConfig: vi.fn(async () => null),
  saveAdminConfig: vi.fn(async (c) => { api.savedCfg = c; return c; }),
  uploadChallengeFile: vi.fn(async (f, name) => (name === "reel-cover.jpg" ? "https://cdn.x/cover.jpg" : "https://cdn.x/reel.mp4")),
  MAX_REEL_MB: 30,
}));
vi.mock("../portfolio/portfolioApi", () => ({
  previewLink: vi.fn(async () => ({ id: "999", cover: "https://img/c.jpg", views: 1500, likes: 80, caption: "my reel\n#YbexDiwaliChallenge @ybex.in", brand: "" })),
  copyCovers: vi.fn(async () => ({})), uploadFile: vi.fn(), videoCoverBlob: vi.fn(async () => new Blob(["x"], { type: "image/jpeg" })), fetchIgMedia: vi.fn(async () => []),
}));
const auth = vi.hoisted(() => ({ user: null }));
vi.mock("../../contexts/AuthContext", () => ({ useAuth: () => ({ user: auth.user }) }));
vi.mock("sonner", () => ({ toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn() }) }));

import AddCollabsScreen from "../portfolio/AddCollabsScreen";
import ChallengePage from "../../pages/ChallengePage";
import { ChallengeHomeCard } from "./ChallengeUi";
import { toast } from "sonner";
import AdminChallengeEntries from "../admin/AdminChallengeEntries";

function Where() { const l = useLocation(); return <div data-testid="where">{l.pathname + l.search}</div>; }
const page = () => render(
  <MemoryRouter initialEntries={["/challenge"]}>
    <Routes><Route path="/challenge" element={<ChallengePage />} /><Route path="*" element={<Where />} /></Routes>
  </MemoryRouter>);

beforeEach(() => {
  vi.useFakeTimers({ toFake: ["Date"] }); vi.setSystemTime(new Date(STARTS_AT + 2 * 86400_000));
  Object.assign(api, { me: null, pub: { phase: "open", entries: 0, creators: 0, winners: [] }, stamps: {}, stampError: null, stampCalls: [] });
  auth.user = null;
  vi.mocked(toast.error).mockClear(); vi.mocked(toast.success).mockClear();
});
afterEach(() => { cleanup(); vi.useRealTimers(); });

async function pasteAndTag(brand = "Ybex") {
  fireEvent.change(screen.getByLabelText("Collab link"), { target: { value: "https://www.instagram.com/reel/ABCDE12/" } });
  await act(async () => { await new Promise((r) => setTimeout(r, 700)); });
  await waitFor(() => expect(screen.getByText("Found on your Instagram")).toBeTruthy());
  fireEvent.click(screen.getByText("Add this collab"));
  fireEvent.click(screen.getByText(/Next · tag brand/));
  fireEvent.change(screen.getByLabelText("Brand name"), { target: { value: brand } });
}

describe("v367 flow · Add collabs → toggle → stamp → save", () => {
  it("toggle ON: the server stamp is saved with the reel and the entry is reported", async () => {
    api.me = { phase: "open", is_creator: true, onboarded: true, left: 3 };
    api.stamps = { ig_999: { challenge: "diwali2026", challenge_at: "2026-10-23T10:00:00.000Z", challenge_sig: "sig" } };
    const onSave = vi.fn(async () => true);
    render(<AddCollabsScreen handle="" media={[]} existing={[]} onClose={() => {}} onSave={onSave} renderPicker={() => null} />);
    await pasteAndTag("Ybex");
    await waitFor(() => expect(screen.getByTestId("challenge-toggle")).toBeTruthy());
    fireEvent.click(screen.getByText(/Tag as Ybex & enter/));
    await waitFor(() => expect(onSave).toHaveBeenCalled());
    const [items, info] = onSave.mock.calls[0];
    expect(api.stampCalls[0][0]).toMatchObject({ id: "ig_999", content_url: "https://www.instagram.com/reel/ABCDE12/" });
    expect(items[0]).toMatchObject({ id: "ig_999", challenge: "diwali2026", challenge_sig: "sig", brand_name: "Ybex" });
    expect(items[0].enter).toBeUndefined();
    expect(info.entered).toEqual(["ig_999"]);
  });
  it("stamp refused (e.g. limit): the reel is still saved, not entered, and the creator is told why", async () => {
    api.me = { phase: "open", is_creator: true, onboarded: true, left: 3 };
    api.stampError = Object.assign(new Error("You've used all 3 entries."), { code: "LIMIT" });
    const onSave = vi.fn(async () => true);
    render(<AddCollabsScreen handle="" media={[]} existing={[]} onClose={() => {}} onSave={onSave} renderPicker={() => null} />);
    await pasteAndTag("Ybex");
    await waitFor(() => screen.getByTestId("challenge-toggle"));
    fireEvent.click(screen.getByText(/Tag as Ybex & enter/));
    await waitFor(() => expect(onSave).toHaveBeenCalled());
    expect(onSave.mock.calls[0][0][0].challenge).toBeUndefined();
    expect(onSave.mock.calls[0][1].entered).toEqual([]);
    expect(vi.mocked(toast.error).mock.calls[0][0]).toMatch(/not entered: You've used all 3 entries/);
  });
  it("after the close date there is no toggle and no stamp call", async () => {
    vi.setSystemTime(new Date(ENTRIES_CLOSE_AT + 1000));
    api.me = { phase: "judging", is_creator: true, onboarded: true, left: 3 };
    const onSave = vi.fn(async () => true);
    render(<AddCollabsScreen handle="" media={[]} existing={[]} onClose={() => {}} onSave={onSave} renderPicker={() => null} />);
    await pasteAndTag("Ybex");
    expect(screen.queryByTestId("challenge-toggle")).toBeNull();
    fireEvent.click(screen.getByText(/Tag 1 reel as Ybex/));
    await waitFor(() => expect(onSave).toHaveBeenCalled());
    expect(api.stampCalls).toHaveLength(0);
  });
});

describe("v367 flow · /challenge Join", () => {
  it("logged out → sign up as a creator; Log in link keeps /challenge", async () => {
    page();
    await waitFor(() => screen.getByTestId("challenge-join"));
    expect(screen.getByTestId("challenge-join").textContent).toBe("Join Challenge");
    fireEvent.click(screen.getByText("Log in"));
    expect(screen.getByTestId("where").textContent).toBe("/login?next=/challenge");
    cleanup(); page();
    fireEvent.click(await screen.findByTestId("challenge-join"));
    expect(screen.getByTestId("where").textContent).toBe("/signup?role=creator");
  });
  it("creator without a name / contact → onboarding", async () => {
    auth.user = { user_id: "c1", role: "creator", onboarded: false };
    api.me = { phase: "open", is_creator: true, onboarded: false, eligible: false, entries: [], left: 3 };
    page();
    await act(async () => {});
    fireEvent.click(screen.getByTestId("challenge-join"));
    expect(screen.getByTestId("where").textContent).toBe("/onboarding");
  });
  it("creator → 'Is your reel ready?' → Yes opens Portfolio Add; 3 entries → disabled", async () => {
    auth.user = { user_id: "c1", role: "creator", onboarded: false };
    api.me = { phase: "open", is_creator: true, onboarded: false, eligible: true, entries: [], left: 3 }; // basics are enough
    page(); await act(async () => {});
    fireEvent.click(screen.getByTestId("challenge-join"));
    expect(screen.getByTestId("reel-ready-sheet").textContent).toMatch(/Is your reel ready\?/);
    fireEvent.click(screen.getByTestId("reel-ready-yes"));
    expect(screen.getByTestId("where").textContent).toBe("/creator/settings?section=portfolio&add=1&diwali=1"); // v377: "Add your Diwali reel"
    cleanup();
    api.me = { ...api.me, entries: [{ no: 1 }, { no: 2 }, { no: 3 }], left: 0 };
    page(); await act(async () => {});
    expect(screen.getByTestId("challenge-join").textContent).toBe("All 3 entries used");
    expect(screen.getByTestId("challenge-join").disabled).toBe(true);
  });
  it("brand sees 'For creators only'; after 2 Nov 'Entries closed'", async () => {
    auth.user = { user_id: "b1", role: "brand", onboarded: true };
    page(); await act(async () => {});
    expect(screen.getByTestId("challenge-join").textContent).toBe("For creators only");
    cleanup(); auth.user = null;
    vi.setSystemTime(new Date(ENTRIES_CLOSE_AT + 5000));
    api.pub = { phase: "judging", now: ENTRIES_CLOSE_AT + 5000, entries: 40, creators: 30, winners: [] };
    page(); await act(async () => {});
    expect(screen.getByTestId("challenge-join").textContent).toBe("Entries closed");
    expect(screen.getByText("Entries are closed")).toBeTruthy();
  });
  it("5 Nov: winners show on the same page", async () => {
    vi.setSystemTime(new Date(RESULTS_AT + 5000));
    api.pub = { phase: "results", now: RESULTS_AT + 5000, entries: 40, creators: 30, winners: [{ rank: "1st", no: 7, name: "Ravi", handle: "elite_ravi", user_id: "c1", cover: "", content_url: "https://instagram.com/reel/AAAAA1", views: 9000, likes: 100 }] };
    page(); await act(async () => {});
    expect(screen.getByText("Winners")).toBeTruthy();
    expect(screen.getByText("Ravi")).toBeTruthy();
  });
  it("countdown uses the server clock, not a wrong phone clock", async () => {
    vi.setSystemTime(new Date(ENTRIES_CLOSE_AT + 86400_000)); // phone says 3 Nov
    api.pub = { phase: "open", now: ENTRIES_CLOSE_AT - 2 * 86400_000, entries: 0, creators: 0, winners: [] }; // server: 31 Oct
    page(); await act(async () => {});
    expect(screen.getByText("ENTRIES CLOSE IN")).toBeTruthy();
  });
});

describe("v367 flow · Home card", () => {
  const home = () => render(<MemoryRouter><ChallengeHomeCard /></MemoryRouter>);
  it("no entry → join card; entry → thumbnail, numbers, days left", async () => {
    api.me = { phase: "open", is_creator: true, onboarded: true, entries: [], left: 3 };
    home(); expect(await screen.findByTestId("challenge-join-card")).toBeTruthy();
    cleanup();
    api.me = { phase: "open", is_creator: true, onboarded: true, entries: [{ no: 4, item_id: "a", cover: "", views: 12000, likes: 340 }], left: 2 };
    home();
    const card = await screen.findByTestId("challenge-entry-card");
    expect(card.textContent).toMatch(/Entry #4/);
    expect(card.textContent).toMatch(/12,000/);
    expect(card.textContent).toMatch(/days left/);
  });
  it("hidden a week after results", async () => {
    vi.setSystemTime(new Date(RESULTS_AT + 8 * 86400_000));
    api.me = { phase: "over", is_creator: true, entries: [] };
    home(); await act(async () => {});
    expect(screen.queryByTestId("challenge-join-card")).toBeNull();
    expect(screen.queryByTestId("challenge-entry-card")).toBeNull();
  });
});

describe("v368 flow · /challenge shows the admin's sponsors, scripts and prizes", () => {
  it("Powered by logos + names, Brand scripts with copy, saved prizes", async () => {
    api.pub = { phase: "open", entries: 0, creators: 0, winners: [], config: {
      sponsors: [{ name: "Wefrnd", logo: "data:image/webp;base64,AAAA", scripts: ["Script one", "Script two"] }, { name: "ProRewards", logo: "", scripts: [] }],
      prizes: [{ title: "1st prize", value: "₹25,000 + iPhone", note: "" }] } };
    page(); await act(async () => {});
    expect(screen.getByTestId("powered-by").textContent).toContain("ProRewards");
    expect(screen.getByAltText("Wefrnd")).toBeTruthy();
    expect(screen.getByTestId("sponsor-scripts").textContent).toContain("Script two");
    expect(screen.getByText("₹25,000 + iPhone")).toBeTruthy();
    expect(screen.queryByText("₹12,000")).toBeNull(); // saved prizes replace the defaults
  });
  it("nothing saved → defaults, no Powered by line", async () => {
    page(); await act(async () => {});
    expect(screen.queryByTestId("powered-by")).toBeNull();
    expect(screen.getByText("₹20,000")).toBeTruthy(); // default ₹1,00,000 split
    expect(screen.getByTestId("prize-pool").textContent).toMatch(/₹1,00,000.*Prize pool.*50 winners.*Free entry/); // v377: Ravi's v3 hero (big amount, "Free entry")
  });
});

describe("v368 flow · Admin → Sponsors & prizes", () => {
  it("name + script typed once → saved for every place", async () => {
    render(<MemoryRouter><AdminChallengeEntries /></MemoryRouter>);
    fireEvent.click(await screen.findByTestId("open-sponsors"));
    const name = await screen.findByLabelText("Sponsor 1 name");
    fireEvent.change(name, { target: { value: "Wefrnd" } });
    fireEvent.change(screen.getByLabelText("Sponsor 1 script 1"), { target: { value: "Show a real friend in 15s" } });
    fireEvent.click(screen.getByText("Add script"));
    fireEvent.change(screen.getByLabelText("Sponsor 1 script 2"), { target: { value: "  " } });
    fireEvent.change(screen.getByLabelText("Prize 1 value"), { target: { value: "₹25,000" } });
    fireEvent.click(screen.getByText("Save everywhere"));
    await waitFor(() => expect(api.savedCfg).toBeTruthy());
    expect(api.savedCfg.sponsors).toEqual([{ name: "Wefrnd", logo: "", scripts: ["Show a real friend in 15s"] }]);
    expect(api.savedCfg.prizes[0]).toMatchObject({ title: "1st prize", value: "₹25,000" });
  });
  it("two sponsors with the same name are stopped", async () => {
    render(<MemoryRouter><AdminChallengeEntries /></MemoryRouter>);
    fireEvent.click(await screen.findByTestId("open-sponsors"));
    fireEvent.change(await screen.findByLabelText("Sponsor 1 name"), { target: { value: "Wefrnd" } });
    fireEvent.click(screen.getByText("Add sponsor"));
    fireEvent.change(screen.getByLabelText("Sponsor 2 name"), { target: { value: "wefrnd" } });
    api.savedCfg = null;
    fireEvent.click(screen.getByText("Save everywhere"));
    expect(await screen.findByText("Two sponsors have the same name.")).toBeTruthy();
    expect(api.savedCfg).toBeNull();
  });
});

describe("v369 flow · dates set in Admin drive the page", () => {
  it("/challenge shows the admin's close + results dates", async () => {
    const closes = Date.parse("2026-11-20T18:29:59Z"), results = Date.parse("2026-11-22T18:30:00Z");
    api.pub = { phase: "open", entries: 0, creators: 0, winners: [], closes_at: closes, results_at: results };
    page(); await act(async () => {});
    expect(screen.getByText(/Entries close 20 Nov, 11:59 PM · Winners on 23 Nov/)).toBeTruthy();
  });
  it("Admin: pick 'Close in 14 days' → saved with the dates", async () => {
    render(<MemoryRouter><AdminChallengeEntries /></MemoryRouter>);
    fireEvent.click(await screen.findByTestId("open-sponsors"));
    await screen.findByTestId("challenge-dates");
    fireEvent.click(screen.getByText("Close in 14 days"));
    api.savedCfg = null;
    fireEvent.click(screen.getByText("Save everywhere"));
    await waitFor(() => expect(api.savedCfg).toBeTruthy());
    const c = Date.parse(api.savedCfg.closes_at), r = Date.parse(api.savedCfg.results_at);
    expect(Math.round((c - Date.now()) / 86400_000)).toBeGreaterThanOrEqual(14);
    expect(new Date(c + 5.5 * 3600_000).toISOString().slice(11, 19)).toBe("23:59:59"); // 11:59 PM India
    expect(r).toBeGreaterThan(c);
  });
});

describe("v371 flow · example reels", () => {
  it("/offer plays the admin's example reels (muted, on a loop)", async () => {
    api.pub = { phase: "open", entries: 0, creators: 0, winners: [], config: { reels: [{ url: "https://cdn.x/a.mp4", poster: "https://cdn.x/a.jpg", caption: "How I got my first deal" }, { url: "https://cdn.x/b.mp4" }] } };
    page(); await act(async () => {});
    const vids = screen.getByTestId("example-reels").querySelectorAll("video");
    expect(vids).toHaveLength(2);
    expect(vids[0].getAttribute("src")).toBe("https://cdn.x/a.mp4");
    expect(vids[0].muted).toBe(true);
    expect(vids[0].loop).toBe(true);
    expect(screen.getByText("How I got my first deal")).toBeTruthy();
  });
  it("no reels saved → no section", async () => {
    page(); await act(async () => {});
    expect(screen.queryByTestId("example-reels")).toBeNull();
  });
  it("Admin: upload a reel → cover made → saved with caption; too big / wrong type refused", async () => {
    render(<MemoryRouter><AdminChallengeEntries /></MemoryRouter>);
    fireEvent.click(await screen.findByTestId("open-sponsors"));
    const input = await screen.findByLabelText("Upload example reel");
    const big = new File(["x"], "big.mp4", { type: "video/mp4" }); Object.defineProperty(big, "size", { value: 40 * 1048576 });
    fireEvent.change(input, { target: { files: [big] } });
    expect(vi.mocked(toast.error).mock.calls.at(-1)[0]).toMatch(/under 30 MB/);
    fireEvent.change(input, { target: { files: [new File(["x"], "a.gif", { type: "image/gif" })] } });
    expect(vi.mocked(toast.error).mock.calls.at(-1)[0]).toMatch(/MP4 or MOV/);
    fireEvent.change(input, { target: { files: [new File(["x"], "ok.mp4", { type: "video/mp4" })] } });
    const cap = await screen.findByLabelText("Reel 1 caption");
    fireEvent.change(cap, { target: { value: "My Ybex story" } });
    api.savedCfg = null;
    fireEvent.click(screen.getByText("Save everywhere"));
    await waitFor(() => expect(api.savedCfg).toBeTruthy());
    expect(api.savedCfg.reels).toEqual([{ url: "https://cdn.x/reel.mp4", poster: "https://cdn.x/cover.jpg", caption: "My Ybex story" }]);
  });
});

describe("v371 flow · trust, social proof, remind me", () => {
  it("'Not yet — remind me' saves the reminder and says when", async () => {
    auth.user = { user_id: "c1", role: "creator", onboarded: true };
    api.me = { phase: "open", is_creator: true, onboarded: true, eligible: true, entries: [], left: 3 };
    api.reminded = false;
    page(); await act(async () => {});
    fireEvent.click(screen.getByTestId("challenge-join"));
    fireEvent.click(screen.getByTestId("reel-ready-later"));
    await waitFor(() => expect(api.reminded).toBe(true));
    expect(vi.mocked(toast.success).mock.calls.at(-1)[0]).toMatch(/We'll remind you before entries close on \d+ \w+/);
    expect(screen.queryByTestId("reel-ready-sheet")).toBeNull();
  });
  // v377 (Ravi, "Diwali Challenge v2"): live counters on /offer — "X creators entered" and "₹50 recharge: X of 300 left" (v377 later: Ravi switched the ₹50 from mobile recharge to UPI cash)
  // (the v371 rule "hide small counts" is replaced). The "N entries so far" line under the countdown still waits for 50.
  it("live counters: creators entered + ₹50 recharge left; the pinned bar shows the recharge line", async () => {
    api.pub = { phase: "open", entries: 7, creators: 5, winners: [], recharge_left: 295 };
    page(); await act(async () => {});
    expect(screen.getByTestId("recharge-counter").textContent).toMatch(/₹300 FREE CASH.*Only 295 left/); // v377: v3 hero card · v378: Ravi changed the amount to ₹300
    expect(screen.getByTestId("joined-count").textContent).toBe("5 creators already joined");
    expect(screen.queryByText(/entries so far/)).toBeNull();
    expect(screen.getByTestId("pinned-recharge").textContent).toMatch(/₹300 UPI cash for the first 300 · 295 left/);
    cleanup();
    api.pub = { phase: "open", entries: 0, creators: 0, winners: [] };
    page(); await act(async () => {});
    expect(screen.getByTestId("recharge-counter").textContent).toMatch(/Only 300 left/);
    expect(screen.getByTestId("joined-count").textContent).toBe("Be one of the first 300");
  });
  it("everyone-wins box, how-you-get-paid and the questions are on the page (admin text wins)", async () => {
    api.pub = { phase: "open", entries: 0, creators: 0, winners: [], config: { everyone: "Every valid entry gets a Ybex creator kit." } };
    page(); await act(async () => {});
    expect(screen.getByTestId("everyone-wins").textContent).toMatch(/Everyone who enters wins.*creator kit/);
    expect(screen.getByTestId("trust").textContent).toMatch(/Straight to your bank/);
    expect(screen.getByTestId("faq").textContent).toMatch(/Is it free to join\?/i);
    expect(screen.getByTestId("faq").textContent).toMatch(/Does my reel have to be about Ybex\?.*Any reel of your own works/i); // v377: first question, open
    fireEvent.click(screen.getByText("Do I need a lot of followers?"));
    expect(screen.getByText(/not on follower count/)).toBeTruthy();
  });
});
