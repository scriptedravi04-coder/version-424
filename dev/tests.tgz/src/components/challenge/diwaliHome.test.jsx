// v372: Diwali Home skin (design 2b / 2n) — shows only till Diwali night; brand line makes no fee promise;
// the banner slot stays Admin → Banners; "Powered by" comes from Admin → Sponsors & prizes.
import React from "react";
import { describe, it, expect, vi, afterEach } from "vitest";
import { render, screen, cleanup, waitFor } from "@testing-library/react";
import fs from "fs";
import { STARTS_AT, FESTIVE_UNTIL } from "../../lib/diwaliChallenge";

const pub = vi.hoisted(() => ({ value: { phase: "open", config: { sponsors: [{ name: "Wefrnd", logo: "https://x/w.png" }, { name: "Gutargoo" }] } } }));
vi.mock("../../lib/challengeApi", () => ({ getChallengePublic: vi.fn(async () => pub.value) }));
import { diwaliOn, DhamakaTitle, DiwaliPoweredBy, BRAND_LINE } from "./DiwaliHome";

afterEach(() => { cleanup(); vi.useRealTimers(); });

describe("v372 · Diwali Home skin", () => {
  it("on from the start till Diwali night, off after", () => {
    expect(diwaliOn(STARTS_AT + 1000)).toBe(true);
    expect(diwaliOn(FESTIVE_UNTIL + 1000)).toBe(false);
  });
  it("brand line promises no zero commission (brands pay the 8% fee)", () => {
    expect(BRAND_LINE).not.toMatch(/commission|0%/i);
    render(<DhamakaTitle line={BRAND_LINE} />);
    expect(screen.getByText("Diwali Dhamaka")).toBeTruthy();
  });
  it("Powered by = the Admin sponsors (logo, or the name when there is no logo)", async () => {
    vi.useFakeTimers({ toFake: ["Date"] }); vi.setSystemTime(new Date(STARTS_AT + 2 * 86400_000));
    render(<DiwaliPoweredBy />);
    await waitFor(() => expect(screen.getByTestId("diwali-powered-by")).toBeTruthy());
    expect(screen.getByAltText("Wefrnd")).toBeTruthy();
    expect(screen.getByText("Gutargoo")).toBeTruthy();
  });
  it("Home banner slot is still the Admin banner carousel (nothing hardcoded)", () => {
    for (const f of ["src/pages/creator/CreatorHomeMobile.jsx", "src/pages/brand/BrandHomeMobile.jsx"]) {
      const src = fs.readFileSync(f, "utf8");
      expect(src).not.toMatch(/\{!festive && banners\.length/);
      expect(src).toMatch(/banners\.length > 0 && activeBanner/);
    }
  });
});

import { shouldShowEntry } from "./DiwaliEntryScreen";
describe("v372 · opening poster (design 2l)", () => {
  const pubOpen = { phase: "open" };
  const now = STARTS_AT + 2 * 86400_000;
  it("creators only, once per app open, never on /challenge or login, only while entries are open", () => {
    expect(shouldShowEntry({ user: { role: "creator" }, path: "/dashboard", pub: pubOpen, now, alreadySeen: false })).toBe(true);
    expect(shouldShowEntry({ user: { role: "creator" }, path: "/dashboard", pub: pubOpen, now, alreadySeen: true })).toBe(false);
    expect(shouldShowEntry({ user: { role: "brand" }, path: "/dashboard", pub: pubOpen, now, alreadySeen: false })).toBe(false);
    expect(shouldShowEntry({ user: null, path: "/dashboard", pub: pubOpen, now, alreadySeen: false })).toBe(false);
    expect(shouldShowEntry({ user: { role: "creator" }, path: "/challenge", pub: pubOpen, now, alreadySeen: false })).toBe(false);
    expect(shouldShowEntry({ user: { role: "creator" }, path: "/dashboard", pub: null, now, alreadySeen: false })).toBe(false);
    expect(shouldShowEntry({ user: { role: "creator" }, path: "/dashboard", pub: pubOpen, now: FESTIVE_UNTIL + 40 * 86400_000, alreadySeen: false })).toBe(false);
  });
});
