import { describe, it, expect, vi, beforeEach } from "vitest";
import { trackServerEvent } from "./lib/metaPixel";

describe("v395 QualifiedCreator Pixel half", () => {
  beforeEach(() => { window.fbq = vi.fn(); window.gtag = vi.fn(); });
  it("fires a custom Pixel event with value = 1 (v412) and the server's event id", () => {
    trackServerEvent({ name: "QualifiedCreator", event_id: "qc_u1", followers: 5400 });
    expect(window.fbq).toHaveBeenCalledWith("trackCustom", "QualifiedCreator",
      { value: 1, currency: "INR", followers_count: 5400, content_name: "creator" }, { eventID: "qc_u1" });
    expect(window.gtag).toHaveBeenCalledWith("event", "qualified_creator", expect.objectContaining({ value: 1 }));
  });
  it("ignores anything else", () => {
    trackServerEvent(null);
    trackServerEvent({ name: "Other", event_id: "x", followers: 5 });
    trackServerEvent({ name: "QualifiedCreator", followers: 5 });
    expect(window.fbq).not.toHaveBeenCalled();
  });
});
