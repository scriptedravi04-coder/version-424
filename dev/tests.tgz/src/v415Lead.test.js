import { describe, it, expect } from "vitest";
import fs from "fs";
import { deliverablesLabel, deliverableItemLabel } from "./utils/safeFormat";

const read = (p) => fs.readFileSync(p, "utf8");

describe("v415 lead fixes (brand panel)", () => {
  it("deliverables never print [object Object]", () => {
    expect(deliverablesLabel([{ type: "Reel", count: 1 }])).toBe("Reel");
    expect(deliverablesLabel([{ type: "Reel", count: 2 }, "1 Story"])).toBe("2 × Reel, 1 Story");
    expect(deliverablesLabel('[{"type":"Reel","count":1}]')).toBe("Reel");
    expect(deliverablesLabel("1 Reel + 2 stories")).toBe("1 Reel + 2 stories");
    expect(deliverablesLabel(null)).toBe("");
    expect(deliverableItemLabel({ type: "Story", count: 3 })).toBe("3 × Story");
  });
  it("desktop dashboard campaign list can't crash on object deliverables", () => {
    expect(read("src/components/campaigns/CampaignMiniList.jsx")).toContain("deliverableItemLabel(");
  });
  it("dashboard direct reads can't hold the page on skeletons", () => {
    const s = read("src/components/dashboard/BrandDashboard.jsx");
    expect(s.match(/Promise\.race\(/g)?.length).toBeGreaterThanOrEqual(2);
  });
  it("brands get a calm notification prompt and no takeover when blocked", () => {
    const s = read("src/components/push/PushPermissionScreen.jsx");
    expect(s).toContain('<Sticker calm={role === "brand"} />');
    expect(s).toContain('!(role === "brand" && blocked)');
  });
  it("long UGC countdowns show days", () => {
    expect(read("src/pages/brand/BrandUGCOrders.jsx")).toContain("Math.floor(hours / 24)}d");
  });
  it("no 'Instant Settlement' / 'Total Payment Hold Deposit' in the fee breakup", () => {
    const s = read("src/components/payments/FeeBreakup.jsx");
    expect(s).not.toContain("Instant Settlement");
    expect(s).not.toContain("Total Payment Hold Deposit");
  });
  it("draft campaigns keep an empty budget", () => {
    expect(read("backend/campaigns_routes.ts")).toContain('(isDraftSave ? null : 2000)');
  });
});
