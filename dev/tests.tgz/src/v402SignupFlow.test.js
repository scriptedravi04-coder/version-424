// @vitest-environment jsdom
import { describe, it, expect, vi, beforeEach } from "vitest";
import fs from "node:fs";

// v402 (Ravi 4 Nov): Join = Instagram username first → (500+) Google / email / WhatsApp → photo + name → Home.
const read = (p) => fs.readFileSync(new URL(p, import.meta.url), "utf8");
vi.mock("./lib/api", () => ({ api: { post: vi.fn(), get: vi.fn(() => Promise.resolve({ data: { min: 500 } })) } }));

describe("v402 Instagram check before the account", () => {
  beforeEach(() => { localStorage.clear(); vi.resetModules(); });
  it("ok / low / unverified / unknown", async () => {
    const { api } = await import("./lib/api");
    const { checkInstagram } = await import("./lib/signupPrecheck");
    api.post.mockResolvedValueOnce({ data: { stats: { followers: 1200, name: "Riya" } } });
    expect((await checkInstagram("@Riya.X")).state).toBe("ok");
    api.post.mockResolvedValueOnce({ data: { stats: { followers: 120 } } });
    expect((await checkInstagram("riya.x")).state).toBe("low");
    api.post.mockRejectedValueOnce({ response: { status: 404, data: { code: "NOT_PROFESSIONAL" } } });
    expect((await checkInstagram("riya.x")).state).toBe("unverified");
    api.post.mockRejectedValueOnce({ response: { status: 429, data: { code: "RATE_LIMIT" } } });
    expect((await checkInstagram("riya.x")).state).toBe("unknown");
    expect((await checkInstagram("bad*name")).state).toBe("invalid");
  });
  it("hints under the username box", async () => {
    const { IG_HINTS } = await import("./lib/signupPrecheck");
    expect(IG_HINTS.join(" ")).toMatch(/no password/i);
    expect(IG_HINTS.join(" ")).toMatch(/Trusted by 3,000\+ creators/);
  });
});

describe("v402 photo + name after a new account", () => {
  it("a just-made creator goes to the photo step first, then where they were going", async () => {
    const { afterSignupPath, PHOTO_STEP } = await import("./lib/afterSignup");
    const u = { user_id: "u1", role: "creator" };
    expect(afterSignupPath(u, "", { justCreated: true })).toBe(`${PHOTO_STEP}?then=${encodeURIComponent("/dashboard")}`);
    expect(afterSignupPath(u, "")).toBe("/dashboard"); // a login, not a new account
    expect(afterSignupPath({ user_id: "b", role: "brand" }, "", { justCreated: true })).not.toMatch(/app\/photo/);
  });
  it("name never starts as @handle or an email; the step has Back only, no step label / Exit", async () => {
    const { startName, compactReach } = await import("./pages/app/AppPhotoStep");
    expect(startName({ name: "Riya Sharma" }, { name: "@riya" })).toBe("Riya Sharma");
    expect(startName(null, { name: "@riya" })).toBe("");
    expect(startName(null, { name: "a@b.com" })).toBe("");
    expect(compactReach(84200)).toBe("84K");
    expect(compactReach(120000)).toBe("1.2L");
    const src = read("./pages/app/AppPhotoStep.jsx");
    expect(src).toMatch(/creators\/home-picks/);
    expect(src).not.toMatch(/creators\/explore/);
    expect(src).not.toMatch(/>\s*Step \d of \d\s*</); expect(src).not.toMatch(/>\s*Exit\s*</);
    expect(src).toMatch(/Clear photo = more brand deals/);
    expect(read("./App.jsx")).toMatch(/path="\/app\/photo"/);
    expect(read("./pages/app/AppContinue.jsx")).toMatch(/<CreatorIgFirst/);
  });
});
