import { describe, it, expect } from "vitest";
import fs from "node:fs";
import { socialProfileUrl, kycSubmitted } from "./components/admin/KYCManager";
import { handleFromInput } from "./components/onboarding/Step1_Identity";
import { desktopEvaVisible } from "./components/feedback/DesktopEva";
import { blockingModalOpen } from "./components/dashboard/TourRunner";

// v403 (Ravi 4 Nov): KYC admin page, IG link paste, Eva on desktop, desktop layouts for phone-first screens.
const read = (p) => fs.readFileSync(new URL(p, import.meta.url), "utf8");

describe("v403 KYC admin page", () => {
  it("Instagram handle becomes a link", () => {
    expect(socialProfileUrl("@riya.eats")).toBe("https://instagram.com/riya.eats");
    expect(socialProfileUrl("instagram.com/riya")).toBe("https://instagram.com/riya");
    expect(socialProfileUrl("https://www.youtube.com/@riya")).toBe("https://www.youtube.com/@riya");
    expect(socialProfileUrl("")).toBeFalsy();
  });
  it("no KYC documents → not 'submitted' (no Approve button)", () => {
    expect(kycSubmitted({ status: "PENDING" })).toBe(false);
    expect(kycSubmitted({ pan_number: "ABCDE1234F" })).toBe(true);
    expect(kycSubmitted({ data: { pan_card_url: "x.jpg" } })).toBe(true);
  });
  it("detail page has 'View complete profile' and hides Approve until KYC is sent", () => {
    const s = read("./components/admin/KYCManager.jsx");
    expect(s).toMatch(/kyc-view-profile/);
    expect(s).toMatch(/kyc-not-submitted/);
  });
});

describe("v403 onboarding: pasted Instagram link", () => {
  it("keeps the username, not 'httpsinstagram.com…'", () => {
    expect(handleFromInput("https://www.instagram.com/riya.eats/?igsh=abc")).toBe("riya.eats");
    expect(handleFromInput("@Riya.Eats")).toBe("riya.eats");
  });
});

describe("v403 desktop", () => {
  it("Eva shows for a creator who never did onboarding", () => {
    expect(desktopEvaVisible("/dashboard", { role: "creator", onboarded: false })).toBe(true);
    expect(desktopEvaVisible("/onboarding", { role: "creator" })).toBe(false);
  });
  it("tour waits while another modal is open", () => {
    document.body.innerHTML = '<div role="dialog" aria-modal="true">terms</div>';
    expect(blockingModalOpen(document)).toBe(true);
    document.body.innerHTML = "";
    expect(blockingModalOpen(document)).toBe(false);
  });
  it("push ask, Diwali screen, promo poster and refer page have desktop layouts", () => {
    expect(read("./components/push/PushPermissionScreen.jsx")).toMatch(/md:max-w-\[440px\]/);
    expect(read("./components/challenge/DiwaliEntryScreen.jsx")).toMatch(/\.ybx-dw-root\{inset:auto/);
    expect(read("./components/promo/PromoPopup.jsx")).toMatch(/\.ybx-promo-fs\{inset:auto/);
    expect(read("./components/referral/ReferralHub.jsx")).toMatch(/lg:grid-cols-\[minmax\(0,1fr\)_360px\]/);
  });
});

describe("v404 Diwali poster", () => {
  it("has no 'Entries close in…' countdown line", () => {
    const s = read("./components/challenge/DiwaliEntryScreen.jsx");
    expect(s).not.toMatch(/data-testid="entry-countdown"|Entries close in \{/);
  });
});
