// v415: mobile brand profile / settings match the desktop verification vocabulary; invoice PDF wording.
import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";
import { brandVerificationBadge } from "./components/profile/mobile/BrandProfileMobile";

const read = (p) => fs.readFileSync(path.join(process.cwd(), p), "utf8");
const SRC = "src/components/profile/mobile/BrandProfileMobile.jsx";

describe("brandVerificationBadge — same words as desktop", () => {
  it("maps every status to the shared vocabulary", () => {
    expect(brandVerificationBadge("approved").label).toBe("Verified");
    expect(brandVerificationBadge("APPROVED").label).toBe("Verified");
    expect(brandVerificationBadge("pending").label).toBe("Under review");
    expect(brandVerificationBadge("under_review").label).toBe("Under review");
    expect(brandVerificationBadge("submitted").label).toBe("Under review");
    expect(brandVerificationBadge("rejected").label).toBe("Needs changes");
    expect(brandVerificationBadge("MORE_INFO_NEEDED").label).toBe("More info needed");
    expect(brandVerificationBadge("more_info").label).toBe("More info needed");
    expect(brandVerificationBadge("needs_info").label).toBe("More info needed");
    expect(brandVerificationBadge(null).label).toBe("Verification pending");
    expect(brandVerificationBadge("").label).toBe("Verification pending");
  });
  it("tones: green verified, red needs changes, calm grey pending", () => {
    expect(brandVerificationBadge("approved").tone).toContain("emerald"); // v430: one green (emerald) app-wide
    expect(brandVerificationBadge("rejected").tone).toContain("red");
    expect(brandVerificationBadge(undefined).tone).toContain("slate");
    expect(brandVerificationBadge("pending").tone).toContain("amber");
  });
});

describe("BrandProfileMobile copy + layout", () => {
  const s = read(SRC);
  it("no old KYC wording", () => {
    for (const old of ["KYC Approved", "KYC under review", "KYC: action needed", "KYC rejected", "KYC not done",
      "Settings &amp; Brand Hub", "Finish KYC for Verified Brand Status", "Start KYC Verification", "Payment Hold", "KYC compliance"]) {
      expect(s).not.toContain(old);
    }
  });
  it("header says Settings; calm Verify your brand card with one primary button", () => {
    expect(s).toContain('<p className="text-[11px] font-bold text-slate-500">Settings</p>');
    expect(s).toContain('data-testid="brand-verify-card"');
    expect(s).toContain('"Verify your brand"}');
    expect(s).toContain("View public profile");
    expect(s).toContain("Company details");
  });
  it("reserves the verification card's space while loading (CLS)", () => {
    expect(s).toContain('data-testid="brand-kyc-skeleton"');
    expect(s).toContain("{kycLoading && (");
    expect(s).toContain("readKycCache(kycUid)");
  });
  it("sheets lock scroll, close on Escape, have dialog role and a labelled close button", () => {
    expect(s).toContain("useScrollLock(showLogoutModal || showAgencySheet);");
    expect(s).toContain('e.key !== "Escape"');
    expect(s).toContain('aria-labelledby="brand-logout-title"');
    expect(s).toContain('aria-labelledby="brand-agency-title"');
    expect(s).toMatch(/aria-label="Close"[\s\S]*?w-10 h-10/);
  });
});

describe("invoice PDF wording", () => {
  const t = read("src/utils/invoicePdf.js");
  it("uses 'Ybex escrow protection — Included' like the receipt, no insurance / secured seal", () => {
    expect(t).toContain('doc.text("Ybex escrow protection", L + 1, rowY);'); // v419 redesign
    expect(t).toContain('doc.text("Included", R - 11, rowY, { align: "center" });');
    expect(t).not.toMatch(/Insurance"|100% Secured|SECURE PAYMENT HOLD|SAFETY TRUST SEAL|Secure payment hold"/);
  });
});
