import { describe, it, expect } from "vitest";
import { readFileSync } from "fs";
import { dealTrackerStep, dealTrackerNext, DEAL_TRACK_STEPS } from "./components/chat/dealState";

describe("v418 · deal step tracker (Deal menu)", () => {
  it("maps deal flags to the right step", () => {
    expect(DEAL_TRACK_STEPS).toEqual(["Offer", "Sign", "Pay", "Draft", "Live", "Payout"]);
    expect(dealTrackerStep({}, {})).toBe(0);
    expect(dealTrackerStep({}, { isDealFixed: true })).toBe(1);
    expect(dealTrackerStep({}, { isAgreementSigned: true })).toBe(2);
    expect(dealTrackerStep({}, { isPaymentFunded: true })).toBe(3);
    expect(dealTrackerStep({}, { isContentApproved: true, isPaymentFunded: true })).toBe(4);
    expect(dealTrackerStep({}, { isLiveLinksSubmitted: true })).toBe(5);
    expect(dealTrackerStep({ status: "COMPLETED" }, {})).toBe(6);
    expect(dealTrackerStep({}, { isCancelled: true })).toBe(-1);
    expect(dealTrackerStep({}, { isUgcOrder: true })).toBe(-1);
  });
  it("says what happens next for each side", () => {
    expect(dealTrackerNext(3, true)).toBe("Creator sends the draft for your review");
    expect(dealTrackerNext(3, false)).toBe("Send your draft for review");
    expect(dealTrackerNext(6, true)).toBe("Deal completed");
    expect(dealTrackerNext(-1, true)).toBe("");
  });
  it("lives in the Deal menu, not as a strip under the chat header", () => {
    const m = readFileSync("src/components/chat/BurgerMenuSupport.jsx", "utf8");
    expect(m).toContain('data-testid="deal-step-tracker"');
    expect(readFileSync("src/components/chat/ChatBox.jsx", "utf8")).not.toContain("deal-step-tracker");
    expect(readFileSync("src/components/chat/mobile/ChatBoxMobile.jsx", "utf8")).not.toContain("deal-step-tracker");
  });
});
