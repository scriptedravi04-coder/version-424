// v414: deal page, My Deals list, deal drawer and deal stats — money / status wording and actions.
import { describe, it, expect } from "vitest";
import React from "react";
import { readFileSync } from "fs";
import path from "path";
import { render, screen } from "@testing-library/react";
import DealSummaryStats from "./components/deals/DealSummaryStats";

const read = (f) => readFileSync(path.resolve(process.cwd(), f), "utf8");
const detail = read("src/pages/collabs/DealDetail.jsx");
const collabs = read("src/pages/collabs/Collabs.jsx");
const drawer = read("src/components/deals/DealDetailDrawer.jsx");

describe("v414 DealDetail", () => {
  it("1: Pay card hidden once paid (escrow_hold / payment_funded / escrow_hold_at), cancelled or past active", () => {
    expect(detail).toContain("deal.payment_funded === true");
    expect(detail).toContain("(deal.escrow_hold_at || deal.escrow_held_at) && deal.escrow_hold !== false");
    expect(detail).toMatch(/const showPayCard = !isFundedDeal && !isCancelledDeal && !isPastActiveStage/);
    expect(detail).toMatch(/deal\.agreement_signed_brand && showPayCard/);
    expect(detail).not.toContain("deal.status !== 'FUNDED' && deal.status !== 'IN_PROGRESS'");
  });
  it("2: cancelled / refunded deal shows one card and hides all actions", () => {
    expect(detail).toContain('["CANCELLED", "CANCELED", "REFUNDED"].includes(statusUpper)');
    expect(detail).toContain("Deal cancelled");
    const gated = detail.match(/!isCancelledDeal \/\* v414 \*\//g) || [];
    expect(gated.length).toBeGreaterThanOrEqual(6); // sign, draft, review, approved, proof, promo
  });
  it("10: no 'money is held' wording before the brand pays", () => {
    expect(detail).toContain("Once the brand pays, Ybex holds the money safely until the work is approved.");
    // v416 (QA U32): plain wording, still only when the deal is paid
    expect(detail).toMatch(/isFundedDeal \? "The payment is held by Ybex\."/);
    expect(detail).toMatch(/isFundedDeal \? "The held amount" : "The deal amount"/);
    expect(detail).toMatch(/isFundedDeal \? "Your payment is held by Ybex until you approve the work\."/);
  });
});

describe("v414 My Deals list (Collabs.jsx)", () => {
  it("3: approved / proof don't say Payment Cleared; paid only with a UTR", () => {
    expect(collabs).not.toContain("'Payment Cleared'");
    expect(collabs).toContain("Draft approved · post live link");
    expect(collabs).toContain("Live link under review");
    expect(collabs).toContain("Approved · payout in 1–2 working days");
    expect(collabs).toMatch(/payoutUtr \? \(isBrand \? 'Creator paid' : 'Paid to bank'\)/); // v415: brand wording
  });
  it("4: Revision Requested uses only the latest submission", () => {
    expect(collabs).not.toContain("content_submissions?.some(s => s.status === 'CHANGES_REQUESTED')");
    expect(collabs).toContain("x?.submitted_at || x?.created_at");
    expect(collabs).toContain("const latestAskedChanges");
  });
  it("7: drawer submit goes through the deal chat, legacy only when no thread (404)", () => {
    expect(collabs).toContain("api.get(`/chat/v2/threads/${encodeURIComponent(dealId)}`)");
    expect(collabs).toContain("/submit-content`, {");
    expect(collabs).toContain("video_url: videoUrl, content_url: videoUrl");
    expect(collabs).toContain("err?.response?.status !== 404");
  });
  it("8: no 'Funds released to wallet'", () => {
    expect(collabs).not.toContain("Funds released to wallet");
  });
  it("9: stats show a placeholder while loading and hide on error", () => {
    expect(collabs).toContain('data-testid="deal-stats-skeleton"');
    expect(collabs).toMatch(/\) : !collabsError \? \(\s*<div className="mb-6">\s*<DealSummaryStats/);
  });
});

describe("v414 DealDetailDrawer", () => {
  it("5: awaiting signature comes from the real signature flags and signs in chat", () => {
    expect(drawer).not.toContain("const isAwaitingSig = false;");
    expect(drawer).toContain("rawRow.agreement_signed_creator && rawRow.agreement_signed_brand");
    expect(drawer).toContain("Sign the agreement in chat");
  });
  it("6: submit only when signed + funded + active; approved / proof have their own text", () => {
    expect(drawer).toMatch(/const canSubmit = isProdStage && bothSigned && isFunded/);
    expect(drawer).toContain("Draft approved — post it and add the live link in chat.");
    expect(drawer).toContain("Live link under brand review");
    expect(drawer).toContain("Waiting for brand payment");
  });
  it("8: no 'YBEX Balance' wording", () => {
    expect(drawer).not.toContain("YBEX Balance");
    expect(drawer).toContain("Approved · payout next");
  });
});

describe("v414 DealSummaryStats", () => {
  it("8: labels gross total honestly and counts paid-to-bank only with a UTR", () => {
    render(<DealSummaryStats deals={[
      { stage: "COMPLETED", status: "COMPLETED", payout: 5000, raw: { raw: { payout_reference: "UTR123" } } },
      { stage: "COMPLETED", status: "COMPLETED", payout: 3000, raw: {} },
    ]} />);
    expect(screen.getByText("Earned (approved deals)")).toBeTruthy();
    expect(screen.getByText("₹5,000 paid to bank")).toBeTruthy();
    expect(screen.queryByText("Paid out to your wallet")).toBeNull();
  });
  it("8: without any UTR it doesn't claim a payout", () => {
    render(<DealSummaryStats deals={[{ stage: "COMPLETED", status: "COMPLETED", payout: 3000 }]} />);
    expect(screen.getAllByText("Payout to your bank after approval").length).toBeGreaterThan(0);
  });
});
