import { describe, it, expect } from "vitest";
import React from "react";
import { render, screen, cleanup, act } from "@testing-library/react";
import fs from "fs";
import { YbexDownPage, supportLinks } from "./components/common/OfflineBanner";

describe("v424 maintenance Help sheet", () => {
  it("'Need help?' under the heading (inside the page) opens WhatsApp + Mail", async () => {
    render(<YbexDownPage mode="maintenance" side="brand" />);
    expect(screen.queryByTestId("maintenance-help-sheet")).toBeNull();
    await act(async () => { window.dispatchEvent(new MessageEvent("message", { data: { ybex: "help" } })); });
    expect(screen.getByTestId("maintenance-help-whatsapp").getAttribute("href")).toMatch(/^https:\/\/wa\.me\/918764004299\?text=.*brand/);
    expect(screen.getByTestId("maintenance-help-mail").getAttribute("href")).toMatch(/^mailto:support@ybexmedia\.in\?subject=/);
  });
  it("no Help on the offline screen", () => {
    cleanup();
    render(<YbexDownPage mode="offline" />);
    expect(screen.queryByTestId("maintenance-help-sheet")).toBeNull();
    const html = fs.readFileSync("src/components/common/ybexDownPage.html", "utf8");
    expect(html).toContain('id="helpBtn"');
    expect(html).toContain("post('help')");
    expect(supportLinks("creator").whatsapp).toContain("creator");
  });
  it("the app's live-update check passes through maintenance", () => {
    const s = fs.readFileSync("backend/server.ts", "utf8");
    expect(s).toMatch(/"\/app\/android-update",\s*\n\s*"\/app\/ios-update"/);
  });
});
