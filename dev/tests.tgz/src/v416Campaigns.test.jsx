// v416 (F4): campaigns / explore / invites fixes — unit tests for the pure helpers + source checks.
import { describe, it, expect, vi } from "vitest";
import { readFileSync } from "node:fs";

vi.mock("./lib/api", () => ({ api: { get: vi.fn(), post: vi.fn() }, isBrandLike: () => true }));

import { tiersForRange, followerRangeText, followerRangeFor } from "./utils/followerRange";
import { campaignErrorText, campaignDaysLeft, MIN_CAMPAIGN_PAYOUT } from "./components/campaigns/mobile/HomeCampaignCard";
import { inviteFailReason } from "./components/campaigns/InviteToCampaignModal";
import { toPickerDate } from "./components/ui/custom-date-picker";

const read = (p) => readFileSync(new URL(p, import.meta.url), "utf8");

describe("C22 follower tiers round-trip", () => {
  it("5k–500k keeps Nano (saving no longer narrows it)", () => {
    expect(tiersForRange(5000, 500000)).toEqual(["Nano", "Micro", "Macro"]);
    expect(tiersForRange(10000, 50000)).toEqual(["Micro"]);
    expect(tiersForRange(1000000, null)).toEqual(["Celeb"]);
    const back = followerRangeFor(tiersForRange(5000, 500000));
    expect(back.follower_min).toBeLessThanOrEqual(5000);
    expect(back.follower_max).toBe(500000);
  });
  it("C21 preview ranges are sorted and merged", () => {
    expect(followerRangeText(["Macro", "Nano", "Micro"])).toBe("4k - 500k");
    expect(followerRangeText(["Mega", "Micro"])).toBe("10k - 50k / 500k - 1M");
    expect(followerRangeText(["Celebrities", "Mega"])).toBe("500k+");
  });
});

describe("C13 calm error text", () => {
  it("5xx never shows the raw detail; 4xx keeps the server sentence", () => {
    expect(campaignErrorText({ response: { status: 500, data: { detail: "x" } } }, "fb")).toBe("Something went wrong on our side. Please try again.");
    expect(campaignErrorText({ response: { status: 400, data: { error: "Minimum payout is ₹3,000." } } }, "fb")).toBe("Minimum payout is ₹3,000.");
    expect(campaignErrorText({ message: "Network Error" }, "fb")).toBe("fb");
  });
  it("C14 one ₹3,000 floor", () => {
    expect(MIN_CAMPAIGN_PAYOUT).toBe(2000); // v420 special offer
  });
  it("CR20 days left uses IST calendar days", () => {
    const now = Date.parse("2026-11-07T20:00:00Z"); // 8 Nov 01:30 IST
    expect(campaignDaysLeft("2026-11-08", now)).toBe(0);
    expect(campaignDaysLeft("2026-11-10", now)).toBe(2);
  });
});

describe("C6 per-creator invite reasons", () => {
  it("already invited / applied / server / network", () => {
    expect(inviteFailReason({ response: { status: 409, data: { code: "ALREADY_INVITED", invite_id: "i1" } } })).toBe("already invited");
    expect(inviteFailReason({ response: { status: 409, data: { code: "ALREADY_IN_CAMPAIGN" } } })).toBe("already applied to this campaign");
    expect(inviteFailReason({ response: { status: 500, data: {} } })).toBe("server error");
    expect(inviteFailReason({})).toBe("network problem");
  });
});

describe("C1 date picker", () => {
  it("reads YYYY-MM-DD as a local day; light theme, closes on pick, past days disabled", () => {
    const d = toPickerDate("2026-11-21");
    expect([d.getFullYear(), d.getMonth(), d.getDate()]).toEqual([2026, 10, 21]);
    const s = read("./components/ui/custom-date-picker.jsx");
    expect(s).toContain("setOpen(false)");
    expect(s).toContain("disablePast ? { before: today }");
    expect(s).toContain("bg-white text-gray-900");
    expect(read("./pages/brand/BrandCampaignCreate.jsx")).toContain("disablePast");
  });
});

describe("source checks", () => {
  it("C2 no-fee card: no Accept, brand sends the first offer", () => {
    expect(read("./components/chat/ShortlistCards.jsx")).toContain("noFee ? sendOfferButton : actionButtons");
    expect(read("./components/chat/mobile/MobileShortlistCards.jsx")).toContain("m.no_fee_proposed === true");
  });
  it("C3 tag search uses the api helper (no localStorage token)", () => {
    const s = read("./components/shared/UniversalTagSearch.jsx");
    expect(s).not.toContain('localStorage.getItem("token")');
    expect(s).toContain('api.post(saveEndpoint');
  });
  it("C7 mobile invite carries campaign_id; desktop profile passes campaigns", () => {
    expect(read("./components/explore/mobile/ExploreMobile.jsx")).toContain("campaign_id: picked || undefined");
    expect(read("./pages/creator/CreatorPublicView.jsx")).toMatch(/invitetocampaignmodal2"[\s\S]{0,200}campaigns=\{myCampaigns\}/);
  });
  it("C8 desktop applicants: pause / close + tabs; C12 no fake header", () => {
    const s = read("./pages/brand/BrandCampaignApplicants.jsx");
    expect(s).toContain("/applications-paused");
    expect(s).toContain("/close`");
    expect(s).toContain('role="tablist"');
    expect(s).toContain("{campaign && (");
  });
  it("C16 Back asks before leaving; C17 Launch uses the KYC popup", () => {
    expect(read("./pages/brand/BrandCampaignCreate.jsx")).toContain("Leave without saving?");
    expect(read("./components/campaigns/mobile/campaignCreate/KycShieldNotice.jsx")).toContain("export function LeaveDraftSheet");
    expect(read("./pages/brand/BrandCampaigns.jsx")).not.toContain('navigate("/brand/kyc")');
  });
  it("C15 owner detail copy", () => {
    const s = read("./pages/campaigns/CampaignDetail.jsx");
    expect(s).not.toContain(">Brand Type<");
    expect(s).toContain('"Back to My Campaigns"');
  });
});
