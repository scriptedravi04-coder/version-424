import { describe, it, expect } from "vitest";
import { initialsAvatarUrl } from "./utils/initials";
import { clearUserDrafts, draftSet, draftGet } from "./lib/userDraft";

describe("v423 local avatar + drafts", () => {
  it("initials avatar is a local SVG with the initials, decoded seeds too", () => {
    const u = initialsAvatarUrl(encodeURIComponent("Glow Cosmetics"));
    expect(u.startsWith("data:image/svg+xml")).toBe(true);
    expect(decodeURIComponent(u)).toContain(">GC<");
    expect(decodeURIComponent(initialsAvatarUrl("<script>"))).not.toContain("<script>");
  });
  it("logout clears this user's drafts only", () => {
    localStorage.clear();
    localStorage.setItem("ybex_user", JSON.stringify({ user_id: "u1" }));
    draftSet("brand_kyc_draft", "{\"pan\":\"ABCDE1234F\"}");
    localStorage.setItem("campaign_draft::u2", "other");
    clearUserDrafts();
    expect(draftGet("brand_kyc_draft")).toBeNull();
    expect(localStorage.getItem("campaign_draft::u2")).toBe("other");
  });
});
