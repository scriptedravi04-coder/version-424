// v417 — chat frontend (agent B): Ybex Support label, revision-limit support action, date separators,
// paperclip attachments, unread-after-switch, scroll follow, composer focus.
import React from "react";
import fs from "fs";
import { describe, it, expect, afterEach } from "vitest";
import { render, screen, cleanup } from "@testing-library/react";
import { isSupportMessage, revisionLimitReached, isRevisionLimitError, chatAttachmentError } from "./components/chat/dealState";
import { chatDayLabel, dateSeparatorFor, istDayKey } from "./components/chat/chatTime";
import MessageBubble from "./components/chat/MessageBubble";
import MobileMessageRow from "./components/chat/mobile/MobileMessageRow";
import MobileDeliverableCard from "./components/chat/mobile/MobileDeliverableCard";

const read = (p) => fs.readFileSync(p, "utf8");
afterEach(cleanup);

describe("1 — staff messages show Ybex Support (old + new shapes)", () => {
  it("detects every shape", () => {
    expect(isSupportMessage({ sender_role: "admin" })).toBe(true);
    expect(isSupportMessage({ sender_role: "admin", is_staff: true, sender_label: "Ybex Support", metadata: { sender_role: "admin", is_staff: true } })).toBe(true);
    expect(isSupportMessage({ message_type: "admin_injection", from_name: "Platform Admin", metadata: { action: "admin_message" } })).toBe(true);
    expect(isSupportMessage({ from_name: "Platform Admin" })).toBe(true);
    expect(isSupportMessage({ metadata: JSON.stringify({ sender_role: "support" }) })).toBe(true);
    expect(isSupportMessage({ sender_role: "brand", content: "hi" })).toBe(false);
    expect(isSupportMessage({ sender_role: "creator", from_name: "Asha" })).toBe(false);
    expect(isSupportMessage(null)).toBe(false);
  });
  it("desktop + mobile bubbles render the label for an old admin_injection row", () => {
    const m = { id: "a1", message_type: "admin_injection", sender_user_id: "adm", from_name: "Platform Admin", content: "We are checking this.", created_at: "2026-11-07T10:00:00Z" };
    render(<MessageBubble message={m} isMine={false} isUserBrand={false} thread={{ id: "t" }} />);
    expect(screen.getByTestId("support-label").textContent).toMatch(/Ybex Support/);
    cleanup();
    render(<MobileMessageRow message={{ ...m, message_type: "text", sender_role: "admin" }} isMine={false} isBrand={false} thread={{ id: "t" }} allMessages={[]} />);
    expect(screen.getByTestId("support-label").textContent).toMatch(/Ybex Support/);
  });
  it("a brand message has no label", () => {
    render(<MessageBubble message={{ id: "b1", message_type: "text", sender_role: "brand", sender_user_id: "u_b", content: "Hello" }} isMine={false} isUserBrand={false} thread={{ id: "t" }} />);
    expect(screen.queryByTestId("support-label")).toBeNull();
  });
});

describe("2 — revision limit → Contact support", () => {
  it("limit from thread / UGC order numbers; unknown = false", () => {
    expect(revisionLimitReached({ revision_count: 2, revisions_used: 2 })).toBe(true);
    expect(revisionLimitReached({ revision_count: 2, revisions_used: 1 })).toBe(false);
    expect(revisionLimitReached({ ugc_order: { revision_count: 3, revisions_used: 3 } })).toBe(true);
    expect(revisionLimitReached({ revision_count: 2 })).toBe(false);
    expect(revisionLimitReached(null)).toBe(false);
  });
  it("reads the server's limit error", () => {
    expect(isRevisionLimitError({ response: { status: 400, data: { error: "Revision limit reached (2/2)." } } })).toBe(true);
    expect(isRevisionLimitError({ response: { status: 400, data: { revisions_used: 3, revision_count: 3 } } })).toBe(true);
    expect(isRevisionLimitError({ response: { status: 500, data: { error: "x" } } })).toBe(false);
  });
  it("mobile draft card swaps Request changes for Contact support", () => {
    const msg = { id: "d1", message_type: "content_proof_submitted", sender_role: "creator", metadata: { media_url: "https://example.com/a.mp4" }, created_at: "2026-11-07T10:00:00Z" };
    render(<MobileDeliverableCard message={msg} isMine={false} isBrand thread={{ id: "t", revision_count: 1, revisions_used: 1, flow_state: "CONTENT_SUBMITTED" }} onApprove={() => {}} onRequestChanges={() => {}} onContactSupport={() => {}} />);
    expect(screen.getByTestId("revision-limit-support").textContent).toMatch(/Contact support/);
  });
  it("desktop draft card + mobile sheet wiring", () => {
    const cpn = read("src/components/chat/ContentProofNotice.jsx");
    expect(cpn).toMatch(/revisionLimitReached\(thread\)/);
    expect(cpn).toMatch(/isRevisionLimitError\(e\)/);
    expect(read("src/components/chat/mobile/ChatBoxMobile.jsx")).toMatch(/r === "limit"\) \{ setActiveSheet\("orderSupport"\)/);
  });
});

describe("3 — date separators", () => {
  const now = new Date("2026-11-07T12:00:00+05:30");
  it("Today / Yesterday / 7 Nov 2026 by IST day", () => {
    expect(chatDayLabel("2026-11-07T01:00:00+05:30", now)).toBe("Today");
    expect(chatDayLabel("2026-11-06T23:59:00+05:30", now)).toBe("Yesterday");
    expect(chatDayLabel("2026-10-07T10:00:00+05:30", now)).toBe("7 Oct 2026");
    expect(chatDayLabel("2025-11-07T10:00:00+05:30", now)).toBe("7 Nov 2025");
    expect(istDayKey("2026-11-06T19:00:00Z")).toBe("2026-11-07"); // 00:30 IST
    expect(chatDayLabel("bad", now)).toBe("");
  });
  it("only on a new day", () => {
    const a = { created_at: "2026-11-05T10:00:00+05:30" }, b = { created_at: "2026-11-05T18:00:00+05:30" }, c = { created_at: "2026-11-07T09:00:00+05:30" };
    expect(dateSeparatorFor(a, null, now)).toBe("5 Nov 2026");
    expect(dateSeparatorFor(b, a, now)).toBe("");
    expect(dateSeparatorFor(c, b, now)).toBe("Today");
  });
  it("bubble shows it only when prevMessage is passed", () => {
    const m = { id: "x", message_type: "text", sender_role: "brand", content: "Hi", created_at: "2026-11-01T10:00:00+05:30" };
    render(<MessageBubble message={m} isMine isUserBrand thread={{ id: "t" }} />);
    expect(screen.queryByTestId("date-separator")).toBeNull();
    cleanup();
    render(<MessageBubble message={m} prevMessage={null} isMine isUserBrand thread={{ id: "t" }} />);
    expect(screen.getByTestId("date-separator").textContent).toBe("1 Nov 2026");
    expect(read("src/components/chat/ChatBox.jsx")).toMatch(/prevMessage=\{msgIdx > 0 \? uniqueMessages\[msgIdx - 1\] : null/);
  });
});

describe("4 — paperclip attachments", () => {
  const f = (name, size = 1000, type = "") => ({ name, size, type });
  it("same allow-list and 50 MB limit as the server", () => {
    for (const n of ["a.jpg", "a.JPEG", "a.png", "a.webp", "a.heic", "a.heif", "a.gif", "a.mp4", "a.mov", "a.pdf"]) expect(chatAttachmentError(f(n))).toBe("");
    for (const n of ["a.exe", "a.docx", "a.zip", "a.webm", "a.svg"]) expect(chatAttachmentError(f(n))).not.toBe("");
    expect(chatAttachmentError(f("big.mp4", 50 * 1024 * 1024 + 1))).toMatch(/50 MB/);
    expect(chatAttachmentError(f("noext", 10, "image/png"))).toBe("");
  });
  it("desktop + mobile composers have the button", () => {
    expect(read("src/components/chat/chatBox/ChatBoxComposer.jsx")).toMatch(/aria-label="Attach file"/);
    expect(read("src/components/chat/ChatBox.jsx")).toMatch(/onFileChange=\{isCancelled \? undefined : handleFileUpload\}/);
    const mob = read("src/components/chat/mobile/ChatBoxMobile.jsx");
    expect(mob).toMatch(/aria-label="Attach file"/);
    expect(read("src/components/chat/mobile/useChatThreadMobile.js")).toMatch(/chat-attachments\//);
  });
});

describe("5 — unread / scroll / focus", () => {
  it("unread after switching uses message time, not the stale count", () => {
    const s = read("src/pages/dashboard/Chat.jsx");
    expect(s).toMatch(/t\?\._activity_at/);
    expect(s).toMatch(/const newer = lt > 0 \? lt > mark\.t : /);
  });
  it("mobile follows only near the bottom; desktop tracks it before the new message", () => {
    expect(read("src/components/chat/mobile/ChatBoxMobile.jsx")).toMatch(/nearBottomRef\.current = b\.scrollHeight - b\.scrollTop - b\.clientHeight < 160/);
    expect(read("src/components/chat/ChatBox.jsx")).toMatch(/nearBottomRef\.current \|\|/);
  });
  it("composer refocuses on chat switch", () => {
    expect(read("src/components/chat/chatBox/ChatBoxComposer.jsx")).toMatch(/\}, \[props\.threadId\]\);/);
  });
});
