import { describe, it, expect } from "vitest";
import { readFileSync, existsSync } from "fs";
import { wlProfileUrl, kycWaiting, waitlistChipMatch } from "./components/admin/WaitlistManager";
import { dedupeByInstagram } from "../backend/exploreGate";
import { approveAccountProfile } from "../backend/creatorApplication";
const read = (p) => readFileSync(p, "utf8");

describe("v419 admin cleanup", () => {
  it("dead admin pieces are gone", () => {
    expect(existsSync("src/components/admin/AdminMoreMobile.jsx")).toBe(false);
    const admin = read("src/pages/admin/Admin.jsx");
    expect(admin).not.toMatch(/case 'more'/);
    expect(admin).toMatch(/React\.lazy\(\(\) => import\('..\/..\/components\/admin\/KYCManager'\)\)/);
    expect(read("backend/admin_content_routes.ts")).not.toMatch(/router\.post\("\/admin\/faq"/);
    expect(read("backend/admin_system_maintenance_routes.ts")).not.toMatch(/router\.get\("\/admin\/bypass"/);
    expect(read("src/components/admin/PlatformTools.jsx")).not.toMatch(/handlePublishVersion/);
  });
  it("Overview counts come from one counts call", () => {
    const a = read("src/components/admin/AdminAnalytics.jsx");
    expect(a).not.toMatch(/api\.get\("admin\/kyc"\)/);
    expect(a).toMatch(/counts\.ugc_active/);
  });
  it("KYC list: whole row opens, waiting first, status boxes", () => {
    const k = read("src/components/admin/KYCManager.jsx");
    expect(k).toMatch(/data-testid="kyc-row"/);
    expect(k).toMatch(/kyc-box-/);
  });
  it("waitlist handle opens Instagram", () => {
    expect(wlProfileUrl({ handle: "@yashu_xi", platform: "Instagram" })).toBe("https://www.instagram.com/yashu_xi/");
    expect(wlProfileUrl({ handle: "bad handle!" })).toBe("");
    expect(wlProfileUrl({ platform: "YouTube", youtube_link: "youtube.com/@x" })).toBe("https://youtube.com/@x");
  });
  it("Left sign-up rows have their own list", () => {
    const w = read("src/components/admin/WaitlistManager.jsx");
    expect(w).toMatch(/'started', 'Left sign-up'/);
    expect(waitlistChipMatch({ source: "join_started" }, "app")).toBe(false);
    expect(kycWaiting({ kyc_status: "pending" })).toBe(true);
    expect(kycWaiting({ kyc_status: "approved" })).toBe(false);
  });
  it("Explore shows one card per Instagram handle (reviewed one wins)", () => {
    const rows = [{ user_id: "a", instagram_handle: "same", created_at: "2026-01-01" }, { user_id: "b", instagram_handle: "@Same", reviewed_at: "x" }, { user_id: "c" }];
    expect(dedupeByInstagram(rows).map((r) => r.user_id)).toEqual(["b", "c"]);
  });
  it("approving an application approves the waiting account, never a rejected one", async () => {
    const db = { creator_profiles: [{ user_id: "u1", profile_status: "approved" }, { user_id: "u2", profile_status: "rejected" }] };
    expect(await approveAccountProfile(null, db, "u1")).toBe(true);
    expect(db.creator_profiles[0].reviewed_at).toBeTruthy();
    expect(await approveAccountProfile(null, db, "u2")).toBe(false);
  });
});

describe("v419 in-house PIN sheet", () => {
  it("is the app's own box, not the browser prompt", () => {
    const r = read("src/lib/razorpay.js");
    expect(r).not.toMatch(/window\.prompt/);
    expect(r).toMatch(/askInhousePin\(\{ amount: verifiedAmount/);
  });
  it("returns the typed PIN, null on Cancel, and refuses short PINs", async () => {
    const { askInhousePin } = await import("./lib/razorpay");
    let p = askInhousePin({ amount: 1500 });
    const input = document.querySelector('[data-testid="inhouse-pin-input"]');
    expect(document.body.textContent).toContain("₹1,500");
    input.value = "12"; document.querySelector('[data-testid="inhouse-pin-confirm"]').click();
    expect(document.querySelector('[data-testid="inhouse-pin-error"]').textContent).toMatch(/4 to 8/);
    input.value = "4321"; document.querySelector('[data-testid="inhouse-pin-confirm"]').click();
    expect(await p).toBe("4321");
    expect(document.getElementById("ybx-inhouse-pin")).toBeNull();
    p = askInhousePin({ error: "Wrong PIN. Please try again." });
    expect(document.querySelector('[data-testid="inhouse-pin-error"]').textContent).toBe("Wrong PIN. Please try again.");
    document.getElementById("ybx-pin-cancel").click();
    expect(await p).toBeNull();
  });
});

describe("v419 lighter phone admin + help desk", () => {
  it("phone queues fetch a list only when its count is above 0", () => {
    const s = read("src/components/admin/mobile/AdminMobileScreens.jsx");
    expect(s).toMatch(/useAdminData\("kyc", need\("kyc"\)\)/);
    expect(s).toMatch(/enabled: Boolean\(cc\) && Number\(cc\[k\]\) > 0/);
  });
  it("help desk polls less often", () => {
    const h = read("src/pages/admin/AdminHelpdesk.jsx");
    expect(h).toMatch(/fetchTickets\(\); \}, 60000\)/);
    expect(h).toMatch(/selectedTicket\.ticket_id\); \}, 20000\)/);
  });
});

describe("v419 waitlist KYC buttons (Ravi: no confirm, no new tab)", () => {
  it("View KYC opens the review on the same page; Approve KYC has no confirm", () => {
    const w = read("src/components/admin/WaitlistManager.jsx");
    expect(w).toMatch(/import \{ KYCReviewPanel \} from "\.\/KYCManager"/);
    expect(w).toMatch(/data-testid="wl-kyc-overlay"/);
    expect(w).not.toMatch(/tab=verifications&open=\$\{/);
    expect(w).toMatch(/onClick=\{\(\) => approveKycOf\(selectedItemDetails\)\} data-testid="wl-approve-kyc"/);
  });
});

describe("v419 admin round 2 (hubs, waitlist row, no fake audit)", () => {
  it("Money / Orders / Marketing / Developer are real pages with their own tabs", async () => {
    const { adminHub, adminNavTo, adminNavActive } = await import("./lib/adminSearch");
    const m = adminHub("marketing");
    expect(m.items.map((i) => i.id)).toEqual(["blog", "push", "broadcast", "promos", "banners", "landing", "challenge"]);
    expect(adminNavTo(m.items[1])).toBe("/admin?tab=marketing&view=push");
    expect(adminNavActive(m.items[0], "?tab=marketing")).toBe(true);
    expect(read("src/pages/admin/Admin.jsx")).toMatch(/data-testid=\{`admin-hub-\$\{hub\.hub\}`\}/);
    expect(read("src/components/admin/PlatformTools.jsx")).toMatch(/embedded = false/);
  });
  it("a designer with only Banners sees only Banners in Marketing", async () => {
    const { adminItemAllowed } = await import("./lib/adminPermissions");
    const { adminHub } = await import("./lib/adminSearch");
    const u = { role: "admin", team_role: "sub_admin", permissions: ["settings_banners"] };
    expect(adminHub("marketing").items.filter((i) => adminItemAllowed(u, i)).map((i) => i.id)).toEqual(["banners"]);
    expect(adminHub("developer").items.filter((i) => adminItemAllowed(u, i))).toEqual([]);
  });
  it("waitlist row: status tick, only Approve / Reject, KYC filter approves both", () => {
    const w = read("src/components/admin/WaitlistManager.jsx");
    expect(w).toMatch(/<WlStatusTick status=\{item\.status\} \/>/);
    expect(w).not.toMatch(/setQuickAuditTarget|>\s*Audit\s*</);
    expect(w).toMatch(/'Approve \+ KYC'/);
    expect(w).toMatch(/data-testid="wl-kyc-filter"/);
  });
  it("the fake Google search audit is gone everywhere", () => {
    for (const f of ["src/components/admin/KYCManager.jsx", "src/components/admin/UserEnforcementPanel.jsx", "src/components/admin/AdminUsersTab.jsx", "src/components/admin/mobile/AdminMobileScreens.jsx"]) {
      expect(read(f)).not.toMatch(/kyc-grounded-audit|QuickAuditModal|LiveGroundedAuditCard/);
    }
    expect(existsSync("src/components/admin/QuickAuditModal.jsx")).toBe(false);
  });
  it("Users: no KYC approve when nothing was sent; Edit profile on the user page", () => {
    expect(read("src/components/admin/UserEnforcementPanel.jsx")).toMatch(/isKycPending = rawKycStatus === 'PENDING' && !isKycApproved && kycHasData/);
    expect(read("src/components/admin/userEnforcement/BasicDetailsCard.jsx")).toMatch(/data-testid="admin-edit-creator"/);
  });
});

describe("v419 waitlist gender filter", () => {
  it("reads every way the form saved it", async () => {
    const { wlGender } = await import("./components/admin/WaitlistManager");
    expect(wlGender({ gender: "Female" })).toBe("female");
    expect(wlGender({ gender: "M" })).toBe("male");
    expect(wlGender({ gender: "" })).toBe("");
    expect(read("src/components/admin/WaitlistManager.jsx")).toMatch(/data-testid="wl-gender-filter"/);
  });
});

describe("v419 sidebar: one row per hub page", () => {
  it("Money / Orders / Marketing / Developer are single rows under Tools", async () => {
    const { ADMIN_NAV, adminNavFolded, adminNavActive } = await import("./lib/adminSearch");
    const f = adminNavFolded(ADMIN_NAV);
    const tools = f.find((g) => g.group === "Tools");
    expect(tools.items.map((i) => i.label)).toEqual(["Money", "Orders & leads", "Marketing", "Developer"]);
    expect(f.some((g) => g.group === "Marketing")).toBe(false);
    expect(adminNavActive(tools.items[2], "?tab=marketing&view=push")).toBe(true);
  });
});

describe("v419 menu v3 (Ravi: best UX)", () => {
  it("Daily work on top + Support & safety row; Users is one row with a list; Tools at the end", async () => {
    const { ADMIN_NAV, adminNavFolded, adminHub } = await import("./lib/adminSearch");
    const f = adminNavFolded(ADMIN_NAV);
    expect(f.find((g) => g.group === "Daily work").items.map((i) => i.label)).toEqual(["Waitlist", "KYC checks", "Campaign approvals", "Payouts & refunds", "Support & safety"]);
    const users = f.flatMap((g) => g.items).find((i) => i.children);
    expect(users.children.map((c) => c.label)).toEqual(["All users", "Brands", "Agencies", "Creators", "Unclaimed creators", "Admins", "Recycle bin"]);
    expect(adminHub("support").items.map((i) => i.id)).toEqual(["helpdesk", "feedback", "reports", "chat"]);
    expect(f.map((g) => g.group)).toEqual(["", "Daily work", "", "Tools"]);
  });
});
