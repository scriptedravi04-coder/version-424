// v415 Area A — brand app shell and home (quick-action sheet, tour, footer, Eva on desktop, popups).
import { describe, it, expect, vi, afterEach } from "vitest";
import React from "react";
import { readFileSync } from "fs";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { quickActionsMayShow, otherPopupOpen, isBrandHomePath } from "./components/quickActions/QuickActionsMobile";
import { buildBrandApplicationActions } from "./components/quickActions/quickActionsData";
import { blockingModalOpen, dashboardReady } from "./components/dashboard/TourRunner";
import { DESKTOP_EVA_CSS } from "./components/feedback/DesktopEva";

vi.mock("./contexts/AuthContext", () => ({ useAuth: () => ({ user: { role: "brand", user_id: "u1" } }) }));
vi.mock("react-router-dom", async (orig) => ({ ...(await orig()), useNavigate: () => () => {} }));

const read = (p) => readFileSync(new URL(p, import.meta.url), "utf8");
afterEach(() => { cleanup(); document.body.innerHTML = ""; });

describe("v415 quick-action sheet (brands)", () => {
  it("opens by itself only on Home, once per session; creators keep the old rule", () => {
    expect(quickActionsMayShow({ role: "brand", path: "/dashboard", autoUsed: false, openPath: null })).toBe(true);
    expect(quickActionsMayShow({ role: "brand", path: "/brand/campaigns", autoUsed: false, openPath: null })).toBe(false);
    expect(quickActionsMayShow({ role: "brand", path: "/dashboard", autoUsed: true, openPath: null })).toBe(false);
    expect(quickActionsMayShow({ role: "brand", path: "/dashboard", autoUsed: true, openPath: "/dashboard" })).toBe(true);
    expect(quickActionsMayShow({ role: "brand", path: "/brand/payments", autoUsed: true, openPath: "done" })).toBe(false);
    expect(quickActionsMayShow({ role: "creator", path: "/campaigns", autoUsed: true, openPath: null })).toBe(true);
    expect(isBrandHomePath("/brand")).toBe(true);
    expect(isBrandHomePath("/brand/notifications")).toBe(false);
  });
  it("waits while another popup is up (but not for itself)", () => {
    expect(otherPopupOpen(document)).toBe(false);
    document.body.innerHTML = '<div role="dialog" aria-modal="true">terms</div>';
    expect(otherPopupOpen(document)).toBe(true);
    document.body.innerHTML = '<div data-testid="quick-actions" role="dialog" aria-modal="true" data-popup-open="true"></div>';
    expect(otherPopupOpen(document)).toBe(false);
  });
  it("closed items are remembered across sessions and the sheet is a real dialog", () => {
    const s = read("./components/quickActions/QuickActionsMobile.jsx");
    expect(s).toContain("localStorage.setItem(BRAND_CLOSED_KEY");
    expect(s).toMatch(/role="dialog" aria-modal="true"/);
    expect(s).toContain('if (e.key === "Escape") closeAll();');
  });
  it("campaign title shows once (headline no longer repeats it)", () => {
    const [card] = buildBrandApplicationActions([{ c: { campaign_id: "c1", title: "Diwali Sweets Reel" }, apps: [{ application_id: "a1", status: "pending", full_name: "Asha" }] }]);
    expect(card.headline).not.toContain("Diwali Sweets Reel");
    expect(card.details[0]).toEqual({ label: "Campaign", value: "Diwali Sweets Reel" });
  });
});

describe("v415 product tour", () => {
  it("starts only after the dashboard has loaded", () => {
    document.body.innerHTML = '<div data-dashboard-loading="true"></div>';
    expect(dashboardReady(false, document)).toBe(false);
    document.body.innerHTML = '<div data-testid="brand-dashboard"></div>';
    expect(dashboardReady(false, document)).toBe(true);
    document.body.innerHTML = '<div data-testid="creator-dashboard"></div>';
    expect(dashboardReady(true, document)).toBe(true);
  });
  it("also waits for promo / quick-action popups", () => {
    document.body.innerHTML = '<div data-popup-open="true"></div>';
    expect(blockingModalOpen(document)).toBe(true);
  });
  it("brand dashboard marks its skeleton and has the tour anchors", () => {
    const s = read("./components/dashboard/BrandDashboard.jsx");
    expect(s).toContain('data-dashboard-loading="true"');
    expect(s).toContain('id="tour-profile-header"');
    expect(s).toContain('id="tour-brand-tasks"');
    expect(s).not.toContain("This feature is still in training/beta.");
  });
});

describe("v415 footer + layout shift", () => {
  it("brands lose the filler slogans; the brand home footer waits for the home to load", () => {
    const l = read("./components/layout/Layout.jsx");
    expect(l).toContain('if (isBrandUser) return null;'); // v416: isBrandUser = isBrandLike(role) covers agency / talent manager
    expect(l).toContain('window.addEventListener("yb:home-ready", ready);');
    expect(l).toContain("if (footerWaitsForHome && !homeReady) return null;");
  });
  it("brand homes signal 'loaded' and the phone home shows one placeholder while loading", () => {
    const m = read("./pages/brand/BrandHomeMobile.jsx");
    expect(m).toContain('window.dispatchEvent(new Event("yb:home-ready"))');
    expect(m).toContain('data-testid="brand-home-loading"');
    expect(read("./components/dashboard/BrandDashboard.jsx")).toContain('window.dispatchEvent(new Event("yb:home-ready"))');
  });
  it("sidebar lights sub-pages of a section", () => {
    const l = read("./components/layout/Layout.jsx");
    expect(l).toContain('also={["/brand/dashboard"]}');
    expect(l).toContain('also={["/brand/ugc"]}');
  });
});

describe("v415 desktop Eva", () => {
  it("fully on screen at a fixed corner, no tilted half-peek, room under the page", () => {
    expect(DESKTOP_EVA_CSS).toContain('[data-testid="feedback-bot"]{right:20px!important;bottom:20px!important');
    expect(DESKTOP_EVA_CSS).toContain('[style*="translateX(30px)"]{transform:none!important}');
    expect(DESKTOP_EVA_CSS).toContain("padding-bottom:112px");
  });
});

describe("v415 popups", () => {
  it("KYC prompt: dialog, Escape closes, nothing when closed", async () => {
    const { default: KycPromptModal } = await import("./components/common/KycPromptModal");
    const onClose = vi.fn();
    const { rerender } = render(<KycPromptModal isOpen={false} onClose={onClose} role="brand" />);
    expect(screen.queryByRole("dialog")).toBeNull();
    rerender(<KycPromptModal isOpen onClose={onClose} role="brand" />);
    expect(screen.getByRole("dialog")).toBeTruthy();
    expect(screen.getByText("Not now")).toBeTruthy();
    fireEvent.keyDown(window, { key: "Escape" });
    expect(onClose).toHaveBeenCalled();
  });
  it("blocking notification popup and team message are real dialogs; install popup waits for others", () => {
    expect(read("./components/NotificationPopup.jsx")).toContain('role="dialog" aria-modal="true" aria-labelledby="ybex-popup-title"');
    expect(read("./components/dashboard/BrandDashboard.jsx")).toContain('aria-label="Message from the Ybex team"');
    expect(read("./components/common/PWAInstallPrompt.jsx")).toContain('document.querySelector(\'[aria-modal="true"],[data-popup-open="true"]\')');
  });
  it("schedule-call sheet animates in/out and locks the page", () => {
    const s = read("./pages/brand/brandHome/ScheduleCallModal.jsx");
    expect(s).toContain("<AnimatePresence>{isScheduleCallModalOpen && (");
    expect(s).toContain("useScrollLock(Boolean(isScheduleCallModalOpen));");
  });
});

describe("v415 quick actions on every brand route", async () => {
  const { quickActionHiddenOn } = await import("./components/quickActions/quickActionsData");
  it("brands: no auto-open on /help, /deals or any non-Home page; never on Help for anyone", () => {
    for (const p of ["/help", "/help/tickets", "/deals", "/deals/deal1", "/brand/campaigns", "/creators", "/brand/notifications", "/settings"]) {
      expect(quickActionsMayShow({ role: "brand", path: p, autoUsed: false, openPath: null })).toBe(false);
    }
    expect(quickActionHiddenOn("/help/tickets")).toBe(true);
  });
});
