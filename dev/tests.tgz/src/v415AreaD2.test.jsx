// v415 Area D2 — brand path from ad to panel, help center, deals list (brand side).
import { describe, it, expect } from "vitest";
import React from "react";
import fs from "fs";
import path from "path";
import { render, screen } from "@testing-library/react";
import BrandLivePreview from "./components/Onboarding/BrandLivePreview";
import { shortDealCode } from "./components/deals/DealDetailDrawer";

const read = (p) => fs.readFileSync(path.resolve(process.cwd(), p), "utf8");

describe("v415 D2: deal code", () => {
  it("shows an 8-character uppercase code, never the full UUID", () => {
    expect(shortDealCode("3f9a1c2e-7b4d-4e11-9a0b-1234567890ab")).toBe("3F9A1C2E");
    expect(shortDealCode("")).toBe("");
    expect(shortDealCode(null)).toBe("");
  });
  it("the drawer no longer prints the raw id", () => {
    const src = read("src/components/deals/DealDetailDrawer.jsx");
    expect(src).not.toMatch(/Deal ID: \{deal\.id\}/);
    expect(src).toMatch(/Deal #\{shortDealCode\(deal\.id\)\}/);
  });
});

describe("v415 D2: brand live preview", () => {
  it("shows no fake Connect button, no invented handle, and a natural placeholder", () => {
    render(<BrandLivePreview formData={{ companyName: "QA Foods" }} />);
    expect(screen.queryByText("Connect")).toBeNull();
    expect(screen.queryByText(/Please Tell Us About/i)).toBeNull();
    expect(screen.getByText("Your brand description appears here.")).toBeTruthy();
    expect(screen.queryByText("@qafoods")).toBeNull();
    expect(screen.queryByLabelText("X (Twitter)")).toBeNull();
    expect(screen.queryByLabelText("Facebook")).toBeNull();
  });
  it("shows only the links the brand filled", () => {
    render(<BrandLivePreview formData={{ companyName: "QA Foods", instagramHandle: "qafoods", websiteUrl: "qafoods.in" }} />);
    expect(screen.getByText("@qafoods")).toBeTruthy();
    expect(screen.getByLabelText("Instagram")).toBeTruthy();
    expect(screen.queryByLabelText("Facebook")).toBeNull();
    expect(screen.getByText("qafoods.in")).toBeTruthy();
  });
});

describe("v415 D2: desktop brand onboarding", () => {
  const src = read("src/components/Onboarding/BrandOnboardingFlow.jsx");
  it("uses the app purple, not blue", () => {
    expect(src).not.toMatch(/#3B82F6|bg-blue-|text-blue-|border-blue-|59,130,246/);
    expect(src).toMatch(/var\(--violet\)/);
  });
  it("has no percentage next to Step x of 4", () => {
    expect(src).not.toMatch(/\* 100\)\}%/);
  });
  it("fills the whole window and keeps the publish button from getting stuck", () => {
    expect(src).toMatch(/min-h-\[100dvh\] bg-\[var\(--bg-base\)\]/);
    expect(src).toMatch(/try \{\s*await saveRoleConsent\("brand"\)/);
  });
  it("plain payment wording (no SSL / 256-bit / 100% refund guarantee)", () => {
    expect(src).not.toMatch(/256-Bit|SSL Secure|Full refund guarantee|Got It, Thanks/);
  });
});

describe("v415 D2: mobile onboarding disabled button", () => {
  it("disabled primary button is grey, not pale purple", () => {
    const src = read("src/components/onboarding/mobile/MobileOnboardingShell.tsx");
    expect(src).toMatch(/background: disabled \? "#E5E5EA" : "#7C3AED"/);
  });
});

describe("v415 D2: deals list for brands", () => {
  const src = read("src/pages/collabs/Collabs.jsx");
  it("brand sees the creator, not its own name", () => {
    expect(src).toMatch(/isBrand \? "With:" : "Applied to:"/);
    expect(src).toMatch(/brandName: isBrand \? creatorName/);
    expect(src).toMatch(/subtitle: isBrand \? null/);
  });
  it("finished deals can open their chat on desktop", () => {
    expect(src).toMatch(/tab === "history" && \(it\.thread_id \|\| it\.raw\?\.thread_id\)/);
    expect(src).toMatch(/View chat/);
  });
});

describe("v415 D2: help center", () => {
  it("ticket form animates as one sheet and closes on Escape", () => {
    const src = read("src/components/help/TicketForm.jsx");
    expect(src).toMatch(/<PopupPanel as="form"/);
    expect(src).toMatch(/e\.key === "Escape"/);
    expect(src).toMatch(/useScrollLock\(true\)/);
  });
  it("a 'No' vote is not counted as helpful", () => {
    const src = read("src/pages/help/HelpCategory.jsx");
    expect(src).toMatch(/handleHelpful\(article\.id, article\.view_count \|\| 0, false\)/);
  });
});
