// v414 — chat fix batch (F1–F15): fake lifecycle text, typed messages as cards, optimistic sends, polls,
// failed sends, virtual threads, unread badge, cancelled orders, pre-sign chat, Cancel deal, stale offers,
// invite pitch masking, admin Mark Safe / Unrestrict.
import React from "react";
import fs from "fs";
import { describe, it, expect, afterEach, vi } from "vitest";
import { render, screen, cleanup, fireEvent } from "@testing-library/react";
import { deriveDealState, isServerWrittenMessage, allowsLegacyTextMatch } from "./components/chat/dealState";
import MobileMessageRow, { isLiveLinkMessage, supersededReviewCards } from "./components/chat/mobile/MobileMessageRow";
import MessageBubble from "./components/chat/MessageBubble";
import { makeClientMsgId, clientMsgIdOf, findTempFor, mergeServerMessages, sendRefusalReason } from "./lib/chatSync";

const read = (p) => fs.readFileSync(p, "utf8");
afterEach(cleanup);

const T = { id: "thread_camp_1", campaign_id: "c1", status: "ACTIVE", agreement_signed_brand: true, agreement_signed_creator: true };
const userMsg = (content, extra = {}) => ({ id: `m_${Math.random()}`, message_type: "text", sender_user_id: "u_creator", sender_role: "creator", content, created_at: "2026-11-07T10:00:00Z", ...extra });

describe("F1 — stage is never read from a user's text", () => {
  it("typed / attachment 'payment released' or 'payment secured' don't complete or fund the deal", () => {
    for (const type of ["text", "attachment", "file", "image", "video"]) {
      const s = deriveDealState({ thread: T, messages: [userMsg("Payment released! Escrow payment secured", { message_type: type })] });
      expect(s.isDealCompleted).toBe(false);
      expect(s.isPaymentFunded).toBe(false);
    }
  });
  it("a server-written lifecycle row still counts", () => {
    const s = deriveDealState({ thread: T, messages: [{ id: "s1", message_type: "system", content: "🎉 Escrow payment released", sender_user_id: null }] });
    expect(s.isDealCompleted).toBe(true);
    const f = deriveDealState({ thread: T, messages: [{ id: "s2", message_type: "payment_secured", sender_user_id: "u_brand", content: "💰 Payment Secured!" }] });
    expect(f.isPaymentFunded).toBe(true);
  });
  it("helpers", () => {
    expect(isServerWrittenMessage(userMsg("x"))).toBe(false);
    expect(isServerWrittenMessage({ message_type: "", sender_user_id: "u1", sender_role: "creator" })).toBe(false);
    expect(isServerWrittenMessage({ message_type: "", sender_user_id: "" })).toBe(true);
    expect(isServerWrittenMessage({ message_type: "payout_released", sender_user_id: "u_brand" })).toBe(true);
    expect(allowsLegacyTextMatch({ message_type: "system", sender_user_id: "system" })).toBe(true);
    expect(allowsLegacyTextMatch({ message_type: "system", sender_user_id: "u1" })).toBe(false);
    expect(allowsLegacyTextMatch({ message_type: "payout_released" })).toBe(false);
  });
  it("desktop ChatBox and mobile hook use the same rule", () => {
    expect(read("src/components/chat/ChatBox.jsx")).toContain("const isChatText = (m) => !isServerWrittenMessage(m);");
    expect(read("src/components/chat/mobile/useChatThreadMobile.js")).toContain("const isChatText = (m) => !isServerWrittenMessage(m);");
  });
});

describe("F2/F3 — typed messages stay plain bubbles; payout before draft approved", () => {
  const rowProps = { isMine: false, isBrand: true, isUgcOrder: false, thread: T, amount: 5000, campaignTitle: "C", isDealCompleted: false, allMessages: [] };
  it.each([
    "Thank you for the invitation!",
    "will send the live post link tonight",
    "Payout Released?",
    "brand signed already?",
    "escrow funded na?",
    "draft approved hua?",
  ])("mobile: %s", (txt) => {
    render(<MobileMessageRow {...rowProps} message={userMsg(txt)} />);
    expect(screen.getByText(txt)).toBeTruthy();
    expect(screen.queryByText(/Accept/i)).toBeNull();
    expect(screen.queryByText(/Draft approved 🎉/)).toBeNull();
    expect(isLiveLinkMessage(userMsg(txt))).toBe(false);
  });
  it("desktop: a typed 'Payout Released' is a plain bubble", () => {
    render(<MessageBubble message={userMsg("Payout Released")} isMine={false} isUserBrand={false} thread={T} />);
    expect(screen.getByText("Payout Released")).toBeTruthy();
  });
  it("UGC final approval (payment_released) is not shown as 'Draft approved'", () => {
    render(<MobileMessageRow {...rowProps} isUgcOrder message={{ id: "p1", message_type: "payment_released", sender_user_id: "u_brand", content: "🎉 UGC Deliverable Approved & Payment Released!", metadata: { action: "payout_released" } }} />);
    expect(screen.queryByText(/Draft approved 🎉/)).toBeNull();
  });
  it("legacy system row with no sender still reads its text", () => {
    expect(isLiveLinkMessage({ message_type: "system", content: "Creator submitted live post links" })).toBe(true);
  });
});

describe("F4 — only the latest decline card keeps buttons", () => {
  it("older declined cards are superseded", () => {
    const msgs = [
      { message_type: "content_proof_submitted" },
      { message_type: "revision_declined" },
      { message_type: "content_proof_submitted" },
      { message_type: "revision_declined" },
    ];
    const s = supersededReviewCards(msgs);
    expect(s.has(1)).toBe(true);
    expect(s.has(3)).toBe(false);
    expect(read("src/components/chat/mobile/MobileMessageRow.jsx")).toContain("onApproveLast={!isDealCompleted && !isSuperseded ? onApproveDeliverable : null}");
  });
  it("older link-decline cards are superseded by a newer submission", () => {
    const s = supersededReviewCards([{ message_type: "live_links_resubmit_declined" }, { message_type: "live_links_submitted" }]);
    expect(s.has(0)).toBe(true);
  });
});

describe("F5/F6 — client_msg_id matching and merge", () => {
  const temp = (content, cid, extra = {}) => ({ id: `temp_${cid}`, client_msg_id: cid, sender_user_id: "me", content, status: "sending", created_at: "2026-11-07T10:00:00Z", ...extra });
  it("ids look like c_<time>_<rand>", () => {
    expect(makeClientMsgId()).toMatch(/^c_\d+_[a-z0-9]+$/);
    expect(clientMsgIdOf({ metadata: { client_msg_id: "c_1" } })).toBe("c_1");
    expect(clientMsgIdOf({ metadata: JSON.stringify({ client_msg_id: "c_2" }) })).toBe("c_2");
  });
  it("matches by client_msg_id, never another user's message", () => {
    const list = [temp("ok", "c_a"), temp("ok", "c_b")];
    expect(findTempFor(list, { id: "r1", client_msg_id: "c_b", sender_user_id: "me", content: "ok" })).toBe(1);
    expect(findTempFor(list, { id: "r2", sender_user_id: "other", content: "ok", created_at: "2026-11-07T10:00:01Z" })).toBe(-1);
    // no echo: same sender + text within 30 s
    expect(findTempFor(list, { id: "r3", sender_user_id: "me", content: "ok", created_at: "2026-11-07T10:00:05Z" })).toBe(0);
    expect(findTempFor(list, { id: "r4", sender_user_id: "me", content: "ok", created_at: "2026-11-07T10:05:00Z" })).toBe(-1);
  });
  it("a poll keeps pending and failed bubbles; an old identical row doesn't swallow a new one", () => {
    const old = { id: "r_old", sender_user_id: "me", content: "ok", created_at: "2026-11-07T09:59:58Z" };
    const prev = [old, temp("ok", "c_new"), { ...temp("hi", "c_f"), status: "failed" }];
    const merged = mergeServerMessages(prev, [old]);
    expect(merged.map((m) => m.id)).toEqual(["r_old", "temp_c_new", "temp_c_f"]);
    const confirmed = mergeServerMessages(prev, [old, { id: "r_new", client_msg_id: "c_new", sender_user_id: "me", content: "ok" }]);
    expect(confirmed.map((m) => m.id)).toEqual(["r_old", "r_new", "temp_c_f"]);
  });
  it("sends carry client_msg_id and stale polls are ignored (desktop + mobile)", () => {
    for (const f of ["src/components/chat/ChatBox.jsx", "src/components/chat/mobile/useChatThreadMobile.js"]) {
      const s = read(f);
      expect(s).toContain("client_msg_id: clientMsgId");
      expect(s).toContain("seqAtStart !== sendSeqRef.current");
      expect(s).toContain("mergeServerMessages(prev,");
      expect(s).not.toMatch(/startsWith\("temp_"\) && m\.content === newMessage\.content/);
    }
  });
});

describe("F7 — failed sends", () => {
  it("server reason for blocks, null for network errors", () => {
    expect(sendRefusalReason({ response: { status: 403, data: { code: "CHAT_RESTRICTED", detail: "Your chat is paused until 9 Nov" } } })).toBe("Your chat is paused until 9 Nov");
    expect(sendRefusalReason({ response: { status: 400, data: { blocked: true, error: "Contact details cannot be shared" } } })).toBe("Contact details cannot be shared");
    expect(sendRefusalReason({ message: "Network Error" })).toBeNull();
  });
  it("mobile failed bubble: tap to try again calls onRetry", () => {
    const onRetry = vi.fn();
    render(<MobileMessageRow message={{ ...userMsg("hello"), id: "temp_1", status: "failed" }} isMine isBrand={false} thread={T} allMessages={[]} onRetry={onRetry} />);
    expect(screen.getByText("Not sent — tap to try again")).toBeTruthy();
    fireEvent.click(screen.getByTestId("failed-message"));
    expect(onRetry).toHaveBeenCalled();
  });
  it("mobile failed bubble shows the server's reason", () => {
    render(<MobileMessageRow message={{ ...userMsg("hello"), id: "temp_1", status: "failed", fail_reason: "Chat closed" }} isMine isBrand={false} thread={T} allMessages={[]} />);
    expect(screen.getByText("Not sent — Chat closed")).toBeTruthy();
  });
  it("desktop failed bubble retries", () => {
    const onRetry = vi.fn();
    render(<MessageBubble message={{ ...userMsg("yo"), id: "temp_2", status: "failed" }} isMine isUserBrand={false} thread={T} onRetry={onRetry} />);
    fireEvent.click(screen.getByTestId("failed-message"));
    expect(onRetry).toHaveBeenCalled();
  });
  it("mobile keeps / restores the text when the send fails", () => {
    const s = read("src/components/chat/mobile/ChatBoxMobile.jsx");
    expect(s).toContain("if (ok === false) setText((cur) => (cur ? cur : typed));");
  });
});

describe("F8/F9 — inbox", () => {
  const s = read("src/pages/dashboard/Chat.jsx");
  it("virtual chat only on 404; 403 / other errors show a message once", () => {
    expect(s).toContain("if (st === 404) {");
    expect(s).toContain("This chat isn't yours");
    expect(s).toContain("openTriedRef.current !== urlThreadId");
    expect(s).not.toContain('toast.error("Couldn\'t open this chat. Please try again."');
    expect(read("src/components/chat/ChatBox.jsx")).toContain("Start this chat from the campaign/invite");
  });
  it("opened chat keeps unread 0 until a newer message", () => {
    expect(s).toContain("const unreadCount = isActive ? 0 : effectiveUnread(t);");
  });
});

describe("F10/F11/F12/F13/F14/F15", () => {
  it("F10: cancelled UGC orders hide the pinned brief / upload", () => {
    expect(read("src/components/chat/mobile/ChatBoxMobile.jsx")).toContain("!isDealCompleted && !isCancelled; // v414");
    expect(read("src/components/chat/ChatBox.jsx")).toContain("const showTabs = !isDealCompleted && !isCancelled;");
  });
  it("F11: no pre-sign text block on desktop", () => {
    expect(read("src/components/chat/ChatBox.jsx")).not.toContain("Please sign the SLA Contract first");
    expect(read("src/components/chat/chatBox/ChatBoxComposer.jsx")).not.toContain("Please sign contract above");
  });
  it("F12: Cancel deal in the chat menu (desktop + mobile share BurgerMenuSupport)", () => {
    const b = read("src/components/chat/BurgerMenuSupport.jsx");
    expect(b).toContain("/cancel-deal`, { reason }");
    expect(b).toContain("This cancels the deal for both sides.");
    expect(b).toContain("Ybex support will review and refund the brand.");
    expect(b).toContain('"Cancellation request sent to Ybex support"');
    expect(read("src/components/chat/mobile/ChatBoxMobile.jsx")).toContain("<BurgerMenuSupport thread={currentThread} user={user} onDealChanged=");
  });
  it("F13: mobile accept / sign send the amount", () => {
    const h = read("src/components/chat/mobile/useChatThreadMobile.js");
    expect(h).toContain("{ counter_amount: shown }");
    expect(h).toContain("amount: signAmount");
    expect(h).toContain('["STALE_OFFER", "AMOUNT_CHANGED"]');
  });
  it("F14: invite pitch always masked", () => {
    expect(read("src/components/chat/ShortlistCards.jsx")).not.toContain("isInviteOffer ? m.pitch");
    expect(read("src/components/chat/mobile/MobileShortlistCards.jsx")).not.toContain("isInviteOffer ? pitch");
  });
  it("F15: Mark Safe text; Unrestrict uses the chat-violations route", () => {
    const a = read("src/components/chat/AdminChatDashboard.jsx");
    expect(a).toContain("Mark as reviewed (does not lift restriction)");
    expect(a).not.toContain("/admin/users/${userId}/unrestrict");
    expect(a).toContain("{ action: 'unrestrict', user_id: userId }");
  });
});
