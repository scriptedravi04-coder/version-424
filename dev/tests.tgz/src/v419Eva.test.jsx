// v419 (Ravi: "ye sab kr de"): Eva — own deals + UGC orders, topic-first scripts / captions / hashtags,
// rate advice without guessed reach, brand filters that really filter, budget-fit answers.
import { describe, it, expect } from "vitest";
import * as L from "./components/assist/creator/creatorLogic";

describe("v419 · creator Eva intents", () => {
  const I = (t) => L.detectCreatorIntent(t)?.intent;
  it("own UGC orders and deals are not the campaign list", () => {
    expect(I("ugc orders dikhao")).toBe("myUgc");
    expect(I("ugc video ka timer kitna bacha hai")).toBe("myUgc");
    expect(I("Diwali Sweets wale deal ka kya status hai")).toBe("myDeals");
    expect(I("brand ne revision manga hai")).toBe("myDeals");
    expect(I("deal ka chat kholo")).toBe("myDeals");
    expect(I("invoice chahiye mujhe deal ka")).toBe("invoice");
    expect(I("mere deals")).toBe("myDeals");
    expect(I("show campaigns for me")).toBe("campaigns");
    expect(I("Show UGC briefs")).toBe("campaigns");
  });
  it("deal and UGC lines use the real state, amount and time left", () => {
    const now = Date.parse("2026-11-09T00:00:00Z");
    const d = L.dealLines([{ id: "t1", status: "active", flow_state: "escrow_funded", agreed_amount: 12000, deadline: "2026-11-22T09:00:00Z", campaign_title: "Diwali Sweets Reel — x", brand: { company_name: "Kinara" } },
      { id: "t2", status: "cancelled" }, { id: "t3", is_ugc: true }], () => ({ label: "Your turn · upload draft", needsAction: true }), now);
    expect(d).toHaveLength(1);
    expect(d[0].text).toBe("Kinara · Diwali Sweets Reel · ₹12,000 — Your turn · upload draft · draft 14 days left");
    expect(d[0]).toMatchObject({ link: "/chat/t1", cta: "Upload", urgent: true });
    const u = L.ugcLines([{ id: "o1", stage: "IN_PROGRESS", amount: 3000, deadline: "2026-11-22T09:00:00Z", brief: { title: "Unboxing video" } }, { id: "o2", stage: "COMPLETED" }], now);
    expect(u).toHaveLength(1);
    expect(u[0].text).toBe('"Unboxing video" · ₹3,000 — make & upload the video · 14 days left');
    expect(u[0].link).toBe("/creator/ugc/orders");
  });
  it("rate: no guessed reach; per format; typed reach", () => {
    expect(L.fairRates({ followers_instagram: 12000 }).reach).toBe(0);
    expect(L.reachFromText("kitna charge karu 10k followers")).toBe(0);
    expect(L.reachFromText("meri reach 20k hai")).toBe(20000);
    expect(L.reachFromText("avg views 15k, reel ka kitna lu")).toBe(15000);
    expect(L.rateFormat("youtube video ka kitna lu 50k subs")).toBe("yt");
    expect(L.rateFormat("story ka rate")).toBe("story");
    expect(L.fairFor("reel", 20000)).toBe(6000);
    expect(L.fairFor("story", 20000)).toBe(2400);
    expect(L.fairFor("yt", 0)).toBe(0);
  });
  it("scripts / captions / hashtags follow the creator's topic", () => {
    expect(L.topicFrom("reel script likh do masala chai ke liye")).toBe("masala chai");
    expect(L.topicFrom("caption likho diwali sweets reel ke liye")).toBe("diwali sweets");
    expect(L.topicFrom("write a script for my lipstick")).toBe("lipstick");
    expect(L.writeMode("caption likho diwali sweets reel ke liye")).toBe("caption");
    expect(L.writeMode("hashtags do food reel ke liye")).toBe("hashtags");
    expect(L.writeMode("reel script likh do")).toBe("script");
    const tags = L.hashtagsFor("masala chai", "Food");
    expect(tags).toContain("#masalachai"); expect(tags).toContain("#foodie"); expect(tags.length).toBeLessThanOrEqual(12);
  });
});

import { parseCreatorQuery as pq, refineCreators as rc, parseBudgetFit, budgetFit, detectBrandIntent as dbi, reachOf as ro } from "./components/assist/brand/brandLogic";
describe("v419 brand Eva filters + budget", () => {
  it("language / gender filter drops creators with nothing set", () => {
    const list = [{ id: 1, languages: ["Tamil"], gender: "female" }, { id: 2 }, { id: 3, languages: ["Hindi"], gender: "male" }];
    expect(rc(list, { ...pq("tamil creators") }).map((c) => c.id)).toEqual([1]);
    expect(rc(list, { ...pq("female creators") }).map((c) => c.id)).toEqual([1]);
  });
  it("followers minimum + reach from instagram_stats + 3-digit count", () => {
    expect(pq("1 lakh se zyada followers wale creators").followersMin).toBe(100000);
    expect(pq("creators followers 50k se upar").followersMin).toBe(50000);
    expect(pq("50k se kam followers creators").followersMax).toBe(50000);
    expect(ro({ instagram_stats: { avg_views: 12000 } })).toBe(12000);
    expect(pq("100 creators dikhao fashion").count).toBe(100);
  });
  it("budget questions", () => {
    expect(parseBudgetFit("10 creators 50k mein?")).toEqual({ count: 10, budget: 50000 });
    expect(parseBudgetFit("budget 1 lakh hai kitne creators milenge")).toEqual({ count: 0, budget: 100000 });
    expect(parseBudgetFit("fashion creators ₹15k tak")).toBeNull();
    expect(dbi("10 creators 50k mein?").intent).toBe("budgetFit");
    expect(dbi("Jaipur fashion creators ₹15k tak").intent).toBe("creators");
    const list = [4000, 5000, 6000, 9000, 20000, 0].map((r, i) => ({ id: i, rate_reel: r }));
    const r = budgetFit(list, { count: 3, budget: 18000 });
    expect(r).toMatchObject({ priced: 5, per: 6000, under: 3, enough: true, needFor: 15000 });
    expect(budgetFit(list, { count: 0, budget: 10000 }).fit).toBe(2);
    expect(budgetFit(list, { count: 5, budget: 20000 }).enough).toBe(false);
  });
});

describe("v419 brand Eva — every creator detail", () => {
  const P = (q) => pq(q);
  it("parses state, gender split, engagement, age, barter, YouTube, verified", () => {
    const a = P("Rajasthan ke 5 male 5 female fashion creators");
    expect(a.state).toBe("rajasthan"); expect(a.split).toEqual({ male: 5, female: 5 }); expect(a.count).toBe(10); expect(a.gender).toBe("");
    expect(P("engagement 4% se upar food creators").minEr).toBe(4);
    expect(P("4% engagement wale creators").minEr).toBe(4);
    expect(P("age 18-25 creators barter wale")).toMatchObject({ ageMin: 18, ageMax: 25, barter: true });
    expect(P("youtubers verified tech")).toMatchObject({ platform: "youtube", verified: true });
    expect(P("UP ke creators dikhao").state).toBe("uttar pradesh");
    expect(P("Jaipur creators").state).toBe("");
    expect(P("hindi bangla creators").language).toBe("hindi");
  });
  it("filters on them and picks the gender split", () => {
    const list = [
      { id: 1, gender: "Male", state: "Rajasthan", engagement_rate: 5, avg_views_30d: 900, barter_mode: "partial_barter", age_band: "18-24" },
      { id: 2, gender: "male", state: "Rajasthan", engagement_rate: 2, avg_views_30d: 5000, barter_mode: "cash_only" },
      { id: 3, gender: "Female", city: "Jaipur", state: "Rajasthan", engagement_rate: 6, avg_views_30d: 3000, followers_youtube: 2000, instagram_verified_at: "x" },
      { id: 4, gender: "", state: "Rajasthan", engagement_rate: 9 },
      { id: 5, gender: "female", state: "Gujarat", engagement_rate: 9 },
    ];
    expect(rc(list, P("Rajasthan ke 1 male 1 female creators")).map((c) => c.id)).toEqual([2, 3]);
    expect(rc(list, P("engagement 4% creators")).map((c) => c.id)).toEqual([1, 3, 4, 5]);
    expect(rc(list, P("barter wale creators")).map((c) => c.id)).toEqual([1]);
    expect(rc(list, P("age 18-22 creators")).map((c) => c.id)).toEqual([1]);
    expect(rc(list, P("verified youtubers")).map((c) => c.id)).toEqual([3]);
  });
});

import * as CL from "./components/assist/creator/creatorLogic";
describe("v419 creator Eva as a manager", () => {
  const I = (t) => CL.detectCreatorIntent(t)?.intent;
  it("routes the new asks", () => {
    expect(I("meri profile complete karo")).toBe("fillProfile");
    expect(I("Complete my profile in chat")).toBe("fillProfile");
    expect(I("meri dob 10 may 2001 hai")).toBe("fillProfile");
    expect(I("paisa kab aayega")).toBe("payWhen");
    expect(I("when will i get paid")).toBe("payWhen");
    expect(I("is mahine ki report")).toBe("monthReport");
    expect(I("agreement samjhao")).toBe("agreement");
    expect(I("7 din ka plan banao")).toBe("plan");
    expect(I("brand ne 5000 offer kiya, reply likho")).toBe("brandReply");
    expect(I("mere liye best campaign kaunsa hai")).toBe("match");
    expect(I("show campaigns for me")).toBe("campaigns");
    expect(I("mera rate kitna hona chahiye")).toBe("rate");
  });
  it("parses profile answers", () => {
    expect(CL.parseFill("gender", "ladki")).toMatchObject({ payload: { gender: "Female" } });
    expect(CL.parseFill("dob", "10 May 2001").payload.dob).toBe("2001-05-10");
    expect(CL.parseFill("dob", "10/05/2001").payload.dob).toBe("2001-05-10");
    expect(CL.parseFill("dob", "31/02/2001")).toBeNull();
    expect(CL.parseFill("dob", "10 May 2020")).toBeNull();
    expect(CL.parseFill("languages", "hindi aur english").payload.languages).toEqual(["Hindi", "English"]);
    expect(CL.parseFill("city", "Jaipur").payload.city).toBe("Jaipur");
    expect(CL.parseFill("niche", "fashion, beauty").payload.category).toBe("Fashion, Beauty");
    expect(CL.parseFill("barter", "haan chalega").payload.barter).toBe("Products Only");
    expect(CL.parseFill("barter", "sirf paise").payload.barter).toBe("Paid Campaigns Only");
    expect(CL.missingFill({ gender: "Male", languages: ["Hindi"], city: "Jaipur" })).toEqual(["dob", "niche", "barter"]);
    expect(CL.fillsInText("meri DOB 10 May 2001 hai").map((x) => x[0])).toEqual(["dob"]);
  });
  it("payments, report, plan, contract, reply", () => {
    const now = Date.parse("2026-11-09T06:00:00Z");
    const tx = [{ creator_net_amount: 10800, status: "held", payout_status: "pending", brand_name: "QA Foods", kind: "campaign" },
      { creator_net_amount: 5000, status: "released", payout_status: "RELEASED", brand_name: "Boat", released_at: "2026-11-06T06:00:00Z" },
      { creator_net_amount: 7200, status: "released", payout_status: "completed", payout_completed_at: "2026-11-02T06:00:00Z", payout_reference: "UTR1" }];
    const p = CL.paymentLines(tx, { kycOk: true }, now);
    expect(p.map((x) => x.tone)).toEqual(["wait", "ok", "done"]);
    expect(p[1].text).toMatch(/approved/);
    expect(p[2].text).toMatch(/UTR1/);
    const r = CL.monthReport({ txns: tx, applications: [{ created_at: "2026-11-03T06:00:00Z", status: "accepted" }] }, new Date(now));
    expect(r.earned).toBe(12200); expect(r.apps).toBe(1); expect(r.accepted).toBe(1);
    expect(CL.contentPlan({ category: "Food" }, now).days).toHaveLength(7);
    expect(CL.contractFlags("The brand gets rights in perpetuity, exclusive for 1 year, payment net 90 days").length).toBe(3);
    expect(CL.brandReplyDraft({ kind: "counter", offer: 5000, myRate: 9000 })).toMatch(/₹9,000/);
  });
});
