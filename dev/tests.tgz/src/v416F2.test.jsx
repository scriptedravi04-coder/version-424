// v416 (F2): payments & deals pages — one payments source, honest totals, full receipts, funded deals, copy.
import { describe, it, expect, afterEach } from "vitest";
import React from "react";
import { readFileSync } from "fs";
import path from "path";
import { render, screen, cleanup } from "@testing-library/react";
afterEach(() => cleanup());
import { paymentsSummary, overviewItemToTx } from "./components/payments/BrandPaymentsMobile";
import { normaliseRefund } from "./components/payments/BrandRefundsCard";
import InvoiceModal from "./components/payments/InvoiceModal";
import { ugcHeldFromOverview } from "./pages/brand/BrandUGCPayments";
import { rowLooksFunded, dealIsFunded, isUgcItem } from "./pages/collabs/Collabs";
import DealProgressStepper from "./components/deals/DealProgressStepper";

const read = (f) => readFileSync(path.join(process.cwd(), f), "utf8");
const txt = () => document.body.textContent.replace(/\s+/g, " ");

describe("v416 · payments overview (U1/U2)", () => {
  it("summary uses held_now / released_total / refunded_total (new names)", () => {
    const s = paymentsSummary({ summary: { held_now: 27000, in_escrow: 1, released_total: 3000, refunded_total: 12000, active_ugc: 1 }, items: [], refunds: [] });
    expect(s.held).toBe(27000);
    expect(s.released).toBe(3000);
    expect(s.refunded).toBe(12000);
    expect(s.activeLine).toBe("1 UGC");
  });
  it("falls back to the old names and per-row amounts", () => {
    const s = paymentsSummary({
      summary: { in_escrow: 12000, spent_this_year: 99999 },
      items: [{ status: "released", amount: 8800, deal_amount: 8000 }, { status: "escrow", amount: 12000 }],
      refunds: [{ status: "refunded", amount: 500 }, { status: "pending", amount: 700 }],
    });
    expect(s.held).toBe(12000);
    expect(s.released).toBe(8000); // never spent_this_year (that includes held money)
    expect(s.refunded).toBe(500);
    // per-row released (part of a UGC brief) wins when present
    expect(paymentsSummary({ summary: {}, items: [{ status: "escrow", released: 3000 }, { status: "released", released: 8000 }] }).released).toBe(11000);
  });
  it("desktop and phone read the same overview; desktop no longer reads escrow-transactions", () => {
    const d = read("src/pages/brand/BrandPayments.jsx");
    expect(d).toContain('api.get("brand/payments-overview"');
    expect(d).not.toContain("escrow-transactions");
    expect(d).toContain("overview={overview}");
    const m = read("src/components/payments/BrandPaymentsMobile.jsx");
    expect(m).not.toContain(">Released this year<");
    expect(m).toContain("Released to creators");
  });
  it("UGC held = open paid briefs (server number first, else brief amount minus released orders)", () => {
    expect(ugcHeldFromOverview({ summary: { ugc_held_now: 15000 }, items: [] })).toBe(15000);
    const ov = { summary: {}, items: [{ kind: "ugc", status: "escrow", brief_id: "b1", amount: 18000 }, { kind: "campaign", status: "escrow", amount: 5000 }] };
    expect(ugcHeldFromOverview(ov, [{ brief_id: "b1", status: "COMPLETED", creator_payout: 3000 }])).toBe(15000);
    expect(ugcHeldFromOverview({ summary: {}, items: [{ kind: "ugc", status: "escrow", held: 6000, amount: 18000 }] })).toBe(6000);
    expect(ugcHeldFromOverview(null)).toBeNull();
  });
  it("refunds from /brand/refunds and from the overview read the same", () => {
    expect(normaliseRefund({ id: "1", status: "PROCESSED", reference: "UTR1", amount: 100, refunded_at: "2026-11-01" })).toMatchObject({ status: "refunded", utr: "UTR1" });
    expect(normaliseRefund({ id: "2", status: "refunded", utr: "UTR2", amount: 100, kind: "ugc" })).toMatchObject({ status: "refunded", utr: "UTR2", kind: "ugc" });
    expect(normaliseRefund({ id: "3", status: "FAILED", failure_reason: "bad UPI" })).toMatchObject({ status: "failed", failure: "bad UPI" });
    expect(normaliseRefund({ id: "4", status: "PENDING" }).status).toBe("pending");
  });
  it("refunds card shows a retry instead of disappearing on a failed load (CR21)", () => {
    const s = read("src/components/payments/BrandRefundsCard.jsx");
    expect(s).toContain("brand-refunds-error");
    expect(s).not.toContain(".catch(() => setData({ refunds: [] }))");
  });
});

describe("v416 · UGC receipt (U3/U17/U31)", () => {
  const ugcItem = { id: "brief_b1", kind: "ugc", brief_id: "b1", title: "Masala launch", who: "2 creators", payee_name: "Creators (2)", amount: 3000,
    gross_amount: 3000, deal_amount: 3000, brand_paid_amount: 3283, brand_fee_amount: 240, brand_fee_gst: 43, brand_fee_pct: 8,
    transaction_id: "txn_abcdefghijklmnop", payment_id: "pay_QWERTYUIOPASDF", date: "2026-11-02T10:00:00Z" };
  it("maps an overview row to the receipt fields", () => {
    const tx = overviewItemToTx(ugcItem);
    expect(tx).toMatchObject({ gross_amount: 3000, brand_paid_amount: 3283, brand_fee_amount: 240, brand_fee_gst: 43, creator_name: "Creators (2)", order_type: "ugc", campaign_title: "Masala launch" });
  });
  it("receipt shows fee + GST and bills what was paid, full ids, real payee, Download PDF", () => {
    render(<InvoiceModal transaction={overviewItemToTx(ugcItem)} isBrand creatorName="Creators (2)" brandName="QA Foods" onClose={() => {}} />);
    expect(txt()).toMatch(/Total Billed Amount:?\s*₹3,283\.00/);
    expect(screen.getByTestId("invoice-brand-fee").textContent).toMatch(/₹240/);
    expect(screen.getByTestId("invoice-brand-fee-gst").textContent).toMatch(/₹43/);
    expect(txt()).toContain("pay_QWERTYUIOPASDF");
    expect(txt()).toContain("TXN_ABCDEFGHIJKLMNOP".replace("TXN_", ""));
    expect(txt()).toContain("Creators (2)");
    expect(txt()).toContain("UGC Content Deliverables");
    expect(txt()).toContain("Download PDF");
    expect(txt()).not.toContain("Print / Save PDF");
  });
  it("only the total paid known → the difference shows as fee + GST", () => {
    render(<InvoiceModal transaction={{ id: "t9", gross_amount: 3000, brand_paid_amount: 3283, order_type: "ugc", campaign_title: "X" }} isBrand onClose={() => {}} />);
    expect(screen.getByTestId("invoice-brand-fee").textContent).toMatch(/Convenience fee & GST.*₹283/);
    expect(txt()).toMatch(/Total Billed Amount:?\s*₹3,283\.00/);
  });
  it("no 'Campaign Partnership' placeholder; '2 creators' becomes 'Creators (2)'", () => {
    render(<InvoiceModal transaction={{ id: "t8", gross_amount: 3000, order_type: "ugc" }} isBrand creatorName="2 creators" onClose={() => {}} />);
    expect(txt()).not.toContain("Campaign Partnership");
    expect(txt()).toContain("UGC brief");
    expect(txt()).toContain("Creators (2)");
  });
  it("PDF: brand copy says the payment is held in escrow; fee + GST line", () => {
    const s = read("src/utils/invoicePdf.js");
    expect(s).not.toContain("Your payment transfer of INR");
    expect(s).toContain("PAYMENT RECEIVED");
    expect(s).toContain("unsplitFee");
  });
});

describe("v416 · deals (U4/U13/U14/M16/U18/U19/U25/U32/CR23)", () => {
  it("a thread with flow_state escrow_funded / ESCROW_HELD or a held payment = funded", () => {
    expect(rowLooksFunded({ flow_state: "escrow_funded" })).toBe(true);
    expect(rowLooksFunded({ status: "ESCROW_HELD" })).toBe(true);
    expect(rowLooksFunded({ payment_funded: true })).toBe(true);
    expect(rowLooksFunded({ status: "in_progress" })).toBe(false);
    expect(rowLooksFunded({ escrow_hold: false, escrow_hold_at: "2026-11-01" })).toBe(false);
    const deal = { id: "deal1", thread_id: "thread_camp_deal1", raw: { id: "deal1", status: "in_progress", raw: {} } };
    expect(dealIsFunded(deal)).toBe(false);
    expect(dealIsFunded(deal, { threads: { thread_camp_deal1: { flow_state: "escrow_funded" } } })).toBe(true);
    expect(dealIsFunded(deal, { heldDealIds: new Set(["deal1"]) })).toBe(true);
  });
  it("list + drawer use the funded flag", () => {
    expect(read("src/pages/collabs/Collabs.jsx")).toContain("deal.isFunded ||");
    expect(read("src/components/deals/DealDetailDrawer.jsx")).toContain("deal.isFunded === true");
  });
  it("UGC history rows are named as UGC orders", () => {
    expect(isUgcItem({ id: "ugcord_1", raw: {} })).toBe(true);
    expect(isUgcItem({ subtitle: "Completed UGC Order", raw: {} })).toBe(true);
    expect(isUgcItem({ id: "deal1", raw: { id: "deal1" } })).toBe(false);
    expect(read("src/pages/collabs/Collabs.jsx")).toContain("'UGC order'");
  });
  it("brand mobile empty Applications tab has brand copy and goes to /brand/campaigns", () => {
    const m = read("src/components/deals/mobile/DealsMobile.jsx");
    expect(m).toContain("Creators who apply to your campaigns will appear here.");
    expect(m).toContain('isBrandView ? "View my campaigns" : "Browse live campaigns"');
    expect(read("src/pages/collabs/Collabs.jsx")).toContain('navigate(isBrand ? "/brand/campaigns" : "/campaigns")');
  });
  it("tablet: deals are one column until xl; negotiating highlights no step", () => {
    const c = read("src/pages/collabs/Collabs.jsx");
    expect(c).not.toContain("md:grid-cols-2 lg:grid-cols-2");
    expect(c).toContain("grid-cols-1 xl:grid-cols-2");
    expect(c).toContain('isNegotiating ? "Not started"');
  });
  it("decline has a busy guard", () => {
    const c = read("src/pages/collabs/Collabs.jsx");
    expect(c).toContain("if (busyId) return;");
    expect(c).toContain("disabled={Boolean(busyId)}");
  });
  it("completed stepper says bank, not wallet", () => {
    render(<DealProgressStepper stage="COMPLETED" />);
    expect(txt()).not.toMatch(/wallet/i);
    expect(txt()).toContain("payout reaches the bank in 1–2 working days");
  });
  it("deal page: real title, agreed amount, 4 steps, plain words", () => {
    const d = read("src/pages/collabs/DealDetail.jsx");
    expect(d).toContain("pageTitle");
    expect(d).toContain('["In Production", "Waiting for Approval", "Approved", "Completed"]');
    expect(d).not.toContain("electronic stamp compliance standards");
    expect(d).not.toContain("dispatch their proposed draft review asset link");
    expect(d).not.toContain("Back to My Collabs");
    expect(d).toContain("Back to Deals");
    expect(read("src/components/payments/FeeBreakup.jsx")).toContain('totalLabel = "Total you pay"');
  });
  it("UGC payments table fits a tablet (no 640px minimum)", () => {
    const u = read("src/pages/brand/BrandUGCPayments.jsx");
    expect(u).not.toContain("min-w-[640px]");
    expect(u).toContain("hidden lg:table-cell");
  });
});
