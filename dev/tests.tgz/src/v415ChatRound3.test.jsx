// v415 round 3 (F5a) — chat fixes: H1 deliverables, H2 tablet layout, H3 funded states, M4 calm errors,
// M7 links, M8 needs-action / badge refresh, M9 deal info steps, M10 dialogs, M11 cancel copy, LOW copy.
import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";
import React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { splitLinks, LinkifiedText } from "./components/chat/MessageBubble";
import { calmError, calmText } from "./components/chat/calmError";
import { deriveDealState, hasExtraFundedSignal } from "./components/chat/dealState";
import { dealInfoStep } from "./components/chat/DealInfoPanel";
import { getInboxChip } from "./components/chat/mobile/chatStageMap";
import { deliverablesLabel } from "./utils/safeFormat";

const read = (p) => fs.readFileSync(path.join(process.cwd(), p), "utf8");

describe("H3 · funded deal never asks to pay again", () => {
  const base = { id: "thread_camp_1", status: "ACTIVE", agreement_signed_brand: true, agreement_signed_creator: true, payment_funded: false };
  it("flow_state escrow_funded (any case) counts as funded", () => {
    for (const fs_ of ["escrow_funded", "ESCROW_FUNDED", "Escrow_Funded"]) {
      expect(deriveDealState({ thread: { ...base, flow_state: fs_ }, isBrand: true }).isPaymentFunded).toBe(true);
    }
  });
  it("a held transaction or a server 'payment held' card counts; a typed message does not", () => {
    expect(hasExtraFundedSignal({ ...base, transaction: { status: "ESCROW_HELD" } })).toBe(true);
    const sys = { message_type: "payment_secured", sender_role: "system", content: "Payment held safely" };
    expect(hasExtraFundedSignal(base, [sys])).toBe(true);
    const typed = { message_type: "text", sender_user_id: "u_brand", content: "payment held?" };
    expect(hasExtraFundedSignal(base, [typed])).toBe(false);
    expect(deriveDealState({ thread: { ...base, flow_state: "AI_AGREEMENT_READY" }, isBrand: true }).isPaymentFunded).toBe(false);
  });
  it("a refunded thread is not funded by these extra signals", () => {
    expect(hasExtraFundedSignal({ ...base, flow_state: "ESCROW_FUNDED", payment_status: "REFUNDED" })).toBe(false);
  });
  it("desktop ChatBox uses the same shared list + helper", () => {
    const src = read("src/components/chat/ChatBox.jsx");
    expect(src).toMatch(/FUNDED_FLOW_STATES\.includes\(flowState\)/);
    expect(src).toMatch(/hasExtraFundedSignal\(currentThread, messages\)/);
    expect(src.split("\n").length).toBeLessThan(2100);
  });
});

describe("M7 · links in chat are clickable and safe", () => {
  it("splits http(s) links and leaves trailing punctuation out", () => {
    const parts = splitLinks("see https://drive.google.com/file/d/abc/view. thanks");
    expect(parts.map((p) => p.href).filter(Boolean)).toEqual(["https://drive.google.com/file/d/abc/view"]);
    expect(parts.map((p) => p.text).join("")).toBe("see https://drive.google.com/file/d/abc/view. thanks");
  });
  it("never links javascript: and renders target=_blank rel=noopener noreferrer", () => {
    expect(splitLinks("javascript:alert(1)").some((p) => p.href)).toBe(false);
    const html = renderToStaticMarkup(<LinkifiedText text={'hi https://ex.com/a?x=1 <b>"x"</b>'} />);
    expect(html).toContain('href="https://ex.com/a?x=1"');
    expect(html).toContain('target="_blank"');
    expect(html).toMatch(/rel="noopener noreferrer/);
    expect(html).not.toContain("<b>");
  });
  it("mobile bubble uses it too", () => {
    expect(read("src/components/chat/mobile/MobileMessageRow.jsx")).toMatch(/<LinkifiedText text=\{content\}/);
  });
});

describe("M4 · send failure toast is a sentence, never raw server text", () => {
  const err = (status, detail) => ({ response: { status, data: { detail } } });
  it("drops one-word / code replies and 5xx text", () => {
    expect(calmError(err(400, "x"), "Message not sent.")).toBe("Message not sent.");
    expect(calmError(err(400, "bad_request"), "Fallback")).toBe("Fallback");
    expect(calmError(err(500, "Something exploded badly here"), "Fallback")).toBe("Fallback");
    expect(calmError(err(400, "Minimum offer is ₹3,000"), "Fallback")).toBe("Minimum offer is ₹3,000");
    expect(calmText("x")).toBe(null);
    expect(calmText("This chat is closed now.")).toBe("This chat is closed now.");
  });
  it("re-sending a failed text reuses its client_msg_id (desktop + mobile)", () => {
    expect(read("src/components/chat/ChatBox.jsx")).toMatch(/m\.status === 'failed' && String\(m\.content \|\| ''\)\.trim\(\) === msg\)\?\.client_msg_id \|\| makeClientMsgId\(\)/);
    expect(read("src/components/chat/mobile/useChatThreadMobile.js")).toMatch(/latestMsgsRef\.current[\s\S]{0,140}client_msg_id \|\| makeClientMsgId\(\)/);
  });
});

describe("H1 · campaign details never crash on object deliverables", () => {
  it("labels objects and JSON strings", () => {
    expect(deliverablesLabel([{ type: "Reel", count: 2 }, "Story"], "\n").split("\n")).toEqual(["2 × Reel", "Story"]);
    expect(deliverablesLabel('[{"type":"Post"}]')).toBe("Post");
  });
  it("BurgerMenuSupport renders text lines, not the raw items", () => {
    const src = read("src/components/chat/BurgerMenuSupport.jsx");
    expect(src).toMatch(/deliverableLines\.map\(\(d, i\) => <li key=\{i\}>\{d\}<\/li>\)/);
    expect(src).not.toMatch(/thread\.deliverables\.map/);
  });
});

describe("M10 / M11 · chat menu popups", () => {
  const src = read("src/components/chat/BurgerMenuSupport.jsx");
  it("all five popups use PopupPanel (role=dialog, focus, Escape) with a label", () => {
    expect((src.match(/<PopupPanel /g) || []).length).toBe(5);
    for (const id of ["status", "details", "contacts", "support", "cancelDeal"]) expect(src).toContain(`id="burger-${id}-title"`);
  });
  it("cancel on a funded deal says how much is held and that support refunds it", () => {
    expect(src).toMatch(/Ybex support reviews your request and refunds ₹\$\{heldAmount/);
  });
});

describe("M9 · deal information steps", () => {
  it("funded / lowercase states highlight a step", () => {
    expect(dealInfoStep({ status: "ACTIVE", flow_state: "escrow_funded" })).toBe("ACTIVE");
    expect(dealInfoStep({ status: "NEGOTIATING", flow_state: "ai_agreement_ready" })).toBe("NEGOTIATING");
    expect(dealInfoStep({ status: "CONTENT_SUBMITTED", flow_state: "submitted" })).toBe("CONTENT_SUBMITTED");
    expect(dealInfoStep({ status: "COMPLETED" })).toBe("COMPLETED");
    expect(dealInfoStep({ status: "CANCELLED", flow_state: "CANCELLED" })).toBe("CANCELLED");
  });
  it("plain step names and Escape closes", () => {
    const src = read("src/components/chat/DealInfoPanel.jsx");
    expect(src).not.toMatch(/step\.replace\('_', ' '\)/);
    expect(src).toMatch(/e\.key === 'Escape'/);
  });
});

describe("M8 · needs action + badge refresh", () => {
  it("an offer received by the creator is an action", () => {
    const chip = getInboxChip({ id: "t1", status: "NEGOTIATING", flow_state: "NEGOTIATING", last_message: { message_type: "brand_invitation_offer", sender_role: "brand" } }, false);
    if (chip.label === "Offer received") expect(chip.needsAction).toBe(true);
  });
  it("opening a chat asks the nav badge to recount", () => {
    expect(read("src/pages/dashboard/Chat.jsx")).toContain('"ybex:chat-read"');
    expect(read("src/components/chat/mobile/useChatThreadMobile.js")).toContain('"ybex:chat-read"');
  });
});

describe("H2 · tablet inbox shows list OR chat", () => {
  it("lg breakpoint split, min-w-0 pane, back button until lg", () => {
    const src = read("src/pages/dashboard/Chat.jsx");
    expect(src).toMatch(/activeThread \? 'hidden lg:flex' : 'flex'/);
    expect(src).toMatch(/flex-1 min-w-0 flex flex-col \$\{!activeThread \? 'hidden lg:flex' : 'flex'\}/);
    expect(read("src/components/chat/chatBox/ChatBoxHeader.jsx")).toMatch(/className="lg:hidden -ml-1/);
  });
});

describe("LOW · chat copy", () => {
  it("no emoji enum labels and no 'mentioned' empty state", () => {
    expect(read("src/components/chat/SystemMessage.jsx")).not.toMatch(/Brand Action 🏢|Ybex Official Notice/);
    expect(read("src/components/chat/ChatBox.jsx")).not.toMatch(/whenever you're mentioned/);
  });
});
