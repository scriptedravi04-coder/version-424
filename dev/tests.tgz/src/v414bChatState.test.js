// v414b: chat state fixes (items 9, 10, 11, 12, 16, 17, 18, 19 of the v414 review).
import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";
import { deriveDealState, isThreadCancelled, cancelledLabel, isClosedNotCompleted } from "./components/chat/dealState";
import { getChatStage, getInboxChip } from "./components/chat/mobile/chatStageMap";
import { counterTermsFrom } from "../backend/deals_chat_routes";

const read = (p) => fs.readFileSync(path.resolve(__dirname, "..", p), "utf8");

describe("9 · price lock matches desktop", () => {
  const camp = (flow) => ({ id: "thread_camp_1", campaign_id: "c1", status: "NEGOTIATING", flow_state: flow });
  it("an unsigned prepared agreement does not lock the price", () => {
    for (const f of ["AI_AGREEMENT_READY", "AWAITING_SIGNATURE", "AGREEMENT_PENDING", "CONTRACT_READY"]) {
      expect(deriveDealState({ thread: camp(f) }).isNegotiationLocked).toBe(false);
    }
  });
  it("a signature or a later stage still locks it", () => {
    expect(deriveDealState({ thread: { ...camp("AI_AGREEMENT_READY"), agreement_signed_brand: true } }).isNegotiationLocked).toBe(true);
    for (const f of ["CONTRACT_SIGNED", "PROOF_SUBMITTED", "ACTIVE", "COMPLETED"]) {
      expect(deriveDealState({ thread: camp(f) }).isNegotiationLocked).toBe(true);
    }
  });
});

describe("12 · cancelled / refunded UGC orders are not completed", () => {
  const ugc = (extra) => ({ id: "thread_ugc_1", ugc_order_id: "ugcord_1", status: "COMPLETED", flow_state: "CANCELLED", ...extra });
  it("status COMPLETED + flow CANCELLED shows cancelled, not completed", () => {
    const s = deriveDealState({ thread: ugc({}) });
    expect(s.isDealCompleted).toBe(false);
    expect(s.isCancelled).toBe(true);
    const stage = getChatStage({ thread: ugc({}), isUgcOrder: true, isDealCompleted: s.isDealCompleted, messages: [] });
    expect(stage.key).toBe("cancelled");
    expect(stage.action).toBeNull();
  });
  it("refunded payment / expired order labels", () => {
    const refunded = ugc({ flow_state: "ACTIVE", ugc_order: { status: "IN_PROGRESS", payment_status: "REFUNDED" } });
    expect(isClosedNotCompleted(refunded)).toBe(true);
    expect(deriveDealState({ thread: refunded }).isCancelled).toBe(true);
    expect(cancelledLabel(refunded)).toBe("Refunded");
    const expired = ugc({ flow_state: "ACTIVE", ugc_order: { status: "EXPIRED" } });
    expect(deriveDealState({ thread: expired }).isDealCompleted).toBe(false);
    expect(cancelledLabel(expired)).toBe("Expired");
  });
  it("a real completed order is still completed", () => {
    const done = { id: "thread_ugc_2", ugc_order_id: "ugcord_2", status: "COMPLETED", flow_state: "COMPLETED", ugc_order: { status: "COMPLETED", payment_status: "RELEASED" } };
    const s = deriveDealState({ thread: done });
    expect(s.isDealCompleted).toBe(true);
    expect(s.isCancelled).toBe(false);
    expect(getChatStage({ thread: done, isUgcOrder: true, isDealCompleted: true, messages: [] }).key).toBe("completed");
  });
  it("inbox chip says cancelled", () => {
    expect(getInboxChip(ugc({}), true).label).toBe("Cancelled");
  });
  it("desktop ChatBox gates isDealCompleted the same way", () => {
    expect(read("src/components/chat/ChatBox.jsx")).toMatch(/const isDealCompleted = currentThread && !isClosedNotCompleted\(currentThread\)/);
  });
});

describe("19 · closed chats match the server list", () => {
  it("covers CANCELLED, CANCELED, DECLINED, REJECTED, REFUNDED, EXPIRED on status / flow / deal", () => {
    for (const v of ["CANCELLED", "CANCELED", "DECLINED", "REJECTED", "REFUNDED", "EXPIRED"]) {
      expect(isThreadCancelled({ flow_state: v })).toBe(true);
      expect(isThreadCancelled({ status: v })).toBe(true);
      expect(isThreadCancelled({ deal: { status: v } })).toBe(true);
    }
    expect(isThreadCancelled({ flow_state: "REVISION_DECLINED" })).toBe(false);
    expect(isThreadCancelled({ status: "COMPLETED", flow_state: "COMPLETED" })).toBe(false);
  });
  it("declined chip keeps its old text", () => {
    expect(getInboxChip({ id: "thread_camp_3", campaign_id: "c", status: "NEGOTIATING", flow_state: "DECLINED" }, true).label).toBe("Declined by creator");
  });
  it("desktop and mobile swap the composer for the closed note", () => {
    const desk = read("src/components/chat/ChatBox.jsx");
    expect(desk).toContain('data-testid="chat-closed-note"');
    expect(desk).toContain('data-testid="chat-closed-note-mobile"');
    expect(read("src/components/chat/mobile/ChatBoxMobile.jsx")).toMatch(/isCancelled \? \( \/\* v414[^\n]*\n\s*<div data-testid="chat-closed-note"/);
  });
});

describe("18 · desktop funded check ignores refunded escrow timestamps", () => {
  it("requires escrow_hold !== false", () => {
    const src = read("src/components/chat/ChatBox.jsx");
    expect(src).toContain("(currentThread?.deal?.escrow_hold_at && currentThread?.deal?.escrow_hold !== false)");
    expect(src).toContain("(currentThread?.ugc_order?.escrow_held_at && currentThread?.ugc_order?.escrow_hold !== false)");
  });
});

describe("10 / 11 · negotiation table", () => {
  const src = read("src/components/chat/NegotiationTable.jsx");
  it("Accept / Decline only while a counter is pending", () => {
    expect(src).toContain("const counterPending = String(thread?.flow_state || '').toUpperCase() === 'NEGOTIATING_COUNTER'");
    expect(src).toContain("setActiveOffer(declinedAfter || !counterPending ? null : latestOffer)");
  });
  it("sends delivery_days / revision_count only when changed", () => {
    expect(src).toContain("...(deadlineTouched ? { delivery_days: deadlineDays } : {})");
    expect(src).toContain("...(revisionsTouched ? { revision_count: revisions } : {})");
    expect(src).not.toMatch(/^\s*delivery_days: deadlineDays,/m);
  });
  it("server moves the deadline only when the offer carried delivery_days", () => {
    expect(counterTermsFrom({ proposed_amount: 5000 })).toEqual({});
    expect(counterTermsFrom({ revision_count: 2 })).toEqual({ revision_count: 2 });
    expect(counterTermsFrom({ delivery_days: null })).toEqual({});
    const now = Date.UTC(2026, 10, 7);
    expect(counterTermsFrom({ delivery_days: 10 }, now).deadline).toBe("2026-11-17");
  });
});

describe("16 · UGC has no negotiation", () => {
  it("mobile hook refuses counters / accepts on UGC", () => {
    const src = read("src/components/chat/mobile/useChatThreadMobile.js");
    expect(src).toMatch(/if \(isUgcOrder\) \{ toast\.error\("UGC price is fixed by the brief, so it can't be negotiated\."\)/);
    expect(src).toMatch(/if \(isUgcOrder\) \{ toast\.error\("UGC price is fixed by the brief, so there's no counter offer to accept\."\)/);
  });
  it("mobile offer cards are read-only on UGC; desktop has no Negotiate on UGC", () => {
    const mob = read("src/components/chat/mobile/ChatBoxMobile.jsx");
    expect(mob).toContain("onCounterOffer={isUgcOrder ? null");
    expect(mob).toContain("onAcceptOffer={isUgcOrder ? null");
    expect(read("src/components/chat/ChatBox.jsx")).toContain("onNegotiate={isUgcOrder ? undefined");
  });
  it("decline-counter can reset a funded UGC counter back to ACTIVE", () => {
    const be = read("backend/deals_chat_routes.ts");
    expect(be).toContain("const fundedUgcReset = reason === 'funded' && !isCampaignThreadRecord(thread) && upper(thread.flow_state) === 'NEGOTIATING_COUNTER';");
    expect(be).toContain("if ((reason === 'funded' && !fundedUgcReset) || reason === 'signed_both') return lockedResponse(res, thread, order);");
    expect(be).toContain('const resetFlow = fundedUgcReset ? "ACTIVE" : "NEGOTIATING";');
  });
});

describe("17 · one-signature update includes NULL flow rows", () => {
  it("uses .or(is.null, neq.ACTIVE)", () => {
    const be = read("backend/deals_chat_routes.ts");
    expect(be).toContain(".or('flow_state.is.null,flow_state.neq.ACTIVE')");
    expect(be).not.toContain(".neq('flow_state', 'ACTIVE')");
  });
});
