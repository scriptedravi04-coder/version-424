// v419 (Ravi): Eva free invoice — maths, reading, routing, and the server's checks.
import { describe, it, expect } from "vitest";
import * as C from "./components/assist/invoice/invoiceCore";
import { detectCreatorIntent } from "./components/assist/creator/creatorLogic";
import { detectBrandIntent } from "./components/assist/brand/brandLogic";
import { invData } from "./components/assist/invoice/EvaInvoice";

describe("v419 invoice core", () => {
  it("numbers by financial year", () => {
    expect(C.fyOf("2026-11-09")).toBe("26-27");
    expect(C.fyOf("2027-03-31")).toBe("26-27");
    expect(C.fyOf("2027-04-01")).toBe("27-28");
    expect(C.invoiceNumber("Aarohi Sharma", "2026-11-09", 7)).toBe("AS/26-27/0007");
  });
  it("GST: none without GSTIN, CGST+SGST same state, IGST other state; whole rupees add up", () => {
    const base = { items: [{ d: "Reel", q: 2, r: 9000 }, { d: "Story", q: 1, r: 3333 }], disc: { mode: "pct", val: 10 }, tds: "none" };
    const a = C.calc({ ...base, gstOn: false }, "27");
    expect(a.sub).toBe(21333); expect(a.disc).toBe(2133); expect(a.gst).toBe(0); expect(a.total).toBe(19200);
    const b = C.calc({ ...base, gstOn: true, billTo: { st: "27" } }, "27");
    expect(b.inter).toBe(false); expect(b.half).toBe(1728); expect(b.total).toBe(19200 + 3456);
    const c = C.calc({ ...base, gstOn: true, billTo: { st: "29" } }, "27");
    expect(c.inter).toBe(true); expect(c.igst).toBe(3456);
  });
  it("TDS is on the amount before GST, and never on a Ybex deal", () => {
    const r = { items: [{ d: "Reel", q: 1, r: 10000 }], gstOn: true, billTo: { st: "07" }, tds: "194C1" };
    expect(C.calc(r, "07").tds).toBe(100);
    expect(C.calc(r, "07").net).toBe(11800 - 100);
    expect(C.calc({ ...r, viaYbex: true }, "07").tds).toBe(0);
  });
  it("reads items, amounts, GSTIN, UPI, bank, state", () => {
    expect(C.parseItems("2 reels 9k each and 1 story 3500")).toEqual([{ d: "Instagram reel", q: 2, r: 9000 }, { d: "Instagram story", q: 1, r: 3500 }]);
    expect(C.parseItems("3 reels for 30000 total")[0]).toMatchObject({ q: 3, r: 10000 });
    expect(C.parseAmount("1.2 lakh")).toBe(120000);
    expect(C.gstinOk("27AAPFU0939F1ZV")).toBe(true);
    expect(C.gstinOk("27AAPFU0939F1ZX")).toBe(false);
    expect(C.upiIn("pay me at riya.k@okhdfc please")).toBe("riya.k@okhdfc");
    expect(C.bankIn("50100123456789 HDFC0001234")).toEqual({ acc: "50100123456789", ifsc: "HDFC0001234" });
    expect(C.stateCodeIn("Bangalore")).toBe("29");
    expect(C.stateCodeIn("Tamil Nadu")).toBe("33");
    expect(C.words(19350)).toBe("Rupees Nineteen Thousand Three Hundred Fifty only");
  });
  it("server check refuses bad records", () => {
    expect(C.cleanRecord({ items: [], billTo: { name: "X" } }).ok).toBe(false);
    expect(C.cleanRecord({ items: [{ d: "Reel", q: 1, r: 100 }], billTo: { name: "" } }).ok).toBe(false);
    const ok = C.cleanRecord({ items: [{ d: "Reel", q: 1, r: 5000 }], billTo: { name: "Kinara", gstin: "27AAPFU0939F1ZV" }, tds: "hack", dueDays: 999, date: "2026-11-09" });
    expect(ok.ok).toBe(true); expect(ok.rec.tds).toBe("none"); expect(ok.rec.dueDays).toBe(120); expect(ok.rec.billTo.st).toBe("27");
    expect(C.cleanRecord({ items: [{ d: "Reel", q: 1, r: 5000 }], billTo: { name: "K" }, viaYbex: true }).rec.viaYbex).toBe(false); // needs a deal
  });
  it("status", () => {
    expect(C.statusOf({ status: "PENDING", due: "2026-11-01" }, "2026-11-09")).toBe("overdue");
    expect(C.statusOf({ status: "PENDING", due: "2026-11-20" }, "2026-11-09")).toBe("unpaid");
    expect(C.statusOf({ status: "PAID", due: "2026-11-01" }, "2026-11-09")).toBe("paid");
  });
});

describe("v419 invoice in Eva", () => {
  it("opens from creator and brand chat, not for Ybex's own payment invoice", () => {
    for (const t of ["create invoice", "invoice banao", "bill bana do Kinara ke liye", "my invoices", "Invoice", "mujhe invoice chahiye"]) expect(detectCreatorIntent(t)?.intent, t).toBe("invoice");
    for (const t of ["create invoice", "invoice banao", "my invoices"]) expect(detectBrandIntent(t)?.intent, t).toBe("invoice");
    expect(detectBrandIntent("download gst invoice for my payment")?.intent).not.toBe("invoice");
  });
  it("the printed invoice: Ybex deal shows paid through Ybex and no UPI", () => {
    const me = { name: "Riya K", state: "08", gstOn: false, pay: { label: "UPI", v: "riya@okaxis" }, link: "ybexmedia.in/creator/u1", idLabel: "PAN", id: "ABCPK1234L" };
    const rec = { no: "RK/26-27/0001", date: "2026-11-09", due: "2026-11-24", items: [{ d: "Reel", q: 1, r: 8000 }], billTo: { name: "Masala Box" }, tds: "194C1", status: "PENDING" };
    const v = invData(rec, me, "creator", "2026-11-09");
    expect(v.amountDue).toBe("₹7,920"); expect(v.payQr).toMatch(/^upi:\/\/pay\?pa=riya%40okaxis/); expect(v.docTitle).toBe("INVOICE"); expect(v.link).toMatch(/ref=invoice/);
    const y = invData({ ...rec, viaYbex: true, campaign: { name: "Diwali" } }, me, "creator", "2026-11-09");
    expect(y.payQr).toBe(""); expect(y.hasTds).toBe(false); expect(y.amountDue).toBe("₹8,000");
  });
});

// v431 (Ravi's screenshot): "yes" as the item, "2 reels 4500 each" as the price, "change my UPI" after the invoice
import React from "react";
import { render, act, waitFor, cleanup } from "@testing-library/react";
import { vi } from "vitest";
vi.mock("./lib/api", () => {
  const me = { name: "Prorewards", address: "Jaipur", pay: { label: "UPI", v: "old@okhdfc" } };
  let saved = null;
  return { api: {
    get: vi.fn(async () => ({ data: { ok: true, role: "brand", me, clients: [], invoices: [], today: "2026-11-12" } })),
    put: vi.fn(async (_u, body) => { Object.assign(me, body.pay ? { pay: { label: "UPI", v: body.pay.v } } : body); return { data: { ok: true, me: { ...me } } }; }),
    post: vi.fn(async (_u, body) => {
      if (_u === "assist/ai") { // v431: the AI reader — answers only for the "AI" test's phrases, else unsure → rules
        if (/do reel/i.test(body.text)) return { data: { ok: true, data: { action: "update", items: [{ d: "Instagram Reel", q: 2, r: 4500 }] } } };
        if (/kab tak/i.test(body.text)) return { data: { ok: true, data: { action: "answer", reply: "Usually within 7 days." } } };
        return { data: { ok: false } };
      }
      saved = { id: "inv1", no: "PR/26-27/0001", ...body }; return { data: { ok: true, invoice: saved } };
    }),
    patch: vi.fn(async (_u, body) => { saved = { ...saved, ...body }; return { data: { ok: true, invoice: saved } }; }),
  } };
});
import { EvaInvoiceChat } from "./components/assist/invoice/EvaInvoice";
import { api as mockedApi } from "./lib/api";
describe("v431 invoice chat fixes", () => {
  it("yes isn't an item; a full line at the price step counts qty × rate; UPI can be changed after", async () => {
    const ref = React.createRef();
    render(<EvaInvoiceChat ref={ref} role="brand" text="invoice for Chacha" />);
    await waitFor(() => expect(ref.current.state.f?.step).toBe("item"), { timeout: 4000 });
    await waitFor(() => expect(ref.current.state.typing).toBe(false), { timeout: 3000 });
    act(() => ref.current.send("yes"));
    await waitFor(() => expect(ref.current.state.typing).toBe(false), { timeout: 3000 });
    expect(ref.current.state.f.items.length).toBe(0);
    act(() => ref.current.send("shoot"));
    await waitFor(() => expect(ref.current.state.f?.step).toBe("price"), { timeout: 3000 });
    await waitFor(() => expect(ref.current.state.typing).toBe(false), { timeout: 3000 });
    act(() => ref.current.send("2 reels 4500 each"));
    await waitFor(() => expect(ref.current.state.f?.step).toBe("due"), { timeout: 3000 });
    expect(ref.current.state.f.items).toEqual([{ d: expect.any(String), q: 2, r: 4500 }]);
    await waitFor(() => expect(ref.current.state.typing).toBe(false), { timeout: 3000 });
    act(() => ref.current.send("7 days"));
    await waitFor(() => expect(ref.current.state.f?.step).toBe("done"), { timeout: 4000 });
    await waitFor(() => expect(ref.current.state.busy || ref.current.state.typing).toBe(false), { timeout: 3000 });
    act(() => ref.current.send("i want to change me upi id"));
    await waitFor(() => expect(ref.current.state.f?.step).toBe("pay"), { timeout: 3000 });
    await waitFor(() => expect(ref.current.state.typing).toBe(false), { timeout: 3000 });
    act(() => ref.current.send("new@okaxis"));
    await waitFor(() => expect(mockedApi.patch).toHaveBeenCalled(), { timeout: 4000 });
    expect(mockedApi.put).toHaveBeenCalledWith("invoices/profile", { pay: { v: "new@okaxis" } }, expect.anything());
    cleanup();
  }, 20000);
});

describe("v431 invoice AI reader", () => {
  it("uses the AI's reading (Hinglish line → 2 × ₹4,500) and answers questions without losing the step", async () => {
    const ref = React.createRef();
    render(<EvaInvoiceChat ref={ref} role="brand" text="invoice for Chacha" />);
    await waitFor(() => expect(ref.current.state.f?.step).toBe("item"), { timeout: 4000 });
    await waitFor(() => expect(ref.current.state.typing).toBe(false), { timeout: 3000 });
    act(() => ref.current.send("payment kab tak aata hai?"));
    await waitFor(() => expect(ref.current.state.msgs.some((m) => m.text === "Usually within 7 days.")).toBe(true), { timeout: 4000 });
    expect(ref.current.state.f.step).toBe("item");
    await waitFor(() => expect(ref.current.state.typing).toBe(false), { timeout: 3000 });
    act(() => ref.current.send("do reel banayi thi 4500 wali"));
    await waitFor(() => expect(ref.current.state.f?.step).toBe("due"), { timeout: 4000 });
    expect(ref.current.state.f.items).toEqual([{ d: "Instagram Reel", q: 2, r: 4500 }]);
    cleanup();
  }, 20000);
});
