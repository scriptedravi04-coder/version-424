// v416 F3 (UGC brand screens) — tests for the round-3 fixes.
import { describe, it, expect, vi, beforeEach } from "vitest";
import fs from "fs";
import path from "path";

vi.mock("./lib/api", () => ({ api: { get: vi.fn(), post: vi.fn() }, isBrandLike: (r) => ["brand", "agency", "talent_manager"].includes(String((r && r.role) || r || "").toLowerCase()) }));

import { ugcBudgetError, briefClaimLabel, UGC_MIN_BUDGET, UGC_MAX_BUDGET } from "./pages/brand/BrandUGCMobile";
import { countdownLabel } from "./pages/brand/BrandUGCOrders";
import { formatWait } from "./utils/ugcOrderCancel";
import { refundCoverText } from "./components/brand/CancelBriefModal";
import { withUgcOrderLink, ugcOrderIdOf } from "./components/shared/NotificationItem";
import { creatorNoteOf } from "./pages/brand/brandUgc/DeliverablePreviewCard";
import { savePaidBriefOrder, getPaidBriefOrder, savePendingBriefOrder, clearPaidBriefOrder } from "./lib/briefPaymentRetry";

const read = (p) => fs.readFileSync(path.join(process.cwd(), p), "utf8");

describe("CR19 / U12 / U21: UGC budget limits", () => {
  it("₹500 – ₹5,00,000 per creator, errors instead of a clamp", () => {
    expect(UGC_MIN_BUDGET).toBe(2000); // v420 special offer (usually ₹3,000)
    expect(UGC_MAX_BUDGET).toBe(500000);
    expect(ugcBudgetError(0)).toMatch(/at least ₹2,000 \(special offer — usually ₹3,000\)/);
    expect(ugcBudgetError(1999)).toMatch(/at least/);
    expect(ugcBudgetError(2000)).toBe("");
    expect(ugcBudgetError(500000)).toBe("");
    expect(ugcBudgetError(999999)).toMatch(/at most ₹5,00,000/);
    expect(ugcBudgetError("abc")).toMatch(/at least/);
  });
  it("desktop wizard uses the shared rule and no longer clamps on blur", () => {
    const d = read("src/pages/brand/BrandUGCPost.jsx");
    expect(d).toContain("ugcBudgetError(formData.budget)");
    expect(d).not.toMatch(/onBlur=\{\(\) => \{\s*if \(!formData\.budget/);
    expect(d).not.toContain("Testing mode: allow starting from ₹1");
  });
});

describe("U9: one brief status on phone and desktop", () => {
  it("says how many slots are claimed", () => {
    expect(briefClaimLabel(0, 5)).toBe("Finding creators");
    expect(briefClaimLabel(1, 5)).toBe("1 of 5 claimed");
    expect(briefClaimLabel(1, 1)).toBe("Creator assigned");
    expect(briefClaimLabel(3, 3)).toBe("All 3 slots claimed");
    expect(read("src/pages/brand/BrandInstantUGC.jsx")).toContain("briefClaimLabel(claimedC, maxC)");
  });
});

describe("U24: long waits in days", () => {
  it("formatWait and the countdown label", () => {
    expect(formatWait((309 * 60 + 35) * 60000)).toBe("12d 21h");
    expect(formatWait(90 * 60000)).toBe("1h 30m");
    expect(countdownLabel(72)).toBe("72h delivery countdown");
    expect(countdownLabel(528)).toBe("Delivery countdown");
  });
});

describe("U7: cancel refund wording is accurate", () => {
  it("reads the server breakdown and never says 100%", () => {
    const withFee = refundCoverText({ open_slots: 4, refund_breakdown: { service_fee_paid: 283, service_fee_refunded: 0 } });
    expect(withFee).toMatch(/creator budget for the 4 open slots/);
    expect(withFee).toMatch(/service fee \+ GST \(₹283\) is not refunded/);
    expect(refundCoverText({ open_slots: 1, refund_breakdown: { service_fee_paid: 0, service_fee_refunded: 0 } })).toBe("The full creator budget for the 1 open slot comes back to you.");
    expect(refundCoverText({ open_slots: 2 })).toMatch(/Any service fee \+ GST paid is not part/);
    expect(read("src/components/brand/CancelBriefModal.jsx")).not.toContain("100% refundable");
  });
});

describe("CR13: notification deep links open the order", () => {
  it("adds ?order= for brand UGC order links only", () => {
    const n = { event_type: "UGC_READY", event_ref_id: "ugcord_abc_123" };
    expect(ugcOrderIdOf(n)).toBe("ugcord_abc_123");
    expect(withUgcOrderLink("/brand/ugc/orders", n)).toBe("/brand/ugc/orders?order=ugcord_abc_123");
    expect(withUgcOrderLink("/brand/ugc/orders", { event_ref_id: "deal_1" })).toBe("/brand/ugc/orders");
    expect(withUgcOrderLink("/brand/payments", n)).toBe("/brand/payments");
    expect(read("src/pages/brand/BrandUGCOrders.jsx")).toContain('q.get("order")');
    expect(read("src/pages/brand/BrandUGCMobile.jsx")).toContain('new URLSearchParams(location.search).get("order")');
  });
});

describe("CR7: paid brief orders are per user", () => {
  beforeEach(() => { localStorage.clear(); localStorage.setItem("ybex_user", JSON.stringify({ user_id: "A" })); });
  it("another account never sees the order; no user → nothing saved", () => {
    savePaidBriefOrder("order_1", 1000);
    expect(localStorage.getItem("ugc_paid_order:A")).toBeTruthy();
    localStorage.setItem("ybex_user", JSON.stringify({ user_id: "B" }));
    expect(getPaidBriefOrder()).toBeNull();
    localStorage.removeItem("ybex_user");
    savePendingBriefOrder("order_2", 5);
    expect(getPaidBriefOrder()).toBeNull();
    localStorage.setItem("ybex_user", JSON.stringify({ user_id: "A" }));
    clearPaidBriefOrder();
    expect(getPaidBriefOrder()).toBeNull();
  });
});

describe("CR6 / U5: the post button never sticks and a paid retry is labelled", () => {
  it("razorpay reports SDK / simulation failures to onError", () => {
    const r = read("src/lib/razorpay.js");
    expect(r).toContain('if (onError) onError(new Error("Payment window couldn\'t load"))');
    expect(r).toContain("if (direct && onError) onError(err)");
  });
  it("desktop handlePost has a finally; both screens show 'Retry saving brief (no new charge)'", () => {
    const d = read("src/pages/brand/BrandUGCPost.jsx");
    expect(d).toMatch(/finally \{[^}]*if \(!postingRef\.current\) setIsSubmitting\(false\)/);
    expect(d).toContain("Retry saving brief (no new charge)");
    expect(read("src/pages/brand/BrandUGCMobile.jsx")).toContain("Retry saving brief (no new charge)");
  });
});

describe("CR11 / CR12 / CR24: live, fresh, ordered refreshes", () => {
  it("desktop orders bypass the cache and drop stale answers", () => {
    const s = read("src/pages/brand/BrandUGCOrders.jsx");
    expect(s).toContain('api.get("ugc/orders/brand", fresh ? { bypassCache: true } : undefined)');
    expect(s).toContain("if (seq !== fetchSeqRef.current) return true;");
  });
  it("phone screen polls + listens to the socket", () => {
    const s = read("src/pages/brand/BrandUGCMobile.jsx");
    expect(s).toContain('lease.on("ugc_order_updated", onUgcEvent)');
    expect(s).toContain("setInterval(quiet, 30000)");
    expect(s).toContain("{ bypassCache: true }");
  });
});

describe("U8 / U10 / U11 / U28 / U27", () => {
  it("retention wording comes from the shared rule", () => {
    const s = read("src/pages/brand/brandUgc/ApprovedPayoutModal.jsx");
    expect(s).toContain('retentionLine("brand"');
    expect(s).not.toContain("from this order any time.");
  });
  it("no window.confirm on the phone UGC screen", () => {
    expect(read("src/pages/brand/BrandUGCMobile.jsx")).not.toMatch(/window\.confirm\(/);
  });
  it("AI writer needs something typed and never invents a product", () => {
    const s = read("src/pages/brand/BrandUGCMobile.jsx");
    expect(s).not.toContain('|| "D2C Product"');
    expect(read("src/pages/brand/brandUgc/AiPromptSheet.jsx")).toContain("disabled={aiGenerating || !hasTyped}");
  });
  it("creator note shown on phone; poisoned notes skipped", () => {
    expect(creatorNoteOf({ creator_notes: "Shot in daylight" })).toBe("Shot in daylight");
    expect(creatorNoteOf({ creator_notes: "Revision feedback: redo" })).toBe("");
    expect(read("src/pages/brand/brandUgc/OrdersTab.jsx")).toContain('{ id: "revision", label: "Revision" }');
  });
  it("Manage orders filters by the brief", () => {
    expect(read("src/pages/brand/BrandInstantUGC.jsx")).toContain('setSearchParams({ tab: "orders", brief: String(brief.id) })');
    expect(read("src/pages/brand/BrandUGCOrders.jsx")).toContain("if (briefFilter && String(o.raw?.brief_id");
  });
});
