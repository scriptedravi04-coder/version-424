// v415: brand campaigns area — budget wording, IST day counts, preview copy, no made-up ROI, popup polish.
import { describe, it, expect } from "vitest";
import { readFileSync } from "fs";
import { campaignBudgetText, campaignDaysLeft, lookingForLine, budgetLine } from "./components/campaigns/mobile/HomeCampaignCard";
import { pickedDateToDay } from "./pages/brand/BrandCampaignCreate";

const read = (p) => readFileSync(p, "utf8");

describe("v415 campaignBudgetText", () => {
  it("min 0 with a max reads 'Up to', not Barter or ₹0 – ₹X", () => {
    expect(campaignBudgetText({ budget_min: 0, budget_max: 5000 })).toBe("Up to ₹5,000");
    expect(campaignBudgetText({ budget_min: null, budget_max: 5000 })).toBe("Up to ₹5,000");
  });
  it("Barter only when both are 0 / empty", () => {
    expect(campaignBudgetText({ budget_min: 0, budget_max: 0 })).toBe("Barter");
    expect(campaignBudgetText({ budget_min: 0 })).toBe("Barter");
    expect(campaignBudgetText({})).toBe("");
    expect(campaignBudgetText(null)).toBe("");
  });
  it("full en-IN amounts and ranges", () => {
    expect(campaignBudgetText({ budget_min: 1500, budget_max: 1500 })).toBe("₹1,500");
    expect(campaignBudgetText({ budget_min: 5000, budget_max: 150000 })).toBe("₹5,000 – ₹1,50,000");
    expect(campaignBudgetText({ budget_min: 5000, budget_max: 25000 }, "–")).toBe("₹5,000–₹25,000");
    expect(budgetLine({ budget_min: 0, budget_max: 5000 })).toBe("Up to ₹5,000");
    expect(budgetLine({})).toBe("Open budget");
  });
});

describe("v415 campaignDaysLeft (IST calendar days)", () => {
  const now = Date.parse("2026-11-07T04:30:00Z"); // 10:00 IST on 7 Nov
  it("counts whole IST days to a YYYY-MM-DD close date", () => {
    expect(campaignDaysLeft("2026-11-22", now)).toBe(15);
    expect(campaignDaysLeft("2026-11-07", now)).toBe(0);
    expect(campaignDaysLeft("2026-11-06", now)).toBe(-1);
  });
  it("reads a timestamp as its IST day; bad / empty → null", () => {
    expect(campaignDaysLeft("2026-11-21T18:30:00.000Z", now)).toBe(15); // = 22 Nov 00:00 IST
    expect(campaignDaysLeft("", now)).toBe(null);
    expect(campaignDaysLeft("not a date", now)).toBe(null);
  });
  it("late evening IST still counts the same day", () => {
    const late = Date.parse("2026-11-07T18:00:00Z"); // 23:30 IST on 7 Nov
    expect(campaignDaysLeft("2026-11-08", late)).toBe(1);
  });
});

describe("v415 lookingForLine", () => {
  it("no 'Any Niche' / 'Any Gender' / dangling commas", () => {
    const line = lookingForLine({ categories: [], platforms: ["Instagram"], reach: "10k - 50k followers", gender: "Both", languages: [], locations: [] });
    expect(line).toBe("Creators on Instagram with 10k - 50k followers, anywhere in India.");
    expect(line).not.toMatch(/Any Niche|Any Gender|, ,|Pan India/);
  });
  it("lists niches, gender, languages and cities", () => {
    expect(lookingForLine({ categories: ["Food"], platforms: ["Instagram", "YouTube"], reach: "5k followers", gender: "Female", languages: ["Hindi", "English"], locations: ["Jaipur"] }))
      .toBe("Food creators (female) on Instagram & YouTube with 5k followers, fluent in Hindi or English, based in Jaipur.");
  });
});

describe("v415 pickedDateToDay", () => {
  it("keeps the picked calendar day (no UTC shift) and passes YYYY-MM-DD through", () => {
    expect(pickedDateToDay("2026-11-22")).toBe("2026-11-22");
    const localMidnight = new Date(2026, 10, 22).toISOString();
    expect(pickedDateToDay(localMidnight)).toBe("2026-11-22");
    expect(pickedDateToDay("")).toBe("");
    expect(pickedDateToDay("garbage")).toBe("");
  });
});

describe("v415 source checks", () => {
  it("no made-up ROI / analysis PDF on brand campaign screens", () => {
    for (const p of ["src/pages/brand/BrandCampaignApplicants.jsx", "src/components/campaigns/mobile/BrandCampaignDetailMobile.jsx", "src/pages/campaigns/CampaignDetail.jsx"]) {
      const src = read(p);
      expect(src).not.toMatch(/predict-roi/);
      expect(src).not.toMatch(/<ExportAnalyticsPdfButton/);
      expect(src).not.toMatch(/Predict ROI for Applicant Pool|Run ROI Prediction/);
    }
  });
  it("invite modal: full amounts, rate prefill never below the minimum, Escape closes", () => {
    const src = read("src/components/campaigns/InviteToCampaignModal.jsx");
    expect(src).not.toMatch(/Math\.round\(Number\(v\) \/ 1000\)\}K/);
    expect(src).toMatch(/Math\.max\(reelRate, MIN_CAMPAIGN_PAYOUT\)/);
    expect(src).toMatch(/e\.key === "Escape"/);
  });
  it("one budget rule everywhere (no 'budget_min === 0 → Barter')", () => {
    for (const p of ["src/components/campaigns/CampaignCard.jsx", "src/components/campaigns/mobile/BrandCampaignsMobile.jsx", "src/components/campaigns/mobile/BrandCampaignDetailMobile.jsx", "src/components/campaigns/InviteToCampaignModal.jsx"]) {
      expect(read(p)).not.toMatch(/budget_min === 0\) (return|bits\.push)\("Barter"\)|c\.budget_min === 0 \? "Barter"/);
      expect(read(p)).toMatch(/campaignBudgetText/);
    }
  });
  it("decline sheet locks scroll and animates out; declined pitch stays (status rejected)", () => {
    expect(read("src/components/campaigns/RejectApplicantSheet.jsx")).toMatch(/useScrollLock\(Boolean\(liveApplicant\)\)/);
    expect(read("src/components/campaigns/RejectApplicantSheet.jsx")).toMatch(/ybSheetDown/);
    expect(read("src/pages/brand/BrandCampaignApplicants.jsx")).toMatch(/status: "rejected"/);
  });
  it("create wizard: no invented ₹1,000 draft budget, no dead 'Total Campaign' switch, double-submit guard on phone", () => {
    const d = read("src/pages/brand/BrandCampaignCreate.jsx");
    expect(d).not.toMatch(/\|\| 1000\)/);
    expect(d).not.toMatch(/\["Per Influencer", "Total Campaign"\]\.map/);
    expect(d).not.toMatch(/Influencer Specialist @|truncate">Various</);
    const m = read("src/components/campaigns/mobile/MobileCampaignCreate.jsx");
    expect(m).toMatch(/if \(submitting\) return; \/\/ v415/);
    expect(m).not.toMatch(/fixed inset-0 z-50 flex items-end/);
  });
  it("campaign card: one status pill, no endless pulse", () => {
    const src = read("src/components/campaigns/CampaignCard.jsx");
    expect(src).not.toMatch(/animate-ping|animate-pulse/);
    expect((src.match(/\{statusLabel\}/g) || []).length).toBe(1);
  });
});
