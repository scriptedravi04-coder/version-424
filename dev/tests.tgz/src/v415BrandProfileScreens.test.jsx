// v415 — brand profile mobile sub-screens, shared PopupPanel, ProfileBanner.
import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import React, { useState } from "react";
import fs from "fs";
import path from "path";
import { render, screen, fireEvent, act, cleanup } from "@testing-library/react";
import { PopupPanel, Presence } from "./components/common/Popup";
import { kycBadgeFor } from "./components/profile/mobile/brand/brandMobileUi";
import { deviceLabel } from "./components/profile/mobile/brand/SessionsScreen";
import { bannerExpired, DIWALI_EVENT_END } from "./components/promo/ProfileBanner";

const read = (p) => fs.readFileSync(path.resolve(process.cwd(), p), "utf8");
const tick = () => act(() => new Promise((r) => setTimeout(r, 5)));

afterEach(() => { cleanup(); document.body.style.overflow = ""; });

describe("v415 PopupPanel", () => {
  it("is a dialog, locks the page, and restores the previous overflow on close", async () => {
    document.body.style.overflow = "scroll";
    const { unmount } = render(<PopupPanel kind="modal">Hi</PopupPanel>);
    const dlg = screen.getByRole("dialog");
    expect(dlg.getAttribute("aria-modal")).toBe("true");
    expect(document.body.style.overflow).toBe("hidden");
    unmount();
    expect(document.body.style.overflow).toBe("scroll");
  });

  it("nested popups keep the page locked until the last one closes", () => {
    function Two({ inner }) {
      return <PopupPanel kind="modal">outer{inner && <PopupPanel kind="modal">inner</PopupPanel>}</PopupPanel>;
    }
    const { rerender, unmount } = render(<Two inner />);
    rerender(<Two inner={false} />);
    expect(document.body.style.overflow).toBe("hidden");
    unmount();
    expect(document.body.style.overflow).toBe("");
  });

  it("Escape closes only the top popup, and not when closeOnEscape is false", async () => {
    const outer = vi.fn();
    const inner = vi.fn();
    const { rerender } = render(
      <PopupPanel kind="modal" onClose={outer}>o<PopupPanel kind="modal" onClose={inner}>i</PopupPanel></PopupPanel>
    );
    fireEvent.keyDown(window, { key: "Escape" });
    await tick();
    expect(inner).toHaveBeenCalledTimes(1);
    expect(outer).not.toHaveBeenCalled();
    rerender(<PopupPanel kind="modal" onClose={outer} closeOnEscape={false}>o</PopupPanel>);
    fireEvent.keyDown(window, { key: "Escape" });
    await tick();
    expect(outer).not.toHaveBeenCalled();
  });

  it("doesn't call onClose twice when the screen already closes on Escape itself", async () => {
    const calls = vi.fn();
    function Screen() {
      const [open, setOpen] = useState(true);
      const close = () => { calls(); setOpen(false); };
      React.useEffect(() => {
        const k = (e) => { if (e.key === "Escape") close(); };
        window.addEventListener("keydown", k);
        return () => window.removeEventListener("keydown", k);
      });
      return <Presence>{open && <PopupPanel key="p" kind="modal" onClose={close}>x</PopupPanel>}</Presence>;
    }
    render(<Screen />);
    fireEvent.keyDown(window, { key: "Escape" });
    await tick();
    await tick();
    expect(calls).toHaveBeenCalledTimes(1);
  });

  it("moves focus into the panel and back to the opener", () => {
    const btn = document.createElement("button");
    document.body.appendChild(btn);
    btn.focus();
    const { unmount } = render(<PopupPanel kind="modal">x</PopupPanel>);
    expect(document.activeElement).toBe(screen.getByRole("dialog"));
    unmount();
    expect(document.activeElement).toBe(btn);
    btn.remove();
  });

  it("fade menus are not modal (no lock)", () => {
    render(<PopupPanel kind="fade">menu</PopupPanel>);
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(document.body.style.overflow).toBe("");
  });
});

describe("v415 brand verification vocabulary", () => {
  it("uses Verified / Under review / Needs changes / More info needed / Verification pending", () => {
    expect(kycBadgeFor("approved").label).toBe("Verified");
    expect(kycBadgeFor("pending").label).toBe("Under review");
    expect(kycBadgeFor("rejected").label).toBe("Needs changes");
    expect(kycBadgeFor("more_info_needed").label).toBe("More info needed");
    expect(kycBadgeFor(null).label).toBe("Verification pending");
  });
  it("no KYC / secure payment hold jargon on brand sub-screens", () => {
    for (const f of ["KycScreen", "PublicProfileScreen", "ContactScreen", "HelpScreen"]) {
      const s = read(`src/components/profile/mobile/brand/${f}.jsx`).replace(/\/\/.*$/gm, "").replace(/\{?\/\*[\s\S]*?\*\/\}?/g, "");
      expect(s, f).not.toMatch(/"[^"\n]*\bKYC\b[^"\n]*"|>[^<{\n]*\bKYC\b/);
      expect(s, f).not.toMatch(/secure payment hold/i);
    }
    expect(read("src/components/profile/mobile/brand/KycScreen.jsx")).toContain('"Brand verification"');
  });
});

describe("v415 sessions device names", () => {
  it("turns a raw browser string into a readable device", () => {
    expect(deviceLabel("Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1")).toBe("Safari on iPhone");
    expect(deviceLabel("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36")).toBe("Chrome on Windows");
    expect(deviceLabel("Pixel 8")).toBe("Pixel 8");
    expect(deviceLabel("")).toBe("Unknown device");
  });
});

describe("v415 ProfileBanner", () => {
  const diwali = { id: "1", image_url: "https://x/diwali.png", link_url: "/challenge" };
  const entry = { id: "2", image_url: "https://x/a.png", link_url: "/creator/settings?section=portfolio&add=1&diwali=1" };
  const plain = { id: "3", image_url: "https://x/b.png", link_url: "/refer" };
  const nov7 = Date.parse("2026-11-07T10:00:00Z");
  const nov10 = Date.parse("2026-11-10T10:00:00Z");
  it("Diwali banners show during the event and hide after 15 Nov 2026", () => {
    expect(bannerExpired(diwali, nov7, "creator")).toBe(false);
    expect(bannerExpired(diwali, nov10, "creator")).toBe(false);
    expect(bannerExpired(diwali, DIWALI_EVENT_END + 1, "creator")).toBe(true);
  });
  it("entry banners and brand Diwali banners hide after entries close (8 Nov)", () => {
    expect(bannerExpired(entry, nov7, "creator")).toBe(false);
    expect(bannerExpired(entry, nov10, "creator")).toBe(true);
    expect(bannerExpired(diwali, nov10, "brand")).toBe(true);
  });
  it("other banners are untouched; ends_at is respected", () => {
    expect(bannerExpired(plain, DIWALI_EVENT_END + 86400000, "brand")).toBe(false);
    expect(bannerExpired({ ...plain, ends_at: "2026-11-01T00:00:00Z" }, nov7, "brand")).toBe(true);
  });
  it("never pops in after the page drew (no layout shift)", () => {
    const s = read("src/components/promo/ProfileBanner.jsx");
    expect(s).toContain("if (!cur) return cur;");
  });
});

describe("v415 brand sub-screen polish (source)", () => {
  it("sub-screens hide the bottom bar and fade in (opacity only)", () => {
    const s = read("src/components/profile/mobile/brand/brandMobileUi.jsx");
    expect(s).toContain("useHideBottomNav(true)");
    expect(s).toMatch(/SCREEN_FADE = \{ initial: \{ opacity: 0 \}/);
  });
  it("Payments uses one skeleton (no separate loading screen)", () => {
    const s = read("src/components/profile/mobile/brand/PaymentsScreen.jsx");
    expect(s).not.toContain("Loading ledger");
    expect(s).toContain("listLoading={loading}");
  });
  it("uploads can't get stuck or overlap", () => {
    const s = read("src/components/profile/mobile/brand/CompanyDetailsScreen.jsx");
    expect(s).toContain("try { url = await uploadImage(file); } finally { setUploading(null); }");
    expect(s).toContain("if (uploading) return;");
  });
});
