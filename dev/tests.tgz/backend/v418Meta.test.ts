import { describe, it, expect } from "vitest";
import { readFileSync } from "fs";
import { buildQualifiedPayload, buildEventPayload, isAppRequest, appDataFor, QUALIFIED_10K_EVENT, QUALIFIED_10K_MIN_FOLLOWERS, registrationEventId } from "./metaCapi";
import { hasTags } from "./signupSource";

const webReq = { headers: { "user-agent": "Mozilla/5.0 (Linux; Android 14; Pixel 7 Build/UQ1A) Chrome", referer: "https://ybexmedia.in/app" } };
const appReq = { headers: { ...webReq.headers, "x-ybex-platform": "android", "x-ybex-app-version": "1.0.11" } };

describe("v418 · Meta events (app + website + server)", () => {
  it("QualifiedCreator / 10K always send value 1 and the followers in followers_count", () => {
    const b = buildQualifiedPayload({ user: { user_id: "u1", email: "a@b.co" }, followers: 25000, eventId: "qc10k_u1", eventName: QUALIFIED_10K_EVENT });
    expect(b.data[0].event_name).toBe("QualifiedCreator10K");
    expect(b.data[0].custom_data.value).toBe(1);
    expect(b.data[0].custom_data.followers_count).toBe(25000);
    expect(QUALIFIED_10K_MIN_FOLLOWERS).toBe(10000);
  });
  it("website requests are website events; app requests are app events with app_data", () => {
    expect(isAppRequest(webReq)).toBe(false);
    expect(isAppRequest(appReq)).toBe(true);
    const w = buildEventPayload({ eventName: "CompleteRegistration", user: { user_id: "u1" }, eventId: registrationEventId("u1"), req: webReq });
    expect(w.data[0].action_source).toBe("website");
    expect(w.data[0].event_source_url).toBe("https://ybexmedia.in/app");
    expect(w.data[0].event_id).toBe("reg_u1");
    const a = buildEventPayload({ eventName: "CompleteRegistration", user: { user_id: "u1" }, eventId: "reg_u1", req: appReq });
    expect(a.data[0].action_source).toBe("app");
    expect(a.data[0].event_source_url).toBeUndefined();
    const ad = appDataFor(appReq);
    expect(ad.extinfo[0]).toBe("a2");
    expect(ad.extinfo[1]).toBe("com.ybex.app");
    expect(ad.extinfo[4]).toBe("14");
    expect(ad.extinfo).toHaveLength(16);
  });
  it("10K creators get both events; server answers carry the list", () => {
    const s = readFileSync("backend/metaCapi.ts", "utf8");
    expect(s).toContain("export async function qualifyCreatorAll(");
    expect(readFileSync("backend/auth_routes.ts", "utf8")).toContain("meta_event: meta_events[0], meta_events");
    expect(readFileSync("backend/instagramConnect.ts", "utf8")).toContain("meta_event: meta_events[0], meta_events");
    expect(readFileSync("src/lib/api.js", "utf8")).toContain("trackServerEvents(response.data.meta_events)");
  });
  it("the server sends CompleteRegistration once per new account", () => {
    const s = readFileSync("backend/signupSource.ts", "utf8");
    expect(s).toContain("void sendRegistration({ user: { ...user, ...row }, req })");
    expect(readFileSync("src/lib/signupSource.js", "utf8")).toContain("`reg_${uid}`");
  });
  it("the app header is allowed by CORS", () => {
    expect(readFileSync("backend/server.ts", "utf8")).toContain("X-Ybex-Platform, X-Ybex-App-Version");
  });
});

describe("v418 · UTM kept across browsers", () => {
  it("tags = utm_source / gclid / fbclid", () => {
    expect(hasTags({ utm_source: "meta" })).toBe(true);
    expect(hasTags({ fbclid: 1 })).toBe(true);
    expect(hasTags({ referrer: "x" })).toBe(false);
  });
  it("e-mail typed → server keeps the tags; signup-source falls back to them; Google/Apple carry them", () => {
    const s = readFileSync("backend/signupSource.ts", "utf8");
    expect(s).toContain('router.post("/auth/pre-source"');
    expect(s).toContain("if (!hasTags(body)) { const pre = await preSourceFor(row.email)");
    const o = readFileSync("backend/oauth_routes.ts", "utf8");
    expect(o).toContain("await carryOauthSource(String(req.query.state");
    expect(o).toContain("await carryOauthSource(String(body.state");
    const c = readFileSync("src/pages/app/AppContinue.jsx", "utf8");
    expect(c).toContain("sendPreSource(api, cleanEmail)");
    expect(c).toContain("src: JSON.stringify(");
  });
  it("the Play link's referrer is public behind PLAY_STORE_LIVE", () => {
    const s = readFileSync("backend/signupSource.ts", "utf8");
    expect(s).toContain('router.get("/public/app-links"');
    expect(s).toContain("process.env.PLAY_STORE_LIVE");
  });
});

describe("v418 · Android build", () => {
  const sh = readFileSync("android-app/scripts/mac-prepare-android.sh", "utf8");
  it("version 1.0.11 (code 12), Meta SDK + install referrer, plugin copied, AD_ID kept", () => {
    // v419: later uploads bump it again — the code only ever goes up
    expect(Number((sh.match(/VERSION_CODE=(\d+)/) || [])[1])).toBeGreaterThanOrEqual(12);
    expect(sh).toMatch(/VERSION_NAME="1\.0\.\d+"/);
    expect(sh).toContain("com.facebook.android:facebook-core");
    expect(sh).toContain("com.android.installreferrer:installreferrer");
    expect(sh).toContain("com.facebook.sdk.ApplicationId");
    expect(sh).toContain('cp ../android-overrides/app/src/main/java/com/ybex/app/*.java');
    expect(sh).not.toMatch(/for n in \["com\.google\.android\.gms\.permission\.AD_ID"/);
  });
  it("the plugin is registered and has both methods", () => {
    const main = readFileSync("android-overrides/app/src/main/java/com/ybex/app/MainActivity.java", "utf8");
    expect(main).toContain("registerPlugin(MetaEventsPlugin.class)");
    const p = readFileSync("android-overrides/app/src/main/java/com/ybex/app/MetaEventsPlugin.java", "utf8");
    expect(p).toContain('@CapacitorPlugin(name = "MetaEvents")');
    expect(p).toContain("public void logEvent(PluginCall call)");
    expect(p).toContain("public void getInstallReferrer(final PluginCall call)");
  });
});
