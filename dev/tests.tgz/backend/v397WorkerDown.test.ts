// v397 (Ravi: "website down ki thi, maintenance page dikhna chahiye tha par nahi hua"): the Cloudflare worker shows the
// maintenance page when the hosting answers a page load with its OWN page (app stopped / unpublished), not only on 502/503.
import { describe, it, expect, vi, afterEach } from "vitest";
import worker from "../cloudflare/ybex-proxy-worker.js";

const page = (path = "/") => new Request("https://ybexmedia.in" + path, { headers: { accept: "text/html" } });
const origin = (status: number, body: string, type = "text/html; charset=utf-8") => vi.fn(async () => new Response(body, { status, headers: { "content-type": type } }));
afterEach(() => vi.unstubAllGlobals());

describe("v397 worker: maintenance page whenever Ybex itself isn't answering", () => {
  it("hosting's own page (200 / 404 / 500 without Ybex's root) → maintenance page", async () => {
    for (const [st, body] of [[200, "<html><body>This app is not available</body></html>"], [404, "<html>Not found</html>"], [500, "<html>Error</html>"]] as const) {
      vi.stubGlobal("fetch", origin(st, body));
      const r = await worker.fetch(page("/"), {}, {});
      expect(r.status, `${st}`).toBe(503);
      expect(await r.text()).toContain("Ybex is under maintenance");
    }
  });
  it("Ybex's own page passes through untouched (also its own 404 page)", async () => {
    vi.stubGlobal("fetch", origin(200, '<html><body><div id="root"></div></body></html>'));
    const r = await worker.fetch(page("/explore"), {}, {});
    expect(r.status).toBe(200);
    expect(await r.text()).toContain('<div id="root">');
  });
  it("API calls are not touched (a real 404 / 500 from the API stays as it is)", async () => {
    vi.stubGlobal("fetch", origin(404, '{"detail":"nope"}', "application/json"));
    const r = await worker.fetch(new Request("https://ybexmedia.in/api/x", { headers: { accept: "application/json" } }), {}, {});
    expect(r.status).toBe(404);
  });
});
