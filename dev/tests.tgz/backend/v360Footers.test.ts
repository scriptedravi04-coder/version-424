import { describe, it, expect } from "vitest";
import fs from "fs";
const read = (p: string) => fs.readFileSync(p, "utf8");
describe("v360 · campaign page, popups above the nav, footer spacing", () => {
  it("full-screen popups that ask for z-40/50 are lifted above the bottom nav", () => {
    const s = read("src/components/common/Popup.jsx");
    expect(s).toContain("zIndex: 1000");
    expect(read("src/components/brand/CancelBriefModal.jsx")).toContain("<ModalPortal>");
  });
  it("phone campaign page: one row of New / Shortlisted / Hired / Passed tabs, opens the first non-empty one", () => {
    const s = read("src/components/campaigns/mobile/BrandCampaignDetailMobile.jsx");
    expect(s).toContain('role="tablist"');
    expect(s).toContain("tabChosen.current");
    expect(s).not.toContain(">\n                No applicants in this category.");
  });
  it("old footer pages: no full-screen height / big bottom gap before the footer", () => {
    expect(read("src/components/layout/PremiumFooter.jsx")).toContain("mt-2 md:mt-12");
    for (const f of ["src/components/campaigns/mobile/BrandCampaignsMobile.jsx", "src/components/payments/BrandPaymentsMobile.jsx",
      "src/components/payments/CreatorEarningsMobile.jsx", "src/components/campaigns/mobile/CampaignsListMobile.jsx", "src/components/deals/mobile/DealsMobile.jsx"]) {
      expect(read(f)).not.toMatch(/min-h-screen bg-\[#F[24]F[24]F[78]\][^"]*pb-(16|28)/);
    }
    expect(read("src/components/explore/mobile/ExploreMobile.jsx")).not.toContain("selected.length ? 170 : 110");
  });
});
