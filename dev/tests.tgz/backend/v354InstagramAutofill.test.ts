// v354 (Ravi): username once → photo (unless uploaded), numbers, reels for the portfolio; smart refresh by activity;
// admin bulk fetch for creators + unclaimed + waitlist.
import { describe, it, expect, beforeEach } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { mediaListFrom, emailFromBio, photoIsReplaceable, isIgPhoto, refreshEveryDays, refreshDue, lastActiveByUser, makeBudget, firstMention } from "./instagramAutofill";
import { fetchByUsername, statsFromInstagram } from "./instagramConnect";

const root = path.resolve(__dirname, "..");
const read = (p: string) => fs.readFileSync(path.join(root, p), "utf8");
const DAY = 86400000;

describe("v354 — reels + bio", () => {
  it("marks brand collabs and keeps only posts with a link", () => {
    const list = mediaListFrom([
      { id: "1", permalink: "https://instagram.com/reel/a", caption: "Loving my new earbuds @boat.nirvana #ad", media_product_type: "REELS", media_type: "VIDEO", thumbnail_url: "t1", like_count: 900, view_count: 40000 },
      { id: "2", permalink: "https://instagram.com/p/b", caption: "dance trend 💃", media_type: "IMAGE", media_url: "m2", like_count: 50 },
      { id: "3", caption: "no link" },
    ]);
    expect(list).toHaveLength(2);
    expect(list[0]).toMatchObject({ kind: "reel", collab: true, brand: "boat.nirvana", thumb: "t1", views: 40000 });
    expect(list[1]).toMatchObject({ kind: "post", collab: false, thumb: "m2" });
  });
  it("e-mail from bio, first @mention", () => {
    expect(emailFromBio("Collabs 📩 Hello.Riya@Gmail.com.")).toBe("hello.riya@gmail.com");
    expect(emailFromBio("no mail here")).toBeNull();
    expect(firstMention("thanks @Nykaa!")).toBe("nykaa");
  });
  it("stats carry media + bio_email", () => {
    const s: any = statsFromInstagram({ username: "a", followers_count: 10, biography: "mail: a@b.co" }, [{ id: "1", permalink: "https://x", caption: "#collab" }]);
    expect(s.bio_email).toBe("a@b.co");
    expect(s.media[0].collab).toBe(true);
  });
});

describe("v354 — photo is never taken over from an upload", () => {
  it("replaceable: empty, our Instagram copy, Google / placeholder pictures", () => {
    expect(photoIsReplaceable("")).toBe(true);
    expect(photoIsReplaceable("https://x.supabase.co/storage/v1/object/public/avatars/ig/riya.webp?v=1")).toBe(true);
    expect(photoIsReplaceable("https://lh3.googleusercontent.com/a/abc=s96-c")).toBe(true);
    expect(photoIsReplaceable("/api/files/123")).toBe(false);
    expect(photoIsReplaceable("https://x.supabase.co/storage/v1/object/public/avatars/u1/123.webp")).toBe(false);
    expect(isIgPhoto("https://x/avatars/ig/a.jpg")).toBe(true);
  });
});

describe("v354 — refresh schedule by activity", () => {
  const now = Date.parse("2026-10-20T12:00:00Z");
  it("daily / every 3 days / every 10 days", () => {
    expect(refreshEveryDays(now - 3 * 3600e3, now)).toBe(1);
    expect(refreshEveryDays(now - 2 * DAY, now)).toBe(3);
    expect(refreshEveryDays(now - 20 * DAY, now)).toBe(10);
    expect(refreshEveryDays(null, now)).toBe(10);
  });
  it("due only when that many days passed (never synced → due)", () => {
    expect(refreshDue(null, null, now)).toBe(true);
    expect(refreshDue(new Date(now - 2 * DAY).toISOString(), now - 2 * DAY, now)).toBe(false);
    expect(refreshDue(new Date(now - 3 * DAY).toISOString(), now - 2 * DAY, now)).toBe(true);
    expect(refreshDue(new Date(now - 5 * DAY).toISOString(), null, now)).toBe(false);
    expect(refreshDue(new Date(now - 23.5 * 3600e3).toISOString(), now - 3600e3, now)).toBe(true);
  });
  it("last use from login rows (expires_at = last use + 30 days)", () => {
    const m = lastActiveByUser([{ user_id: "a", expires_at: new Date(now + 29 * DAY).toISOString() }, { user_id: "a", expires_at: new Date(now + 10 * DAY).toISOString() }], 30 * DAY);
    expect(m.get("a")).toBe(now - DAY);
  });
  it("budget", () => {
    const b = makeBudget(2, 1000);
    expect(b.take(0)).toBe(true); expect(b.take(1)).toBe(true); expect(b.take(2)).toBe(false);
    expect(b.waitMs(500)).toBe(500); expect(b.take(1001)).toBe(true);
  });
});

describe("v354 — Business Discovery asks for posts, falls back if Meta refuses a field", () => {
  beforeEach(() => { process.env.IG_GRAPH_TOKEN = "tok"; process.env.IG_BUSINESS_ID = "1784"; });
  it("retries with the safe field list on (#100)", async () => {
    const asked: string[] = [];
    const fake: any = async (url: string) => {
      asked.push(decodeURIComponent(url));
      if (asked.length === 1) return { ok: false, status: 400, json: async () => ({ error: { code: 100, message: "nonexisting field (thumbnail_url)" } }) };
      return { ok: true, json: async () => ({ business_discovery: { username: "a", followers_count: 5, media: { data: [] } } }) };
    };
    const s = await fetchByUsername("a", fake);
    expect(asked[0]).toContain("permalink");
    expect(asked[0]).toContain("biography");
    expect(asked[1]).not.toContain("permalink");
    expect(s.followers).toBe(5);
  });
});

describe("v354 — wiring", () => {
  it("server: bulk job, smart refresh, photo copy", () => {
    const s = read("backend/instagramConnect.ts");
    expect(s).toContain('router.post("/admin/creators/instagram-bulk"');
    expect(s).toContain("pickAutoRefresh("); // v419: active creators only, 50 a day
    expect(s).toContain("photoIsReplaceable(");
  });
  it("screens: auto popup, reel picker in onboarding + profile, admin button", () => {
    expect(read("src/components/instagram/InstagramFetchButton.jsx")).toContain("Fetching your Instagram data");
    expect(read("src/pages/onboarding/CreatorOnboardingMobile.jsx")).toContain("<InstagramReelPicker");
    expect(read("src/components/onboarding/Step4_RateCard.tsx")).toContain("<InstagramReelPicker");
    expect(read("src/pages/creator/profileScreens/PortfolioScreen.jsx")).toContain("<InstagramReelPicker");
    expect(read("src/components/admin/WaitlistManager.jsx")).toContain("<AdminInstagramBulkFetch");
    expect(read("src/components/admin/AdminUsersTab.jsx")).toContain("<AdminInstagramBulkFetch");
  });
});

describe("v419 auto refresh — only app users, 50 a day, in turns", () => {
  it("picks active creators only, oldest fetch first, never twice a day", async () => {
    const { pickAutoRefresh } = await import("./instagramAutofill");
    const now = Date.parse("2026-11-10T00:00:00Z");
    const act = new Map([["a", now - 3600e3], ["b", now - 2 * DAY], ["c", now - 30 * DAY], ["d", now - 3600e3]]);
    const rows = [
      { user_id: "a", instagram_synced_at: new Date(now - 5 * DAY).toISOString() },
      { user_id: "b", instagram_synced_at: new Date(now - 9 * DAY).toISOString() },
      { user_id: "c", instagram_synced_at: new Date(now - 40 * DAY).toISOString() }, // not using the app → never
      { user_id: "d", instagram_synced_at: new Date(now - 2 * 3600e3).toISOString() }, // fetched today → not again
      { user_id: "e", instagram_synced_at: null }, // never logged in → never
    ];
    expect(pickAutoRefresh(rows, act, 50, now)).toEqual(["b", "a"]);
    expect(pickAutoRefresh(rows, act, 1, now)).toEqual(["b"]);
    const s = read("backend/instagramConnect.ts");
    expect(s).not.toMatch(/for \(const mode of \["new", "old"\]/);
  });
});
