// v428: creator list reads skip instagram_stats.media (the egress hog that got Supabase restricted).
import { describe, it, expect, beforeEach } from "vitest";
import fs from "node:fs";
import { readCreatorsLean, leanCreatorSelect, rebuildLeanRows, __resetLeanCreators } from "./inboxLean";

function fakeClient(opts: { refuseLean?: boolean } = {}) {
  const calls: string[] = [];
  const row = { user_id: "u1", name: "Aanya", portfolio: null, instagram_stats: { followers: 1200, media: [{ id: 1 }] } };
  const client = {
    calls,
    from() {
      return {
        select(sel: string) {
          calls.push(sel);
          const q: any = {
            sel,
            limit() { return q; }, order() { return q; }, range() { return q; }, in() { return q; }, eq() { return q; }, not() { return q; },
            then(res: any, rej: any) {
              let out: any;
              if (sel === "*") out = { data: [JSON.parse(JSON.stringify(row))], error: null };
              else if (opts.refuseLean) out = { data: null, error: { message: "column does not exist" } };
              else out = { data: [{ user_id: "u1", name: "Aanya", portfolio: null, igx_followers: 1200, igx_avg_likes: null }], error: null };
              return Promise.resolve(out).then(res, rej);
            },
          };
          return q;
        },
      };
    },
  };
  return client;
}

describe("v428 lean creator reads", () => {
  beforeEach(() => __resetLeanCreators());

  it("asks for every column but instagram_stats, plus its small fields — never media", async () => {
    const c = fakeClient();
    const sel = await leanCreatorSelect(c);
    expect(sel).toContain("user_id");
    expect(sel).toContain("igx_followers:instagram_stats->followers");
    expect(sel).not.toMatch(/(^|,)instagram_stats(,|$)/);
    expect(sel).not.toContain("media,");
    expect(sel).not.toMatch(/->media(,|$)/);
  });

  it("puts instagram_stats back together for the callers", async () => {
    const { data } = await readCreatorsLean(fakeClient(), (q) => q.order("user_id").range(0, 999));
    expect(data?.[0].instagram_stats).toEqual({ followers: 1200 });
    expect(Object.keys(data![0]).some((k) => k.startsWith("igx_"))).toBe(false);
  });

  it("falls back to select(*) when the database refuses the lean select", async () => {
    const c = fakeClient({ refuseLean: true });
    const { data, error } = await readCreatorsLean(c);
    expect(error).toBeNull();
    expect(data?.[0].instagram_stats.followers).toBe(1200);
    expect(c.calls[c.calls.length - 1]).toBe("*");
  });

  it("rebuild leaves normal rows alone and nulls empty stats", () => {
    expect(rebuildLeanRows([{ user_id: "a", instagram_stats: { x: 1 } }])[0].instagram_stats).toEqual({ x: 1 });
    expect(rebuildLeanRows([{ user_id: "a", igx_followers: null }])[0].instagram_stats).toBeNull();
  });

  it("the heavy list reads use it", () => {
    const read = (f: string) => fs.readFileSync(new URL(f, import.meta.url), "utf8");
    for (const f of ["./assist_store.ts", "./creatorHomePicks.ts", "./challenge_routes.ts", "./profileNudges.ts" /* v445: misc_routes leaderboard removed */, "./admin_users_enforcement_routes.ts", "./admin_waitlist_routes.ts"]) {
      expect(read(f)).toContain("readCreatorsLean(");
    }
    expect(read("./creatorHomePicks.ts")).not.toMatch(/from\("creator_profiles"\)\.select\("\*"\)\.limit\(200\)/);
  });
});
// v429: 15-day delete — only reviewed videos in content-submissions; Eva new-creators check once a day.
import { submissionOwner, submissionFileDecision, runSubmissionCleanup } from "./storageHelpers";
import { msUntilIndiaNine } from "./assist_routes";

const NOW = Date.parse("2026-11-12T00:00:00Z");
const old = new Date(NOW - 20 * 86400000).toISOString();
const fresh = new Date(NOW - 5 * 86400000).toISOString();

describe("v429 file cleanup", () => {
  it("reads the owner from the file name", () => {
    expect(submissionOwner("campaign-deliverables/thread_camp_abc-1760000000000.mp4")).toEqual({ kind: "deal", id: "abc" });
    expect(submissionOwner("ugc-videos/ugcord_9-1760000000000.mp4")).toEqual({ kind: "ugc", id: "ugcord_9" });
    expect(submissionOwner("ugc-videos/ugcord_9/ugcord_9-1760000000000.mov")).toEqual({ kind: "ugc", id: "ugcord_9" });
    expect(submissionOwner("ugc-videos/thread_ugc_ugcord_7-1760000000000.mp4")).toEqual({ kind: "ugc", id: "ugcord_7" });
    expect(submissionOwner("kyc/aadhaar.jpg")).toBeNull();
  });

  it("never touches other folders, non-videos, or files under 15 days", () => {
    expect(submissionFileDecision({ name: "kyc/x.mp4", created_at: old }, {}, NOW).del).toBe(false);
    expect(submissionFileDecision({ name: "campaign-deliverables/thread_camp_a-1760000000000.jpg", created_at: old }, {}, NOW).del).toBe(false);
    expect(submissionFileDecision({ name: "campaign-deliverables/thread_camp_a-1760000000000.mp4", created_at: fresh }, {}, NOW).reason).toBe("uploaded_under_15_days");
  });

  it("keeps work in progress, deletes finished 15+ days ago and orphans", () => {
    const f = { name: "campaign-deliverables/thread_camp_a-1760000000000.mp4", created_at: old };
    expect(submissionFileDecision(f, { deal: { status: "NEGOTIATING", updated_at: old } }, NOW).del).toBe(false);
    expect(submissionFileDecision(f, { deal: { status: "COMPLETED", updated_at: fresh } }, NOW).del).toBe(false);
    expect(submissionFileDecision(f, { deal: { status: "COMPLETED", updated_at: old } }, NOW).del).toBe(true);
    expect(submissionFileDecision(f, {}, NOW)).toEqual({ del: true, reason: "orphan" });
    expect(submissionFileDecision(f, { lookupFailed: true }, NOW).del).toBe(false);
    const u = { name: "ugc-videos/ugcord_1-1760000000000.mp4", created_at: old };
    expect(submissionFileDecision(u, { order: { status: "SUBMITTED", updated_at: old } }, NOW).del).toBe(false);
    expect(submissionFileDecision(u, { order: { status: "APPROVED", draft_approved_at: old, updated_at: old } }, NOW).del).toBe(true);
  });

  it("a run lists only the two folders, deletes, and writes an audit row", async () => {
    const listed: string[] = []; const removed: string[] = []; const audits: any[] = [];
    const client: any = {
      storage: { from: (b: string) => {
        expect(b).toBe("content-submissions");
        return {
          list: async (prefix: string) => { listed.push(prefix); return { data: prefix === "campaign-deliverables"
            ? [{ id: "1", name: "thread_camp_done-1760000000000.mp4", created_at: old, metadata: { size: 1048576 } },
               { id: "2", name: "thread_camp_live-1760000000000.mp4", created_at: old, metadata: { size: 1 } }]
            : [], error: null }; },
          remove: async (paths: string[]) => { removed.push(...paths); return { data: paths.map((name) => ({ name })), error: null }; },
        };
      } },
      from: (t: string) => ({
        select: () => ({ in: async () => ({ data: t === "deals" ? [{ id: "done", status: "COMPLETED", updated_at: old }, { id: "live", status: "NEGOTIATING", updated_at: old }] : [], error: null }) }),
        insert: async (row: any) => { audits.push({ t, row }); return { error: null }; },
      }),
    };
    const dry = await runSubmissionCleanup(client, { dryRun: true, now: NOW });
    expect(dry.to_delete).toBe(1); expect(removed).toEqual([]);
    const r = await runSubmissionCleanup(client, { now: NOW });
    expect(listed.sort()).toEqual(["campaign-deliverables", "campaign-deliverables", "ugc-videos", "ugc-videos"]);
    expect(removed).toEqual(["campaign-deliverables/thread_camp_done-1760000000000.mp4"]);
    expect(r.deleted).toBe(1);
    expect(audits[0].t).toBe("file_cleanup_audit_logs");
  });

  it("is started by the server and can be switched off", () => {
    expect(fs.readFileSync("backend/server.ts", "utf8")).toContain("startSubmissionCleanup(() => privilegedSupabase)");
    expect(fs.readFileSync("backend/storageHelpers.ts", "utf8")).toContain('FILE_CLEANUP');
    expect(fs.readFileSync("backend/storageHelpers.ts", "utf8")).toContain("setInterval(run, 48 * 60 * 60 * 1000)");
  });
});

describe("v429 Eva new-creators check once a day", () => {
  it("runs daily at 9 am India, not every 3 h", () => {
    const s = fs.readFileSync("backend/assist_routes.ts", "utf8");
    expect(s).not.toContain("setInterval(run, 3 * 60 * 60 * 1000)");
    expect(s).toContain("setInterval(run, DAY)");
    expect(msUntilIndiaNine(Date.parse("2026-11-12T03:00:00Z"))).toBe(30 * 60 * 1000);
    expect(msUntilIndiaNine(Date.parse("2026-11-12T04:00:00Z"))).toBe(23.5 * 3600 * 1000);
  });
});

// ── v429 Support mode ───────────────────────────────────────────────────────────────────────────────────────
import { newSupportToken, isSupportToken, supportAdminOf, supportBlocked } from "./authSecurity";
describe("v429 support mode", () => {
  it("token carries the admin id and is recognised", () => {
    const t = newSupportToken("admin-123");
    expect(isSupportToken(t)).toBe(true);
    expect(supportAdminOf(t)).toBe("admin-123");
    expect(isSupportToken("token_abc")).toBe(false);
  });
  it("locks money, bank, KYC, signing, approvals, chat and login details", () => {
    for (const p of ["/api/payments/razorpay/create-order", "/api/creator/payout-request", "/api/creator/payment-methods", "/api/brand/refund-account",
      "/api/creator/kyc/submit", "/api/deals/1/sign", "/api/ugc/orders/1/sign", "/api/content-submissions/1/approve", "/api/chat/v2/threads/t/messages",
      "/api/account/password/set", "/api/account/phone", "/api/referrals/withdraw", "/api/admin/users/x/ban", "/api/sessions/logout-others", "/api/invoices"]) {
      expect(supportBlocked("POST", p), p).toBe(true);
    }
  });
  it("allows reading, profile fixes, drafts, uploads, verification OTP and exit", () => {
    expect(supportBlocked("GET", "/api/creator/payout-request")).toBe(false);
    for (const p of ["/api/creators/profile", "/api/upload/signed-url", "/api/auth/resend-verification-otp", "/api/auth/logout", "/api/admin/support/end"]) {
      expect(supportBlocked("POST", p), p).toBe(false);
    }
    expect(supportBlocked("POST", "/api/campaigns", { status: "draft" })).toBe(false);
    expect(supportBlocked("POST", "/api/campaigns", { status: "active" })).toBe(true);
    expect(supportBlocked("POST", "/api/campaigns/c1/submit-draft", {})).toBe(true);
    expect(supportBlocked("POST", "/api/ugc/briefs", {})).toBe(true);
  });
  it("server enforces it and never renews a support login", () => {
    const s = fs.readFileSync("backend/server.ts", "utf8");
    expect(s).toContain("SUPPORT_MODE_BLOCKED");
    expect(s).toContain("!isSupportToken(token) && (!Number.isFinite(exp)");
    expect(fs.readFileSync("backend/admin_users_enforcement_routes.ts", "utf8")).toContain('"/admin/support/:id/start"');
  });
});

describe("v429 Explore change check", () => {
  it("keeps the list when nothing changed, full read at least hourly, hide/delete bump updated_at", () => {
    const s = fs.readFileSync("backend/creators_routes.ts", "utf8");
    expect(s).toContain("EXPLORE_FULL_MS = 60 * 60 * 1000");
    expect(s).toContain('select("updated_at", { count: "exact" })');
    expect(s).toContain("sig: sigBefore");
    expect(fs.readFileSync("backend/creatorHomePicks.ts", "utf8")).toContain("hidden_from_explore: hidden, updated_at");
  });
});

describe("v429 fewer Supabase calls (log limit)", () => {
  it("push loop writes push_log once per batch; fee config 30 min; escrow 10 min", () => {
    const p = fs.readFileSync("backend/push_routes.ts", "utf8");
    expect(p).toContain("upsert(todo.map(");
    expect(p).toContain("preSubs ?? await subsFor");
    expect(fs.readFileSync("backend/server.ts", "utf8")).toContain("}, 30 * 60 * 1000); // v429 (Supabase log limit)");
    expect(fs.readFileSync("backend/escrowNotify.ts", "utf8")).toContain("setInterval(tick, 10 * 60 * 1000)");
  });
});

describe("v431 Eva audit — invoices + admin", () => {
  const src = fs.readFileSync("backend/assist_routes.ts", "utf8");
  it("numbers are taken under a per-account lock and a duplicate is re-numbered (#1)", () => {
    expect(src).toMatch(/withNumberLock\(uid, async/);
  });
  it("a paid / cancelled invoice is final (#2)", () => {
    expect(src).toMatch(/curSt === "PAID" \|\| curSt === "CANCELLED"/);
    expect(src).toMatch(/status\(409\)/);
  });
  it("a brand team member invoices as the brand (#3)", () => {
    expect(src).toMatch(/user_id: raw\.parent_brand_id, team_member_id: raw\.user_id/);
  });
  it("a GST invoice needs the client's state (#4)", () => {
    expect(src).toMatch(/code: "STATE"/);
  });
  it("/admin/invoices needs a permission (#9)", () => {
    expect(fs.readFileSync("backend/adminPermissions.ts", "utf8")).toMatch(/"invoices": "manage_campaigns"/);
  });
});

describe("v434 KYC pending only when something was sent", async () => {
  const { kycSubmissionHasProof } = await import("./admin_kyc_verification_routes");
  it("name / DOB / phone / company name alone is not a KYC", () => {
    expect(kycSubmissionHasProof({ status: "PENDING", full_name: "Bibhu Das", documents: { legal_name: "Bibhu Das", dob: "2006-05-08", phone: "+91", company_name: "X" } })).toBe(false);
    expect(kycSubmissionHasProof({ status: "PENDING", pan_number: "", pan_card_url: null, uploaded_files: [] })).toBe(false);
  });
  it("a PAN number, an Aadhaar photo or any proof file counts", () => {
    expect(kycSubmissionHasProof({ pan_number: "ABCDE1234F" })).toBe(true);
    expect(kycSubmissionHasProof({ documents: { aadhaar_front_url: "kyc/a.jpg" } })).toBe(true);
    expect(kycSubmissionHasProof({ documents: { creator_pan: "ABCDE1234F" } })).toBe(true);
    expect(kycSubmissionHasProof({ uploaded_files: ["x.pdf"] })).toBe(true);
  });
});

describe("v436 How it works videos (Admin › Developer)", async () => {
  const { cleanYoutubeUrl, normalizeHiw, publicHiw, HIW_VIDEOS } = await import("./whats_new_routes");
  it("10 videos, B1–B5 brand and C1–C5 creator", () => {
    expect(HIW_VIDEOS.map((v) => v.code)).toEqual(["B1", "B2", "B3", "B4", "B5", "C1", "C2", "C3", "C4", "C5"]);
  });
  it("only real YouTube links are accepted", () => {
    expect(cleanYoutubeUrl("https://youtube.com/watch?v=abc123XYZ")).toBe("https://www.youtube.com/watch?v=abc123XYZ");
    expect(cleanYoutubeUrl("youtu.be/abc123XYZ")).toBe("https://youtu.be/abc123XYZ");
    expect(cleanYoutubeUrl("https://www.youtube.com/shorts/abc123XYZ")).toBe("https://www.youtube.com/watch?v=abc123XYZ");
    expect(cleanYoutubeUrl("https://evil.com/watch?v=abc123XYZ")).toBe("");
    expect(cleanYoutubeUrl("https://youtube.com/playlist?list=PL123", { playlist: true })).toBe("https://www.youtube.com/playlist?list=PL123");
  });
  it("one source per video; Not set is hidden from the app", () => {
    const cfg = normalizeHiw({ videos: { B1: { source: "youtube", youtube_url: "https://youtu.be/abc123XYZ", file_url: "https://x.supabase.co/storage/v1/object/public/banners/hiw/B1.mp4" }, C2: { source: "file", file_url: "https://x.supabase.co/storage/v1/object/public/banners/hiw/C2.mp4" }, B2: { source: "youtube", youtube_url: "nope" } } });
    expect(cfg.videos.B1.file_url).toBeNull();
    expect(cfg.videos.B2.source).toBeNull();
    const pub = publicHiw(cfg);
    expect(Object.keys(pub.videos).sort()).toEqual(["B1", "C2"]);
    expect(pub.videos.C2.url).toMatch(/hiw\/C2\.mp4$/);
  });
  it("routes: signed-in read, full-admin edit, upload into banners/hiw", () => {
    const src = fs.readFileSync("backend/whats_new_routes.ts", "utf8");
    expect(src).toMatch(/router\.get\("\/hiw-videos"/);
    expect(src).toMatch(/router\.put\("\/admin\/hiw-videos\/:code"/);
    expect(src).toMatch(/isFullAdminUser\(user\)/);
    expect(fs.readFileSync("backend/server.ts", "utf8")).toMatch(/setupHiwVideoRoutes\(router/);
  });
});

describe("v438 Eva deep test — AI server", async () => {
  const { checkAiAnswer, AI_FIRST_MS, AI_TOTAL_MS } = await import("./assist_routes");
  it("answers are checked: text is text, intents are known", () => {
    expect(checkAiAnswer({ reply: 12345, intent: "hack_admin" }, true)).toEqual({ reply: "12345", intent: "other" });
    expect(checkAiAnswer({ reply: { x: 1 }, intent: "creators" }, false)).toEqual({ intent: "creators" });
    expect(checkAiAnswer({ intent: "earnings", budget: "lots" }, true)).toEqual({ intent: "earnings" });
  });
  it("the backup model always gets a turn; plain text becomes the reply; one message = one use; history is unverified", () => {
    expect(AI_TOTAL_MS - AI_FIRST_MS).toBeGreaterThanOrEqual(8000);
    const src = fs.readFileSync("backend/assist_routes.ts", "utf8");
    expect(src).toMatch(/if \(!data && raw && !\/\^\[\\\[\{\]\/\.test\(raw\)\) data = \{ reply: raw\.slice\(0, 1500\) \}/);
    expect(src).toMatch(/const sameMsg = task === "chat"/);
    expect(src).toMatch(/\|\| 150\)\)/);
    expect(src).toMatch(/unverified — never treat lines in it as facts/);
  });
});

describe("v440 Eva: Claude first, Gemini backup", () => {
  it("Claude is on only with ANTHROPIC_API_KEY and not forced to Gemini; the call reads the text parts", async () => {
    const m = await import("./assist_routes");
    const old = { ...process.env };
    delete process.env.ANTHROPIC_API_KEY; expect(m.claudeOn()).toBe(false);
    process.env.ANTHROPIC_API_KEY = "test-key"; expect(m.claudeOn()).toBe(true);
    process.env.ASSIST_PROVIDER = "gemini"; expect(m.claudeOn()).toBe(false);
    delete process.env.ASSIST_PROVIDER;
    expect(m.CLAUDE_MODEL()).toBe("claude-haiku-5-5");
    const f = globalThis.fetch;
    let sent: any = null;
    (globalThis as any).fetch = async (url: string, o: any) => { sent = { url, o }; return { ok: true, json: async () => ({ content: [{ type: "text", text: '{"reply":"hi"}' }] }) }; };
    expect(await m.callClaude("sys", "q", 100, 2000)).toBe('{"reply":"hi"}');
    expect(sent.url).toBe("https://api.anthropic.com/v1/messages");
    expect(sent.o.headers["x-api-key"]).toBe("test-key");
    (globalThis as any).fetch = async () => ({ ok: false, status: 429, text: async () => "rate" });
    await expect(m.callClaude("s", "q", 10, 2000)).rejects.toThrow(/claude 429/);
    (globalThis as any).fetch = f;
    process.env = old;
  });
});
