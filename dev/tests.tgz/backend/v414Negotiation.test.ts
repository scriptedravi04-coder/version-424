import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";
import {
  setupDealsChatRoutes, negotiationLockReason, negotiationLockedFor, negotiationLockedMessage,
  isOrderFunded, latestOfferFrom, counterTermsFrom,
} from "./deals_chat_routes";

// v414 — negotiation / signing fixes (B1–B10).

const ROOT = path.resolve(__dirname, "..");
const read = (p: string) => fs.readFileSync(path.resolve(ROOT, p), "utf8");

const BRAND = "brand-1";
const CREATOR = "creator-1";
const brand = { user_id: BRAND, role: "brand" };
const creator = { user_id: CREATOR, role: "creator" };
const CAMP = "11111111-1111-4111-8111-111111111111";
const UGC = "ugcord_abc123";

function harness(thread: any, opts: { messages?: any[]; orders?: any[] } = {}) {
  const db: any = { chat_threads: [thread], deals: [], chat_messages: [...(opts.messages || [])], ugc_orders: [...(opts.orders || [])] };
  const routes: Record<string, any> = {};
  const router: any = { post: (paths: any, fn: any) => { (Array.isArray(paths) ? paths : [paths]).forEach((p: string) => (routes[p] = fn)); } };
  let actor: any;
  const noop = async (_req: any, res: any) => res.json({});
  setupDealsChatRoutes({} as any, router, {
    supabase: null, privilegedSupabase: null, getDb: () => db, saveDb: () => {}, parseAuthUser: async () => actor,
    sendNotification: async () => {}, serializeChatMessage: (t: any) => t, insertChatMessageToSupabase: async () => {},
    parseThreadState: () => ({}), updateThreadState: async () => {}, enrichThread: (t: any) => t,
    handleThreadApproveLiveLinks: noop, handleThreadApproveContent: noop, handleThreadSubmitLiveLink: noop,
    handleThreadRejectLiveLinks: noop, handleThreadDeclineLiveLinksResubmission: noop, getIsTestMode: () => false,
  } as any);
  const call = async (p: string, user: any, body: any = {}) => {
    actor = user; let status = 200; let json: any;
    const res = { status(s: number) { status = s; return this; }, json(j: any) { json = j; return this; } };
    if (!routes[p]) throw new Error("no route " + p);
    await routes[p]({ params: { threadId: thread.id }, body, path: p, app: { get: () => null } }, res);
    return { status, json };
  };
  return { db, call, routes };
}

const campThread = (x: any = {}) => ({ id: CAMP, campaign_id: "c1", brand_id: BRAND, creator_id: CREATOR, status: "NEGOTIATING", flow_state: "NEGOTIATING", agreed_amount: 10000, ...x });
const ugcThread = (x: any = {}) => ({ id: UGC, deal_id: UGC, is_ugc: true, brand_id: BRAND, creator_id: CREATOR, status: "NEGOTIATING", flow_state: "NEGOTIATING", agreed_amount: 5000, ...x });

describe("B9 · funded checks", () => {
  it("a hold time alone is not funded once escrow_hold is false (refund)", () => {
    expect(isOrderFunded({ escrow_held_at: "2026-01-01", escrow_hold: false })).toBe(false);
    expect(isOrderFunded({ escrow_hold_at: "2026-01-01", escrow_hold: false })).toBe(false);
    expect(isOrderFunded({ escrow_held_at: "2026-01-01" })).toBe(true);
    expect(isOrderFunded({ escrow_hold: true })).toBe(true);
    expect(isOrderFunded({ payment_status: "ESCROW_HELD" })).toBe(true);
    expect(isOrderFunded({ status: "PENDING" })).toBe(false);
  });
  it("server populateThreadData only counts escrow_hold_at while escrow_hold isn't false", () => {
    const s = read("backend/server.ts");
    expect(s).toContain("(Boolean(deal?.escrow_hold_at) && deal?.escrow_hold !== false)");
    expect(s).toContain("(Boolean(order?.escrow_held_at) && order?.escrow_hold !== false)");
  });
});

describe("B6 · lock reasons and messages", () => {
  it("unsigned agreement-ready does not lock; a signature does, with who signed", () => {
    expect(negotiationLockReason(campThread({ flow_state: "AI_AGREEMENT_READY" }))).toBe(null);
    expect(negotiationLockReason(campThread({ agreement_signed_brand: true }))).toBe("signed_brand");
    expect(negotiationLockedMessage(campThread({ agreement_signed_creator: true }))).toContain("signed by the creator");
    expect(negotiationLockedMessage(campThread({ agreement_signed_brand: true, agreement_signed_creator: true }))).toContain("both sides");
  });
  it("a funded UGC order locks, even for admins via the route check", () => {
    expect(negotiationLockReason(ugcThread(), { escrow_hold: true })).toBe("funded");
    expect(negotiationLockedFor(ugcThread({ flow_state: "ACTIVE" }), creator)).toBe(true);
    expect(negotiationLockedFor(ugcThread(), creator, { status: "PENDING" })).toBe(false);
  });
  it("creator can counter on AI_AGREEMENT_READY while nobody signed; locked message names the signer", async () => {
    const { db, call } = harness(campThread({ flow_state: "AI_AGREEMENT_READY" }));
    const r = await call("/campaign/threads/:threadId/creator-negotiate", creator, { counter_amount: 12000 });
    expect(r.status).toBe(200);
    expect(db.chat_threads[0].flow_state).toBe("NEGOTIATING_COUNTER");
    const h2 = harness(campThread({ flow_state: "AGREEMENT_SIGNED", agreement_signed_brand: true }));
    const r2 = await h2.call("/campaign/threads/:threadId/creator-negotiate", creator, { counter_amount: 12000 });
    expect(r2.status).toBe(409);
    expect(r2.json.code).toBe("NEGOTIATION_LOCKED");
    expect(r2.json.error).toContain("signed by the brand");
  });
});

describe("B7 · ₹3,000 minimum by thread type, not URL", () => {
  it("campaign thread on the /chat/v2 path is still held to ₹3,000", async () => {
    const { call } = harness(campThread());
    expect((await call("/chat/v2/threads/:threadId/creator-negotiate", creator, { counter_amount: 1000 })).status).toBe(400);
  });
  it("UGC thread called on the /campaign/ path is not", async () => {
    const { call } = harness(ugcThread());
    expect((await call("/campaign/threads/:threadId/creator-negotiate", creator, { counter_amount: 2500 })).status).toBe(200); // v420: UGC floor ₹2,000 too
  });
});

describe("B1 · UGC counter / accept", () => {
  it("the creator who sent the latest counter cannot accept it", async () => {
    const { call, db } = harness(ugcThread(), { orders: [{ id: UGC, status: "PENDING" }] });
    expect((await call("/ugc/threads/:threadId/creator-negotiate", creator, { counter_amount: 7000 })).status).toBe(200);
    const r = await call("/ugc/threads/:threadId/brand-accept-counter", creator, { counter_amount: 7000 });
    expect(r.status).toBe(403);
    expect(db.chat_threads[0].agreed_amount).toBe(5000);
  });
  it("the brand accepts the server's counter; a different body amount is STALE_OFFER with current_amount", async () => {
    const { call, db } = harness(ugcThread(), { orders: [{ id: UGC, status: "PENDING" }] });
    await call("/ugc/threads/:threadId/creator-negotiate", creator, { counter_amount: 7000 });
    const stale = await call("/ugc/threads/:threadId/brand-accept-counter", brand, { counter_amount: 99999 });
    expect(stale.status).toBe(409);
    expect(stale.json.code).toBe("STALE_OFFER");
    expect(stale.json.current_amount).toBe(7000);
    expect(db.chat_threads[0].agreed_amount).toBe(5000);
    const ok = await call("/ugc/threads/:threadId/brand-accept-counter", brand, {});
    expect(ok.status).toBe(200);
    expect(db.chat_threads[0].agreed_amount).toBe(7000);
  });
  it("a funded UGC order can't be countered or accepted", async () => {
    const { call, db } = harness(ugcThread({ flow_state: "NEGOTIATING_COUNTER", counter_amount: 9000 }), { orders: [{ id: UGC, status: "ACCEPTED", escrow_hold: true, payment_status: "ESCROW_HELD" }] });
    const c = await call("/ugc/threads/:threadId/creator-negotiate", creator, { counter_amount: 8000 });
    expect(c.status).toBe(409);
    expect(c.json.code).toBe("NEGOTIATION_LOCKED");
    const a = await call("/ugc/threads/:threadId/brand-accept-counter", brand, {});
    expect(a.status).toBe(409);
    expect(a.json.code).toBe("NEGOTIATION_LOCKED");
    const admin = await call("/ugc/threads/:threadId/brand-accept-counter", { user_id: "adm", role: "admin" }, {});
    expect(admin.status).toBe(409);
    expect(db.chat_threads[0].agreed_amount).toBe(5000);
  });
  it("an in-progress UGC thread is not rolled back to negotiating", async () => {
    const { call, db } = harness(ugcThread({ status: "ACTIVE", flow_state: "ACTIVE" }));
    expect((await call("/ugc/threads/:threadId/creator-negotiate", creator, { counter_amount: 8000 })).status).toBe(409);
    expect(db.chat_threads[0].flow_state).toBe("ACTIVE");
  });
});

describe("B4 · decline counter on the server", () => {
  it("the other side declines; flow back to NEGOTIATING; message posted", async () => {
    const { call, db } = harness(campThread());
    await call("/campaign/threads/:threadId/creator-negotiate", creator, { counter_amount: 15000 });
    const own = await call("/campaign/threads/:threadId/decline-counter", creator);
    expect(own.status).toBe(403);
    const r = await call("/chat/v2/threads/:threadId/decline-counter", brand);
    expect(r.status).toBe(200);
    expect(db.chat_threads[0].flow_state).toBe("NEGOTIATING");
    const msg = db.chat_messages.find((m: any) => m.metadata?.action === "counter_offer_declined");
    expect(msg.content).toBe("Counter offer of ₹15,000 declined");
    // nothing pending any more
    expect((await call("/ugc/threads/:threadId/decline-counter", brand)).status).toBe(409);
    expect((await call("/campaign/threads/:threadId/brand-accept-counter", brand)).status).toBe(409);
  });
  it("NegotiationTable Decline calls the server", () => {
    const s = read("src/components/chat/NegotiationTable.jsx");
    expect(s).toContain("/decline-counter`");
  });
});

describe("B5 · revisions / delivery days travel with the counter", () => {
  it("stored on the offer and written to the thread on accept", async () => {
    const { call, db } = harness(campThread());
    await call("/campaign/threads/:threadId/creator-negotiate", creator, { counter_amount: 12000, revision_count: 2, delivery_days: 10, breakdown: [{ id: "a", name: "Reel", qty: 2, rate: 6000 }] });
    const offer = db.chat_messages.find((m: any) => m.message_type === "negotiation_offer");
    expect(offer.metadata).toMatchObject({ proposed_amount: 12000, revision_count: 2, delivery_days: 10 });
    expect(offer.metadata.breakdown).toHaveLength(1);
    const r = await call("/campaign/threads/:threadId/brand-accept-counter", brand, { counter_amount: 12000 });
    expect(r.status).toBe(200);
    expect(db.chat_threads[0].revision_count).toBe(2);
    expect(db.chat_threads[0].deadline).toMatch(/^\d{4}-\d{2}-\d{2}$/);
  });
  it("counterTermsFrom keeps 0 revisions and ignores junk", () => {
    expect(counterTermsFrom({ revision_count: 0 })).toEqual({ revision_count: 0 });
    expect(counterTermsFrom({ delivery_days: 3 }, Date.UTC(2026, 0, 1))).toEqual({ deadline: "2026-01-04" });
    expect(counterTermsFrom({ revision_count: "x" })).toEqual({});
  });
  it("latestOfferFrom picks the newest by time, either id field", () => {
    const l = latestOfferFrom([
      { message_type: "negotiation_offer", sender_id: "a", metadata: { proposed_amount: 1 }, created_at: "2026-01-02" },
      { message_type: "negotiation_offer", sender_user_id: "b", metadata: { proposed_amount: 2 }, created_at: "2026-01-01" },
    ]);
    expect(l).toMatchObject({ sender: "a", amount: 1 });
  });
});

describe("B8 · sign stale guard returns current_amount", () => {
  it("a sign with a different amount is AMOUNT_CHANGED with current_amount; no amount still allowed through to OTP", async () => {
    const { call } = harness(campThread({ flow_state: "AI_AGREEMENT_READY" }));
    const r = await call("/campaign/threads/:threadId/sign", creator, { amount: 9000 });
    expect(r.status).toBe(409);
    expect(r.json.code).toBe("AMOUNT_CHANGED");
    expect(r.json.current_amount).toBe(10000);
    const r2 = await call("/campaign/threads/:threadId/sign", creator, {});
    expect(r2.json.code).toBe("SIGN_OTP_REQUIRED");
  });
});

describe("B2 / B3 · signatures", () => {
  const s = read("backend/deals_chat_routes.ts");
  it("sign writes only its own column, re-reads, and never overwrites ACTIVE with a one-side flow", () => {
    expect(s).toContain("update({ ...ownSig, updated_at: new Date().toISOString() }).eq('id', threadId)");
    expect(s).toContain(".select('agreement_signed_creator, agreement_signed_brand, agreement_signed_at, flow_state, status')");
    expect(s).toContain(".or('flow_state.is.null,flow_state.neq.ACTIVE')"); // v414b: NULL flow rows count too
    expect(s).not.toMatch(/const threadUpdates: any = \{\s*agreement_signed_creator: signedCreator,/);
  });
  it("one signature (AGREEMENT_SIGNED) maps to NEGOTIATING, not ACTIVE", () => {
    const srv = read("backend/server.ts");
    expect(srv).toContain("['NEGOTIATING', 'NEGOTIATING_COUNTER', 'AI_AGREEMENT_READY', 'AGREEMENT_SIGNED'].includes(upper)");
  });
  it("offer cards don't call one signature 'executed'", () => {
    for (const f of ["src/components/chat/OfferCard.jsx", "src/components/chat/mobile/MobileOfferCard.jsx"]) {
      const c = read(f);
      const block = c.slice(c.indexOf("const isAgreementExecuted"), c.indexOf("const isAgreementExecuted") + 400);
      expect(block, f).not.toContain("agreement_signed_at ||");
      expect(block, f).not.toContain("threadStatusUpper === 'ACTIVE'");
    }
  });
});

describe("B10 · revision fallback matches the server (5)", () => {
  it("no '|| 1' revision fallbacks left", () => {
    expect(read("src/components/chat/OfferCard.jsx")).not.toContain("offer.revision_count || 1");
    expect(read("src/components/chat/ContractModal.jsx")).not.toContain("thread?.revision_count || 1");
    const m = read("src/components/chat/mobile/MobileContractSheet.jsx");
    expect(m).not.toContain("revision_count || 1");
    expect(m).not.toContain("Number(thread?.revision_count) || 1");
    expect(read("backend/campaignGuards.ts")).toContain("return 5;");
  });
});
