import { describe, it, expect } from "vitest";
import fs from "fs";

const read = (p: string) => fs.readFileSync(p, "utf8");

describe("v356 · footers from Ravi's 'Settings & Home' design", () => {
  it("both homes end with the colour city footer (creator → brands art, brand → creators art)", () => {
    const layout = read("src/components/layout/Layout.jsx");
    expect(layout).toContain('kind: "city"');
    expect(layout).toContain("<HomeCityFooter variant={footerProps.variant} />");
    const f = read("src/components/footer/HomeCityFooter.jsx");
    // v363 requirement change (Ravi: "creators ke liye 'find brands from corner shop' line kyu? dono side grammar aur
    // motive fix karo"): each side now speaks to its reader.
    expect(f).toContain("From local shops to big brands — ");
    expect(f).toContain("your next collab is here.");
    expect(f).toContain("From corner shops to big companies — ");
    expect(f).toContain("find the right creators for you.");
    expect(f).toContain("/img/footer/city-brands.svg");
    expect(f).toContain("/img/footer/city-creators.svg");
    expect(f).toContain("md:hidden"); // phone version
    expect(f).toContain("hidden md:block"); // desktop version
  });

  it("art files exist and carry no heavy metadata", () => {
    for (const p of ["city-brands.svg", "city-creators.svg", "founder-ravi.webp", "founder-signature.webp"]) {
      expect(fs.existsSync(`public/img/footer/${p}`)).toBe(true);
    }
    expect(read("public/img/footer/city-brands.svg")).not.toContain("<metadata>");
    expect(read("public/img/footer/city-creators.svg")).not.toContain("<metadata>");
  });

  it("settings (phone + desktop, creator + brand) end with the founder note + version line", () => {
    const note = read("src/components/footer/FounderNote.jsx");
    for (const t of ["Why I built Ybex", "So creators get paid on time and brands get work they can trust.", "Ravi Sharma", "Founder, Ybex", "@ybex.in", "in Jaipur"]) {
      expect(note).toContain(t);
    }
    expect(read("src/pages/creator/CreatorMobileProfile.jsx")).toContain("<FounderNoteMobile");
    expect(read("src/components/profile/mobile/BrandProfileMobile.jsx")).toContain("<FounderNoteMobile");
    expect(read("src/pages/creator/CreatorSettings.jsx")).toContain("<FounderNoteDesktop");
    expect(read("src/pages/brand/BrandSettings.jsx")).toContain("<FounderNoteDesktop");
    // brand Log out still opens the confirm sheet
    expect(read("src/components/profile/mobile/BrandProfileMobile.jsx")).toContain("onClick={() => setShowLogoutModal(true)}");
  });

  it("phone /brand/profile (the brand settings hub) gets no second footer under the founder note", () => {
    expect(read("src/components/layout/Layout.jsx")).toContain('path === "/brand/profile" && typeof window !== "undefined" && window.innerWidth < 768');
  });
});
