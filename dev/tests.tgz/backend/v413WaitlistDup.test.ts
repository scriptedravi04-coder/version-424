import { describe, it, expect } from "vitest";
import fs from "fs";
// v413: a "Started" Join-screen lead is hidden in Waitlist once a creator account with the same Instagram handle exists.
describe("v413 waitlist duplicate", () => {
  const src = fs.readFileSync("backend/admin_waitlist_routes.ts", "utf8");
  it("drops join_started rows whose handle already has a creator account", () => {
    expect(src).toMatch(/source \|\| ''\) === 'join_started'/);
    expect(src).toMatch(/accountHandles\.has\(igKey\(w\.social_handle\)\)/);
    expect(src).toMatch(/cp\.instagram_handle \|\| cp\.handle/);
  });
});
