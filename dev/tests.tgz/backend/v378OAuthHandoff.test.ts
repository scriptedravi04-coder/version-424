import { describe, it, expect } from "vitest";
import { makeState, readState, HANDOFF_RE } from "./oauth_routes";
import { readFileSync } from "fs";

describe("v378 · iPhone Home Screen sign-in hand-off", () => {
  it("carries a valid hand-off id in the signed state, drops a bad one", () => {
    const h = "0123456789abcdef0123456789abcdef";
    expect(HANDOFF_RE.test(h)).toBe(true);
    expect(readState(makeState("creator", Date.now(), "s", false, h), Date.now(), "s")?.h).toBe(h);
    expect(readState(makeState("creator", Date.now(), "s", false, "nope"), Date.now(), "s")?.h).toBeUndefined();
  });
  it("Google always gets ybexmedia.in when the app talks to the hosting address", () => {
    const s = readFileSync("backend/oauth_routes.ts", "utf8");
    expect(s).toContain('return "https://ybexmedia.in";');
    expect(s).toContain('router.get("/auth/oauth/handoff"');
  });
  it("the sheet says 'go back to the app' instead of running the website", () => {
    const s = readFileSync("src/pages/app/AppOAuthDone.jsx", "utf8");
    expect(s).toContain("oauth-handoff-done");
    expect(readFileSync("src/pages/app/AppContinue.jsx", "utf8")).toContain("waitForHandoff(handoff");
  });
});

import { googleIdTokenOk } from "./oauth_routes";
describe("v378 · phone's own Google account picker (native app)", () => {
  const now = Date.parse("2026-10-29T10:00:00Z");
  const ok = { aud: "web-id", iss: "https://accounts.google.com", exp: String(now / 1000 + 600), email: "a@b.in", email_verified: "true" };
  it("accepts only our client ids, Google, unexpired, verified e-mail", () => {
    expect(googleIdTokenOk(ok, ["web-id"], now)).toBe(true);
    expect(googleIdTokenOk({ ...ok, aud: "other" }, ["web-id"], now)).toBe(false);
    expect(googleIdTokenOk({ ...ok, iss: "evil" }, ["web-id"], now)).toBe(false);
    expect(googleIdTokenOk({ ...ok, exp: String(now / 1000 - 1) }, ["web-id"], now)).toBe(false);
    expect(googleIdTokenOk({ ...ok, email_verified: "false" }, ["web-id"], now)).toBe(false);
  });
  it("older app builds without the plugin keep the browser sign-in", () => {
    const n = readFileSync("src/lib/native.js", "utf8");
    expect(n).toContain('if (!isNative() || !SL?.login || !SL?.initialize) return null;');
  });
});
