// v348 (Ravi): manual settle / refund (admin decides brand / creator / Ybex fee), promo popups take turns,
// promo link page picker, Eva + promo only inside the app, stuck unread badge from no-sender cards.
import { describe, it, expect } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { settlementBlock, validateSettlement, settlementUpdate, readSettlement, upiPayLink } from "./manualSettlement";
import { payoutReleaseBlock, isPaidOut, isRefunded, isEscrowHeld, netAfterPartialRefund } from "./adminMoney";
import { livePromos, pickPromo, appPath } from "./promo_routes";
import { choosePromo } from "../src/components/promo/PromoPopup.jsx";
import { isPublicPage, showInAppExtras } from "../src/lib/inAppPage.js";
import { splitFor, upiLink } from "../src/components/admin/SettleDealModal.jsx";

const root = path.resolve(__dirname, "..");
const read = (p: string) => fs.readFileSync(path.join(root, p), "utf8");
const TX = { id: "11111111-1111-1111-1111-111111111111", deal_id: "d1", gross_amount: 10000, platform_fee_amount: 1271, gst_amount: 229, creator_net_amount: 8500, status: "SUCCESS", payout_status: "PENDING", refund_status: "NONE", refund_amount: 0 };
const body = (b: number, c: number, k: number, extra: any = {}) => ({ brand_amount: b, creator_amount: c, ybex_amount: k, reason: "Deal cancelled", brand_utr: b > 0 ? "UTR123456" : "", creator_utr: c > 0 ? "UTR654321" : "", ...extra });
const apply = (b: number, c: number, k: number) => {
  const { clean } = validateSettlement(TX, body(b, c, k));
  return { ...TX, ...settlementUpdate(TX, clean!, "admin1", "2026-10-19T10:00:00.000Z") };
};

describe("v348 — manual settlement rules", () => {
  it("the three parts must add up to what the brand paid; nothing is pre-chosen", () => {
    expect(validateSettlement(TX, body(5000, 5000, 0)).clean).toBeTruthy();
    expect(validateSettlement(TX, body(5000, 4000, 0)).problem?.code).toBe("SPLIT_MISMATCH");
    expect(validateSettlement(TX, { reason: "x y z" }).problem).toBeTruthy();
    expect(validateSettlement(TX, body(-1, 10001, 0)).problem).toBeTruthy();
    expect(validateSettlement(TX, body(4750, 4750, 500)).clean?.ybex_amount).toBe(500);
  });
  it("UTR needed for each side that gets money, and a reason", () => {
    expect(validateSettlement(TX, body(5000, 5000, 0, { brand_utr: "" })).problem).toBeTruthy();
    expect(validateSettlement(TX, body(0, 10000, 0, { brand_utr: "" })).clean).toBeTruthy();
    expect(validateSettlement(TX, body(10000, 0, 0, { reason: "" })).problem).toBeTruthy();
  });
  it("half-half with 5% fee: creator row shows only the creator's part, no second payout possible", () => {
    const row = apply(4750, 4750, 500);
    expect(row.creator_net_amount).toBe(4750);
    expect(row.refund_amount).toBe(4750);
    expect(row.refund_status).toBe("PROCESSED");
    expect(row.payout_status).toBe("PAID");
    expect(row.platform_fee_amount).toBe(500);
    expect(isPaidOut(row)).toBe(true);
    expect(payoutReleaseBlock(row)?.code).toBe("ALREADY_PAID");
    expect(isEscrowHeld(row)).toBe(false);
    expect(readSettlement(row)?.original?.creator_net_amount).toBe(8500);
  });
  it("all to brand = full refund", () => {
    const row = apply(10000, 0, 0);
    expect(row.status).toBe("REFUNDED");
    expect(isRefunded(row)).toBe(true);
    expect(payoutReleaseBlock(row)?.code).toBe("ALREADY_REFUNDED");
  });
  it("part to brand, nothing to creator: the locked release route finds nothing left", () => {
    const row = apply(9000, 0, 1000);
    expect(netAfterPartialRefund(row, Number(row.creator_net_amount))).toBe(0);
    expect(isEscrowHeld(row)).toBe(false);
  });
  it("Ybex keeps everything: counts as closed, never paid later", () => {
    const row = apply(0, 0, 10000);
    expect(isPaidOut(row)).toBe(true);
  });
  it("blocks: already paid / settled / UGC / not funded", () => {
    expect(settlementBlock({ ...TX, payout_status: "PAID" })?.code).toBe("ALREADY_PAID_OUT");
    expect(settlementBlock(apply(5000, 5000, 0))?.code).toBe("ALREADY_SETTLED");
    expect(settlementBlock({ ...TX, deal_id: null, ugc_order_id: "u1" })?.code).toBe("NOT_A_DEAL");
    expect(settlementBlock({ ...TX, status: "INITIATED" })?.code).toBe("NOT_FUNDED");
    expect(settlementBlock(TX)).toBeNull();
  });
  it("UPI QR link carries the amount", () => {
    expect(upiPayLink("ravi@okhdfc", "Ravi", 4750, "Ybex refund")).toContain("am=4750.00");
    expect(upiPayLink("not-upi", "x", 10, "")).toBeNull();
    expect(upiLink("ravi@okhdfc", "Ravi", 10, "n")).toContain("pa=ravi%40okhdfc");
    expect(splitFor(1000000, 5, "half")).toEqual({ b: 475000, c: 475000, k: 50000 });
    expect(splitFor(1000000, 0, "brand")).toEqual({ b: 1000000, c: 0, k: 0 });
  });
  it("routes are registered and the locked payment file is untouched by this feature", () => {
    expect(read("backend/server.ts")).toContain("setupManualSettlementRoutes(router");
    expect(read("backend/adminPermissions.ts")).toContain('"settlements": "manage_escrow"');
    expect(read("backend/payment_routes.ts")).not.toContain("manualSettlement");
  });
});

describe("v348 — promo popups take turns; profile banner separate", () => {
  const rows = [
    { id: "a", layout: "sheet", audience: "all", is_active: true, image_url: "x", priority: 100, created_at: "2026-10-13", frequency: "every_open" },
    { id: "b", layout: "card", audience: "all", is_active: true, image_url: "y", priority: 100, created_at: "2026-10-16", frequency: "every_open" },
    { id: "c", layout: "banner", audience: "all", is_active: true, image_url: "z", priority: 0, created_at: "2026-10-10" },
  ];
  it("server sends the whole list; the banner never competes with popups", () => {
    expect(livePromos(rows, "brand").map((p) => p.id)).toEqual(["b", "a"]);
    expect(pickPromo(rows, "brand", Date.now(), "banner")?.id).toBe("c");
  });
  it("same priority → the one shown longest ago goes next", () => {
    const list = livePromos(rows, "brand");
    const seen: any = { b: 2000, a: 1000 };
    expect(choosePromo(list, (p: any) => seen[p.id] ?? null).id).toBe("a");
    seen.a = 3000;
    expect(choosePromo(list, (p: any) => seen[p.id] ?? null).id).toBe("b");
  });
  it("a 'once' popup already seen no longer blocks the next", () => {
    const list = [{ id: "hi", priority: 50, frequency: "once", image_url: "x" }, { id: "lo", priority: 0, frequency: "every_open", image_url: "y" }];
    expect(choosePromo(list, (p: any) => (p.id === "hi" ? 1 : null)).id).toBe("lo");
  });
  it("links copied from the web app become app pages", () => {
    expect(appPath("https://ybexapp.ai.studio/refer")).toBe("/refer");
    expect(appPath("https://ybexmedia.in/dashboard?assist=new")).toBe("/dashboard?assist=new");
    expect(appPath("https://instagram.com/ybex")).toBe("https://instagram.com/ybex");
    expect(read("src/components/admin/AdminPromoPopups.jsx")).toContain('["Chat with Ybex Eva", "/dashboard?assist=new"]');
  });
});

describe("v348 — Eva / promo only inside the app", () => {
  it("public pages", () => {
    for (const p of ["/", "/login", "/signup", "/privacy-policy", "/r/ABC", "/info/terms", "/blog/x", "/app", "/admin", "/forgot-password"]) expect(isPublicPage(p)).toBe(true);
    for (const p of ["/dashboard", "/brand/campaigns", "/chat", "/refer", "/profile", "/brand", "/creator/ugc"]) expect(isPublicPage(p)).toBe(false);
  });
  it("needs a signed-in user", () => {
    expect(showInAppExtras("/dashboard", null)).toBe(false);
    expect(showInAppExtras("/", { user_id: "u" })).toBe(false);
    expect(showInAppExtras("/dashboard", { user_id: "u" })).toBe(true);
    expect(read("src/components/promo/PromoPopup.jsx")).toContain("showInAppExtras(");
    expect(read("src/components/feedback/DesktopEva.jsx")).toContain("isPublicPage(pathname)");
  });
});

describe("v348 — unread badge: cards with no sender never count", () => {
  it("same rule as open-chat → mark read (sender <> me skips NULL senders)", () => {
    // v417: "me" is now my whole side (brand owner + team) — still skips NULL senders
    expect(read("backend/inboxLean.ts")).toContain("m.sender_user_id && !mySideHas(currentUserId, m.sender_user_id)");
    expect(read("backend/server.ts")).toContain("m.sender_user_id && !mySideHas(currentUserId, m.sender_user_id)");
  });
});
