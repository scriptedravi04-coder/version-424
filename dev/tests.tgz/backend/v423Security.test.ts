// v423 — brand panel security report (S1–S16, E1–E2)
import { describe, it, expect } from "vitest";
import fs from "fs";
import { emailChangeNeedsProof } from "./contactProof";

const read = (p: string) => fs.readFileSync(p, "utf8");

describe("v423 brand security", () => {
  it("S1: a NEW POC email needs a server-side OTP proof; unchanged / login email does not", () => {
    expect(emailChangeNeedsProof("new@x.com", "old@x.com", "login@x.com")).toBe(true);
    expect(emailChangeNeedsProof("OLD@x.com ", "old@x.com", "login@x.com")).toBe(false);
    expect(emailChangeNeedsProof("login@x.com", "old@x.com", "login@x.com")).toBe(false);
    expect(emailChangeNeedsProof("", "old@x.com", "login@x.com")).toBe(false);
    expect(read("backend/brands_routes.ts")).toMatch(/code: "EMAIL_NOT_VERIFIED"/);
    expect(read("backend/session_routes.ts")).toMatch(/rememberContactProof\(String\(verifier\.user_id\), String\(value\)\)/);
  });
  it("S2: OTP send has per-IP and global limits, and logs no full address", () => {
    const s = read("backend/session_routes.ts");
    expect(s).toMatch(/const flood = otpFlood\(req\)/);
    expect(s).not.toMatch(/Dispatched to \$\{value\.trim\(\)\}/);
  });
  it("S3/S7: no account-enumeration message, no raw database errors", () => {
    const b = read("backend/brands_routes.ts");
    expect(b).not.toMatch(/detail: "Email address is already in use by another account\./);
    expect(b).not.toMatch(/Supabase brand profile save failed: " \+/);
    expect(read("backend/misc_routes.ts")).not.toMatch(/Could not configure storage bucket: \$\{e\.message\}/);
  });
  it("S4/S5/S10/S15: KYC docs owned by the brand, admin-only KYC, own-storage images, minimal team fields", () => {
    const b = read("backend/brands_routes.ts");
    expect(b).toMatch(/Please upload your KYC documents again from this account/);
    expect(b).toMatch(/Only the brand's admin can submit KYC/);
    expect(b).toMatch(/Please upload the image from your device/);
    expect(b).toMatch(/const pick = \(u: any\) => \(\{ user_id: u\.user_id, name/);
  });
  it("S8/S13/S14/S16/E2", () => {
    expect(read("backend/session_routes.ts")).toMatch(/if \(owned\) req\.app\?\.get\?\.\("authLookup"\)\?\.forgetToken/);
    expect(read("backend/campaigns_routes.ts")).toMatch(/code: "CAMPAIGN_NOT_DRAFTABLE"/);
    expect(read("backend/ugc_routes.ts")).toMatch(/Only the brand's admin can approve and release payment/);
    expect(read("backend/session_routes.ts")).toMatch(/verified: false,\s*\n\s*message: `\$\{platform\} link saved`/);
    expect(read("backend/signingEmail.ts")).toMatch(/const isBrand = isBrandLike\(user\?\.role\)/);
  });
  it("S9/S11/S12: drafts cleared on logout, no dicebear, new tabs without opener", () => {
    expect(read("src/contexts/AuthContext.jsx")).toMatch(/clearUserDrafts\(\)/);
    const walk = (d: string): string[] => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => e.isDirectory() ? walk(`${d}/${e.name}`) : [`${d}/${e.name}`]);
    const src = walk("src").filter((f) => /\.(js|jsx)$/.test(f) && !/\.test\./.test(f) && !/utils\/initials\.js$/.test(f));
    expect(src.filter((f) => read(f).includes("api.dicebear.com"))).toEqual([]);
    expect(read("src/components/dashboard/BrandDashboard.jsx")).toMatch(/window\.open\(ctaUrl, '_blank', 'noopener,noreferrer'\)/);
  });
});

import { rememberContactProof, takeContactProof } from "./contactProof";
describe("v423 contact proof store", () => {
  it("a verified email can be saved once by the same user", async () => {
    await rememberContactProof("u1", "New@Brand.test ");
    expect(await takeContactProof("u2", "new@brand.test")).toBe(false);
    expect(await takeContactProof("u1", "new@brand.test")).toBe(true);
    expect(await takeContactProof("u1", "new@brand.test")).toBe(false);
  });
});
