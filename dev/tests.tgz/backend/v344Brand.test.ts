import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";

// v344: brand-side fixes — source checks (one small assertion per fix).
const ROOT = path.resolve(__dirname, "..");
const src = (rel: string) => fs.readFileSync(path.join(ROOT, rel), "utf8");

const CREATE = "src/components/campaigns/mobile/MobileCampaignCreate.jsx";
const UGC = "src/pages/brand/BrandUGCMobile.jsx";

describe("v344 brand fixes", () => {
  it("1. editing a live campaign hides Save draft, says 'Changes sent for review', no 0 Applications tile", () => {
    const s = src(CREATE);
    expect(s).toMatch(/const canSaveDraft = !editId \|\| editStatus === "draft"/);
    expect((s.match(/canSaveDraft \?/g) || []).length).toBe(2);
    expect(s).toMatch(/canSaveDraft && \(/);
    expect(s).toContain('"Changes sent for review"');
    expect(s).toContain('{editId ? "Edit campaign" : "New campaign"}');
    expect(src("src/components/campaigns/mobile/campaignCreate/PublishedScreen.jsx")).toMatch(/\{!isEdit && \(/);
  });

  it("2. budget: min > 0, max > 0, min <= max; min=1; no || 1000 fallback", () => {
    const s = src(CREATE);
    expect(s).not.toMatch(/\|\| 1000/);
    expect(s).toContain("Please enter a minimum payout above ₹0.");
    expect(s).toContain("Min payout can't be more than max payout.");
    expect((src("src/components/campaigns/mobile/campaignCreate/PayoutPerCreator.jsx").match(/min="1"/g) || []).length).toBe(3);
  });

  it("3. creators needed is validated 1–500 (no silent 0→10)", () => {
    const s = src(CREATE);
    expect(s).not.toMatch(/parseInt\(customCreatorsNeeded, 10\) \|\| 10\b/);
    expect(s).toContain("Creators needed must be between 1 and 500.");
    // v416 requirement change: no silent 600 → 500 cap — the number stays and the message shows the 1–500 limit
    expect(src("src/components/campaigns/mobile/campaignCreate/AdvancedTargetingForm.jsx")).toMatch(/Number\(customCreatorsNeeded\) <= 500/);
  });

  it("4. payout release asks for confirmation only once", () => {
    const s = src(UGC);
    const handler = s.slice(s.indexOf("const handleApproveOrder"), s.indexOf("setApprovingOrder(true)"));
    expect(handler).not.toContain("window.confirm");
  });

  it("5. Manage Orders opens the search box with the filter", () => {
    // v416 (U27, requirement change): Manage orders filters by the brief's id (a title search matched other briefs)
    expect(src(UGC)).toContain("setOrderBriefFilter({ id: brief.id");
  });

  it("6. Back on step 1 at /brand/ugc/post goes to /brand/ugc/briefs", () => {
    expect(src(UGC)).toContain('navigate("/brand/ugc/briefs", { replace: true })');
    expect(src("src/App.jsx")).toContain('path="/brand/ugc/briefs"');
  });

  it("7. closed UGC orders: grey Closed badge, no timer, no Payment Hold", () => {
    const s = src("src/pages/brand/brandUgc/OrdersTab.jsx");
    expect(s).toMatch(/const isClosed = \["CANCELLED", "CANCELED", "EXPIRED", "REFUNDED"\]/);
    expect(s).toContain('{isClosed ? "Closed"');
    expect(s).toContain("!isCompleted && !isClosed && !isDeclined && !isChangesAsked && !isInReview"); // v358 requirement change: no creator timer while the draft waits for the brand
  });

  it("8. applicants load error shows Retry, no fake Draft chip", () => {
    expect(src("src/pages/brand/BrandCampaignApplicants.jsx")).toContain("appsError={appsError}");
    const m = src("src/components/campaigns/mobile/BrandCampaignDetailMobile.jsx");
    expect(m).toContain("noPitches && appsError ?");
    expect(m).toContain("Couldn't load applicants");
    expect(m).toContain("const chip = !campaign ? null :");
  });

  it("9. home: applicants total is informational; template asks before replacing a draft", () => {
    const s = src("src/pages/brand/BrandHomeMobile.jsx");
    expect(s).not.toContain("new applicant");
    expect(s).toContain("so far across your campaigns");
    expect(s).toMatch(/draftGet\("campaign_draft"\)[\s\S]{0,300}appConfirm/); // v430: app confirm sheet
  });

  it("10. desktop campaign detail: no creator Apply/KYC for brands; own campaign → Manage applicants", () => {
    const s = src("src/pages/campaigns/CampaignDetail.jsx");
    expect(s).toContain("{isCreatorViewer && <KycPromptModal");
    expect(s).toContain("/applicants`}");
    expect(s).toContain("Manage applicants");
  });

  it("11. invite sheets show a Retry on a failed campaigns fetch; review plural", () => {
    expect(src("src/components/explore/mobile/ExploreMobile.jsx")).toContain("Couldn't load your campaigns");
    expect(src("src/components/campaigns/InviteToCampaignModal.jsx")).toMatch(/campaignsError \? \(/);
    const p = src("src/pages/creator/CreatorPublicView.jsx");
    expect(p).toContain("campaignsError={myCampaignsError}");
    expect(p).toContain('review${totalReviewsCount === 1 ? "" : "s"}');
  });

  it("12. sheets lock background scroll", () => {
    expect(src(CREATE)).toMatch(/useScrollLock\(showNicheSheet \|\| showCitySheet/);
    expect(src(UGC)).toContain("useScrollLock(showLivePreview || showApplicantsSheet)");
    expect(src("src/components/campaigns/mobile/BrandCampaignDetailMobile.jsx")).toContain("useScrollLock(open); // v344"); // v417: the pitch player is its own component (PitchPlayer)
  });

  it("13. New menu sits above BottomNav", () => {
    const s = src("src/components/campaigns/mobile/BrandCampaignsMobile.jsx");
    expect(s).toContain("z-[70]");
    expect(s).toContain("z-[71]");
    expect(s).not.toMatch(/z-\[4[56]\]/);
  });

  it("14. KYC Edit & resubmit opens on the business step", () => {
    expect(src("src/pages/brand/BrandKycMobile.jsx")).toContain('searchParams.get("edit") === "true" ? "business" : "status"');
  });

  it("15. brand profile reads campaigns via the server", () => {
    const s = src("src/pages/brand/BrandProfile.jsx");
    expect(s).toContain('api.get("campaigns?mine=true")');
    expect(s).not.toMatch(/supabase\.from\('campaigns'\)/);
  });

  it("16. Skip niches & publish clears niches", () => {
    const s = src("src/pages/onboarding/BrandOnboardingMobile.jsx");
    expect(s).toContain('preferred_niches: skipNiches ? "" : formData.niches');
    expect(s).toContain("publish({ skipNiches: true })");
  });
});
