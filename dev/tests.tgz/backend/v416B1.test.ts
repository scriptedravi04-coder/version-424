import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";
import { isBrandLike } from "./roleGuards";
import { campaignPayoutProblem, MIN_CAMPAIGN_PAYOUT, MIN_INVITE_AMOUNT } from "./directInvites";
import { cleanLocationName } from "./misc_routes";

const read = (f: string) => fs.readFileSync(path.join(__dirname, f), "utf8");

describe("v416 B1 — roles (CR4)", () => {
  it("agency and talent manager count as brands", () => {
    expect(isBrandLike("brand")).toBe(true);
    expect(isBrandLike("Agency")).toBe(true);
    expect(isBrandLike("talent_manager")).toBe(true);
    expect(isBrandLike("creator")).toBe(false);
    expect(isBrandLike(null)).toBe(false);
  });
  it("campaign create / update / launch use isBrandLike", () => {
    const src = read("campaigns_routes.ts");
    expect(src).not.toMatch(/user\.role !== "brand"/);
    expect((src.match(/isBrandLike\(user\.role\)/g) || []).length).toBeGreaterThanOrEqual(3);
  });
});

describe("v416 B1 — ₹3,000 per creator on publish (C14)", () => {
  it("same floor as invites", () => expect(MIN_CAMPAIGN_PAYOUT).toBe(MIN_INVITE_AMOUNT));
  it("drafts and barter are exempt", () => {
    expect(campaignPayoutProblem(null, "Paid", true)).toBeNull();
    expect(campaignPayoutProblem(0, "Barter", false)).toBeNull();
  });
  it("paid publish needs ₹3,000+", () => {
    // v420: ₹2,000 special offer (the message says it's usually ₹3,000)
    expect(campaignPayoutProblem(1, "Paid", false)).toMatch(/₹2,000 per creator \(special offer — usually ₹3,000\)/);
    expect(campaignPayoutProblem(null, "Paid", false)).toMatch(/₹2,000/);
    expect(campaignPayoutProblem(1999, undefined, false)).not.toBeNull();
    expect(campaignPayoutProblem(2000, "Paid", false)).toBeNull();
  });
  it("create, update and submit-draft all check it", () => {
    const src = read("campaigns_routes.ts");
    expect((src.match(/campaignPayoutProblem\(/g) || []).length).toBeGreaterThanOrEqual(5);
  });
});

describe("v416 B1 — campaign save honesty (CR3, CR18, CR8)", () => {
  const src = read("campaigns_routes.ts");
  it("a failed Supabase write is a 500, not success", () => {
    expect(src).toMatch(/CAMPAIGN_SAVE_FAILED[\s\S]*CAMPAIGN_SAVE_FAILED/);
    expect(src).not.toMatch(/continuing to local fallback/);
    expect(src).not.toMatch(/persisting to local database fallback/);
  });
  it("local copy is whitelisted, not the raw body", () => {
    expect(src).not.toMatch(/Object\.assign\(localCamp, req\.body/);
    expect(src).not.toMatch(/\.\.\.req\.body,\s*\n\s*\.\.\.campaign/);
  });
  it("applicant city never falls back to the KYC address", () => {
    expect(src).not.toMatch(/kyc\.address/);
  });
});

describe("v416 B1 — no invented creator fee on shortlist (C2)", () => {
  const src = read("campaigns_routes.ts");
  it("uses only the creator's proposed amount and flags no_fee_proposed", () => {
    expect(src).toMatch(/const creatorFee = knownAmount\(app\.proposed_amount\)/);
    expect(src).toMatch(/no_fee_proposed: noFeeProposed/);
    expect(src).toMatch(/amount: noFeeProposed \? null/);
  });
});

describe("v416 B1 — invites (C4, C5, C26)", () => {
  const src = read("creators_routes.ts");
  it("company name comes from Supabase brand_profiles", () => {
    expect(src).toMatch(/invite-brand-profile/);
    expect(src).toMatch(/brand_name: bp\.company_name \|\| inv\.brand_name/);
  });
  it("brand can list its sent invitations", () => {
    expect(src).toMatch(/router\.get\(\["\/brands\/invitations", "\/brand\/invitations"\]/);
    expect(src).toMatch(/can_withdraw:/);
  });
  it("accepting a campaign invite adds an ACCEPTED application", () => {
    expect(src).toMatch(/from\("campaign_applications"\)\.insert\(\{[\s\S]*?status: "ACCEPTED"/);
  });
});

describe("v416 B1 — POST /locations/save (C3)", () => {
  it("route exists", () => expect(read("misc_routes.ts")).toMatch(/router\.post\("\/locations\/save"/));
  it("validates names", () => {
    expect(cleanLocationName("  Navi   Mumbai ")).toBe("Navi Mumbai");
    expect(cleanLocationName("x")).toBeNull();
    expect(cleanLocationName("<script>")).toBeNull();
    expect(cleanLocationName("Port Blair (Andaman)")).toBe("Port Blair (Andaman)");
  });
});

describe("v416 B1 — brand profile partial save (CR1)", () => {
  const src = read("brands_routes.ts");
  it("update writes only the fields that were sent", () => {
    expect(src).toMatch(/update\(patch\)/);
    expect(src).toMatch(/const keep = /);
    expect(src).not.toMatch(/industry: body\.industry \|\| ""/);
  });
});
