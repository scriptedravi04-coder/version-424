import { describe, it, expect, vi } from "vitest";
import fs from "node:fs";
import { purgeDue, runAccountPurge, PURGE_AFTER_DAYS } from "./admin_wipe_routes";

// v404 (QA P-1, Ravi "kr de"): self-deleted accounts are wiped for good after 30 days.
const DAY = 86400000, NOW = Date.parse("2026-12-10T00:00:00Z");
const row = (o: any = {}) => ({ user_id: "u1", role: "creator", is_deleted: true, deletion_reason: "self_serve", deletion_requested_at: new Date(NOW - 31 * DAY).toISOString(), ...o });
const read = (p: string) => fs.readFileSync(new URL(p, import.meta.url), "utf8");

describe("v404 30-day purge", () => {
  it("only self-deleted, 30+ days old, non-admin accounts are due", () => {
    expect(PURGE_AFTER_DAYS).toBe(30);
    expect(purgeDue(row(), NOW)).toBe(true);
    expect(purgeDue(row({ deletion_requested_at: new Date(NOW - 29 * DAY).toISOString() }), NOW)).toBe(false);
    expect(purgeDue(row({ is_deleted: false }), NOW)).toBe(false);
    expect(purgeDue(row({ deletion_reason: null }), NOW)).toBe(false); // admin bin delete
    expect(purgeDue(row({ deletion_requested_at: null }), NOW)).toBe(false);
    expect(purgeDue(row({ role: "admin" }), NOW)).toBe(false);
  });

  it("does nothing until the column exists", async () => {
    const q: any = { select: () => q, eq: () => q, lt: () => q, limit: () => Promise.resolve({ data: null, error: { code: "42703", message: 'column users.deletion_requested_at does not exist' } }) };
    const client = { from: vi.fn(() => q) };
    const r = await runAccountPurge({ client, getDb: () => ({}), saveDb: () => {} }, { now: NOW });
    expect(r.skipped).toBe("column_missing");
    expect(r.purged).toEqual([]);
    expect(client.from).toHaveBeenCalledTimes(1);
  });

  it("admin wipe and purge share one wipe; transactions are kept", () => {
    const w = read("./admin_wipe_routes.ts");
    expect(w).toMatch(/export async function wipeAccountData/);
    expect(w).toMatch(/WIPE_HAS_ACTIVE_MONEY/);
    expect(w).toMatch(/WIPE_INCOMPLETE/);
    expect(read("./accountWipe.ts")).toMatch(/WIPE_KEEP_TABLES = new Set\(\["transactions"/);
    expect(read("./server.ts")).toMatch(/setupAccountPurge\(router/);
  });
});

describe("v404 /transactions (QA L-1)", () => {
  it("parallel calls share one read; optional paging", () => {
    const s = read("./payment_routes.ts");
    expect(s).toMatch(/inFlightTx/);
    expect(s).toMatch(/X-Total-Count/);
  });
});

describe("v405 Google sign-in address (redirect_uri_mismatch with localhost)", () => {
  it("live server never sends localhost to Google", async () => {
    const { oauthOrigin } = await import("./oauth_routes");
    const prod = { NODE_ENV: "production" };
    expect(oauthOrigin("localhost:3000", "", prod)).toBe("https://ybexmedia.in");
    expect(oauthOrigin("127.0.0.1:3000", "", prod)).toBe("https://ybexmedia.in");
    expect(oauthOrigin("localhost:3000", "ybexmedia.in", prod)).toBe("https://ybexmedia.in");
    expect(oauthOrigin("localhost:3000", "www.ybexmedia.in", prod)).toBe("https://www.ybexmedia.in");
    expect(oauthOrigin("ybexapp.ai.studio", "", prod)).toBe("https://ybexmedia.in");
    expect(oauthOrigin("localhost:3000", "ybexapp.ai.studio", prod)).toBe("https://ybexmedia.in");
    expect(oauthOrigin("ybexmedia.in", "", prod)).toBe("https://ybexmedia.in");
    // local development keeps working
    expect(oauthOrigin("localhost:3000", "", { NODE_ENV: "development" })).toBe("http://localhost:3000");
    expect(oauthOrigin("localhost:3000", "", { NODE_ENV: "production", OAUTH_ALLOW_LOCALHOST: "true" })).toBe("http://localhost:3000");
  });
});

describe("v407 Instagram username already has an account", () => {
  it("masks the email; WhatsApp placeholder emails give nothing", async () => {
    const { maskEmail } = await import("./followerGate");
    expect(maskEmail("ravi.sharma@gmail.com")).toBe("r•••@gmail.com");
    expect(maskEmail("phone-919876543210@ybex.io")).toBe(null);
    expect(maskEmail("")).toBe(null);
  });
});

describe("v407 fewer database calls (Supabase logs)", () => {
  it("collabs page reads collabs + waves once each; no creator_profiles.id reads; push log not rewritten; status cached", () => {
    const cs = read("./content_submissions_routes.ts");
    expect(cs).toMatch(/supabase\.from\('collabs'\)\.select\('\*'\)\.or\(both\)/);
    expect(cs).toMatch(/supabase\.from\('waves'\)\.select\('\*'\)\.or\(both\)/);
    expect(cs).not.toMatch(/from\('waves'\)\s*\.select\('\*'\)\s*\.eq\('from_user_id'/);
    expect(read("./creators_routes.ts")).toMatch(/profileIdColumnMissing/);
    expect(read("./push_routes.ts")).toMatch(/handled\.has\(String\(n\.id\)\)/); // v429: batch version
    expect(read("./misc_routes.ts")).toMatch(/statusCache/);
  });
});
