// v365 (Ravi: "CSV waitlist import mein email optional kar do — Instagram handle hai to bina email ke row accept ho, duplicate
// handle se pakdo; approve pe 'Claim your profile' email na bheje, baaki unclaimed profile waise hi bane").
import { describe, it, expect } from "vitest";
import { prepareCsvRows, toWaitlistRow, fillMissing } from "./waitlistCsvImport";
import { approveCreatorApplication, sendApplicationDecisionEmail, likeExact, WAITLIST_COLUMNS, USERS_COLUMNS, CREATOR_PROFILE_COLUMNS } from "./creatorApplication";

const COLUMNS: Record<string, string[]> = { waitlist: WAITLIST_COLUMNS, users: USERS_COLUMNS, creator_profiles: CREATOR_PROFILE_COLUMNS };
const unknownColumn = (name: string, rows: any[]) => {
  for (const r of rows) for (const k of Object.keys(r)) if (!COLUMNS[name].includes(k)) return { message: `Could not find the '${k}' column of '${name}'` };
  return null;
};
// Like Postgres: ilike with "\_" / "\%" escapes = exact, case-insensitive. NOT NULL users.email is checked too.
const unescape = (v: string) => String(v).replace(/\\([\\%_])/g, "$1");
function fakeClient(seed: { users?: any[]; creator_profiles?: any[] } = {}) {
  const t: Record<string, any[]> = { waitlist: [], users: seed.users || [], creator_profiles: seed.creator_profiles || [] };
  const from = (name: string) => {
    const filters: Array<(r: any) => boolean> = [];
    const q: any = {
      select() { return q; },
      ilike(c: string, v: string) { filters.push((r) => String(r[c] || "").toLowerCase() === unescape(v).toLowerCase()); return q; },
      eq(c: string, v: any) { filters.push((r) => String(r[c]) === String(v)); return q; },
      limit() { return Promise.resolve({ data: t[name].filter((r) => filters.every((f) => f(r))), error: null }); },
      upsert(rows: any[]) {
        const bad = unknownColumn(name, rows); if (bad) return Promise.resolve({ error: bad });
        if (name === "users" && rows.some((r) => !r.email)) return Promise.resolve({ error: { message: 'null value in column "email" of relation "users"' } });
        if (name === "creator_profiles" && rows.some((r) => !r.name)) return Promise.resolve({ error: { message: 'null value in column "name"' } });
        for (const r of rows) { const i = t[name].findIndex((x) => x.user_id === r.user_id); if (i >= 0) t[name][i] = { ...t[name][i], ...r }; else t[name].push(r); }
        return Promise.resolve({ error: null });
      },
      update(patch: any) { const bad = unknownColumn(name, [patch]); if (bad) return { eq: () => Promise.resolve({ error: bad }) }; return { eq(c: string, v: any) { t[name].filter((r) => String(r[c]) === String(v)).forEach((r) => Object.assign(r, patch)); return Promise.resolve({ error: null }); } }; },
    };
    return q;
  };
  return { t, from };
}
const deps = (c: any) => ({ client: c, getDb: () => ({}), saveDb: () => {} });

describe("v365 · CSV rows without email", () => {
  it("a row with an Instagram handle and no email is accepted (email saved as null, not \"\")", () => {
    const [r] = prepareCsvRows([{ name: "Riya", instagram: "@Riya_K" }], new Set());
    expect(r.status).toBe("ok");
    expect(r.value!.email).toBeNull();
    expect(r.value!.social_handle).toBe("Riya_K");
    const row = toWaitlistRow(r.value!);
    expect((row as any).email).toBeNull();
    expect(row.source).toBe("csv_import");
  });
  it("no email AND no handle → error; a bad email is still an error", () => {
    const [a, b] = prepareCsvRows([{ name: "No Contact" }, { name: "Bad", email: "nope", instagram: "bad1" }], new Set());
    expect(a.status).toBe("error");
    expect(a.reason).toMatch(/Email or Instagram handle/);
    expect(b.status).toBe("error");
    expect(b.reason).toMatch(/Email does not look right/);
  });
  it("duplicates are caught by handle: twice in the file, or already on Ybex", () => {
    const res = prepareCsvRows([
      { name: "A", instagram: "same.one" },
      { name: "B", instagram_link: "https://instagram.com/Same.One/" },
      { name: "C", instagram: "known_x" },
    ], new Set(), new Set(), { handles: new Set(["known_x"]) });
    expect(res.map((r) => r.status)).toEqual(["ok", "duplicate", "duplicate"]);
    expect(res[1].reason).toMatch(/twice in this file/);
    expect(res[2].reason).toMatch(/already on Ybex/);
  });
  it("several handle-only rows don't clash with each other (no shared empty email)", () => {
    const res = prepareCsvRows([{ name: "A", instagram: "a1" }, { name: "B", instagram: "b2" }, { name: "C", instagram: "c3" }], new Set());
    expect(res.every((r) => r.status === "ok")).toBe(true);
  });
  it("re-upload completes a handle-only row an earlier import made (by handle)", () => {
    const [r] = prepareCsvRows([{ name: "Riya", instagram: "riya_k", city: "Jaipur", followers: "12k" }], new Set(), new Set(), { updatableHandles: new Set(["riya_k"]) });
    expect(r.status).toBe("update");
    const patch = fillMissing({ id: "w1", name: "Riya", social_handle: "riya_k", city: null, followers: null }, r.value!);
    expect(patch).toMatchObject({ city: "Jaipur", followers: 12000 });
    expect(patch).not.toHaveProperty("email");
  });
  it("email rows behave as before", () => {
    const [a, b] = prepareCsvRows([{ name: "E", email: "e@x.in" }, { name: "F", email: "e@x.in", instagram: "f1" }], new Set());
    expect(a.status).toBe("ok");
    expect(b.status).toBe("duplicate");
  });
});

describe("v365 · approving a creator with no email", () => {
  const entry = { id: "w1", name: "Riya", email: null, social_handle: "riya_k", followers: 12000, avg_reach: "3000", status: "Pending", source: "csv_import" };

  it("makes ONE unclaimed profile (placeholder login email, profile email null) and sends no email", async () => {
    const c = fakeClient();
    c.t.waitlist.push({ ...entry });
    const r: any = await approveCreatorApplication(c.t.waitlist[0], deps(c));
    expect(r.ok).toBe(true);
    expect(c.t.users).toHaveLength(1);
    expect(c.t.users[0].email).toMatch(/^unclaimed_CRTR_UNCLAIMED_.+@ybex\.io$/);
    expect(c.t.users[0].auth_method).toBe("unclaimed");
    expect(c.t.creator_profiles).toHaveLength(1);
    expect(c.t.creator_profiles[0]).toMatchObject({ instagram_handle: "riya_k", is_claimed: false, email: null, follower_count: 12000 });
    expect(c.t.waitlist[0]).toMatchObject({ status: "Approved", linked_user_id: r.shadowUserId });
    expect(await sendApplicationDecisionEmail(c.t.waitlist[0], "approved")).toBe(false);
  });
  it("approving again reuses the same unclaimed profile (no second listing)", async () => {
    const c = fakeClient();
    c.t.waitlist.push({ ...entry });
    const first: any = await approveCreatorApplication(c.t.waitlist[0], deps(c));
    const second: any = await approveCreatorApplication({ ...c.t.waitlist[0] }, deps(c));
    expect(second.ok).toBe(true);
    expect(second.shadowUserId).toBe(first.shadowUserId);
    expect(c.t.creator_profiles).toHaveLength(1);
    expect(c.t.users).toHaveLength(1);
  });
  it("another no-email row with the same handle updates that listing instead of duplicating it", async () => {
    const c = fakeClient();
    c.t.waitlist.push({ ...entry }, { ...entry, id: "w2", followers: 15000 });
    await approveCreatorApplication(c.t.waitlist[0], deps(c));
    await approveCreatorApplication(c.t.waitlist[1], deps(c));
    expect(c.t.creator_profiles).toHaveLength(1);
    expect(c.t.creator_profiles[0].follower_count).toBe(15000);
  });
  it("a creator who already has a real profile with that handle is linked, never copied", async () => {
    const c = fakeClient({ creator_profiles: [{ user_id: "real1", name: "Riya", instagram_handle: "riya_k", is_claimed: true, creator_type: "influencer" }] });
    c.t.waitlist.push({ ...entry });
    const r: any = await approveCreatorApplication(c.t.waitlist[0], deps(c));
    expect(r.ok).toBe(true);
    expect(c.t.users).toHaveLength(0);
    expect(c.t.creator_profiles).toHaveLength(1);
    expect(c.t.waitlist[0]).toMatchObject({ status: "Approved", linked_user_id: "real1", is_registered_user: true });
  });
  it("\"_\" in a handle or email is matched exactly (not as an ilike wildcard)", async () => {
    expect(likeExact("riya_k%")).toBe("riya\\_k\\%");
    const c = fakeClient({ creator_profiles: [{ user_id: "other", name: "X", instagram_handle: "riyaxk", is_claimed: true }] });
    c.t.waitlist.push({ ...entry });
    const r: any = await approveCreatorApplication(c.t.waitlist[0], deps(c));
    expect(r.shadowUserId).toBeTruthy(); // "riya_k" did not match "riyaxk"
  });
});
