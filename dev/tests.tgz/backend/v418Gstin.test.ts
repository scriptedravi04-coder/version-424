import { describe, it, expect } from "vitest";
import { readFileSync } from "fs";
import { GSTIN_RE } from "./brandPayments";
import { isCampaignEscrowFunded, isCampaignPossiblyFunded } from "./campaignGuards";

describe("v418 · brand GSTIN on receipts", () => {
  it("accepts a real-shaped GSTIN and rejects junk / PAN / empty", () => {
    expect(GSTIN_RE.test("08AAACY1234F1Z5")).toBe(true);
    for (const bad of ["", "ABCDE1234F", "08AAACY1234F1X5", "123", "08aaacy1234f1z5"]) expect(GSTIN_RE.test(bad)).toBe(false);
  });
  it("payments-overview reads brand_kyc and only sets brand_gstin when valid", () => {
    const s = readFileSync("backend/brandPayments.ts", "utf8");
    expect(s).toContain('c.from("brand_kyc").select("gst_number")');
    expect(s).toContain("find((g: string) => GSTIN_RE.test(g)) || null");
    expect(s).toContain("if (gstRaw) for (const it of items) it.brand_gstin = gstRaw;");
  });
  it("receipt (screen + PDF) shows GSTIN only for the brand and only when present", () => {
    const m = readFileSync("src/components/payments/InvoiceModal.jsx", "utf8");
    expect(m).toContain("{isBrand && transaction.brand_gstin && <div");
    const pdf = readFileSync("src/utils/invoicePdf.js", "utf8");
    expect(pdf).toContain("if (isBrand && transaction.brand_gstin)");
    const map = readFileSync("src/components/payments/BrandPaymentsMobile.jsx", "utf8");
    expect(map).toContain("brand_gstin: it.brand_gstin || null");
  });
});


describe("v418 · cancelling a paid deal never closes it outright", () => {
  it("a thread already in a paid state counts as funded even when no deposit row matches", async () => {
    for (const fs of ["escrow_funded", "ESCROW_HELD", "content_submitted", "AWAITING_LIVE_LINK"]) {
      expect(await isCampaignPossiblyFunded({ client: null, db: {}, dealId: null, thread: { flow_state: fs } })).toBe(true);
    }
    expect(await isCampaignPossiblyFunded({ client: null, db: {}, dealId: null, thread: { flow_state: "NEGOTIATING", status: "active" } })).toBe(false);
    // payouts keep the strict check: a flow label alone never releases money
    expect(await isCampaignEscrowFunded({ client: null, db: {}, dealId: null, thread: { flow_state: "LIVE_LINKS_SUBMITTED" } })).toBe(false);
  });
  it("a held deposit found by the thread's deal id counts (non-UUID ids too)", async () => {
    const db = { transactions: [{ id: "t1", deal_id: "deal1", status: "held", gross_amount: 12000 }] };
    expect(await isCampaignPossiblyFunded({ client: null, db, dealId: null, thread: { deal_id: "deal1", flow_state: "active" } })).toBe(true);
  });
  it("after a full admin refund both sides get a notification", () => {
    const s = readFileSync("backend/payment_routes.ts", "utf8");
    expect(s).toContain('type: "deal_refunded", title: x.title');
    expect(readFileSync("backend/campaign_lifecycle.ts", "utf8")).toContain("const funded = await isCampaignPossiblyFunded(");
  });
});
