// v363 (Ravi's design 1f): phone public profile — photo-led cover, adaptive page colour, live numbers, cover grid.
import { describe, it, expect } from "vitest";
import fs from "fs";
import { luminance, averageHex, themeFor, DARK_FALLBACK } from "../src/components/publicProfile/adaptiveTheme";
import { profileNumbers, shortCount } from "../src/components/publicProfile/PhotoLedHeaderMobile";
import { groupCoversByBrand } from "../src/components/publicProfile/PortfolioCoversMobile";

describe("v363 · public profile (phone)", () => {
  it("adaptive theme: dark photo edge → dark page + white CTA, light edge → light page + purple CTA", () => {
    expect(luminance("#000000")).toBe(0);
    expect(luminance("#ffffff")).toBeCloseTo(1, 5);
    expect(themeFor("#0B0B10").mode).toBe("dark");
    expect(themeFor("#0B0B10").ctaBg).toBe("#FFFFFF");
    expect(themeFor("#F4F1EC").mode).toBe("light");
    expect(themeFor("#F4F1EC").ctaBg).toBe("#7C3AED");
    expect(themeFor(DARK_FALLBACK).mode).toBe("dark");
    // average skips transparent pixels
    expect(averageHex(new Uint8ClampedArray([255, 0, 0, 255, 0, 0, 255, 255, 9, 9, 9, 0]))).toBe("#800080");
    expect(averageHex(new Uint8ClampedArray([]))).toBeNull();
  });

  it("numbers: live only when synced without an error; never invented", () => {
    const live = profileNumbers({ ig_followers: 10376, avg_views_30d: 19379, avg_likes_30d: 1160, engagement_rate: 11.21, instagram_synced_at: "2026-10-20", instagram_stats: {} });
    expect(live).toMatchObject({ followers: 10376, views: 19379, likes: 1160, er: 11.21, live: true });
    expect(profileNumbers({ instagram_synced_at: "x", instagram_stats: { error: "not_professional" } }).live).toBe(false);
    const empty = profileNumbers({});
    expect(empty.followers).toBeUndefined();
    expect(empty.er).toBeNull();
    expect(shortCount(10376)).toBe("10.4K");
    expect(shortCount(19379)).toBe("19.4K");
    expect(shortCount(0)).toBe("—");
    expect(shortCount(null)).toBe("—");
  });

  it("portfolio: covers grouped by brand, items without a cover left out of the grid", () => {
    const g = groupCoversByBrand([
      { cover: "a", brand_name: "@lenskart" }, { cover: "b", brand_name: "Lenskart" }, { cover: "c", brand_name: "boAt" },
      { cover: "d" }, { content_url: "https://x" }, "https://instagram.com/reel/abc",
    ]);
    expect(g.map((x) => [x.brand, x.items.length])).toEqual([["lenskart", 2], ["boAt", 1], ["Other work", 1]]);
  });

  it("page: every phone viewer gets the photo-led header; old content stays reachable", () => {
    const pv = fs.readFileSync("src/pages/creator/CreatorPublicView.jsx", "utf8");
    expect(pv).toContain("<PhotoLedHeaderMobile");
    expect(pv).toContain("const photoLed = isMobile;");
    expect(pv).toContain('"Send collab request"');
    expect(pv).toContain('const mobileTabs = ["Portfolio", "Rate Card", "Stats", "Reviews", "AI Match", "Home"]');
    expect(pv).toContain("<PortfolioCoversMobile");
    expect(pv).toContain("<ReportUserLink");
    expect(pv).toContain("<BlockUserButton");
  });
});
