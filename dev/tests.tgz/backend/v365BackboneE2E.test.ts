// v365 deep test (Ravi: "ye main backbone hai — database, calls, backend sab sahi working; blackbox + whitebox testing").
// Black-box: the REAL payment routes on a realistic in-memory Supabase (filters really applied, unknown columns refused
// with the LIVE column lists of 21 Oct 2026) and a stateful fake Razorpay. Every scenario checks exact rupees.
import { describe, it, expect, vi, beforeEach } from "vitest";
import express from "express";
import crypto from "crypto";

// ───────────────────────── fake Razorpay (stateful) ─────────────────────────
const rz = vi.hoisted(() => {
  const orders = new Map<string, any>();
  let n = 0;
  return {
    orders,
    reset() { orders.clear(); n = 0; },
    api: {
      orders: {
        create: async (o: any) => { const id = `order_T${++n}`; const row = { id, amount: o.amount, currency: o.currency, notes: o.notes || {}, status: "created", amount_paid: 0 }; orders.set(id, row); return { ...row }; },
        fetch: async (id: string) => { const o = orders.get(id); if (!o) throw new Error("not found"); return { ...o }; },
        fetchPayments: async (id: string) => ({ items: orders.get(id)?.status === "paid" ? [{ id: `pay_${id}`, status: "captured" }] : [] }),
      },
      payments: { fetch: async (id: string) => ({ id, status: "captured" }) },
    },
  };
});
vi.mock("./helpers", async (importOriginal) => {
  const orig: any = await importOriginal();
  return { ...orig, getRazorpay: () => rz.api };
});

import { setupPaymentRoutes } from "./payment_routes";
import { __resetFeeConfigCache } from "./brandFee";
import { refundBlock } from "./adminMoney";

// ───────────────────────── realistic fake Supabase ─────────────────────────
const LIVE: Record<string, string> = {
  platform_fee_config: "id,threshold_amount,below_threshold_rate,above_threshold_rate,gst_rate,created_at,updated_at,platform_gst_registered,platform_gstin,ugc_commission_pct,withdrawal_min_limit,auto_payout_threshold,offer_mode,offer_fee_pct,offer_label,offer_promo_line,offer_line_until,brand_markup_pct,creator_deduction_pct,agency_markup_pct,agency_deduction_pct,payout_freeze_all,min_campaign_budget,max_campaign_budget,withdrawal_fee_rate,dispute_refund_window_days,fee_model,creator_fee_pct,brand_fee_pct",
  coupons: "id,code,type,discount_amount,applies_to,usage_limit,used_count,per_user_limit,valid_from,valid_until,min_campaign_value,status,created_by,created_at,updated_at,override_fee_rate,applies_to_first_n_payouts,auto_apply",
  coupon_redemptions: "id,coupon_id,user_id,campaign_id,deal_id,ugc_order_id,discount_applied,redeemed_at,payouts_consumed",
  deals: "id,application_id,campaign_id,creator_id,brand_id,agreed_amount,is_barter,barter_details,deliverables,content_deadline,go_live_date,revision_count,revisions_used,posting_requirements,agreement_signed_creator,agreement_signed_brand,agreement_signed_at,status,created_at,updated_at,escrow_hold,escrow_hold_reason,escrow_hold_by_admin_id,escrow_hold_at,promised_reach,delivered_reach,delivered_reach_source,delivered_reach_updated_at,performance_score,performance_tier,on_time_submission,brand_rating",
  chat_threads: "id,deal_id,campaign_id,creator_id,brand_id,status,agreed_amount,deliverables,deadline,revision_count,agreement_signed_creator,agreement_signed_brand,agreement_signed_at,created_at,updated_at,flow_state,campaign_deal_id,ugc_order_id_text,is_ugc,ugc_order_id",
  ugc_briefs: "id,brand_id,title,product_name,product_description,budget,max_creators,claimed_count,status,detailed_requirements,sample_content_url,dos,donts,deliverable_type,video_duration,created_at,brand_name,relisted_at,relist_count,is_priority,delivery_hours,razorpay_order_id",
  transactions: "id,deal_id,creator_id,gross_amount,platform_fee_amount,creator_net_amount,gst_amount,zaakpay_order_id,status,created_at,payout_type,admin_action_by,admin_action_note,ugc_order_id,refund_amount,refund_status,refund_reason,refund_reference,refunded_at,refunded_by,correct_fee_amount,fee_correction_note,payout_status,payout_reference,expected_payout_date,payout_completed_at,payout_completed_by,campaign_deal_id,ugc_order_id_text,brief_id,brand_id,escrow_hold,updated_at,notes,payout_requested,payout_request_count,payout_request_notes,last_payout_requested_at,razorpay_payment_id,brand_fee_pct,brand_fee_amount,brand_fee_gst,brand_paid_amount,coupon_code",
};
const COLS: Record<string, Set<string>> = Object.fromEntries(Object.entries(LIVE).map(([k, v]) => [k, new Set(v.split(","))]));
const unescape = (v: string) => String(v).replace(/\\([\\%_])/g, "$1");
const likeRe = (pat: string) => new RegExp("^" + String(pat).replace(/\\([\\%_])|([.*+?^${}()|[\]\\])|(%)|(_)/g, (_m, esc, rx, pc, us) => esc ? esc.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") : rx ? "\\" + rx : pc ? ".*" : us ? "." : "") + "$", "i");

function fakeDb(seed: Record<string, any[]>) {
  const t: Record<string, any[]> = JSON.parse(JSON.stringify(seed));
  const log: { table: string; op: string; row?: any; patch?: any }[] = [];
  const badCol = (table: string, row: any) => {
    const allowed = COLS[table];
    if (!allowed) return null;
    for (const k of Object.keys(row || {})) if (!allowed.has(k)) return { message: `Could not find the '${k}' column of '${table}' in the schema cache`, code: "PGRST204" };
    return null;
  };
  const from = (table: string) => {
    if (!t[table]) t[table] = [];
    const filters: Array<(r: any) => boolean> = [];
    let op = "select"; let patch: any = null; let ins: any[] = []; let head = false; let countOn = false;
    let lim = Infinity; let order: { c: string; asc: boolean } | null = null;
    const match = () => t[table].filter((r) => filters.every((f) => f(r)));
    const q: any = {
      select: (_c?: string, o?: any) => { if (o?.head) head = true; if (o?.count) countOn = true; return q; },
      eq: (c: string, v: any) => { filters.push((r) => String(r[c]) === String(v)); return q; },
      neq: (c: string, v: any) => { filters.push((r) => String(r[c]) !== String(v)); return q; },
      gt: (c: string, v: any) => { filters.push((r) => Number(r[c]) > Number(v)); return q; },
      gte: (c: string, v: any) => { filters.push((r) => r[c] >= v); return q; },
      lte: (c: string, v: any) => { filters.push((r) => r[c] <= v); return q; },
      in: (c: string, vs: any[]) => { filters.push((r) => (vs || []).map(String).includes(String(r[c]))); return q; },
      is: (c: string, v: any) => { filters.push((r) => (v === null ? r[c] == null : r[c] === v)); return q; },
      not: () => q, filter: () => q, match: () => q,
      ilike: (c: string, v: string) => { const re = likeRe(v); filters.push((r) => re.test(String(r[c] ?? ""))); return q; },
      or: (expr: string) => {
        const parts = String(expr).split(",").map((p) => p.split("."));
        filters.push((r) => parts.some(([c, o, ...v]) => { const val = v.join("."); if (o === "eq") return String(r[c]) === val; if (o === "is") return val === "null" ? r[c] == null : String(r[c]) === val; return false; }));
        return q;
      },
      order: (c: string, o?: any) => { order = { c, asc: o?.ascending !== false }; return q; },
      limit: (n: number) => { lim = n; return q; },
      range: (a: number, b: number) => { lim = b - a + 1; return q; },
      insert: (rows: any) => { op = "insert"; ins = Array.isArray(rows) ? rows : [rows]; return q; },
      upsert: (rows: any) => { op = "upsert"; ins = Array.isArray(rows) ? rows : [rows]; return q; },
      update: (p: any) => { op = "update"; patch = p; return q; },
      delete: () => { op = "delete"; return q; },
      maybeSingle: () => run().then((r: any) => ({ ...r, data: Array.isArray(r.data) ? r.data[0] || null : r.data })),
      single: () => q.maybeSingle(),
      then: (ok: any, bad: any) => run().then(ok, bad),
    };
    const run = async () => {
      if (op === "insert" || op === "upsert") {
        for (const r of ins) { const e = badCol(table, r); if (e) return { data: null, error: e }; }
        const out = ins.map((r) => ({ id: r.id ?? crypto.randomUUID(), ...r }));
        t[table].push(...out); out.forEach((row) => log.push({ table, op, row }));
        return { data: out, error: null };
      }
      if (op === "update") {
        const e = badCol(table, patch); if (e) return { data: null, error: e };
        const rows = match(); rows.forEach((r) => Object.assign(r, patch)); log.push({ table, op, patch });
        return { data: rows, error: null };
      }
      if (op === "delete") { const rows = match(); t[table] = t[table].filter((r) => !rows.includes(r)); return { data: rows, error: null }; }
      let rows = match();
      if (order) { const { c, asc } = order; rows = [...rows].sort((a, b) => (a[c] > b[c] ? 1 : a[c] < b[c] ? -1 : 0) * (asc ? 1 : -1)); }
      const count = rows.length;
      rows = rows.slice(0, lim);
      return { data: head ? null : rows, error: null, count: countOn ? count : null };
    };
    return q;
  };
  return { t, log, client: { from, rpc: async () => ({ data: null, error: null }), storage: { from: () => ({}) } } };
}

// ───────────────────────── app + helpers ─────────────────────────
const SECRET = "test_secret_v365";
function app(db: any, user: any) {
  const a = express(); a.use(express.json());
  const router = express.Router();
  setupPaymentRoutes(a, router, {
    supabase: db.client, privilegedSupabase: db.client, getDb: () => ({ transactions: [], chat_threads: [], deals: [] }), saveDb: () => {},
    parseAuthUser: async () => user, logAdminAction: async () => ({}), sendNotification: async () => ({}), fetchUserScopedTransactions: async () => [],
    serializeChatMessage: (m: any) => m, insertChatMessageToSupabase: async () => ({}), parseThreadState: () => ({}), getIsTestMode: () => false,
  } as any);
  a.use("/api", router);
  return a;
}
async function call(a: any, method: string, path: string, body?: any) {
  const srv = a.listen(0); const port = srv.address().port;
  try {
    const r = await fetch(`http://127.0.0.1:${port}/api${path}`, { method, headers: { "content-type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
    let j: any = null; try { j = await r.json(); } catch { j = null; }
    return { status: r.status, body: j };
  } finally { srv.close(); }
}
const sign = (o: string, p: string) => crypto.createHmac("sha256", SECRET).update(`${o}|${p}`).digest("hex");
const pay = (orderId: string, rupees?: number) => { const o = rz.orders.get(orderId)!; o.status = "paid"; o.amount_paid = rupees != null ? Math.round(rupees * 100) : o.amount; };

const DEAL = "11111111-1111-4111-8111-111111111111";
const SPLIT = { id: 1, fee_model: "split", creator_fee_pct: 0, brand_fee_pct: 8, threshold_amount: 20000, below_threshold_rate: 10, above_threshold_rate: 5, gst_rate: 18, platform_gst_registered: false, offer_mode: false, updated_at: "2026-10-21T00:00:00Z" };
const brand = { user_id: "b1", role: "brand", name: "Brand" };
const seed = (cfg: any = SPLIT, amount = 10000, extra: Record<string, any[]> = {}) => ({
  platform_fee_config: [cfg],
  coupons: [], coupon_redemptions: [], transactions: [],
  deals: [{ id: DEAL, agreed_amount: amount, creator_id: "c1", brand_id: "b1", status: "accepted" }],
  chat_threads: [{ id: `thread_camp_${DEAL}`, deal_id: DEAL, creator_id: "c1", brand_id: "b1", agreement_signed_creator: true, agreement_signed_brand: true }],
  ugc_orders: [], users: [{ user_id: "b1", role: "brand", email: "b@x.in" }, { user_id: "c1", role: "creator", email: "c@x.in" }],
  ...extra,
});
const coupon = (over: any = {}) => ({ id: "cp1", code: "DIWALI4", applies_to: "brand_fee", type: "fee_rate_override", override_fee_rate: 4, discount_amount: 0, status: "active", usage_limit: 0, used_count: 0, per_user_limit: 0, min_campaign_value: 0, valid_from: null, valid_until: null, ...over });

async function fullPayment(db: any, body: any = {}, paidRupees?: number) {
  const a = app(db, brand);
  const order = await call(a, "POST", "/payments/razorpay/create-order", { deal_id: DEAL, gross_amount: 1, ...body });
  if (order.status !== 200) return { order };
  pay(order.body.order_id, paidRupees);
  const pid = `pay_${order.body.order_id}`;
  const verify = await call(a, "POST", "/payments/razorpay/verify", { razorpay_order_id: order.body.order_id, razorpay_payment_id: pid, razorpay_signature: sign(order.body.order_id, pid), deal_id: DEAL });
  return { order, verify, a, pid };
}
const tx = (db: any) => db.t.transactions.filter((r: any) => r.payout_type !== "refund");

describe("v365 · split fee end to end (campaign deal)", () => {
  beforeEach(() => { rz.reset(); __resetFeeConfigCache(); process.env.RAZORPAY_KEY_SECRET = SECRET; process.env.RAZORPAY_KEY_ID = "rzp_test_x"; });

  it("quote: ₹10,000 deal → brand ₹10,800, creator ₹10,000 (amount read from the deal, not the browser)", async () => {
    const db = fakeDb(seed());
    const r = await call(app(db, brand), "POST", "/payments/quote", { deal_id: DEAL, gross_amount: 1 });
    expect(r.status).toBe(200);
    expect(r.body.quote).toMatchObject({ feeModel: "split", gross: 10000, creatorFee: 0, creatorNet: 10000, brandFeePercent: 8, brandFee: 800, brandFeeGst: 0, total: 10800 });
  });

  it("create-order 1,080,000 paise → pay → verify → transaction stamped exactly", async () => {
    const db = fakeDb(seed());
    const { order, verify } = await fullPayment(db);
    expect(order.body.amount).toBe(1080000);
    expect(rz.orders.get(order.body.order_id)!.notes).toMatchObject({ deal_id: DEAL, brand_total: "10800", gross: "10000", brand_fee: "800", coupon_code: "" });
    expect(verify!.status).toBe(200);
    const rows = tx(db);
    expect(rows).toHaveLength(1);
    expect(rows[0]).toMatchObject({ gross_amount: 10000, platform_fee_amount: 0, creator_net_amount: 10000, gst_amount: 0, brand_fee_pct: 8, brand_fee_amount: 800, brand_fee_gst: 0, brand_paid_amount: 10800, coupon_code: null, deal_id: DEAL });
  });

  it("verify + webhook-style second persist: one transaction only (idempotent)", async () => {
    const db = fakeDb(seed({ ...SPLIT }, 10000));
    db.t.coupons = [coupon()];
    const { order, a, pid } = await fullPayment(db, { coupon_code: "diwali4" });
    const again = await call(a!, "POST", "/payments/razorpay/verify", { razorpay_order_id: order.body.order_id, razorpay_payment_id: pid, razorpay_signature: sign(order.body.order_id, pid!), deal_id: DEAL });
    expect(again.status).toBe(200);
    expect(tx(db)).toHaveLength(1);
    expect(db.t.coupon_redemptions).toHaveLength(1);
    expect(db.t.coupons[0].used_count).toBe(1);
  });

  it("coupon 4% → ₹10,400; flat ₹300 → ₹10,500; zero_fee → ₹10,000 — stamped with the coupon", async () => {
    for (const [c, total, fee] of [[coupon(), 10400, 400], [coupon({ type: "flat_discount", discount_amount: 300, override_fee_rate: null }), 10500, 500], [coupon({ type: "zero_fee" }), 10000, 0]] as const) {
      rz.reset(); __resetFeeConfigCache();
      const db = fakeDb(seed()); db.t.coupons = [c as any];
      const { order, verify } = await fullPayment(db, { coupon_code: "DIWALI4" });
      expect(order.body.amount).toBe(total * 100);
      expect(verify!.status).toBe(200);
      expect(tx(db)[0]).toMatchObject({ gross_amount: 10000, creator_net_amount: 10000, brand_fee_amount: fee, brand_paid_amount: total, coupon_code: "DIWALI4" });
      expect(db.t.coupon_redemptions[0]).toMatchObject({ coupon_id: "cp1", user_id: "b1", deal_id: DEAL, discount_applied: 800 - fee });
    }
  });

  it("bad coupons → COUPON_INVALID, no Razorpay order, nothing consumed", async () => {
    const bad = [
      coupon({ status: "paused" }), coupon({ valid_until: "2020-01-01T00:00:00Z" }), coupon({ valid_from: "2099-01-01T00:00:00Z" }),
      coupon({ usage_limit: 2, used_count: 2 }), coupon({ min_campaign_value: 50000 }), coupon({ applies_to: "creator" }),
    ];
    for (const c of bad) {
      rz.reset(); __resetFeeConfigCache();
      const db = fakeDb(seed()); db.t.coupons = [c];
      const r = await call(app(db, brand), "POST", "/payments/razorpay/create-order", { deal_id: DEAL, coupon_code: "DIWALI4" });
      expect(r.status).toBe(400);
      expect(r.body.code).toBe("COUPON_INVALID");
      expect(rz.orders.size).toBe(0);
      expect(db.t.coupons[0].used_count).toBe(c.used_count);
    }
    // per-brand limit: this brand already used it once
    const db = fakeDb(seed()); db.t.coupons = [coupon({ per_user_limit: 1 })]; db.t.coupon_redemptions = [{ id: "r0", coupon_id: "cp1", user_id: "b1" }];
    const r = await call(app(db, brand), "POST", "/payments/razorpay/create-order", { deal_id: DEAL, coupon_code: "DIWALI4" });
    expect(r.body.code).toBe("COUPON_INVALID");
    // a team member of the same brand counts as the brand
    const r2 = await call(app(db, { user_id: "tm1", role: "brand", parent_brand_id: "b1", team_role: "member" }), "POST", "/payments/quote", { deal_id: DEAL, coupon_code: "DIWALI4" });
    expect(r2.body.quote.couponError).toMatch(/already used/);
  });

  it("an underscore in a code is not a wildcard (DIWALI_4 ≠ DIWALIX4)", async () => {
    const db = fakeDb(seed()); db.t.coupons = [coupon({ code: "DIWALIX4" })];
    const r = await call(app(db, brand), "POST", "/payments/quote", { deal_id: DEAL, coupon_code: "DIWALI_4" });
    expect(r.body.quote.couponError).toMatch(/doesn't exist/);
    expect(r.body.quote.total).toBe(10800);
  });

  it("an unpaid / abandoned order never consumes the coupon", async () => {
    const db = fakeDb(seed()); db.t.coupons = [coupon()];
    const r = await call(app(db, brand), "POST", "/payments/razorpay/create-order", { deal_id: DEAL, coupon_code: "DIWALI4" });
    expect(r.status).toBe(200);
    expect(db.t.coupon_redemptions).toHaveLength(0);
    expect(db.t.coupons[0].used_count).toBe(0);
  });

  it("underpayment (₹10,000 for a ₹10,800 order) is NOT recorded", async () => {
    const db = fakeDb(seed());
    const { verify } = await fullPayment(db, {}, 10000);
    expect(verify!.status).toBeGreaterThanOrEqual(400);
    expect(tx(db)).toHaveLength(0);
  });

  it("an order made before v364 (no notes) paying the deal amount is still recorded at the old amount", async () => {
    const db = fakeDb(seed());
    rz.orders.set("order_OLD1", { id: "order_OLD1", amount: 1000000, currency: "INR", notes: { deal_id: DEAL, kind: "campaign_escrow" }, status: "paid", amount_paid: 1000000 });
    const r = await call(app(db, brand), "POST", "/payments/razorpay/verify", { razorpay_order_id: "order_OLD1", razorpay_payment_id: "pay_OLD1", razorpay_signature: sign("order_OLD1", "pay_OLD1"), deal_id: DEAL });
    expect(r.status).toBe(200);
    expect(tx(db)[0]).toMatchObject({ gross_amount: 10000, creator_net_amount: 10000 });
    expect(tx(db)[0].brand_paid_amount).toBeUndefined();
  });

  it("legacy fee model is exactly as before: ₹10,000 → 10% from the creator, brand pays ₹10,000; ₹25,000 → 5%", async () => {
    const LEG = { ...SPLIT, fee_model: "legacy" };
    let db = fakeDb(seed(LEG));
    let { order } = await fullPayment(db);
    expect(order.body.amount).toBe(1000000);
    expect(tx(db)[0]).toMatchObject({ gross_amount: 10000, platform_fee_amount: 1000, creator_net_amount: 9000 });
    rz.reset(); __resetFeeConfigCache();
    db = fakeDb(seed(LEG, 25000));
    ({ order } = await fullPayment(db));
    expect(order.body.amount).toBe(2500000);
    expect(tx(db)[0]).toMatchObject({ gross_amount: 25000, platform_fee_amount: 1250, creator_net_amount: 23750 });
  });

  it("GST registered: 18% GST on the brand fee only (creator fee 0 → no creator GST)", async () => {
    const db = fakeDb(seed({ ...SPLIT, platform_gst_registered: true }));
    const { order } = await fullPayment(db);
    expect(order.body.amount).toBe(1094400);
    expect(tx(db)[0]).toMatchObject({ gst_amount: 0, creator_net_amount: 10000, brand_fee_amount: 800, brand_fee_gst: 144, brand_paid_amount: 10944 });
  });

  it("a pending order is reused only for the same total + coupon; a different coupon gets a new order", async () => {
    const db = fakeDb(seed()); db.t.coupons = [coupon()];
    const a = app(db, brand);
    const first = await call(a, "POST", "/payments/razorpay/create-order", { deal_id: DEAL });
    const same = await call(a, "POST", "/payments/razorpay/create-order", { deal_id: DEAL });
    expect(same.body.order_id).toBe(first.body.order_id);
    const withCoupon = await call(a, "POST", "/payments/razorpay/create-order", { deal_id: DEAL, coupon_code: "DIWALI4" });
    expect(withCoupon.body.order_id).not.toBe(first.body.order_id);
    expect(withCoupon.body.amount).toBe(1040000);
  });

  it("unsigned contract → no order (unchanged rule)", async () => {
    const db = fakeDb(seed()); db.t.chat_threads[0].agreement_signed_brand = false;
    const r = await call(app(db, brand), "POST", "/payments/razorpay/create-order", { deal_id: DEAL });
    expect(r.body.code).toBe("CONTRACT_NOT_SIGNED");
    expect(rz.orders.size).toBe(0);
  });
});

describe("v365 · refunds never exceed what the brand paid", () => {
  const base = { id: "t1", status: "SUCCESS", payout_status: "PENDING", gross_amount: 10000, creator_net_amount: 10000, platform_fee_amount: 0, deal_id: DEAL };
  it("split payment: up to brand_paid_amount (₹10,800), not more", () => {
    const t = { ...base, brand_paid_amount: 10800, brand_fee_amount: 800 };
    expect(refundBlock(t, 10800, "PROCESSED")).toBeNull();
    expect(refundBlock(t, 10000, "PROCESSED")).toBeNull();
    expect(refundBlock(t, 800, "PENDING")).toBeNull();
    expect(refundBlock(t, 10801, "PROCESSED")?.code).toBe("REFUND_TOO_HIGH");
  });
  it("older payments: the deal amount stays the cap", () => {
    expect(refundBlock(base, 10000, "PROCESSED")).toBeNull();
    expect(refundBlock(base, 10001, "PROCESSED")?.code).toBe("REFUND_TOO_HIGH");
  });
  it("route: ₹10,800 refund with a reason recorded on a split payment; ₹11,000 refused", async () => {
    const db = fakeDb(seed());
    db.t.transactions = [{ ...base, id: "22222222-2222-4222-8222-222222222222", zaakpay_order_id: "order_X", brand_paid_amount: 10800, brand_fee_amount: 800, brand_fee_pct: 8, brand_id: "b1", creator_id: "c1" }];
    const admin = { user_id: "adm", role: "admin" };
    const tooHigh = await call(app(db, admin), "POST", "/admin/transactions/22222222-2222-4222-8222-222222222222/refund", { refund_amount: 11000, refund_reason: "Brand cancelled", refund_status: "PENDING" });
    expect(tooHigh.status).toBe(400);
    const ok = await call(app(db, admin), "POST", "/admin/transactions/22222222-2222-4222-8222-222222222222/refund", { refund_amount: 10800, refund_reason: "Brand cancelled before work started", refund_status: "PENDING" });
    expect(ok.status).toBe(200);
    expect(db.t.transactions[0]).toMatchObject({ refund_amount: 10800, refund_reason: "Brand cancelled before work started", refund_status: "PENDING" });
  });
});

// ───────────────────────── UGC brief: escrow + brand fee charged once ─────────────────────────
import { setupUgcBrowseRoutes } from "./ugc_routes";
describe("v365 · UGC brief with the split fee", () => {
  beforeEach(() => { rz.reset(); __resetFeeConfigCache(); process.env.RAZORPAY_KEY_SECRET = SECRET; process.env.RAZORPAY_KEY_ID = "rzp_test_x"; process.env.PAYMENTS_TEST_MODE = "false"; });
  const ugcApp = (db: any, user: any) => {
    const a = express(); a.use(express.json());
    const router = express.Router();
    setupPaymentRoutes(a, router, {
      supabase: db.client, privilegedSupabase: db.client, getDb: () => ({ transactions: [], chat_threads: [], deals: [] }), saveDb: () => {},
      parseAuthUser: async () => user, logAdminAction: async () => ({}), sendNotification: async () => ({}), fetchUserScopedTransactions: async () => [],
      serializeChatMessage: (m: any) => m, insertChatMessageToSupabase: async () => ({}), parseThreadState: () => ({}), getIsTestMode: () => false,
    } as any);
    const local: any = { ugc_briefs: [], transactions: [], ugc_orders: [] };
    setupUgcBrowseRoutes(a, router, { supabase: db.client, privilegedSupabase: db.client, getDb: () => local, saveDb: () => {}, parseAuthUser: async () => user, ensureUGCChatThread: async () => ({}), enrichBriefsWithBrandProfiles: async (b: any[]) => b } as any);
    a.use("/api", router);
    return a;
  };
  it("₹2,000 × 3 creators = ₹6,000 escrow → brand pays ₹6,480 (₹6,240 with a 4% coupon); deposit stamped; coupon counted once", async () => {
    for (const [code, total, fee] of [["", 6480, 480], ["DIWALI4", 6240, 240]] as const) {
      rz.reset(); __resetFeeConfigCache();
      const db = fakeDb(seed()); db.t.coupons = [coupon()]; db.t.ugc_briefs = [];
      const a = ugcApp(db, brand);
      const q = await call(a, "POST", "/payments/quote", { gross_amount: 6000, coupon_code: code || undefined });
      expect(q.body.quote.total).toBe(total);
      const order = await call(a, "POST", "/payments/razorpay/create-order", { gross_amount: 6000, ...(code ? { coupon_code: code } : {}) });
      expect(order.body.amount).toBe(total * 100);
      pay(order.body.order_id);
      const brief = await call(a, "POST", "/ugc/briefs", { title: "T", product_name: "P", budget: 2000, max_creators: 3, razorpay_order_id: order.body.order_id, deliverable_type: "ugc_video" });
      expect(brief.status).toBe(200);
      const dep = db.t.transactions.find((r: any) => r.brief_id);
      expect(dep).toMatchObject({ gross_amount: 6000, platform_fee_amount: 0, creator_net_amount: 6000, brand_fee_amount: fee, brand_paid_amount: total, coupon_code: code || null });
      expect(db.t.coupon_redemptions).toHaveLength(code ? 1 : 0);
      // the same paid order can't fund a second brief, and doesn't count the coupon again
      const again = await call(a, "POST", "/ugc/briefs", { title: "T2", product_name: "P", budget: 2000, max_creators: 3, razorpay_order_id: order.body.order_id });
      expect([200, 409]).toContain(again.status);
      expect(db.t.transactions.filter((r: any) => r.brief_id)).toHaveLength(1);
      expect(db.t.coupon_redemptions).toHaveLength(code ? 1 : 0);
    }
  });
  it("paying only the escrow (₹6,000) for a ₹6,480 order → no brief", async () => {
    const db = fakeDb(seed()); db.t.ugc_briefs = [];
    const a = ugcApp(db, brand);
    const order = await call(a, "POST", "/payments/razorpay/create-order", { gross_amount: 6000 });
    pay(order.body.order_id, 6000);
    const brief = await call(a, "POST", "/ugc/briefs", { title: "T", product_name: "P", budget: 2000, max_creators: 3, razorpay_order_id: order.body.order_id });
    expect(brief.status).toBe(402);
    expect(brief.body.code).toBe("PAYMENT_TOO_LOW");
    expect(db.t.transactions.filter((r: any) => r.brief_id)).toHaveLength(0);
  });
});

describe("v365 · service-fee refund (brand's 8%) never cuts the creator's pay", () => {
  beforeEach(() => { rz.reset(); __resetFeeConfigCache(); process.env.RAZORPAY_KEY_SECRET = SECRET; });
  it("refund ₹800 from the fee → processed, creator still paid ₹10,000; more than the fee as 'fee' is refused", async () => {
    const db = fakeDb(seed());
    await fullPayment(db);
    const t = tx(db)[0];
    const admin = { user_id: "adm", role: "admin" };
    const tooMuch = await call(app(db, admin), "POST", `/admin/transactions/${t.id}/refund`, { refund_amount: 900, refund_reason: "fee", refund_from: "fee", refund_status: "PENDING" });
    expect(tooMuch.status).toBe(400);
    const r = await call(app(db, admin), "POST", `/admin/transactions/${t.id}/refund`, { refund_amount: 800, refund_reason: "Diwali goodwill", refund_from: "fee", refund_status: "PROCESSED", refund_reference: "UTR1" });
    expect(r.status).toBe(200);
    expect(tx(db)[0]).toMatchObject({ refund_amount: 800, refund_status: "PROCESSED", status: "SUCCESS" });
    expect(String(tx(db)[0].fee_correction_note)).toMatch(/^\[service-fee refund\]/);
    const { netAfterPartialRefund, payoutReleaseBlock } = await import("./adminMoney");
    expect(netAfterPartialRefund(tx(db)[0], 10000)).toBe(10000);
    expect(payoutReleaseBlock(tx(db)[0])).toBeNull();
  });
  it("a deal refund of ₹2,000 (processed) still comes off the creator's pay, as before", async () => {
    const { netAfterPartialRefund } = await import("./adminMoney");
    expect(netAfterPartialRefund({ refund_status: "PROCESSED", refund_amount: 2000, gross_amount: 10000 }, 10000)).toBe(8000);
  });
});

// ───────────────────────── Admin: fee boxes + brand-fee coupons ─────────────────────────
import { setupAdminVersionsCouponsRoutes } from "./admin_versions_coupons_routes";
import { setupAdminCampaignsSettingsRoutes } from "./admin_campaigns_settings_routes";
describe("v365 · Admin fee config + coupons against the live constraints", () => {
  const adminApp = (db: any, user: any, local: any = {}) => {
    const a = express(); a.use(express.json());
    const router = express.Router();
    const deps: any = { supabase: db.client, privilegedSupabase: db.client, getDb: () => local, saveDb: () => {}, parseAuthUser: async () => user, logAdminAction: async () => ({}), sendNotification: async () => ({}), getSettings: () => ({}), getFullFeeAndReferralConfig: async () => db.t.platform_fee_config[0] };
    setupAdminVersionsCouponsRoutes(a, router, deps);
    setupAdminCampaignsSettingsRoutes(a, router, deps);
    a.use("/api", router);
    return a;
  };
  // the live CHECK on coupons.applies_to (after migration v365_coupons_applies_to_brand_fee)
  const withCheck = (db: any) => {
    const orig = db.client.from;
    db.client.from = (table: string) => {
      const q = orig(table);
      if (table !== "coupons") return q;
      const ins = q.insert;
      q.insert = (rows: any) => { const r = Array.isArray(rows) ? rows[0] : rows; if (!["brand", "creator", "brand_fee", "all"].includes(String(r.applies_to))) { const bad: any = { select: () => bad, single: async () => ({ data: null, error: { message: 'violates check constraint "coupons_applies_to_check"' } }), then: (ok: any) => ok({ data: null, error: { message: "check" } }) }; return bad; } return ins(rows); };
      return q;
    };
    return db;
  };
  it("creates a brand-fee coupon (new % / limits / dates) that the brand checkout can then use", async () => {
    const db = withCheck(fakeDb(seed()));
    const admin = { user_id: "adm", role: "admin" };
    const r = await call(adminApp(db, admin, { coupons: [] }), "POST", "/admin/coupons", { code: "diwali4", applies_to: "brand_fee", type: "fee_rate_override", override_fee_rate: 4, usage_limit: 0, per_user_limit: 3, valid_until: "2099-11-08", status: "active" });
    expect(r.status).toBe(201);
    expect(db.t.coupons[0]).toMatchObject({ code: "DIWALI4", applies_to: "brand_fee", type: "fee_rate_override", override_fee_rate: 4 });
    __resetFeeConfigCache();
    const q = await call(app(db, brand), "POST", "/payments/quote", { deal_id: DEAL, coupon_code: "DIWALI4" });
    expect(q.body.quote).toMatchObject({ couponCode: "DIWALI4", brandFeePercent: 4, total: 10400 });
  });
  it("a coupon the database refuses is reported, not kept half-saved", async () => {
    const db = withCheck(fakeDb(seed()));
    const r = await call(adminApp(db, { user_id: "adm", role: "admin" }, { coupons: [] }), "POST", "/admin/coupons", { code: "BADONE", applies_to: "brands_typo", type: "zero_fee" });
    expect(r.status).toBe(502);
    expect(db.t.coupons).toHaveLength(0);
  });
  it("fee boxes: creator 0 / brand 8 saved, clamped to 0–30, non-admin refused", async () => {
    const db = fakeDb(seed({ ...SPLIT, fee_model: "legacy", brand_fee_pct: null, creator_fee_pct: null }));
    const no = await call(adminApp(db, brand, {}), "PUT", "/admin/fee-config", { brand_fee_pct: 50 });
    expect(no.status).toBe(403);
    const ok = await call(adminApp(db, { user_id: "adm", role: "admin" }, {}), "PUT", "/admin/fee-config", { fee_model: "split", creator_fee_pct: 0, brand_fee_pct: 8 });
    expect(ok.status).toBe(200);
    expect(db.t.platform_fee_config.at(-1)).toMatchObject({ fee_model: "split", creator_fee_pct: 0, brand_fee_pct: 8 });
    // v396 (QA M-5): out-of-range values are refused (they used to be clamped silently: 55 → 30, -3 → 0) and nothing changes
    const clamp = await call(adminApp(db, { user_id: "adm", role: "admin" }, {}), "PUT", "/admin/fee-config", { brand_fee_pct: 55, creator_fee_pct: -3 });
    expect(clamp.status).toBe(400);
    expect(db.t.platform_fee_config.at(-1)).toMatchObject({ brand_fee_pct: 8, creator_fee_pct: 0 });
    const empty = await call(adminApp(db, { user_id: "adm", role: "admin" }, {}), "PUT", "/admin/fee-config", { below_threshold_rate: "" });
    expect(empty.status).toBe(400);
  });
});
