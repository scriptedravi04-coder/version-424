// v366 (Ravi: "baaki jo pending hai unhe bhi work karo"): full Instagram disconnect, website from Instagram for brand
// step 1, hub refresh wiring, desktop portfolio covers.
import { describe, it, expect, beforeEach } from "vitest";
import fs from "fs";
import express from "express";
import { setupInstagramRoutes, fetchByUsername, cleanWebsite, previewFields, IG_DISCONNECT_PATCH } from "./instagramConnect";
import { CREATOR_PROFILE_COLUMNS } from "./creatorApplication";

const read = (p: string) => fs.readFileSync(p, "utf8");

async function call(app: any, method: string, path: string, body?: any) {
  const server = app.listen(0); const port = server.address().port;
  try {
    const r = await fetch(`http://127.0.0.1:${port}/api${path}`, { method, headers: { "content-type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
    return { status: r.status, data: await r.json() };
  } finally { server.close(); }
}

describe("v366 · Disconnect Instagram clears the whole link", () => {
  beforeEach(() => { process.env.IG_GRAPH_TOKEN = "t"; process.env.IG_BUSINESS_ID = "1"; });
  it("username, fetched numbers, sync, verification and the login row go; other fields stay", async () => {
    const tables: any = {
      creator_profiles: [{ user_id: "u1", name: "Ravi", bio: "Travel", city: "Jaipur", instagram_handle: "elite_ravi", instagram: "elite_ravi", instagram_stats: { username: "elite_ravi" }, instagram_synced_at: "2026-10-20T00:00:00Z", instagram_verified_at: "2026-10-20T00:00:00Z", instagram_verify_method: "dm", ig_followers: 10376, followers_instagram: 10376, follower_count: 10376, avg_views_30d: 19379, avg_likes_30d: 1160, avg_comments_30d: 3, engagement_rate: 11.21, rate_reel: 5000 }],
      instagram_connections: [{ user_id: "u1", username: "elite_ravi" }],
    };
    const q = (name: string) => {
      let patch: any = null; let del = false;
      const api: any = {
        select: () => api, limit: () => api, not: () => api, neq: () => api, order: () => api,
        update: (p: any) => { patch = p; return api; },
        delete: () => { del = true; return api; },
        eq: (c: string, v: any) => {
          const hit = (tables[name] || []).filter((r: any) => String(r[c]) === String(v));
          if (del) { tables[name] = (tables[name] || []).filter((r: any) => !hit.includes(r)); return Promise.resolve({ error: null }); }
          if (patch) { hit.forEach((r: any) => Object.assign(r, patch)); return Promise.resolve({ error: null }); }
          return api;
        },
        maybeSingle: async () => ({ data: null, error: null }),
        then: (ok: any) => ok({ data: [], error: null }),
      };
      return api;
    };
    const db = { from: q, storage: { from: () => ({}) } };
    const app = express(); app.use(express.json());
    const router = express.Router();
    setupInstagramRoutes(router, { supabase: db, privilegedSupabase: db, getDb: () => ({}), parseAuthUser: async () => ({ user_id: "u1", role: "creator" }) } as any);
    app.use("/api", router);
    const r = await call(app, "POST", "/creator/instagram/disconnect", {});
    expect(r.status).toBe(200);
    const p = tables.creator_profiles[0];
    for (const k of Object.keys(IG_DISCONNECT_PATCH)) expect(p[k]).toBeNull();
    expect(p).toMatchObject({ name: "Ravi", bio: "Travel", city: "Jaipur", rate_reel: 5000 });
    expect(tables.instagram_connections).toHaveLength(0);
  });
  it("every cleared field is a real creator_profiles column", () => {
    const extraLive = ["instagram_verified_at", "instagram_verify_method"]; // live columns not in the approval write list
    for (const k of Object.keys(IG_DISCONNECT_PATCH)) expect([...CREATOR_PROFILE_COLUMNS, ...extraLive]).toContain(k);
  });
});

describe("v366 · website from Instagram (brand step 1)", () => {
  beforeEach(() => { process.env.IG_GRAPH_TOKEN = "t"; process.env.IG_BUSINESS_ID = "1"; });
  it("cleanWebsite: https kept, bare domain gets https, junk → null", () => {
    expect(cleanWebsite("https://lenskart.com/")).toBe("https://lenskart.com/");
    expect(cleanWebsite("lenskart.com")).toBe("https://lenskart.com/");
    expect(cleanWebsite("javascript:alert(1)")).toBeNull();
    expect(cleanWebsite("hello world")).toBeNull();
    expect(cleanWebsite("")).toBeNull();
  });
  it("asks for website; returned in stats and preview", async () => {
    const asked: string[] = [];
    const fake: any = async (url: string) => { asked.push(decodeURIComponent(url)); return { ok: true, json: async () => ({ business_discovery: { username: "lenskart", followers_count: 9, website: "lenskart.com", media: { data: [] } } }) }; };
    const s: any = await fetchByUsername("lenskart", fake);
    expect(asked[0]).toContain("website");
    expect(s.website).toBe("https://lenskart.com/");
    expect(previewFields(s).website).toBe("https://lenskart.com/");
  });
  it("Meta refuses only 'website' → asks again WITH the media fields, without website", async () => {
    const asked: string[] = [];
    const fake: any = async (url: string) => {
      asked.push(decodeURIComponent(url));
      if (asked.length === 1) return { ok: false, status: 400, json: async () => ({ error: { code: 100, message: "nonexisting field (website)" } }) };
      return { ok: true, json: async () => ({ business_discovery: { username: "a", followers_count: 5, media: { data: [] } } }) };
    };
    const s: any = await fetchByUsername("a", fake);
    expect(asked).toHaveLength(2);
    expect(asked[1]).not.toContain("website");
    expect(asked[1]).toContain("permalink");
    expect(s.followers).toBe(5);
    expect(s.website).toBeNull();
  });
});

describe("v366 · wiring", () => {
  it("hub refreshes after connect / refresh / disconnect", () => {
    const hub = read("src/pages/creator/CreatorMobileProfile.jsx");
    expect(hub).toContain("onInstagramChanged={reloadInstagramOnHub}");
    const ps = read("src/pages/creator/profileScreens/PlatformsScreen.jsx");
    expect(ps).toContain("onUpdated={() => onInstagramChanged?.()}");
    expect(ps).toContain("onInstagramChanged?.(); }");
  });
  it("brand step 1 fills + edits the website and publishes it", () => {
    const b = read("src/pages/onboarding/BrandOnboardingMobile.jsx");
    expect(b).toContain('data-testid="brand-ig-website"');
    expect(b).toContain("if (n.website && !String(prev.website");
    expect(b).toContain("website: String(formData.website).trim()");
  });
  it("desktop portfolio uses the same model (covers, brand groups) and keeps edit / delete by position", () => {
    const d = read("src/pages/creator/settingsDesktop/PortfolioList.jsx");
    expect(d).toContain("groupByBrand(parsed)");
    expect(d).toContain("handleOpenEditPortfolioModal(idx)");
    expect(d).toContain("handleDeletePortfolioItem(idx)");
    expect(d).toContain("<Cover src={item.cover}");
  });
});
