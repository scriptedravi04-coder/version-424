import { describe, it, expect, beforeEach } from "vitest";
import fs from "node:fs";
import { signupFollowerBlock, setSignupFollowerLookup, waitlistApprovedFor, setupFollowerGate } from "./followerGate";
import { _resetMinFollowersCache } from "./followerMin";
import { configureEphemeralStore, _resetEphemeral } from "./ephemeralStore";

// v402 (Ravi 4 Nov): Instagram username first; under the minimum → no account (server checks again on every new creator
// account: auth/quick-join, auth/phone/verify, auth/quick-profile). Unknown numbers are let through.
const read = (p: string) => fs.readFileSync(new URL(p, import.meta.url), "utf8");
const client = (waitlist: any[] = []) => ({
  from: (t: string) => {
    const f: Array<(r: any) => boolean> = [];
    const q: any = {
      select: () => q, limit: () => q,
      ilike: (c: string, v: string) => { f.push((r) => String(r[c] || "").toLowerCase() === String(v).replace(/\\/g, "").toLowerCase()); return q; },
      then: (ok: any) => Promise.resolve({ data: t === "waitlist" ? waitlist.filter((r) => f.every((x) => x(r))) : [], error: null }).then(ok),
    };
    return q;
  },
});

describe("v402 sign-up follower check", () => {
  beforeEach(() => { configureEphemeralStore(null); _resetEphemeral(); _resetMinFollowersCache(); setSignupFollowerLookup(null); });

  it("blocks a new account under 500, lets 500+ and unknown through", async () => {
    setSignupFollowerLookup(async (u) => ({ low_one: 120, big_one: 1200, zero_one: 0 } as any)[u] ?? null);
    const low = await signupFollowerBlock(client(), { instagram: "@Low_One", email: "a@b.com" });
    expect(low?.status).toBe(403);
    expect(low?.body.code).toBe("LOW_FOLLOWERS");
    expect(low?.body.followers).toBe(120);
    expect(await signupFollowerBlock(client(), { instagram: "zero_one" })).not.toBeNull(); // a real 0 from Instagram counts
    expect(await signupFollowerBlock(client(), { instagram: "big_one" })).toBeNull();
    expect(await signupFollowerBlock(client(), { instagram: "unknown_one" })).toBeNull();
  });

  it("no lookup (fetch switched off) or Meta too slow → let through", async () => {
    expect(await signupFollowerBlock(client(), { instagram: "low_one" })).toBeNull();
    setSignupFollowerLookup(() => new Promise((ok) => setTimeout(() => ok(10), 200)));
    expect(await signupFollowerBlock(client(), { instagram: "slow", timeoutMs: 20 })).toBeNull();
  });

  it("an approved waitlist row (by email or handle) may join whatever the followers", async () => {
    setSignupFollowerLookup(async () => 50);
    const wl = [{ email: "ok@x.com", social_handle: "@approved_h", status: "Approved" }, { email: "p@x.com", social_handle: "pend", status: "Pending" }];
    expect(await waitlistApprovedFor(client(wl), "OK@x.com", "")).toBe(true);
    expect(await signupFollowerBlock(client(wl), { instagram: "approved_h", email: "z@z.com" })).toBeNull();
    expect(await signupFollowerBlock(client(wl), { instagram: "pend", email: "p@x.com" })).not.toBeNull();
  });

  it("every new-creator route checks before the account is made; public work-link route exists", () => {
    const auth = read("./auth_routes.ts");
    expect((auth.match(/signupFollowerBlock\(/g) || []).length).toBe(3);
    const qj = auth.slice(auth.indexOf('router.post("/auth/quick-join"'));
    expect(qj.indexOf("signupFollowerBlock")).toBeLessThan(qj.indexOf("const newUser"));
    expect(read("./instagramConnect.ts")).toMatch(/setSignupFollowerLookup\(lookupConfigured\(\)/);
    const routes: string[] = [];
    setupFollowerGate({ get: (p: string) => routes.push("GET " + p), post: (p: string) => routes.push("POST " + p) } as any, { supabase: null, privilegedSupabase: null, parseAuthUser: async () => null });
    expect(routes).toContain("POST /public/follower-gate/work");
  });

  it("photo nudge: admin route, bell + push only", () => {
    expect(read("./admin_waitlist_routes.ts")).toMatch(/router\.post\("\/admin\/waitlist\/photo-nudge"/);
    expect(read("./notificationService.ts")).toMatch(/'PHOTO_NUDGE'\]\)/);
  });
});
