// v423 — payments bug report (P1–P17): the pure parts + source guards for the locked flows.
import { describe, it, expect } from "vitest";
import fs from "fs";
import { webhookOrderInfo } from "./razorpayWebhook";
import { briefPaymentStatus } from "./brandPayments";

const read = (p: string) => fs.readFileSync(p, "utf8");

describe("v423 payments", () => {
  it("P1: the webhook reads an Instant UGC order id from the notes", () => {
    const body = { event: "order.paid", payload: { order: { entity: { id: "order_U1", notes: { kind: "ugc_order", ugc_order_id: "ugcord_abc123" } } }, payment: { entity: { id: "pay_1" } } } };
    expect(webhookOrderInfo(body)).toEqual({ orderId: "order_U1", paymentId: "pay_1", dealId: null, kind: "ugc_order", ugcOrderId: "ugcord_abc123" });
    const bad = { event: "order.paid", payload: { order: { entity: { id: "order_U1", notes: { kind: "ugc_order", ugc_order_id: "x,status.eq.1" } } } } };
    expect(webhookOrderInfo(bad)?.ugcOrderId).toBeNull();
    const src = read("backend/payment_routes.ts");
    expect(src).toMatch(/info\.kind === "ugc_order" \? \(info\.ugcOrderId \|\| null\)/);
  });
  it("P6: never the order id as a payment id; only captured payments", () => {
    const src = read("backend/payment_routes.ts");
    expect(src).not.toMatch(/info\.paymentId \|\| info\.orderId/);
    expect(src).not.toMatch(/items\?\.\[0\]\?\.id\) paymentId = payments\.items\[0\]\.id/);
    expect(src).toMatch(/async function capturedPaymentIdFor/);
  });
  it("P4/P5/P17: verify answers PAYMENT_UNCONFIRMED, flags duplicates, compares the signature timing-safe", () => {
    const src = read("backend/payment_routes.ts");
    expect(src).toMatch(/code: 'PAYMENT_UNCONFIRMED'/);
    expect(src).toMatch(/duplicate_payment: Boolean\(result\.duplicatePayment\)/);
    expect(src).toMatch(/crypto\.timingSafeEqual\(sigA, sigB\)/);
    expect(src).not.toMatch(/console\.log\('Valid Source:'/);
  });
  it("P13/P14: create-order checks the deal's brand; check-status needs sign-in and deposit rows only", () => {
    const src = read("backend/payment_routes.ts");
    expect(src).toMatch(/code: "NOT_YOUR_DEAL"/);
    expect(src).toMatch(/const statusUser = await parseAuthUser\(req\)/);
    expect(src).toMatch(/payout_type\.is\.null,payout_type\.neq\.refund/);
  });
  it("P2/P3: the browser checks verified on every path and forgets a failed verify call", () => {
    const src = read("src/lib/razorpay.js");
    expect(src).toMatch(/catch \(e\) \{ persistencePromise = null; throw e; \}/);
    expect(src).not.toMatch(/triggerSuccessOnce\(result\.data\)/);
    expect(src).not.toMatch(/Razorpay signature verification failed/);
    expect(src).toMatch(/attempt >= 3/);
  });
  it("P10: a brief with nothing held any more is released even when slots were cancelled", () => {
    const orders = [{ status: "COMPLETED" }, { status: "COMPLETED" }, { status: "CANCELLED" }];
    expect(briefPaymentStatus({ max_creators: 3 }, orders).status).toBe("escrow");
    expect(briefPaymentStatus({ max_creators: 3 }, orders, 0).status).toBe("released");
    expect(briefPaymentStatus({ max_creators: 3 }, orders, 2000).status).toBe("escrow");
  });
  it("QA: verify refuses crafted ids, and the polling path never answers with an HMAC error", () => {
    const src = read("backend/payment_routes.ts");
    expect(src).toMatch(/for \(const v of \[razorpay_order_id, razorpay_payment_id, deal_id, thread_id\]\)/);
    expect(src).toMatch(/if \(!skipHmac && pollingPath\) \{/);
    expect(src).toMatch(/already_recorded: true/);
  });
});
