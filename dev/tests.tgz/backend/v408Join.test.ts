import { describe, it, expect } from "vitest";
import fs from "node:fs";
import { oauthSignInCore, makeState, readState } from "./oauth_routes";

// v408 (Ravi 5 Nov): Join flow — Google on the creator screens never makes an account by itself; eligible leads only.
const read = (p: string) => fs.readFileSync(new URL(p, import.meta.url), "utf8");

describe("v408 Google on the Join / Log in screen", () => {
  it("noCreate: an unknown Google email makes no account", async () => {
    const db: any = { users: [] };
    const r = await oauthSignInCore({ supabase: null, privilegedSupabase: null, getDb: () => db, saveDb: () => {} }, { email: "new@gmail.com", name: "N", picture: "", provider: "google", role: "creator" }, { noCreate: true });
    expect(r).toMatchObject({ ok: false, error: "not_registered" });
    expect(db.users.length).toBe(0);
  });
  it("an existing account still logs in with noCreate", async () => {
    const db: any = { users: [{ user_id: "u1", email: "old@gmail.com", role: "creator", verified: true }], user_sessions: [] };
    const r = await oauthSignInCore({ supabase: null, privilegedSupabase: null, getDb: () => db, saveDb: () => {} }, { email: "old@gmail.com", name: "", picture: "", provider: "google", role: "creator" }, { noCreate: true });
    expect(r.ok).toBe(true);
    expect(r.created).toBeFalsy();
  });
  it("the join flag travels in the signed state", () => {
    const s = makeState("creator", Date.now(), "secret", false, "", "", true);
    expect(readState(s, Date.now(), "secret")?.j).toBe(true);
    expect(readState(makeState("creator", Date.now(), "secret"), Date.now(), "secret")?.j).toBeUndefined();
  });
  it("pending sign-up re-checks followers before making the account", () => {
    const src = read("./oauth_routes.ts");
    expect(src).toMatch(/\/auth\/oauth\/pending\/complete/);
    expect(src).toMatch(/signupFollowerBlock\(c, \{ instagram: ig, email: p\.email \}\)/);
  });
});

describe("v408 leads + proof", () => {
  it("only eligible creators are kept as Started leads; join proof has no money lines", () => {
    const src = read("./followerGate.ts");
    expect(src).toMatch(/followers < \(await getMinFollowers\(\)\)\) return res\.json\(\{ ok: true, skipped: "not_eligible" \}\)/);
    expect(src).toMatch(/\/public\/join-proof/);
    const proof = src.slice(src.indexOf("/public/join-proof"), src.indexOf("/public/ig-lead"));
    expect(proof).not.toMatch(/creator_net_amount|₹/);
  });
});

describe("v408 uploads with a generic type", () => {
  it("the real type comes from the first bytes", async () => {
    const { sniffType, GENERIC_TYPES } = await import("./fileMagic");
    expect(sniffType(Buffer.from("ffd8ffe000104a4649460001", "hex"))).toBe("image/jpeg");
    expect(sniffType(Buffer.from("%PDF-1.7 xxxxx"))).toBe("application/pdf");
    expect(sniffType(Buffer.from("MZ\x90\x00\x03\x00\x00\x00\x04\x00\x00\x00"))).toBe("");
    expect(GENERIC_TYPES.has("application/octet-stream")).toBe(true);
  });
});

describe("v410 followers Meta didn't give", () => {
  it("missing or a fake 0 is 'unknown' (never blocks sign-up); a real 0 / small number stays", async () => {
    const { statsFromInstagram, trustedFollowers, previewFields } = await import("./instagramConnect");
    expect(statsFromInstagram({ username: "a" }, []).followers).toBeNull();
    expect(statsFromInstagram({ username: "a", followers_count: 320 }, []).followers).toBe(320);
    expect(trustedFollowers({ followers: 0, avg_views: 1752 })).toBeNull();
    expect(trustedFollowers({ followers: 0, avg_views: 10 })).toBe(0);
    expect(trustedFollowers({ followers: null })).toBeNull();
    expect(previewFields({ followers: 0, avg_views: 1752 }).followers).toBeNull();
  });
});

describe("v411 numbers fetched after a sign-up that went on without them", () => {
  it("sign-up asks for the Instagram numbers a few seconds later; a never-fetched profile is fetched on open", () => {
    expect(read("./auth_routes.ts")).toMatch(/kickInstagramRefresh\(u\.user_id\)/);
    expect(read("./oauth_routes.ts")).toMatch(/kickInstagramRefresh\(r\.user\.user_id\)/);
    const ig = read("./instagramConnect.ts");
    expect(ig).toMatch(/!Number\.isFinite\(synced\) \|\| Date\.now\(\) - synced > 20 \* 3600 \* 1000/);
    expect(ig).toMatch(/export function kickInstagramRefresh/);
  });
});
