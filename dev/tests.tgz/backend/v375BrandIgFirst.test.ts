// v375 (Ravi's design "Brand Onboarding IG Split" + "same page, not new pages"): brand step 1 = handle page with the
// answer under the box ("Is this your brand?" card, or one busy line + Continue → logo / name by hand, one automatic
// retry), then the details; the username is saved to brand_profiles.instagram_handle. "No Instagram? Set up manually" never blocks. Rendered for real (the page + IgHandleField), only the
// network is fake. (IgHandleField keeps answers per username for the app visit, so each test uses its own handle.)
import React from "react";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, fireEvent, act, cleanup } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import fs from "fs";

const post = vi.fn();
const get = vi.fn(async (url: string) => (String(url).includes("instagram/config") ? { data: { lookup: true } } : { data: {} }));
vi.mock("../src/lib/api", () => ({ api: { get: (url: any) => get(url), post: (...a: any[]) => post(...a) } }));
const saved: any[] = [];
vi.mock("../src/lib/onboardingProgress", async (orig) => {
  const real: any = await orig();
  return { ...real, loadProgress: vi.fn(async () => null), saveProgress: vi.fn(async (p: any) => { saved.push(p); return { ok: true }; }) };
});
vi.mock("../src/lib/metaPixel", () => ({ useFunnelSteps: () => {} }));

import BrandOnboardingMobile from "../src/pages/onboarding/BrandOnboardingMobile";
import { brandIgOutcome } from "../src/components/onboarding/mobile/BrandIgSteps";

const read = (p: string) => fs.readFileSync(p, "utf8");
const FOUND = { data: { ok: true, stats: { username: "wefrndapp", name: "WeFrnd", followers: 12400, bio: "Find your people.", website: "https://wefrnd.app", photo_url: "https://x/avatars/ig/wefrndapp.webp" }, media: [] } };
const busy = () => Promise.reject({ response: { status: 502, data: { code: "RATE_LIMIT", error: "Instagram is busy right now." } } });

const tick = (ms = 0) => act(async () => { await new Promise((r) => setTimeout(r, ms)); });
function mount() {
  return render(React.createElement(MemoryRouter, null, React.createElement(BrandOnboardingMobile, { user: { user_id: "b1", name: "Ravi", phone: "9876543210" }, onComplete: () => {} })));
}
async function typeHandle(v: string) {
  await tick(); // config + progress loaded
  fireEvent.change(screen.getByLabelText("Instagram handle"), { target: { value: v } });
}

describe("v375 · brand Instagram first", () => {
  beforeEach(() => { cleanup(); post.mockReset(); saved.length = 0; vi.useRealTimers(); });

  it("outcome of a fetch answer", () => {
    expect(brandIgOutcome({ ok: true })).toBe("found");
    expect(brandIgOutcome({ ok: false, status: 404 })).toBe("not_found");
    expect(brandIgOutcome({ ok: false, status: 503, code: "NOT_CONFIGURED" })).toBe("off");
    expect(brandIgOutcome({ ok: false, status: 502, code: "RATE_LIMIT" })).toBe("slow");
    expect(brandIgOutcome({ ok: false, status: 0 })).toBe("slow");
  });

  it("handle → \"Is this your brand?\" card right under the box → Yes, that's us → details filled from Instagram", async () => {
    post.mockResolvedValue(FOUND);
    mount();
    expect(screen.getByText("What's your brand's Instagram?")).toBeTruthy();
    await typeHandle("@wefrndapp");
    fireEvent.click(screen.getByText("Find my brand")); // before the 600 ms auto fetch → asks at once
    await tick(20);
    expect(post).toHaveBeenCalledWith("instagram/preview", { username: "wefrndapp" });
    expect(screen.getByText("Is this your brand?")).toBeTruthy();
    expect(screen.getByText("What's your brand's Instagram?")).toBeTruthy(); // same page
    expect(screen.getByTestId("brand-ig-confirm").textContent).toContain("@wefrndapp · 12.4K followers");
    fireEvent.click(screen.getByText("Yes, that's us"));
    await tick();
    expect(screen.getByText("Your brand, as creators will see it.")).toBeTruthy();
    expect((screen.getByPlaceholderText("Your company name") as HTMLInputElement).value).toBe("WeFrnd");
    expect((screen.getByTestId("brand-ig-website") as HTMLInputElement).value).toBe("https://wefrnd.app");
    expect(screen.queryByText("Fetched from Meta")).toBeNull(); // no second Instagram card on the details
    await tick(700);
    expect(post).toHaveBeenCalledTimes(1);
  });

  it("typing alone shows the card after a moment; Not us clears the username", async () => {
    post.mockResolvedValue(FOUND);
    mount();
    await typeHandle("notus.brand");
    await tick(700);
    expect(screen.getByText("Is this your brand?")).toBeTruthy();
    fireEvent.click(screen.getByText("Not us, change username"));
    await tick();
    expect((screen.getByLabelText("Instagram handle") as HTMLInputElement).value).toBe("");
    expect(screen.queryByText("Is this your brand?")).toBeNull();
  });

  it("Meta busy → one small line + Continue (no new page); details are filled by hand", async () => {
    post.mockImplementation(busy);
    mount();
    await typeHandle("slow.brand");
    fireEvent.click(screen.getByText("Find my brand"));
    await tick(20);
    expect(screen.getByTestId("brand-ig-slow").textContent).toContain("@slow.brand");
    expect(screen.getByText("What's your brand's Instagram?")).toBeTruthy();
    expect(screen.getByTestId("brand-ig-retry").textContent).toMatch(/Retrying automatically in 1[12]s/);
    expect(screen.queryByText(/Instagram is busy right now\. Try again/)).toBeNull(); // not the old red error
    fireEvent.click(screen.getByRole("button", { name: "Continue" }));
    await tick();
    expect(screen.getByText("Your brand, as creators will see it.")).toBeTruthy();
    expect((screen.getByPlaceholderText("Your company name") as HTMLInputElement).value).toBe("");
  });

  it("busy → retries by itself once, then the card shows", async () => {
    let n = 0;
    post.mockImplementation(() => (++n === 1 ? busy() : Promise.resolve(FOUND)));
    mount();
    await typeHandle("late.brand");
    fireEvent.click(screen.getByText("Find my brand"));
    await tick(20);
    expect(screen.getByTestId("brand-ig-slow")).toBeTruthy();
    for (let i = 0; i < 13; i++) await tick(1000); // real time: the countdown is a chain of 1 s timers
    await tick(20);
    expect(post).toHaveBeenCalledTimes(2);
    expect(screen.getByText("Is this your brand?")).toBeTruthy();
  }, 20000);

  it("private / missing account: calm line + Continue without Instagram; manual setup always works", async () => {
    post.mockRejectedValue({ response: { status: 404, data: { code: "NOT_PROFESSIONAL" } } });
    mount();
    await typeHandle("someone");
    fireEvent.click(screen.getByText("Find my brand"));
    await tick(20);
    expect(screen.getByTestId("brand-ig-notfound").textContent).toContain("@someone");
    expect(screen.getByText("Continue without Instagram")).toBeTruthy();
    fireEvent.click(screen.getByText("No Instagram? Set up manually"));
    await tick();
    expect(screen.getByText("Your brand, as creators will see it.")).toBeTruthy();
  });

  it("server: onboarding saves the brand's Instagram username (brand_profiles.instagram_handle)", async () => {
    const { brandIgHandle } = await import("./auth_routes");
    expect(brandIgHandle("@WeFrndApp")).toBe("wefrndapp");
    expect(brandIgHandle("https://www.instagram.com/wefrnd.app/?hl=en")).toBe("wefrnd.app");
    expect(brandIgHandle("not a handle!")).toBe("");
    expect(brandIgHandle("")).toBe("");
    expect(read("backend/auth_routes.ts")).toContain("instagram_handle: brandIgHandle(data.instagram_handle)");
  });

  it("admin brands list shows the brand name (or the name typed in setup) with the person underneath", () => {
    const t = read("src/components/admin/AdminUsersTab.jsx");
    expect(t).toContain("isBrandRow ? (brandName || u.name");
    expect(t).toContain("Setup not finished");
    expect(read("backend/admin_users_enforcement_routes.ts")).toContain("brand_setup:");
  });
});
