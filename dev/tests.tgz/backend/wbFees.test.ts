// White-box tests: fee calculation, stamped fees, escrow / payout / refund guards (money paths).
// Tests marked it.fails document a real bug in the CURRENT code (see the "BUG:" comment above each).
import { describe, it, expect } from "vitest";
import { calculateFee } from "../src/utils/feeCalculator";
import { feeFromStamp, findStampedTransaction, feeAtPaymentTime } from "./stampedFee";
import {
  isPaidOut, isBriefDeposit, isRefundInProgress, isFunded, isRefunded, isEscrowHeld, isPayoutRequested,
  payoutReleaseBlock, refundBlock, pickPayoutAccount, fetchAllRows, netAfterPartialRefund,
} from "./adminMoney";
import { isPaidToBank, readyRows } from "./creatorPayoutRequests";
import { hasRefund } from "./refundFlags";
import { isEscrowDepositRow } from "./campaignGuards";
import { isPaymentFundingSomething, isUnlinkedPaymentRow } from "./briefPayment";

/** Minimal Supabase stand-in for platform_fee_config reads. */
const cfgClient = (config: any, opts: { error?: any; throws?: boolean } = {}) => ({
  from: () => {
    const q: any = {
      select: () => q, order: () => q, limit: () => q,
      maybeSingle: async () => { if (opts.throws) throw new Error("db down"); return { data: config, error: opts.error || null }; },
    };
    return q;
  },
});

describe("calculateFee — default tiered rule (no config)", () => {
  it("15% below ₹20,000, 5% at and above it (threshold is inclusive for the low rate)", async () => {
    const a = await calculateFee(19999);
    expect(a.feePercent).toBe(15);
    expect(a.platformFee).toBe(3000); // 2999.85 rounds to 3000
    expect(a.creatorNet).toBe(16999);
    const b = await calculateFee(20000);
    expect(b.feePercent).toBe(5);
    expect(b.platformFee).toBe(1000);
    expect(b.creatorNet).toBe(19000);
  });

  it("fee + gst + net always adds back to a whole-rupee gross (no paise lost)", async () => {
    for (const g of [1, 7, 99, 101, 333, 1001, 12345, 19999, 20000, 20001, 99999, 250000]) {
      const r = await calculateFee(g, cfgClient({ platform_gst_registered: true, gst_rate: 18 }) as any);
      expect(r.platformFee + r.gstAmount + r.creatorNet).toBe(g);
      expect(Number.isInteger(r.platformFee) && Number.isInteger(r.gstAmount) && Number.isInteger(r.creatorNet)).toBe(true);
    }
  });

  it("₹0 gross → ₹0 everywhere", async () => {
    const r = await calculateFee(0);
    expect([r.platformFee, r.gstAmount, r.creatorNet, r.discountApplied]).toEqual([0, 0, 0, 0]);
  });

  it("a numeric string gross is handled like the number", async () => {
    const r = await calculateFee("1000" as any);
    expect(r.platformFee).toBe(150);
    expect(r.creatorNet).toBe(850);
  });

  it("no GST unless the platform is GST-registered", async () => {
    expect((await calculateFee(1000, cfgClient({ gst_rate: 18 }) as any)).gstAmount).toBe(0);
    const r = await calculateFee(1000, cfgClient({ platform_gst_registered: true, gst_rate: 18 }) as any);
    expect(r.gstAmount).toBe(27); // 18% of the ₹150 fee
    expect(r.creatorNet).toBe(823);
  });

  it("config read error / throw → falls back to the standard rule", async () => {
    expect((await calculateFee(1000, cfgClient(null, { error: { message: "x" } }) as any)).platformFee).toBe(150);
    expect((await calculateFee(1000, cfgClient(null, { throws: true }) as any)).platformFee).toBe(150);
  });

  it("admin config: custom threshold / rates; junk values fall back to defaults", async () => {
    const r = await calculateFee(5000, cfgClient({ threshold_amount: 5000, below_threshold_rate: 20, above_threshold_rate: 8 }) as any);
    expect(r.feePercent).toBe(8);
    expect(r.platformFee).toBe(400);
    const j = await calculateFee(1000, cfgClient({ threshold_amount: "abc", below_threshold_rate: "x", above_threshold_rate: null }) as any);
    expect(j.feePercent).toBe(15);
  });
});

describe("calculateFee — offer mode (convenience fee)", () => {
  it("replaces the platform fee with the offer % and reports the saving", async () => {
    const r = await calculateFee(1000, cfgClient({ offer_mode: true, offer_fee_pct: 2 }) as any);
    expect(r.feeKind).toBe("convenience");
    expect(r.platformFee).toBe(20);
    expect(r.discountApplied).toBe(130);
    expect(r.creatorNet).toBe(980);
  });

  it("coupons do not stack on top of an offer", async () => {
    const r = await calculateFee(1000, cfgClient({ offer_mode: true, offer_fee_pct: 2 }) as any, { type: "zero_fee" });
    expect(r.platformFee).toBe(20);
    expect(r.appliedCoupon).toBeUndefined();
  });

  it("offer % is clamped to 0..100 and defaults to 2", async () => {
    expect((await calculateFee(1000, cfgClient({ offer_mode: true, offer_fee_pct: -5 }) as any)).platformFee).toBe(0);
    expect((await calculateFee(1000, cfgClient({ offer_mode: true }) as any)).platformFee).toBe(20);
    expect((await calculateFee(1000, cfgClient({ offer_mode: "true", offer_fee_pct: 2 }) as any)).feeKind).toBe("platform"); // only boolean true
  });

  // BUG: "Offer: ₹0 platform fee + convenience fee" can RAISE the fee. The admin route allows up to 15%,
  // so with a 10% offer a ₹50,000 deal (normally 5% = ₹2,500) is charged ₹5,000 — the creator loses ₹2,500
  // during a promotion. Fix (feeCalculator.ts:63): platformFee = Math.min(normalFee, Math.round(gross*offerPct/100)).
  // v347: FIXED — this used to be it.fails (bug above is fixed in v347).
  it("an offer never charges more than the normal fee", async () => {
    const r = await calculateFee(50000, cfgClient({ offer_mode: true, offer_fee_pct: 10 }) as any);
    expect(r.platformFee).toBeLessThanOrEqual(2500);
  });
});

describe("calculateFee — coupons", () => {
  it("zero_fee → creator keeps the full gross", async () => {
    const r = await calculateFee(1000, { type: "zero_fee" });
    expect(r.platformFee).toBe(0);
    expect(r.discountApplied).toBe(150);
    expect(r.creatorNet).toBe(1000);
  });

  it("fee_rate_override can only lower the rate, never below 0", async () => {
    expect((await calculateFee(1000, { type: "fee_rate_override", override_fee_rate: 10 })).platformFee).toBe(100);
    expect((await calculateFee(1000, { type: "fee_rate_override", override_fee_rate: 40 })).platformFee).toBe(150);
    expect((await calculateFee(1000, { type: "override_fee_rate", value: -5 })).platformFee).toBe(0);
    // a string rate works
    expect((await calculateFee(1000, { type: "fee_rate_override", override_fee_rate: "10" as any })).platformFee).toBe(100);
  });

  it("documented: a rate-override coupon with NO rate set waives the whole fee (fails open)", async () => {
    const r = await calculateFee(1000, { type: "fee_rate_override" });
    expect(r.platformFee).toBe(0);
  });

  it("flat_discount is capped at the fee", async () => {
    expect((await calculateFee(1000, { type: "flat_discount", discount_amount: 100 })).platformFee).toBe(50);
    const big = await calculateFee(1000, { type: "flat_discount", discount_amount: 5000 });
    expect(big.platformFee).toBe(0);
    expect(big.discountApplied).toBe(150);
    expect(big.creatorNet).toBe(1000);
  });

  it("unknown coupon type / coupon without a type → normal fee", async () => {
    expect((await calculateFee(1000, { type: "mystery" })).platformFee).toBe(150);
    expect((await calculateFee(1000, { code: "X" })).platformFee).toBe(150);
    expect((await calculateFee(1000, null)).platformFee).toBe(150);
  });

  // BUG: a negative flat discount (typo "-100" in Admin → Coupons) INCREASES the fee and reports a negative
  // discount; the creator is charged ₹250 instead of ₹150. Fix (feeCalculator.ts:83):
  // const flatDisc = Math.max(0, Number(...) || 0).
  // v347: FIXED — this used to be it.fails (bug above is fixed in v347).
  it("a negative flat discount never increases the fee", async () => {
    const r = await calculateFee(1000, { type: "flat_discount", discount_amount: -100 });
    expect(r.platformFee).toBeLessThanOrEqual(150);
  });

  // BUG: a non-numeric flat discount makes platformFee / creatorNet NaN, which is then stamped on the
  // transaction (Math.round(NaN) = NaN → null in JSON) and the payout amount is lost.
  // Fix (feeCalculator.ts:83): Number(...) || 0.
  // v347: FIXED — this used to be it.fails (bug above is fixed in v347).
  it("a non-numeric flat discount keeps the amounts numeric", async () => {
    const r = await calculateFee(1000, { type: "flat_discount", discount_amount: "abc" as any });
    expect(Number.isFinite(r.platformFee)).toBe(true);
    expect(Number.isFinite(r.creatorNet)).toBe(true);
  });
});

describe("stampedFee", () => {
  const tx = { gross_amount: 20000, platform_fee_amount: 1000, gst_amount: 180 };

  it("feeFromStamp applies the stamped rates to another amount", () => {
    expect(feeFromStamp(tx, 10000)).toEqual({ feePercent: 5, platformFee: 500, gstAmount: 90, creatorNet: 9410, source: "stamped" });
  });

  it("feeFromStamp: zero-fee stamp is a valid stamp (not 'missing')", () => {
    expect(feeFromStamp({ gross_amount: 5000, platform_fee_amount: 0 }, 5000)).toMatchObject({ platformFee: 0, creatorNet: 5000 });
  });

  it("feeFromStamp returns null for rows with no usable stamp", () => {
    expect(feeFromStamp(null, 100)).toBeNull();
    expect(feeFromStamp({ gross_amount: 0, platform_fee_amount: 10 }, 100)).toBeNull();
    expect(feeFromStamp({ gross_amount: -5, platform_fee_amount: 10 }, 100)).toBeNull();
    expect(feeFromStamp({ gross_amount: 100 }, 100)).toBeNull();
    expect(feeFromStamp({ gross_amount: 100, platform_fee_amount: "abc" }, 100)).toBeNull();
  });

  it("feeFromStamp: negative / junk amount → 0, never a negative payout", () => {
    expect(feeFromStamp(tx, -500)).toMatchObject({ platformFee: 0, gstAmount: 0, creatorNet: 0 });
    expect(feeFromStamp(tx, "x" as any)).toMatchObject({ creatorNet: 0 });
  });

  const txClient = (rowsByCol: Record<string, any[]>) => {
    const calls: string[] = [];
    return {
      calls,
      from: () => {
        let col = "";
        const q: any = {
          select: () => q,
          eq: (c: string) => { col = c; calls.push(c); return q; },
          gt: () => q, order: () => q,
          limit: async () => ({ data: rowsByCol[col] || [], error: null }),
        };
        return q;
      },
    };
  };

  it("findStampedTransaction: uuid deal id tries deal_id first and skips REFUNDED rows", async () => {
    const id = "123e4567-e89b-12d3-a456-426614174000";
    const c = txClient({ deal_id: [{ platform_fee_amount: 10, status: "refunded" }, { platform_fee_amount: 20, status: "SUCCESS" }] });
    const r = await findStampedTransaction(c, { dealId: id });
    expect(r.platform_fee_amount).toBe(20);
    expect(c.calls[0]).toBe("deal_id");
  });

  it("findStampedTransaction: non-uuid ids never hit uuid columns; null client → null", async () => {
    const c = txClient({ ugc_order_id_text: [{ platform_fee_amount: 5 }] });
    const r = await findStampedTransaction(c, { dealId: "abc", ugcOrderId: "ugcord_1" });
    expect(r.platform_fee_amount).toBe(5);
    expect(c.calls).not.toContain("deal_id");
    expect(c.calls).not.toContain("ugc_order_id");
    expect(await findStampedTransaction(null, { dealId: "x" })).toBeNull();
  });

  it("feeAtPaymentTime: stamp wins over today's calculator; no stamp → calculator", async () => {
    const id = "123e4567-e89b-12d3-a456-426614174000";
    const calc = async () => ({ feePercent: 15, platformFee: 1500, gstAmount: 0, creatorNet: 8500 });
    const stamped = await feeAtPaymentTime(txClient({ deal_id: [tx] }), { dealId: id }, 10000, calc);
    expect(stamped.source).toBe("stamped");
    expect(stamped.creatorNet).toBe(9410);
    const calculated = await feeAtPaymentTime(null, { dealId: id }, 10000, calc);
    expect(calculated).toEqual({ feePercent: 15, platformFee: 1500, gstAmount: 0, creatorNet: 8500, source: "calculated" });
  });
});

describe("adminMoney — state predicates", () => {
  it("isPaidOut: PAID / COMPLETED (any case, trimmed) or a UTR; RELEASED alone is not paid", () => {
    expect(isPaidOut({ payout_status: " paid " })).toBe(true);
    expect(isPaidOut({ payout_status: "completed" })).toBe(true);
    expect(isPaidOut({ payout_status: "RELEASED" })).toBe(false);
    expect(isPaidOut({ utr_number: "   " })).toBe(false);
    expect(isPaidOut({ payout_reference: "UTR1" })).toBe(true);
    expect(isPaidOut(null)).toBe(false);
  });

  it("isBriefDeposit only for brief rows without a deal / order", () => {
    expect(isBriefDeposit({ brief_id: "b" })).toBe(true);
    expect(isBriefDeposit({ brief_id: "b", ugc_order_id: "u" })).toBe(false);
    expect(isBriefDeposit({})).toBe(false);
  });

  it("isRefunded: full vs part refund", () => {
    expect(isRefunded({ refund_status: "PROCESSED", gross_amount: 20000, refund_amount: 2000 })).toBe(false);
    expect(isRefunded({ refund_status: "processed", gross_amount: 20000, refund_amount: 20000 })).toBe(true);
    expect(isRefunded({ refund_status: "PROCESSED", gross_amount: 20000, refund_amount: 0 })).toBe(true);
    expect(isRefunded({ status: "refunded" })).toBe(true);
    expect(isRefunded({ refund_status: "PENDING" })).toBe(false);
  });

  it("isEscrowHeld / isFunded / isPayoutRequested / isRefundInProgress", () => {
    expect(isEscrowHeld({ status: "SUCCESS" })).toBe(true);
    expect(isEscrowHeld({ status: "SUCCESS", payout_status: "PAID" })).toBe(false);
    expect(isEscrowHeld({ status: "SUCCESS", brief_id: "b" })).toBe(false);
    expect(isEscrowHeld({ status: "INITIATED" })).toBe(false);
    expect(isFunded({ status: "captured" })).toBe(false);
    expect(isFunded({ status: "escrow_held" })).toBe(true);
    expect(isPayoutRequested({ status: "SUCCESS", payout_requested: true })).toBe(true);
    expect(isPayoutRequested({ status: "SUCCESS", payout_status: "processing" })).toBe(true);
    expect(isPayoutRequested({ payout_requested: true, payout_status: "PAID" })).toBe(false);
    expect(isRefundInProgress({ status: "refund_pending" })).toBe(true);
    expect(isRefundInProgress({ refund_status: "pending" })).toBe(true);
  });
});

describe("adminMoney — payoutReleaseBlock (double-release protection)", () => {
  it("blocks a second payout, refunded money, brief deposits, refunds in flight and unfunded rows", () => {
    expect(payoutReleaseBlock({ status: "SUCCESS", payout_status: "PAID", payout_reference: "U1" })?.code).toBe("ALREADY_PAID");
    expect(payoutReleaseBlock({ status: "SUCCESS", utr_number: "U1" })?.error).toContain("U1");
    expect(payoutReleaseBlock({ status: "REFUNDED", payout_status: "PAID" })?.code).toBe("ALREADY_REFUNDED");
    expect(payoutReleaseBlock({ status: "SUCCESS", brief_id: "b" })?.code).toBe("BRIEF_DEPOSIT");
    expect(payoutReleaseBlock({ status: "SUCCESS", refund_status: "PENDING" })?.code).toBe("REFUND_IN_PROGRESS");
    expect(payoutReleaseBlock({ status: "INITIATED" })?.code).toBe("NOT_FUNDED");
    expect(payoutReleaseBlock({ status: "FAILED" })?.code).toBe("NOT_FUNDED");
  });

  it("allows a funded, unpaid row — including RELEASED (brand approved) and a part-refunded one", () => {
    expect(payoutReleaseBlock({ status: "SUCCESS", payout_status: "RELEASED" })).toBeNull();
    expect(payoutReleaseBlock({ status: "SUCCESS", refund_status: "PROCESSED", gross_amount: 10000, refund_amount: 1000 })).toBeNull();
    expect(payoutReleaseBlock(null)).toBeNull();
  });
});

describe("adminMoney — refundBlock", () => {
  const paid = { status: "SUCCESS", gross_amount: 10000 };
  it("never more than was paid (half-paisa tolerance only)", () => {
    expect(refundBlock(paid, 10000, "PROCESSED")).toBeNull();
    expect(refundBlock(paid, 10000.004, "PROCESSED")).toBeNull();
    expect(refundBlock(paid, 10000.01, "PROCESSED")?.code).toBe("REFUND_TOO_HIGH");
    expect(refundBlock(paid, "10001" as any, "PROCESSED")?.code).toBe("REFUND_TOO_HIGH");
  });
  it("never after payout, never twice, never on unfunded or unknown amounts", () => {
    expect(refundBlock({ ...paid, payout_status: "PAID" }, 1, "PROCESSED")?.code).toBe("ALREADY_PAID_OUT");
    expect(refundBlock({ ...paid, status: "REFUNDED" }, 1, "PROCESSED")?.code).toBe("ALREADY_REFUNDED");
    expect(refundBlock({ status: "INITIATED", gross_amount: 100 }, 1, "PROCESSED")?.code).toBe("NOT_FUNDED");
    expect(refundBlock({ status: "SUCCESS" }, 1, "PROCESSED")?.code).toBe("NO_AMOUNT");
    expect(refundBlock({ status: "SUCCESS", gross_amount: 0, amount: 500 }, 1, "PROCESSED")?.code).toBe("NO_AMOUNT"); // ?? keeps 0
    expect(refundBlock({ status: "SUCCESS", brief_id: "b", gross_amount: 5 }, 1, "PROCESSED")?.code).toBe("BRIEF_DEPOSIT");
  });
  it("a PENDING refund can be completed (REFUND_PENDING status is allowed)", () => {
    expect(refundBlock({ status: "REFUND_PENDING", gross_amount: 100, refund_status: "PENDING" }, 100, "PROCESSED")).toBeNull();
  });
  // v366 moved pin (Ravi: "baaki jo pending hai unhe bhi work karo" — allow further refunds up to what was paid minus
  // what was already refunded). Was: a second part refund was always refused as ALREADY_REFUNDED.
  it("after one PROCESSED part refund, a second one is allowed only up to what is left; never more than paid", () => {
    const part = { ...paid, refund_status: "PROCESSED", refund_amount: 1000 };
    expect(refundBlock(part, 1000, "PROCESSED")).toBeNull();
    expect(refundBlock(part, 9000, "PROCESSED")).toBeNull();
    expect(refundBlock(part, 9001, "PROCESSED")?.code).toBe("REFUND_TOO_HIGH");
    expect(refundBlock({ ...paid, refund_status: "PROCESSED", refund_amount: 10000 }, 1, "PROCESSED")?.code).toBe("ALREADY_REFUNDED");
    expect(refundBlock({ ...paid, refund_status: "PROCESSED", refund_amount: 0 }, 1, "PROCESSED")?.code).toBe("ALREADY_REFUNDED"); // old full refund
  });
});

describe("adminMoney — netAfterPartialRefund", () => {
  it("only a PROCESSED refund with an amount reduces the payout; never below 0", () => {
    expect(netAfterPartialRefund({ refund_status: "PENDING", refund_amount: 2000 }, 18000)).toBe(18000);
    expect(netAfterPartialRefund({ refund_status: "PROCESSED", refund_amount: 0 }, 18000)).toBe(18000);
    expect(netAfterPartialRefund({ refund_status: "processed", refund_amount: "2000" }, "18000" as any)).toBe(16000);
    expect(netAfterPartialRefund({ refund_status: "PROCESSED", refund_amount: 25000 }, 18000)).toBe(0);
    expect(netAfterPartialRefund(null, 500)).toBe(500);
  });

  // BUG (needs a product decision, flagged as money impact): the whole refunded amount is taken from the
  // creator's NET while the platform keeps the full fee on money it gave back. ₹10,000 deal (15% fee →
  // net ₹8,500), ₹5,000 refunded → creator gets ₹3,500 = 65% effective fee on the ₹5,000 the brand kept.
  // A plain ₹5,000 deal would have paid the creator ₹4,250. Fix (adminMoney.ts:172): recompute the fee on
  // (gross - refunded) (feeFromStamp(tx, gross - refunded).creatorNet) instead of net - refunded.
  it.fails("a part refund does not leave the creator worse off than a deal of the remaining size", async () => {
    const tx = { gross_amount: 10000, platform_fee_amount: 1500, refund_status: "PROCESSED", refund_amount: 5000 };
    const remainingDeal = await calculateFee(5000);
    expect(netAfterPartialRefund(tx, 8500)).toBeGreaterThanOrEqual(remainingDeal.creatorNet);
  });
});

describe("adminMoney — pickPayoutAccount / fetchAllRows", () => {
  it("saved UPI wins and never mixes with bank fields", () => {
    const a = pickPayoutAccount({ upi_id: "x@ok", bank_account_number: "1234567890" }, { name: "P" }, null)!;
    expect(a.upi_id).toBe("x@ok");
    expect(a.account_number).toBeNull();
    expect(a.account_holder_name).toBe("P");
  });
  it("profile / KYC fallback; nothing → null; verified only with a destination", () => {
    expect(pickPayoutAccount(null, null, null)).toBeNull();
    const a = pickPayoutAccount({}, { name: "x" }, { ifsc_code: "HDFC0001234", account_number: "1234" })!;
    expect(a.account_number).toBe("1234");
    expect(a.ifsc_code).toBe("HDFC0001234");
    expect(a.source).toBe("profile");
    expect(pickPayoutAccount(null, { name: "x" }, null)!.verified).toBe(false);
  });
  it("fetchAllRows pages until a short page and stops on error", async () => {
    const rows = Array.from({ length: 5 }, (_, i) => i);
    const r = await fetchAllRows(async (from, to) => ({ data: rows.slice(from, to + 1), error: null }), 2);
    expect(r.data).toEqual(rows);
    const e = await fetchAllRows(async (from) => (from === 0 ? { data: [1, 2], error: null } : { data: null, error: "boom" }), 2);
    expect(e).toEqual({ data: [1, 2], error: "boom" });
    const capped = await fetchAllRows(async (from, to) => ({ data: [from, to], error: null }), 2, 4);
    expect(capped.data.length).toBe(4);
  });
});

describe("creatorPayoutRequests.readyRows", () => {
  const base = { status: "SUCCESS", payout_status: "RELEASED" };
  it("one row per deal / order (no double count); RELEASED row preferred", () => {
    const r = readyRows([
      { id: "a", deal_id: "d1", status: "SUCCESS", payout_status: "PENDING" },
      { id: "b", deal_id: "d1", ...base },
      { id: "c", ugc_order_id: "u1", ...base },
      { id: "d", ugc_order_id: "u1", ...base },
    ], { approvedDealIds: new Set(["d1"]) });
    expect(r.map((t) => t.id)).toEqual(["b", "c"]);
  });
  it("excludes paid, refunding, brief deposits, unfunded, and unapproved rows", () => {
    expect(readyRows([
      { id: 1, deal_id: "a", ...base, payout_status: "PAID" },
      { id: 2, deal_id: "b", ...base, utr_number: "U" },
      { id: 3, deal_id: "c", ...base, refund_status: "PENDING" },
      { id: 4, brief_id: "x", ...base },
      { id: 5, deal_id: "e", status: "INITIATED", payout_status: "RELEASED" },
      { id: 6, deal_id: "f", status: "SUCCESS", payout_status: "PENDING" },
      null as any,
    ])).toEqual([]);
    expect(readyRows(undefined as any)).toEqual([]);
  });
  it("isPaidToBank mirrors isPaidOut", () => {
    expect(isPaidToBank({ payout_status: "released" })).toBe(false);
    expect(isPaidToBank({ payout_reference: "R" })).toBe(true);
    expect(isPaidToBank(null)).toBe(false);
  });

  // BUG: after a PART refund to the brand (Session 58: "the rest can still be paid out", adminMoney.isRefunded
  // = false), the creator's "Request payout" never lists that deal again because isRefundedOrRefunding treats
  // any refund_amount > 0 / refund_status PROCESSED as refunded. The rest of the creator's money is stuck
  // until an admin notices. Fix (creatorPayoutRequests.ts:19-22): use adminMoney.isRefunded + isRefundInProgress.
  // v346: FIXED — this used to be it.fails (bug above is fixed in v346).
  it("a part-refunded, approved deal is still ready for payout", () => {
    const r = readyRows([{ id: "p", deal_id: "d9", status: "SUCCESS", payout_status: "RELEASED", gross_amount: 10000, refund_amount: 1000, refund_status: "PROCESSED" }]);
    expect(r.length).toBe(1);
  });
});

describe("refundFlags / campaign deposit rows / brief payment rows", () => {
  it("hasRefund ignores DB defaults (NONE / 0) but sees real refunds", () => {
    expect(hasRefund({ refund_status: "NONE", refund_amount: 0 })).toBe(false);
    expect(hasRefund({ refund_status: " none " })).toBe(false);
    expect(hasRefund({ refund_status: "n/a" })).toBe(false);
    expect(hasRefund({ refund_status: "PENDING" })).toBe(true);
    expect(hasRefund({ refund_amount: "0.5" })).toBe(true);
    expect(hasRefund({ refunded_at: "2026-01-01" })).toBe(true);
    expect(hasRefund(null)).toBe(false);
  });
  it("isEscrowDepositRow: funded statuses or escrow_hold, never a refund row", () => {
    expect(isEscrowDepositRow({ status: "success", refund_status: "NONE" })).toBe(true);
    expect(isEscrowDepositRow({ status: "INITIATED", escrow_hold: true })).toBe(true);
    expect(isEscrowDepositRow({ status: "SUCCESS", refund_amount: 100 })).toBe(false);
    expect(isEscrowDepositRow({ status: "PENDING" })).toBe(false);
    expect(isEscrowDepositRow(null)).toBe(false);
  });
  it("briefPayment: a row funds something only with a brief / deal / order link", () => {
    expect(isPaymentFundingSomething({ razorpay_order_id: "o1", brief_id: "b" }, "o1")).toBe(true);
    expect(isPaymentFundingSomething({ zaakpay_order_id: "o1" }, "o1")).toBe(false);
    expect(isUnlinkedPaymentRow({ zaakpay_order_id: "o1" }, "o1")).toBe(true);
    expect(isUnlinkedPaymentRow({ zaakpay_order_id: "o1" }, "")).toBe(false);
    expect(isUnlinkedPaymentRow({ razorpay_order_id: "o2" }, "o1")).toBe(false);
  });
});
