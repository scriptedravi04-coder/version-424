// v373 (Ravi: redesign the automatic emails, subjects that say the point first, keep the personal welcome as it is,
// no admin email per sign-up, no Diwali emails in code — he sends those himself).
import { describe, it, expect, vi, afterEach } from "vitest";
import fs from "fs";
import path from "path";
import { activityEmailCopy } from "./notificationService";
import { buildEmailHtml, buildLegacyEmailHtml } from "./helpers";
import { sendApplicationDecisionEmail } from "./creatorApplication";

const read = (f: string) => fs.readFileSync(path.join(__dirname, f), "utf8");
const sent: any[] = [];
vi.mock("resend", () => ({ Resend: class { emails = { send: async (m: any) => { sent.push(m); return { error: null }; } }; } }));
afterEach(() => { sent.length = 0; delete process.env.RESEND_API_KEY; });

describe("v373 · every notice type gets its own email", () => {
  it("a rejected campaign is not the 'content revision' email any more", () => {
    const c = activityEmailCopy("CAMPAIGN_REJECTED", "Campaign 'Glow' was not approved.");
    expect(c.subject).toMatch(/campaign needs one fix/i); // v419 short subjects
    expect(c.ctaUrl).toBe("/brand/campaigns");
  });
  it("campaign live, payment held, refunds, settled, reminders: no generic 'New activity on Ybex Media'", () => {
    for (const t of ["CAMPAIGN_LIVE", "payment_funded", "refund_processed", "refund_account_needed", "deal_settled", "reminder", "kyc_update", "admin_message"]) {
      const c = activityEmailCopy(t, "Finish your profile so brands can find you.");
      expect(c.subject, t).not.toMatch(/New activity on Ybex Media/);
      expect(c.ctaUrl, t).not.toBe("/");
    }
    expect(activityEmailCopy("payment_funded").ctaUrl).toBe("/collabs");
    expect(activityEmailCopy("refund_account_needed").ctaUrl).toBe("/brand/payments");
    expect(activityEmailCopy("KYC_REJECTED").ctaUrl).toBe("/kyc");
    expect(activityEmailCopy("profile_approved").ctaUrl).toBe("/profile");
    expect(activityEmailCopy("payout_released").ctaUrl).toBe("/earnings");
    expect(activityEmailCopy("reminder", "🎉 Your profile is 60% done. Finish it today.").subject).toBe("Your profile is 60% done.");
  });
  it("a support reply sends one email, not two", () => {
    expect(read("notificationService.ts")).toMatch(/normType === 'SUPPORT_REPLY'\) return;/);
    expect(read("support_routes.ts")).toContain("/support/tickets/${encodeURIComponent(ticketId)}");
  });
});

describe("v373 · email look", () => {
  it("new layout: inbox preview line, Help / Privacy footer, why you got it; button.url works too (campaign invite)", () => {
    const h = buildEmailHtml({ title: "T", paragraphs: ["x"], preheader: "Preview line", reason: "Because.", button: { text: "Open", url: "https://a.b/c" } });
    expect(h).toContain("Preview line");
    expect(h).toContain('href="https://a.b/c"');
    expect(h).toMatch(/\/help".*Help/);
    expect(h).toContain("Because.");
    expect(h).not.toContain("undefined");
  });
  it("the personal welcome keeps the old look and subject", () => {
    const src = read("auth_routes.ts");
    expect(src).toContain("const welcomeHtml = buildLegacyEmailHtml({");
    expect(src).toContain("const subject = `Wanted to personally reach out`;");
    expect(buildLegacyEmailHtml({ paragraphs: ["a"] })).toContain("All rights reserved");
  });
  it("no admin email per sign-up (the admin bell notice stays)", () => {
    const src = read("auth_routes.ts");
    expect(src).not.toMatch(/New User Signup: \$\{name\}/);
    expect(src).toContain("type: 'user_registered'");
  });
  it("no Diwali Challenge emails in code (Ravi sends them himself)", () => {
    expect(read("challenge_routes.ts")).not.toMatch(/resend|emails\.send/i);
  });
});

describe("v373 · waitlist approval email", () => {
  it("niche in subject and headline, numbers, e-mail filled in on sign-up", async () => {
    process.env.RESEND_API_KEY = "k";
    const ok = await sendApplicationDecisionEmail({ name: "Riya Sharma", email: "riya@gmail.com", niche: "Fashion", social_handle: "riya.creates", followers: 83900, avg_reach: 8500, source: "app" }, "approved");
    expect(ok).toBe(true);
    expect(sent[0].subject).toBe("Profile approved — claim it now"); // v419 (Ravi): short, action-first
    expect(sent[0].html).toContain("Brands in Fashion are waiting. Claim your profile.");
    expect(sent[0].html).toContain("/signup?role=creator&email=riya%40gmail.com");
    expect(sent[0].html).toContain("83,900");
    expect(sent[0].html).toContain("@riya.creates");
  });
  it("CSV-imported rows still get no email (session 36 rule unchanged)", async () => {
    process.env.RESEND_API_KEY = "k";
    expect(await sendApplicationDecisionEmail({ name: "A", email: "a@gmail.com", source: "csv_import" }, "approved")).toBe(false);
  });
  it("bulk approve waits between emails (Resend ~2 a second)", () => {
    expect(read("admin_waitlist_routes.ts")).toContain("BULK_EMAIL_GAP_MS");
  });
  it("pitch email button has a real link", () => {
    const src = read("admin_pitch_leads_routes.ts");
    expect(src).not.toContain("/auth/register?ref=pitch");
    expect(src).toMatch(/link: pitch\.creator_is_claimed/);
  });
});
