import { describe, it, expect } from "vitest";
import fs from "node:fs";
import { cleanAssistBody, redactPii } from "./assist_routes";

// v403: QA report v395 leftovers — S-9 (read on someone else's notification), E-AI-1 (contact details in Eva context).
const read = (p: string) => fs.readFileSync(new URL(p, import.meta.url), "utf8");

describe("v403 QA fixes (backend)", () => {
  it("S-9: marking a notification that isn't yours answers 404, not 200", () => {
    const src = read("./tags_notifications_routes.ts");
    expect(src).toMatch(/Notification not found/);
    expect(src).toMatch(/count:\s*"exact"/);
  });

  it("E-AI-1: emails and Indian phone numbers are masked in Eva context", () => {
    expect(redactPii("call 9876543210 or +91 98765 43210, mail a.b@x.in")).toBe("call [phone hidden] or [phone hidden], mail [email hidden]");
    expect(redactPii("budget ₹6,00,000 for 12 creators")).toBe("budget ₹6,00,000 for 12 creators");
  });

  it("E-AI-1: contact / ID keys are dropped from object context", () => {
    const r = cleanAssistBody({ task: "plan", text: "hi", context: { name: "Riya", phone: "9876543210", email: "r@x.in", pan_number: "ABCDE1234F", rate_reel: 5000, note: "WA 9876543210" } });
    expect(r.context).toContain("Riya");
    expect(r.context).not.toMatch(/9876543210|r@x\.in|ABCDE1234F|5000/);
  });
});
