import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import crypto from "crypto";
import { hashEmail, hashPhone, buildQualifiedPayload, qualifyCreator, sendCapiEvent, QUALIFIED_MIN_FOLLOWERS } from "./metaCapi";

const sha = (v: string) => crypto.createHash("sha256").update(v).digest("hex");
const newCreator = (id: string, extra: any = {}) => ({ user_id: id, role: "creator", email: "Asha@Example.com ", phone: "+91 98765 43210", created_at: new Date().toISOString(), ...extra });

describe("v395 Meta QualifiedCreator", () => {
  let calls: any[] = [];
  beforeEach(() => {
    calls = [];
    process.env.META_CAPI_ACCESS_TOKEN = "SECRET_TOKEN_123";
    process.env.META_PIXEL_ID = "";
    (globalThis as any).fetch = vi.fn(async (url: string, init: any) => { calls.push({ url, body: JSON.parse(init.body) }); return { ok: true, text: async () => "" }; });
  });
  afterEach(() => { delete process.env.META_CAPI_ACCESS_TOKEN; vi.restoreAllMocks(); });

  it("hashes e-mail and phone the way Meta wants", () => {
    expect(hashEmail("  Asha@Example.com ")).toBe(sha("asha@example.com"));
    expect(hashPhone("98765 43210")).toBe(sha("919876543210"));
    expect(hashPhone("+91 98765 43210")).toBe(sha("919876543210"));
    expect(hashEmail("nope")).toBeNull();
    expect(hashPhone("123")).toBeNull();
  });

  it("builds the Conversions API event with value = 1 (v412), same event id, hashed data only", () => {
    const req: any = { headers: { cookie: "_fbp=fb.1.123.456; _fbc=fb.1.123.abc", "user-agent": "UA/1", referer: "https://ybexmedia.in/app/continue/creator" }, socket: { remoteAddress: "1.2.3.4" } };
    const b = buildQualifiedPayload({ user: newCreator("u1"), followers: 5400, eventId: "qc_u1", req, now: 1700000000000 });
    const e = b.data[0];
    expect(e.event_name).toBe("QualifiedCreator");
    expect(e.event_id).toBe("qc_u1");
    expect(e.event_time).toBe(1700000000);
    expect(e.action_source).toBe("website");
    expect(e.custom_data.value).toBe(1);
    expect(e.custom_data.followers_count).toBe(5400);
    expect(e.user_data.em).toEqual([sha("asha@example.com")]);
    expect(e.user_data.ph).toEqual([sha("919876543210")]);
    expect(e.user_data.fbp).toBe("fb.1.123.456");
    expect(e.user_data.fbc).toBe("fb.1.123.abc");
    expect(JSON.stringify(b)).not.toContain("asha@example.com");
    expect(JSON.stringify(b)).not.toContain("9876543210");
  });

  it("fires only at 1,000+ followers, only for creators, only once, only for new accounts", async () => {
    expect(QUALIFIED_MIN_FOLLOWERS).toBe(1000);
    expect(await qualifyCreator({ user: newCreator("a1"), followers: 999 })).toBeNull();
    expect(await qualifyCreator({ user: newCreator("a2"), followers: 0 })).toBeNull();
    expect(await qualifyCreator({ user: newCreator("a3", { role: "brand" }), followers: 50000 })).toBeNull();
    expect(await qualifyCreator({ user: newCreator("a4", { created_at: new Date(Date.now() - 60 * 86400e3).toISOString() }), followers: 50000 })).toBeNull();
    const first = await qualifyCreator({ user: newCreator("a5"), followers: 1000 });
    expect(first).toEqual({ name: "QualifiedCreator", event_id: "qc_a5", followers: 1000 });
    expect(await qualifyCreator({ user: newCreator("a5"), followers: 9000 })).toBeNull(); // once per creator
    await new Promise((r) => setTimeout(r, 20));
    expect(calls.length).toBe(1);
    expect(calls[0].url).toContain("graph.facebook.com");
    expect(calls[0].url).toContain("/965515649959745/events");
    expect(calls[0].body.data[0].event_id).toBe("qc_a5");
  });

  it("without the access token only the Pixel half is sent, and a refused call never throws or prints the token", async () => {
    delete process.env.META_CAPI_ACCESS_TOKEN;
    expect(await sendCapiEvent({ data: [] })).toBe(false);
    expect(calls.length).toBe(0);
    process.env.META_CAPI_ACCESS_TOKEN = "SECRET_TOKEN_123";
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    const bad: any = vi.fn(async () => ({ ok: false, status: 400, text: async () => "bad token SECRET_TOKEN_123" }));
    expect(await sendCapiEvent({ data: [] }, bad)).toBe(false);
    expect(JSON.stringify(warn.mock.calls)).not.toContain("SECRET_TOKEN_123");
  });

  it("is wired: lookup, onboarding and the daily refresh call it; the browser fires the Pixel half with the same id", async () => {
    const fs = await import("node:fs");
    expect(fs.readFileSync("backend/instagramConnect.ts", "utf8")).toMatch(/qualifyCreator(All)?\(\{ user, followers: stats\?\.followers, req \}\)/); // v418: 1K + 10K
    expect(fs.readFileSync("backend/instagramConnect.ts", "utf8")).toMatch(/void qualifyCreator(All)?\(/);
    expect(fs.readFileSync("backend/auth_routes.ts", "utf8")).toMatch(/qualifyCreator(All)?\(\{ user: \{ \.\.\.user, \.\.\.\(dbUser \|\| \{\}\), role \}/);
    expect(fs.readFileSync("src/lib/api.js", "utf8")).toMatch(/response\.data\.meta_event\) trackServerEvent/);
    expect(fs.readFileSync("src/lib/metaPixel.js", "utf8")).toMatch(/\{ eventID: String\(eventId\) \}/);
  });
});
