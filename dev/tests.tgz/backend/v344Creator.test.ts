// v344: source checks for the creator-side fixes (one small check per fix).
import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";

const ROOT = path.resolve(__dirname, "..");
const read = (rel: string) => fs.readFileSync(path.join(ROOT, rel), "utf8");

const settings = read("src/pages/creator/CreatorSettings.jsx");
const mobileProfile = read("src/pages/creator/CreatorMobileProfile.jsx");
const rates = read("src/pages/creator/profileScreens/RatesScreen.jsx");
const earnings = read("src/pages/dashboard/Earnings.jsx");
const earningsMobile = read("src/components/payments/CreatorEarningsMobile.jsx");
const campList = read("src/components/campaigns/mobile/CampaignsListMobile.jsx");
const campDetail = read("src/components/campaigns/mobile/CampaignDetailMobile.jsx");
const home = read("src/pages/creator/CreatorHomeMobile.jsx");
const collabs = read("src/pages/collabs/Collabs.jsx");
const onboarding = read("src/pages/onboarding/CreatorOnboardingMobile.jsx");
const ugc = read("src/pages/creator/CreatorUGCMobile.jsx");
const stickyBar = read("src/pages/creator/creatorUgc/BriefStickyBar.jsx");
const autocomplete = read("src/components/ui/autocomplete.jsx");
const shortlist = read("src/components/chat/mobile/MobileShortlistCards.jsx");

describe("v344 creator fixes", () => {
  it("1. languages are kept as a list and saved in full", () => {
    expect(settings).toMatch(/languages: Array\.isArray\(data\.languages\)/);
    expect(settings).toMatch(/Array\.isArray\(profileFields\.languages\)/);
    expect(mobileProfile).toMatch(/const langListOf = /);
    expect(mobileProfile).toMatch(/language: editForm\.languages\.join\(", "\)/);
    expect(mobileProfile).not.toMatch(/language: editForm\.languages\[0\]/);
  });

  it("2. no made-up Reels/Stories sub-categories", () => {
    expect(settings).toMatch(/subCategories: data\.sub_categories \|\| \[\],/);
  });

  it("3. rate card edits stay in a draft until Save", () => {
    expect(rates).toMatch(/const \[draft, setDraftRaw\]/); // v426: draft follows the loaded card until edited
    expect(rates).toMatch(/saveProfileChanges\(\{ rateCard: toSave \}(, \{ silent: true \})?\)/); // v426: saved rates + edited ones
    expect(rates).not.toMatch(/onChange=\{\(e\) => setRateCard/);
  });

  it("4. In hold leaves out failed / unfinished / cancelled payments", () => {
    expect(earnings).toMatch(/isNeverPaidTx/);
    expect(earnings).toMatch(/!isNeverPaidTx\(e\)/);
    expect(earningsMobile).toMatch(/\["FAILED", "INITIATED", "CANCELLED"\]/);
  });

  it("5. match % only with 2+ compared parts", () => {
    expect(campList).toMatch(/m\.parts\.length >= 2 \? m\.score : null/);
    expect(campDetail).toMatch(/m\.parts\.length >= 2 \? m\.score : null/);
  });

  it("6. brand side never sees Apply; owner gets Manage applicants", () => {
    expect(campDetail).toMatch(/\["brand", "agency", "talent_manager", "admin"\]\.includes\(viewerRole\)/); // v416: + talent manager
    // v358 requirement change: the owner link uses campaign_id || id (database rows have no id)
    expect(campDetail).toMatch(/\/brand\/campaigns\/\$\{cid\}\/applicants/);
  });

  it("7. creator home: expired campaigns, profile, KYC, orders, deal rows", () => {
    expect(home).toMatch(/Date\.parse\(c\.deadline\) \+ 24 \* 3600e3 > Date\.now\(\)/);
    expect(home).toMatch(/if \(meRes\?\.data\) setMyProfile/);
    expect(home).toMatch(/campsData\.length === 0\) setRecommendedCampaigns\(\[\]\)/);
    expect(home).toMatch(/normalizeKycStatus\(\{ status: kycStatus \}\)/);
    expect(home).toMatch(/"\/creator\/ugc\/orders"/);
    expect(home).toMatch(/`\/chat\/\$\{deal\.chatId\}`/);
  });

  it("8. Collabs passes handleTabSelect to DealsMobile", () => {
    expect(collabs).toMatch(/setTab=\{handleTabSelect\}/);
  });

  it("9. onboarding Next waits for a real date of birth", () => {
    expect(onboarding).toMatch(/ageFromDob\(store\.dobDay, store\.dobMonth, store\.dobYear\) === null/);
    expect(onboarding).toMatch(/Enter a valid date of birth/);
  });

  it("10. UGC: failed KYC load is not NONE; no 'sign on desktop'; safe bottom space", () => {
    expect(ugc).toMatch(/if \(failed\.kyc\) setKycStatus/);
    expect(ugc).not.toMatch(/Sign it on desktop/);
    expect(ugc).not.toMatch(/text-\[#0A0A0A\] pb-32"/);
    expect(ugc).toMatch(/pb-\[calc\(150px\+env\(safe-area-inset-bottom\)\)\]/);
    expect(stickyBar).toMatch(/Checking your KYC/);
  });

  it("11. platform screen Back goes back instead of pushing again", () => {
    expect(mobileProfile).toMatch(/const leavePlatformScreen = /);
    expect(mobileProfile).toMatch(/navigate\(-1\)/);
  });

  it("12. 16px inputs on phones; no call to the missing locations/save route", () => {
    expect(autocomplete).toMatch(/text-base md:text-sm/);
    expect(autocomplete).not.toMatch(/fetch\(['"`]\/api\/locations\/save/);
    expect(settings).toMatch(/text-base md:text-xs/);
  });

  it("13. Closed tab says 'Your quote'", () => {
    expect(campList).toMatch(/closed \? "Your quote" : "Per creator"/);
  });

  it("14. '1 day', not '1 days'", () => {
    expect(shortlist).not.toMatch(/`\$\{deliveryDays\} days`/);
    expect(shortlist).toMatch(/=== 1 \? "day" : "days"/);
  });

  it("15. no made-up Instagram platform", () => {
    expect(campDetail).not.toMatch(/\|\| "Instagram"/);
  });
});
