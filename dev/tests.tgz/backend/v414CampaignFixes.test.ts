import { describe, it, expect } from "vitest";
import { readFileSync } from "node:fs";
import { createCampaignLifecycleHandlers } from "./campaigns_routes";
import { isCampaignEscrowFunded, isDepositRefunded, CLOSED_STATES, isKnownLivePostUrl, livePostKey, isEscrowDepositRow } from "./campaignGuards";

// v414 — campaign money + lifecycle fixes (A1–A14).

const read = (p: string) => readFileSync(p, "utf8");
const DEAL = "1c3d5525-0373-40f6-ab50-df43f3e790c6";
const THREAD = `thread_camp_${DEAL}`;
const BRAND = "b0000000-0000-4000-8000-000000000001";
const CREATOR = "c0000000-0000-4000-8000-000000000002";
const STRANGER = "d0000000-0000-4000-8000-000000000003";
const brand = { user_id: BRAND, role: "brand" };
const teamMember = { user_id: "f0000000-0000-4000-8000-000000000009", role: "brand", parent_brand_id: BRAND };
const creator = { user_id: CREATOR, role: "creator" };
const liveLinkMsg = { id: "m_link", thread_id: THREAD, message_type: "live_links_submitted", metadata: { action: "live_link_submitted", link: "https://instagram.com/p/x" } };

function lifecycle(threadExtra: any = {}, dealExtra: any = {}, dbExtra: any = {}, supa: any = null) {
  const db: any = {
    chat_threads: [{ id: THREAD, deal_id: DEAL, campaign_id: "camp1", brand_id: BRAND, creator_id: CREATOR, status: "ACTIVE", flow_state: "ACTIVE", ...threadExtra }],
    deals: [{ id: DEAL, brand_id: BRAND, creator_id: CREATOR, agreed_amount: 20000, status: "ACTIVE", escrow_hold: true, ...dealExtra }],
    transactions: [], chat_messages: [], notifications: [], content_submissions: [], support_tickets: [], ticket_messages: [],
    ...dbExtra,
  };
  let actor: any = null;
  const alerts: any[] = [];
  const h = createCampaignLifecycleHandlers({
    supabase: supa, privilegedSupabase: supa, getDb: () => db, saveDb: () => {},
    parseAuthUser: async () => actor, insertChatMessageToSupabase: async () => ({}),
    broadcastAdminNotification: async (n: any) => { alerts.push(n); },
  });
  const call = async (fn: any, user: any, body: any = {}) => {
    actor = user; let status = 200; let json: any;
    const res = { status(s: number) { status = s; return this; }, json(j: any) { json = j; return this; } };
    await fn({ params: { id: THREAD, threadId: THREAD }, body, app: { get: () => null } }, res);
    return { status, json };
  };
  return { db, h, call, alerts };
}

describe("A1 · a fully refunded deal is not funded and can't be paid out", () => {
  it("escrow_hold_at alone no longer counts once escrow_hold is false", async () => {
    expect(await isCampaignEscrowFunded({ client: null, db: {}, dealId: DEAL, deal: { escrow_hold: false, escrow_hold_at: "2026-11-01" } })).toBe(false);
    expect(await isCampaignEscrowFunded({ client: null, db: {}, dealId: DEAL, deal: { escrow_hold_at: "2026-11-01" } })).toBe(true);
    expect(await isCampaignEscrowFunded({ client: null, db: {}, dealId: DEAL, deal: { escrow_hold: true } })).toBe(true);
  });
  it("REFUNDED is a closed state; isDepositRefunded spots a full refund", () => {
    expect(CLOSED_STATES).toContain("REFUNDED");
    expect(isDepositRefunded([{ status: "REFUNDED", refund_amount: 20000, refund_status: "PROCESSED", gross_amount: 20000 }])).toBe(true);
    expect(isDepositRefunded([{ status: "SUCCESS", refund_amount: 0, refund_status: "NONE" }])).toBe(false);
    // a part refund leaves the deposit live
    expect(isDepositRefunded([{ status: "SUCCESS", refund_amount: 2000, refund_status: "PROCESSED", gross_amount: 20000 }])).toBe(false);
  });
  it("approve refuses with DEAL_REFUNDED and writes no payout", async () => {
    const { db, h, call } = lifecycle({ flow_state: "PROOF_SUBMITTED" }, { escrow_hold: false, escrow_hold_at: "2026-11-01" }, {
      chat_messages: [liveLinkMsg],
      transactions: [{ id: "tx1", deal_id: DEAL, status: "REFUNDED", refund_amount: 20000, refund_status: "PROCESSED", gross_amount: 20000 }],
    });
    const r = await call(h.handleThreadApproveLiveLinks, brand);
    expect(r.status).toBe(409);
    expect(r.json.code).toBe("DEAL_REFUNDED");
    expect(db.chat_messages.filter((m: any) => m.message_type === "live_links_approved").length).toBe(0);
    expect(db.transactions.length).toBe(1);
  });
  it("refund route clears the funded date, cancels the deal + thread and posts the chat line", () => {
    const p = read("backend/payment_routes.ts");
    expect(p).toContain("escrow_hold_at: null,");
    expect(p).toContain("Payment refunded to brand — deal closed");
    expect(p).toMatch(/from\('chat_threads'\)\.update\(\{ status: 'CANCELLED', flow_state: 'CANCELLED'/);
  });
});

// A tiny chainable Supabase stand-in: every call returns the chain; awaiting it asks `answer(table, ops)`.
function fakeSupa(answer: (table: string, ops: string[]) => any) {
  return {
    from(table: string) {
      const ops: string[] = [];
      const chain: any = new Proxy({}, {
        get(_t, prop: string) {
          if (prop === "then") return (ok: any, bad: any) => Promise.resolve(answer(table, ops)).then(ok, bad);
          return (..._a: any[]) => { ops.push(prop); return chain; };
        },
      });
      return chain;
    },
  };
}

describe("A2 · a second approve doesn't record a second payout", () => {
  it("when the conditional COMPLETED update moves no row, it answers already_completed and pays nothing", async () => {
    const supa = fakeSupa((table, ops) => {
      if (table === "deals" && ops.includes("update")) return { data: [], error: null }; // someone else completed it
      if (table === "deals" && ops.includes("maybeSingle")) return { data: { id: DEAL, status: "COMPLETED" }, error: null };
      if (table === "transactions") return { data: [{ id: "tx1", deal_id: DEAL, status: "SUCCESS", refund_status: "NONE", refund_amount: 0, escrow_hold: true }], error: null };
      return { data: null, error: null };
    });
    const { db, h, call, alerts } = lifecycle({ flow_state: "PROOF_SUBMITTED" }, {}, { chat_messages: [liveLinkMsg] }, supa);
    const r = await call(h.handleThreadApproveLiveLinks, brand);
    expect(r.status).toBe(200);
    expect(r.json.already_completed).toBe(true);
    expect(alerts.length).toBe(0);
    expect(db.chat_messages.filter((m: any) => m.message_type === "live_links_approved").length).toBe(0);
  });
  it("source: conditional update + payout-already-on-record check", () => {
    const s = read("backend/campaign_lifecycle.ts");
    expect(s).toContain(".not('status', 'in', '(COMPLETED,CLOSED,CANCELLED,PAID,RELEASED,REFUNDED)')");
    expect(s).toContain("const payoutOnRecord");
  });
});

describe("A3 · funded check reads the paid amount so a part-refunded deposit still counts", () => {
  it("select has gross_amount, brand_paid_amount, fee_correction_note", () => {
    expect(read("backend/campaignGuards.ts")).toContain('refunded_at, escrow_hold, gross_amount, brand_paid_amount, fee_correction_note")');
    expect(isEscrowDepositRow({ status: "SUCCESS", refund_amount: 2000, refund_status: "PROCESSED", gross_amount: 20000 })).toBe(true);
  });
});

describe("A4 · payout card / alert show the stored (after part-refund) net", () => {
  it("message, notification, admin alert and response use storedNet", () => {
    const s = read("backend/campaign_lifecycle.ts");
    expect(s).toContain("creator_net_amount: storedNet, // v414");
    expect(s).toContain("pay ₹${Number(storedNet).toLocaleString('en-IN')} to the creator");
    expect(s).not.toContain("has been released. The deal is now complete!");
  });
});

describe("A5 · cancel a campaign deal", () => {
  it("not funded → cancelled at once, message + the other side told", async () => {
    const { db, h, call } = lifecycle({ flow_state: "NEGOTIATING", status: "NEGOTIATING" }, { escrow_hold: false, status: "NEGOTIATING" });
    const r = await call(h.handleCampaignCancel, brand, { reason: "Dates moved" });
    expect(r.status).toBe(200);
    expect(r.json).toMatchObject({ ok: true, cancelled: true, requested: false });
    expect(db.deals[0].status).toBe("CANCELLED");
    expect(db.chat_threads[0].status).toBe("CANCELLED");
    expect(db.chat_messages.at(-1).text).toBe("Deal cancelled by Brand: Dates moved");
    expect(db.notifications.some((n: any) => n.user_id === CREATOR)).toBe(true);
  });
  it("team member acting for the brand can cancel; creator side is labelled", async () => {
    const a = lifecycle({ flow_state: "NEGOTIATING" }, { escrow_hold: false });
    expect((await a.call(a.h.handleCampaignCancel, teamMember, { reason: "x" })).json.cancelled).toBe(true);
    const b = lifecycle({ flow_state: "NEGOTIATING" }, { escrow_hold: false });
    await b.call(b.h.handleCampaignCancel, creator, { reason: "Not well" });
    expect(b.db.chat_messages.at(-1).text).toBe("Deal cancelled by Creator: Not well");
    expect(b.db.notifications.some((n: any) => n.user_id === BRAND)).toBe(true);
  });
  it("funded → nothing moves, a support ticket + admin alert are made, requested:true (once)", async () => {
    const { db, h, call, alerts } = lifecycle({ flow_state: "ACTIVE" }, { escrow_hold: true });
    const r = await call(h.handleCampaignCancel, creator, { reason: "Can't deliver" });
    expect(r.json).toMatchObject({ ok: true, cancelled: false, requested: true });
    expect(db.deals[0].status).toBe("ACTIVE");
    expect(db.chat_threads[0].status).toBe("ACTIVE");
    expect(db.support_tickets.length).toBe(1);
    expect(alerts.length).toBe(1);
    expect(db.chat_messages.at(-1).text).toContain("Cancellation requested by Creator — Ybex support will review and refund");
    const again = await call(h.handleCampaignCancel, brand, { reason: "again" });
    expect(again.json.requested).toBe(true);
    expect(db.support_tickets.length).toBe(1);
  });
  it("stranger 403, closed deal 409, UGC thread 400 USE_UGC_CANCEL", async () => {
    const a = lifecycle();
    expect((await a.call(a.h.handleCampaignCancel, { user_id: STRANGER, role: "brand" }, { reason: "x" })).status).toBe(403);
    const b = lifecycle({ status: "COMPLETED", flow_state: "COMPLETED" });
    expect((await b.call(b.h.handleCampaignCancel, brand, { reason: "x" })).status).toBe(409);
    const c = lifecycle({ id: THREAD, is_ugc: true, deal_type: "ugc" });
    const rc = await c.call(c.h.handleCampaignCancel, brand, { reason: "x" });
    expect(rc.status).toBe(400);
    expect(rc.json.code).toBe("USE_UGC_CANCEL");
  });
  it("route is registered on both paths", () => {
    expect(read("backend/campaigns_routes.ts")).toContain('router.post(["/chat/v2/threads/:threadId/cancel-deal", "/campaign/threads/:threadId/cancel-deal"], handleCampaignCancel);');
  });
});

describe("A6–A8, A10 · accepting an applicant", () => {
  const s = read("backend/campaigns_routes.ts");
  it("rolls the application back if the deal / thread can't be made", () => {
    expect(s).toContain("await rollbackAccept(); // v414");
    expect(s).toMatch(/if \(threadErr\) \{[\s\S]{0,200}await rollbackAccept\(\);/);
  });
  it("enforces max_creators and refuses closed / not-live campaigns", () => {
    expect(s).toContain('code: "CAMPAIGN_FULL"');
    expect(s).toContain("All ${maxC} creator spots are filled.");
    expect(s).toContain('code: "CAMPAIGN_CLOSED"');
  });
  it("offer card uses the same agreed amount as the contract", () => {
    expect(s).toContain("My proposal: ₹${Number(creatorFee).toLocaleString('en-IN')}."); // v416 (C2): creator's own fee; "No fee proposed yet" when none
    expect(s).not.toContain("Number(app.proposed_amount || 0)");
  });
});

describe("A9 · live-post proof", () => {
  it("accepts real posts, refuses other links", () => {
    for (const ok of ["https://www.instagram.com/reel/DAbc123/", "https://instagram.com/p/x", "https://youtube.com/shorts/abc", "https://www.youtube.com/watch?v=abc123", "https://youtu.be/abc", "https://www.facebook.com/reel/12345", "https://x.com/user/status/123", "https://www.linkedin.com/posts/someone_activity-123"]) {
      expect(isKnownLivePostUrl(ok)).toBe(true);
    }
    for (const bad of ["https://google.com", "https://instagram.com/someuser", "https://youtube.com/@channel", "https://example.com/p/abc", "ftp://instagram.com/p/x"]) {
      expect(isKnownLivePostUrl(bad)).toBe(false);
    }
    expect(livePostKey("https://www.instagram.com/reel/ABC/?igsh=1")).toBe(livePostKey("https://instagram.com/reel/ABC"));
  });
  it("submit-live-link refuses a non-post link and a link used on another deal", async () => {
    const a = lifecycle({ flow_state: "CONTENT_APPROVED" });
    const r1 = await a.call(a.h.handleThreadSubmitLiveLink, creator, { link: "https://google.com" });
    expect(r1.status).toBe(400);
    expect(r1.json.code).toBe("LIVE_LINK_NOT_A_POST");
    const b = lifecycle({ flow_state: "CONTENT_APPROVED" }, {}, { content_submissions: [{ id: "s1", deal_id: "other-deal", submission_type: "live_link", video_url: "https://instagram.com/reel/ABC" }] });
    const r2 = await b.call(b.h.handleThreadSubmitLiveLink, creator, { link: "https://www.instagram.com/reel/ABC/" });
    expect(r2.status).toBe(409);
    expect(r2.json.code).toBe("LIVE_LINK_ALREADY_USED");
  });
});

describe("A11 · closing a campaign closes waiting applications", () => {
  it("marks PENDING as REJECTED and notifies", () => {
    const s = read("backend/campaignManage.ts");
    expect(s).toContain('.update({ status: "REJECTED", rejection_reason: reason })');
    expect(s).toContain("Campaign closed —");
  });
});

describe("A12 / A14 · wording + stages", () => {
  it("approve confirm says Ybex sends the payout, not 'release'", () => {
    expect(read("src/components/chat/mobile/MobileLiveLinksCard.jsx")).toContain("Ybex sends the creator's payout");
    expect(read("src/components/chat/SystemMessage.jsx")).toContain("Ybex sends the creator's payout");
    expect(read("src/components/chat/SystemMessage.jsx")).not.toContain("This releases the secure payout");
  });
  it("completed stage says processing until a UTR exists; link-fix decline has its own brand stage", async () => {
    const { getChatStage: gcs } = await import("../src/components/chat/mobile/chatStageMap.js");
    const getChatStage = gcs as (o: any) => any;
    const done = { id: THREAD, status: "COMPLETED", flow_state: "COMPLETED" };
    expect(getChatStage({ thread: done, isBrand: true, isUgcOrder: false }).label).toBe("Deal completed · Payout processing");
    expect(getChatStage({ thread: { ...done, utr_number: "UTR1" }, isBrand: true, isUgcOrder: false }).label).toBe("Deal completed · Payout released");
    const declined = { id: THREAD, status: "ACTIVE", flow_state: "REVISION_DECLINED_LINKS", payment_funded: true, agreement_signed_brand: true, agreement_signed_creator: true };
    expect(getChatStage({ thread: declined, isBrand: true, isUgcOrder: false }).label).toBe("Creator declined link fix · approve or contact support");
    expect(getChatStage({ thread: declined, isBrand: false, isUgcOrder: false }).action).toBeNull();
  });
});

describe("A13 · /deals/:id/submit-draft + add-collab follow the chat stage", () => {
  const s = read("backend/deals_routes.ts");
  it("refuses a draft past the draft stage or while one is under review", () => {
    expect(s).toContain('code: "DRAFT_UNDER_REVIEW"');
    expect(s).toContain("[...LIVE_LINK_DUE_STATES, ...LIVE_LINK_UNDER_REVIEW_STATES].includes(gFlow)");
    expect(s).not.toContain("UGC Deliverable Draft Submitted");
    expect(s).not.toContain("UGC Deliverable submitted!");
  });
  it("add-collab uses the real thread and refuses while a link is under review", () => {
    expect(s).toContain("const threadId = collabThread?.id || `thread_camp_${id}`;");
    expect(s).toContain('code: "LINK_ALREADY_UNDER_REVIEW"');
  });
});
