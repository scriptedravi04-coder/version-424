// v414b: deal talk that the v414 filter wrongly blocked (prices in a row, @brand tags, deliverable lists,
// payout questions, dates / invoice numbers / story links, attachment filenames with spaces).
import { describe, it, expect } from "vitest";
import express from "express";
import http from "http";
import {
  checkComprehensiveDisallowedContent as check, splitNumberAcrossMessages, resetRecentMessageBuffer,
  chunkDigits, isAllowedLinkToken, stripAttachmentLabel, isDateRun,
} from "./contactSecurityFilter";
import { setupChatCoreRoutes } from "./chat_routes";

const PASS: string[] = [
  // 3 — brand @mentions
  "Please tag @paytm in the caption", "collab with @airtel and @jio", "mention @hdfcbank in the reel",
  // 4 — deliverable lists
  "Instagram: carousel post + 2 stories", "Insta - feed post and story", "Insta: 60s reel", "IG: 15s reel + 3 stories",
  "Instagram - 2 reels and 1 static", "insta: 1min video",
  // 5 — payout questions
  "Bank transfer kab hoga?", "NEFT se payment kab aayega", "Kya main UPI se pay kar sakta hoon?", "payment kab aayega",
  "Ybex se payment mil gaya",
  // 6 — dates, invoice numbers, story links
  "Instagram reel post karunga 15-11-2026 ko", "Reel live on instagram by 10.12.2026", "Invoice number 100234 bhej diya",
  "Story live on 07/11/2026", "Order number 2026110712345", "contact number baad mein dunga", "Deadline 2026-11-20 for the instagram reel",
  "https://www.instagram.com/stories/ravi_k/3245678901234567890/", "instagram.com/stories/ravi_k/3245678901234567890",
  // 7 — attachment filenames with spaces
  "📎 Attached file: WhatsApp Image 2026-11-07 at 18.30.45.jpeg",
  "📎 Attached file: WhatsApp Video 2026-11-07 at 18.30.45 (1).mp4",
  // existing v414 passes
  "Please tag @qafoods in the reel", "Collab post with @qafoods.official", "thanks...", "Okay...", "Sure...",
  "1 IG - Reel, 2 stories", "FB - post", "No. of reels 2, budget 25000", "I'll mail the product, budget 150000",
  "Order id 2026110712345", "📎 Attached file: Screenshot_20261107-183045.png",
  "drive.google.com/file/d/abc", "https://www.instagram.com/reel/abc123/", "https://youtu.be/abc",
  "payment kab aayega?", "Ybex payment done", "paytm", "is gpay accepted?", "I paid via upi on ybex",
  "upi payment failed, retry?", "meet at icici office", "890000 followers, avg reach 2300000",
  "budget is ₹15,000 for 2 reels", "Who should I contact about shipping?", "my phone broke",
];

const BLOCK: [string, string?][] = [
  // 3 — real UPI ids
  ["ravi@okaxis", "UPI"], ["ravi.k@ybl", "UPI"], ["upi ravi at okaxis", "UPI"], ["9876543210@paytm"],
  ["my upi id: ravi123@ybl", "UPI"], ["gpay pe ravi okicici", "UPI"], ["tag me ravi@okaxis", "UPI"],
  // 4 — real handles
  ["insta id: ravi_k"], ["ig: ravi.k"], ["instagram - @ravi_k"], ["ig - ravi_k"], ["telegram @ravik"],
  // 5 — paid outside Ybex
  ["pay me cash outside ybex", "PAY_OUTSIDE"], ["paytm karo bhai", "PAY_OUTSIDE"], ["direct bank transfer kar do", "PAY_OUTSIDE"],
  ["send money directly to my account", "PAY_OUTSIDE"], ["pay me on gpay", "PAY_OUTSIDE"], ["gpay kar do", "PAY_OUTSIDE"],
  ["phonepe pe bhejo", "PAY_OUTSIDE"], ["neft karo", "PAY_OUTSIDE"], ["send money on phonepe", "PAY_OUTSIDE"],
  ["Bank transfer kab hoga? seedha kar do", "PAY_OUTSIDE"],
  // 7 — filename that is a phone number
  ["📎 Attached file: 9876543210.png"], ["📎 Attached file: 98765 43210.jpg"],
  // existing v414 blocks
  ["call me 9876543210"], ["9 8 7 6 5 4 3 2 1 0"], ["nine eight seven six five four three two one zero"],
  ["number: 98765 43210"], ["my insta is @ravi_k dm me"], ["mail me ravi.k@gmail.com"],
  ["wa.me/919876543210"], ["whatsapp me on 98765-43210"], ["+91 98765 43210"],
  ["ravi@gmail.com/ybex.in"], ["wa.me/919876543210?drive.google.com/"], ["9876543210?ybex.club"],
  ["drive.google.com/file/d/9876543210/view"], ["tag me @ravi_k and dm me"], ["follow @ravi_k"], ["ravi_k"],
  ["instagram.com/stories/ravi_k/9876543210"], ["whatsapp 9876543"], ["contact me on 98765 43210"],
];

describe("v414b filter table", () => {
  for (const t of PASS) it(`passes: ${t}`, () => { resetRecentMessageBuffer(); const r = check(t); expect(r.blocked, r.code).toBe(false); });
  for (const [t, code] of BLOCK) it(`blocks: ${t}`, () => {
    resetRecentMessageBuffer();
    const r = check(t);
    expect(r.blocked).toBe(true);
    if (code) expect(r.code).toBe(code);
  });
});

describe("v414b split numbers (2)", () => {
  it("two prices in a row are not a phone number", () => {
    expect(splitNumberAcrossMessages("Negotiable to 60000", ["My rate is 75000"])).toBe(false);
    expect(splitNumberAcrossMessages("60000", ["75000"])).toBe(false);
    expect(splitNumberAcrossMessages("1,50,000", ["75000"])).toBe(false);
    expect(splitNumberAcrossMessages("60000", ["rate 75000"])).toBe(false);
    expect(chunkDigits("75000")).toBeNull();
    expect(chunkDigits("1,50,000")).toBeNull();
    expect(chunkDigits("Negotiable to 60000")).toBeNull();
    expect(chunkDigits("75k")).toBeNull();
    expect(chunkDigits("Reel live by 15-11-2026")).toBeNull();
  });
  it("a real number in pieces is still caught", () => {
    expect(splitNumberAcrossMessages("43210", ["98765"])).toBe(true);
    expect(splitNumberAcrossMessages("210", ["9876", "543"])).toBe(true);
    expect(splitNumberAcrossMessages("9117", ["Reach me at 931", "509"])).toBe(true);
  });
  it("in-memory buffer: prices pass, pieces block", () => {
    resetRecentMessageBuffer();
    const o = { threadId: "t1", senderId: "u1", now: 1_000_000 };
    expect(check("My rate is 75000", o).blocked).toBe(false);
    expect(check("Negotiable to 60000", { ...o, now: o.now + 1000 }).blocked).toBe(false);
    resetRecentMessageBuffer();
    expect(check("75000", o).blocked).toBe(false);
    expect(check("60000", { ...o, now: o.now + 1000 }).blocked).toBe(false);
    resetRecentMessageBuffer();
    expect(check("98765", o).blocked).toBe(false);
    expect(check("43210", { ...o, now: o.now + 1000 }).blocked).toBe(true);
    resetRecentMessageBuffer();
    expect(check("9876", o).blocked).toBe(false);
    expect(check("543", { ...o, now: o.now + 1000 }).blocked).toBe(false);
    expect(check("210", { ...o, now: o.now + 2000 }).blocked).toBe(true);
  });
});

describe("v414b helpers", () => {
  it("story links are allowed", () => {
    expect(isAllowedLinkToken("https://www.instagram.com/stories/ravi_k/3245678901234567890/")).toBe(true);
  });
  it("dates", () => {
    for (const d of ["15-11-2026", "10.12.2026", "07/11/2026", "2026-11-07"]) expect(isDateRun(d)).toBe(true);
    expect(isDateRun("98765-43210")).toBe(false);
  });
  it("attachment label: whole filename with spaces is stripped", () => {
    expect(stripAttachmentLabel("📎 Attached file: WhatsApp Image 2026-11-07 at 18.30.45.jpeg").trim()).toBe("");
    expect(stripAttachmentLabel("📎 Attached file: 9876543210.png")).toContain("9876543210");
  });
});

// ------------------------------------------------------------------ server history window (2)
async function serve(app: express.Express, fn: (base: string) => Promise<void>) {
  const srv = http.createServer(app).listen(0);
  await new Promise((r) => srv.once("listening", r));
  const port = (srv.address() as any).port;
  try { await fn(`http://127.0.0.1:${port}/api`); } finally { srv.close(); }
}
function chatApp(db: any, user: any) {
  const app = express(); app.use(express.json());
  const router = express.Router();
  setupChatCoreRoutes(app, router, {
    supabase: null, privilegedSupabase: null, getDb: () => db, saveDb: () => {},
    parseAuthUser: async () => user, ensureUGCChatThread: async () => null, populateThreadData: async (t: any[]) => t,
    insertChatMessageToSupabase: async () => ({ data: null, error: null }),
  } as any);
  app.use("/api", router);
  return app;
}
const mkDb = () => ({ chat_threads: [{ id: "thread_camp_1", creator_id: "c1", brand_id: "b1", status: "NEGOTIATING", flow_state: "NEGOTIATING" }], chat_messages: [] as any[], user_violations: [] });
const send = (base: string, text: string) => fetch(`${base}/chat/v2/threads/thread_camp_1/messages`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ text }) });

describe("v414b chat route split-number window", () => {
  it("a piece older than 10 minutes is not joined", async () => {
    resetRecentMessageBuffer();
    const db = mkDb();
    db.chat_messages.push({ id: "m1", thread_id: "thread_camp_1", sender_user_id: "c1", message_type: "text", text: "98765", created_at: new Date(Date.now() - 11 * 60e3).toISOString() });
    await serve(chatApp(db, { user_id: "c1", role: "creator" }), async (base) => {
      const r = await send(base, "43210");
      expect(r.status).not.toBe(400);
    });
  });
  it("a recent piece is joined → PHONE_SPLIT", async () => {
    resetRecentMessageBuffer();
    const db = mkDb();
    db.chat_messages.push({ id: "m1", thread_id: "thread_camp_1", sender_user_id: "c1", message_type: "text", text: "98765", created_at: new Date(Date.now() - 2 * 60e3).toISOString() });
    await serve(chatApp(db, { user_id: "c1", role: "creator" }), async (base) => {
      const r = await send(base, "43210");
      expect(r.status).toBe(400);
      expect((await r.json()).code).toBe("PHONE_SPLIT");
    });
  });
  it("two recent prices pass", async () => {
    resetRecentMessageBuffer();
    const db = mkDb();
    db.chat_messages.push({ id: "m1", thread_id: "thread_camp_1", sender_user_id: "c1", message_type: "text", text: "My rate is 75000", created_at: new Date(Date.now() - 60e3).toISOString() });
    await serve(chatApp(db, { user_id: "c1", role: "creator" }), async (base) => {
      const r = await send(base, "Negotiable to 60000");
      expect(r.status).not.toBe(400);
    });
  });
});
