// v364 (Ravi: "Creator fee 0% till Diwali, brand fee 8% deal ke upar, coupon se 4% — campaign + UGC").
import { describe, it, expect, beforeEach } from "vitest";
import { readFileSync } from "fs";
import { calculateFee, brandFeeFor, isSplitFee } from "../src/utils/feeCalculator";
import { quoteBrandPayment, brandCouponProblem, quoteNotes, quoteFromNotes, brandStamp, __resetFeeConfigCache, cleanCouponCode } from "./brandFee";

const read = (p: string) => readFileSync(p, "utf8");
const SPLIT = { fee_model: "split", creator_fee_pct: 0, brand_fee_pct: 8, threshold_amount: 20000, below_threshold_rate: 10, above_threshold_rate: 5, platform_gst_registered: false, gst_rate: 18 };
const LEGACY = { ...SPLIT, fee_model: "legacy" };

function fakeClient(config: any, coupons: any[] = [], redemptions: any[] = []) {
  const q = (table: string) => {
    let rows: any[] = table === "platform_fee_config" ? [config] : table === "coupons" ? coupons : table === "coupon_redemptions" ? redemptions : [];
    const api: any = {
      select: () => api, order: () => api, limit: () => api,
      ilike: (_c: string, v: string) => { rows = rows.filter((r) => String(r.code).toUpperCase() === String(v).toUpperCase()); return api; },
      eq: (c: string, v: any) => { rows = rows.filter((r) => String(r[c]) === String(v)); return api; },
      maybeSingle: async () => ({ data: rows[0] || null, error: null }),
      then: (ok: any) => ok({ data: rows, error: null, count: rows.length }),
    };
    return api;
  };
  return { from: q };
}

describe("v364 · fee calculator", () => {
  it("split: ₹10,000 → brand pays ₹10,800, creator gets ₹10,000, Ybex ₹800", async () => {
    const r: any = await calculateFee(10000, null, null, { config: SPLIT });
    expect(r.feeModel).toBe("split");
    expect(r.platformFee).toBe(0);
    expect(r.creatorNet).toBe(10000);
    expect(r.brandFeePercent).toBe(8);
    expect(r.brandFee).toBe(800);
    expect(r.brandPayable).toBe(10800);
    expect(r.platformFee + r.brandFee).toBe(800);
  });
  it("legacy model is unchanged (tiered fee from the creator, brand pays the deal amount)", async () => {
    const r: any = await calculateFee(10000, null, null, { config: LEGACY });
    expect(r.feePercent).toBe(10);
    expect(r.platformFee).toBe(1000);
    expect(r.creatorNet).toBe(9000);
    expect(r.brandFee).toBe(0);
    expect(r.brandPayable).toBe(10000);
    const old: any = await calculateFee(10000, { type: "zero_fee" } as any);
    expect(old.platformFee).toBe(0);
  });
  it("split ignores creator coupons and offer mode; creator % comes from Admin", async () => {
    const r: any = await calculateFee(10000, null, { type: "fee_rate_override", override_fee_rate: 2 }, { config: { ...SPLIT, offer_mode: true, creator_fee_pct: 2.5 } });
    expect(r.feePercent).toBe(2.5);
    expect(r.platformFee).toBe(250);
    expect(r.creatorNet).toBe(9750);
    expect(r.appliedCoupon).toBeUndefined();
  });
  it("brand coupons: 8% → 4%, ₹ off, 0%, never raise the fee", () => {
    expect(brandFeeFor(10000, SPLIT, { type: "fee_rate_override", override_fee_rate: 4 }).payable).toBe(10400);
    expect(brandFeeFor(10000, SPLIT, { type: "fee_rate_override", override_fee_rate: 12 }).fee).toBe(800);
    expect(brandFeeFor(10000, SPLIT, { type: "flat_discount", discount_amount: 300 }).fee).toBe(500);
    expect(brandFeeFor(10000, SPLIT, { type: "flat_discount", discount_amount: 5000 }).fee).toBe(0);
    expect(brandFeeFor(10000, SPLIT, { type: "zero_fee" }).payable).toBe(10000);
    expect(brandFeeFor(10000, SPLIT, { type: "fee_rate_override", override_fee_rate: 4 }).couponDiscount).toBe(400);
  });
  it("GST on the brand fee only when Ybex is GST registered", () => {
    expect(brandFeeFor(10000, SPLIT).gst).toBe(0);
    const g = brandFeeFor(10000, { ...SPLIT, platform_gst_registered: true });
    expect(g.gst).toBe(144);
    expect(g.payable).toBe(10944);
    expect(isSplitFee(SPLIT)).toBe(true);
    expect(isSplitFee(LEGACY)).toBe(false);
  });
});

describe("v364 · brand coupons + quote", () => {
  beforeEach(() => __resetFeeConfigCache());
  const coupon = { id: "c1", code: "DIWALI4", applies_to: "brand_fee", type: "fee_rate_override", override_fee_rate: 4, status: "active", usage_limit: 0, used_count: 0, per_user_limit: 1, min_campaign_value: 0 };
  it("checks status, dates, limits, minimum and kind", () => {
    expect(brandCouponProblem(coupon, { gross: 10000 })).toBe("");
    expect(brandCouponProblem({ ...coupon, applies_to: "creator" }, { gross: 10000 })).toMatch(/isn't a brand coupon/);
    expect(brandCouponProblem({ ...coupon, status: "paused" }, { gross: 10000 })).toMatch(/isn't active/);
    expect(brandCouponProblem({ ...coupon, valid_until: "2020-01-01T00:00:00Z" }, { gross: 10000 })).toMatch(/expired/);
    expect(brandCouponProblem({ ...coupon, usage_limit: 5, used_count: 5 }, { gross: 10000 })).toMatch(/fully used/);
    expect(brandCouponProblem(coupon, { gross: 10000, usedByThisBrand: 1 })).toMatch(/already used/);
    expect(brandCouponProblem({ ...coupon, min_campaign_value: 20000 }, { gross: 10000 })).toMatch(/20,000/);
    expect(cleanCouponCode(" diwali-4 ")).toBe("DIWALI-4");
  });
  it("quote: no coupon → ₹10,800; DIWALI4 → ₹10,400; bad code → error, full fee", async () => {
    const c = fakeClient(SPLIT, [coupon]);
    const q = await quoteBrandPayment(c, 10000, { brandId: "b1" });
    expect(q.total).toBe(10800);
    expect(q.creatorNet).toBe(10000);
    __resetFeeConfigCache();
    const q2 = await quoteBrandPayment(c, 10000, { brandId: "b1", couponCode: "diwali4" });
    expect(q2.total).toBe(10400);
    expect(q2.couponCode).toBe("DIWALI4");
    expect(q2.couponDiscount).toBe(400);
    __resetFeeConfigCache();
    const q3 = await quoteBrandPayment(c, 10000, { brandId: "b1", couponCode: "NOPE" });
    expect(q3.couponError).toMatch(/doesn't exist/);
    expect(q3.total).toBe(10800);
  });
  it("legacy config: the brand pays the deal amount, coupons aren't looked up", async () => {
    const q = await quoteBrandPayment(fakeClient(LEGACY, [coupon]), 10000, { couponCode: "DIWALI4" });
    expect(q.total).toBe(10000);
    expect(q.couponCode).toBeNull();
  });
  it("order notes round-trip; old orders have none; stamp fields", async () => {
    const q = await quoteBrandPayment(fakeClient(SPLIT, [coupon]), 10000, { brandId: "b1", couponCode: "DIWALI4" });
    const back = quoteFromNotes(quoteNotes(q))!;
    expect(back.total).toBe(10400);
    expect(back.gross).toBe(10000);
    expect(back.couponId).toBe("c1");
    expect(quoteFromNotes({ deal_id: "x", kind: "campaign_escrow" })).toBeNull();
    expect(brandStamp(back, 10400)).toEqual({ brand_fee_pct: 4, brand_fee_amount: 400, brand_fee_gst: 0, brand_paid_amount: 10400, coupon_code: "DIWALI4" });
  });
});

describe("v364 · wiring", () => {
  it("create-order charges the quote total, checks the coupon and writes the notes; quote endpoint exists", () => {
    const s = read("backend/payment_routes.ts");
    expect(s).toContain('router.post("/payments/quote"');
    expect(s).toContain("amount: Math.round(payableAmount * 100)");
    expect(s).toContain('code: "COUPON_INVALID"');
    expect(s).toContain("...quoteNotes(quote)");
    expect(s).toContain("paidRupees + 0.5 < Number(orderQuote.total)");
    expect(s).toContain("brandStamp(orderQuote, orderPaidRupees)");
    // v366 moved pin: the coupon is now counted through the atomic confirmBrandCoupon (DB function), which still falls
    // back to recordBrandCoupon when the function is missing — so both are pinned.
    expect(s).toContain("confirmBrandCoupon(");
    expect(read("backend/brandFee.ts")).toContain("await recordBrandCoupon(client, a.couponId");
  });
  it("UGC brief: brand fee required and stamped", () => {
    const u = read("backend/ugc_routes.ts");
    expect(u).toContain("briefQuote && paidRupees + 0.5 < Number(briefQuote.total || totalBudget)");
    expect(u).toContain("brandStamp(briefQuote, briefPaid)");
  });
  it("rate-card markup is off in the split model; creator previews read the creator %", () => {
    expect(read("backend/server.ts")).toContain("if (splitFeeOn()) return 0;");
    expect(read("backend/misc_routes.ts")).toContain('fee_kind: "split"');
  });
  it("Review & pay shows the server quote and sends the coupon (mobile + desktop + UGC)", () => {
    expect(read("src/components/chat/mobile/MobileEscrowSheet.jsx")).toContain("<BrandFeeSummary");
    expect(read("src/components/chat/systemMessage/SysContractSignedCard.jsx")).toContain("<BrandFeeSummary");
    expect(read("src/components/chat/ChatBox.jsx")).toContain("<BrandFeeSummary");
    expect(read("src/pages/brand/BrandUGCMobile.jsx")).toContain("couponCode: ugcFee.couponCode");
    expect(read("src/pages/brand/BrandUGCPost.jsx")).toContain("couponCode: ugcFee.couponCode");
    expect(read("src/lib/razorpay.js")).toContain("coupon_code: couponCode");
    const f = read("src/components/payments/BrandFeeSummary.jsx");
    expect(f).toContain('api.post("payments/quote"');
    expect(f).toContain("Service fee");
    expect(f).toContain("Total you pay");
  });
  it("Admin: creator % and brand % boxes, brand-fee coupons", () => {
    const a = read("src/components/admin/platformTools/FeesSettingsCard.jsx");
    expect(a).toContain('data-testid="creator-fee-pct"');
    expect(a).toContain('data-testid="brand-fee-pct"');
    expect(read("backend/admin_campaigns_settings_routes.ts")).toContain("current.brand_fee_pct = Math.max(0, Math.min(30");
    expect(read("src/components/admin/PlatformTools.jsx")).toContain('<option value="brand_fee">');
  });
  it("one version label (v364) and one Pixel loader", () => {
    expect(read("src/lib/appVersion.js")).toMatch(/const BUILT_IN = "v(3(6[4-9]|[7-9]\d)|[4-9]\d\d)"/); // v365: label moves with each version
    expect(read("src/components/feedback/FeedbackBot.jsx")).toContain('import { APP_VERSION } from "../../lib/appVersion"');
    expect(read("index.html")).not.toContain("fbevents.js");
    expect(read("src/lib/metaPixel.js")).toContain('META_PIXEL_ID = "965515649959745"');
  });
});
