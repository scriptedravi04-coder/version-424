// White-box tests: referral / invite reward math, creator coupon choice, referral + coupon routes.
// Tests marked it.fails document a real bug in the CURRENT code (see the "BUG:" comment above each).
import { describe, it, expect } from "vitest";
import express from "express";
import {
  DEFAULTS, referralCodeForId, normaliseConfig, rewardBlocks, freeDealsLeft, shareEarned, referralSummary, recordReferral,
} from "./referralProgram";
import { INVITE_DEFAULTS, normaliseInvite, kycApproved, profileComplete, fundedAmount, isCompleted, inviteWallet } from "./inviteRewards";
import { pickCreatorCoupon, resolveCreatorCoupon } from "./creatorCoupons";
import { setupMissingRoutes } from "./missing_routes";

const DAY = 86400e3;
const iso = (ms: number) => new Date(ms).toISOString();
const cfg = normaliseConfig({});

describe("referralProgram — config + codes", () => {
  it("referralCodeForId strips dashes, uppercases, first 8 chars; empty id → empty code", () => {
    expect(referralCodeForId("abcd-ef12-3456")).toBe("YBEX-ABCDEF12");
    expect(referralCodeForId("")).toBe("");
    expect(referralCodeForId(undefined as any)).toBe("");
  });
  it("normaliseConfig keeps admin values inside bounds, else defaults", () => {
    expect(cfg.signups_per_reward).toBe(DEFAULTS.signups_per_reward);
    const c = normaliseConfig({ signups_per_reward: 0, free_deals_per_reward: "5", share_pct_of_earnings: 101, min_withdraw: -1, is_active: "false" });
    expect(c.signups_per_reward).toBe(3); // 0 is below min 1
    expect(c.free_deals_per_reward).toBe(5);
    expect(c.share_pct_of_earnings).toBe(0.2);
    expect(c.min_withdraw).toBe(11);
    expect(c.is_active).toBe(true); // only boolean false turns it off
    expect(normaliseConfig({ is_active: false }).is_active).toBe(false);
    expect(c.friend_reward).toBe(INVITE_DEFAULTS.friend_reward);
  });
});

describe("referralProgram — reward blocks / free deals", () => {
  const now = Date.now();
  const refs = (n: number, at: number, status = "joined") =>
    Array.from({ length: n }, (_, i) => ({ id: `r${at}_${i}`, status, created_at: iso(at + i * 1000) }));

  it("every 3 counted joins = one block; rejected ones never count; to_next counts down", () => {
    const rb = rewardBlocks([...refs(6, now - 10 * DAY), ...refs(1, now - 5 * DAY, "rejected")], cfg);
    expect(rb.joined).toBe(6);
    expect(rb.blocks.length).toBe(2);
    expect(rb.to_next).toBe(3);
    expect(rewardBlocks(refs(2, now), cfg).to_next).toBe(1);
    expect(rewardBlocks([], cfg)).toEqual({ joined: 0, blocks: [], to_next: 3 });
  });

  it("block dates come from the 3rd join; free deals expire after free_deals_valid_days", () => {
    const start = Date.parse("2026-01-01T00:00:00Z");
    const rb = rewardBlocks(refs(3, start), cfg);
    expect(rb.blocks[0].completed_at).toBe(iso(start + 2000));
    expect(rb.blocks[0].expires_at).toBe(iso(start + 2000 + 180 * DAY));
    expect(rb.blocks[0].featured_until).toBe(iso(start + 2000 + 7 * DAY));
  });

  it("freeDealsLeft spends uses oldest-block-first and hides expired blocks", () => {
    const blocks = [
      { completed_at: "", free_deals: 2, expires_at: iso(now + 10 * DAY), featured_until: "" },
      { completed_at: "", free_deals: 2, expires_at: iso(now + 20 * DAY), featured_until: "" },
    ];
    expect(freeDealsLeft(blocks, 0, now)).toEqual({ left: 4, total: 4, expires_at: blocks[0].expires_at });
    expect(freeDealsLeft(blocks, 3, now)).toEqual({ left: 1, total: 2, expires_at: blocks[1].expires_at });
    expect(freeDealsLeft(blocks, 99, now).left).toBe(0);
    expect(freeDealsLeft(blocks, 0, now + 15 * DAY).left).toBe(2);
  });

  // BUG: the monthly cap per referrer (fraud guard) is cosmetic. recordReferral stores referrals over the cap with
  // status "over_cap" and the admin list shows "over monthly limit", but `counts()` only excludes "rejected", so
  // over-cap joins still earn fee-free deals, Featured days and invite cash. Fix (referralProgram.ts:61):
  // counts = !["rejected", "over_cap"].includes(status) (and the same in inviteRewards.loadInviteFacts `counted`).
  // v346: FIXED — this used to be it.fails (bug above is fixed in v346).
  it("joins over the monthly cap do not earn reward blocks", () => {
    const rb = rewardBlocks(refs(3, now - DAY, "over_cap"), cfg);
    expect(rb.blocks.length).toBe(0);
  });

  // BUG: free-deal uses are only COUNTED (referral_reward_uses rows), then charged against the oldest block,
  // even an expired one. A block that expired unused "absorbs" a use made later on a newer block, so the creator
  // gets an extra 0%-fee deal (Ybex loses the whole platform fee on it). Scenario: block A (3 joins 400 days ago,
  // expired 220 days ago, never used), block B (3 joins 30 days ago), one free deal used 10 days ago (so from B).
  // B has 1 left; the summary says 2 and resolveCreatorCoupon applies a zero_fee coupon to a 3rd deal.
  // Fix (referralProgram.ts:79-91 + freeDealUses): read the uses' created_at and spend each use on the oldest
  // block that was live at that time.
  // v346: FIXED — this used to be it.fails (bug above is fixed in v346).
  it("a use made after an old block expired is charged to the live block", async () => {
    const t = Date.now();
    const db: any = {
      referrals: [
        ...refs(3, t - 400 * DAY).map((r) => ({ ...r, referrer_id: "u1", referred_id: `a_${r.id}` })),
        ...refs(3, t - 30 * DAY).map((r) => ({ ...r, referrer_id: "u1", referred_id: `b_${r.id}` })),
      ],
      referral_reward_uses: [{ id: "use1", user_id: "u1", created_at: iso(t - 10 * DAY) }],
    };
    const s = await referralSummary({ supabase: null, privilegedSupabase: null, getDb: () => db }, "u1");
    expect(s.fd.left).toBe(1);
  });
});

describe("referralProgram — share of a friend's earnings", () => {
  it("0.2% of what each friend received, capped at ₹2,000 per friend, rounded to paise", () => {
    const m = new Map<string, number>([["a", 333], ["b", 2_000_000], ["c", 1_000_000]]);
    const s = shareEarned(["a", "b", "c", "missing"], m, cfg);
    expect(s.per).toEqual({ a: 0.67, b: 2000, c: 2000, missing: 0 });
    expect(s.total).toBe(4000.67);
  });
  it("cap 0 → nothing; pct 0 → nothing", () => {
    expect(shareEarned(["a"], new Map([["a", 1e6]]), { ...cfg, share_cap_per_creator: 0 }).total).toBe(0);
    expect(shareEarned(["a"], new Map([["a", 1e6]]), { ...cfg, share_pct_of_earnings: 0 }).total).toBe(0);
  });
});

describe("referralProgram — recordReferral fraud guards (local store)", () => {
  const mk = () => {
    const db: any = { users: [{ user_id: "abcdef12-0000-0000-0000-000000000000", email: "Ref@x.com", phone: "+91 98765 43210" }], referrals: [] };
    return { db, deps: { supabase: null, privilegedSupabase: null, getDb: () => db, saveDb: () => {} } };
  };
  it("unknown code, self (same id / email any case / last-10 phone digits), old account, already referred", async () => {
    const { deps } = mk();
    const code = "YBEX-ABCDEF12";
    expect((await recordReferral(deps, "YBEX-ZZZ", { id: "n1" })).reason).toBe("unknown_code");
    expect((await recordReferral(deps, code, { id: "abcdef12-0000-0000-0000-000000000000" })).reason).toBe("self");
    expect((await recordReferral(deps, code, { id: "n1", email: " ref@X.com " })).reason).toBe("self");
    expect((await recordReferral(deps, code, { id: "n1", phone: "9876543210" })).reason).toBe("self");
    expect((await recordReferral(deps, code, { id: "n1", createdAt: iso(Date.now() - 8 * DAY) })).reason).toBe("not_new");
    expect((await recordReferral(deps, code.toLowerCase(), { id: "n1" })).ok).toBe(true);
    expect((await recordReferral(deps, code, { id: "n1" })).reason).toBe("already");
  });
  it("programme off → nothing recorded", async () => {
    const { db, deps } = mk();
    db.referral_program = { is_active: false };
    expect((await recordReferral(deps, "YBEX-ABCDEF12", { id: "n2" })).reason).toBe("programme_off");
  });
});

describe("inviteRewards", () => {
  const ic = normaliseInvite({});
  it("normaliseInvite bounds", () => {
    expect(normaliseInvite({ friend_reward: -1, brand_invite_max_brands: "4" })).toMatchObject({ friend_reward: 21, brand_invite_max_brands: 4 });
  });
  it("friend rewards stop at the cap; welcome only when complete AND referred", () => {
    const w = inviteWallet(ic, { friendsComplete: Array.from({ length: 60 }, (_, i) => `f${i}`), brandQualified: [], iAmComplete: true, iWasReferred: false, myCompletedDeals: 0 });
    expect(w.friend_earned).toBe(1000);
    expect(w.friend_cap_reached).toBe(true);
    expect(w.welcome).toBe(0);
    expect(inviteWallet(ic, { friendsComplete: [], brandQualified: [], iAmComplete: true, iWasReferred: true, myCompletedDeals: 0 }).available).toBe(21);
  });
  it("brand rewards: max 10 brands, locked until 2 own completed deals", () => {
    const now = Date.parse("2026-10-19T00:00:00Z");
    const brands = Array.from({ length: 12 }, (_, i) => ({ id: `b${i}`, at: iso(now - (20 - i) * DAY) }));
    const locked = inviteWallet(ic, { friendsComplete: [], brandQualified: brands, iAmComplete: false, iWasReferred: false, myCompletedDeals: 1 }, now);
    expect(locked.brand_count).toBe(10);
    expect(locked.locked).toBe(5000);
    expect(locked.available).toBe(0);
    expect(locked.deals_to_unlock).toBe(1);
    expect(locked.featured_until).toBeNull(); // first 10 qualified 11-20 days ago, 7 featured days are over
    const open = inviteWallet(ic, { friendsComplete: ["a"], brandQualified: brands.slice(0, 1), iAmComplete: false, iWasReferred: false, myCompletedDeals: 2 }, now);
    expect(open.available).toBe(521);
    expect(open.locked).toBe(0);
  });
  it("fundedAmount: paid & not undone; deal vs order status lists differ", () => {
    expect(fundedAmount({ amount: 5000, escrow_hold: true }, "deal")).toBe(5000);
    expect(fundedAmount({ amount: 5000, escrow_hold: true, status: "refunded" }, "deal")).toBe(0);
    expect(fundedAmount({ amount: 5000, payment_status: "CAPTURED" }, "deal")).toBe(0);
    expect(fundedAmount({ amount: 5000, payment_status: "CAPTURED" }, "order")).toBe(5000);
    expect(fundedAmount({ agreed_amount: "7000", payment_status: "paid" }, "order")).toBe(7000);
    expect(fundedAmount({ amount: "x", escrow_hold: true }, "deal")).toBe(0);
    expect(fundedAmount(null, "deal")).toBe(0);
    expect(isCompleted({ payment_status: "released" })).toBe(true);
    expect(isCompleted({ status: "APPROVED" })).toBe(false);
  });
  it("profileComplete: KYC first; brand vs creator requirements; banned never", () => {
    expect(kycApproved({}, { status: "VERIFIED" })).toBe(true);
    expect(kycApproved({ kyc_status: "pending" })).toBe(false);
    const brand = { role: "brand", kyc_verified: true, picture: "p" };
    expect(profileComplete(brand, { company_name: "Acme", industry: "Food" }, 0)).toBe(true);
    expect(profileComplete({ ...brand, banned: true }, { company_name: "Acme", industry: "Food" }, 0)).toBe(false);
    const cr = { role: "creator", kyc_verified: true, picture: "p" };
    const p = { bio: "b", category: "c", instagram_handle: "i", rate_reel: 100 };
    expect(profileComplete(cr, p, 1)).toBe(true);
    expect(profileComplete(cr, p, 0)).toBe(false); // portfolio needed
    expect(profileComplete(cr, { ...p, rate_reel: 0, barter_mode: true }, 1)).toBe(true);
    expect(profileComplete(cr, { ...p, ig_followers: "0", instagram_handle: "" }, 1)).toBe(false); // "0" is not a value
    expect(profileComplete(null, p, 1)).toBe(false);
  });
});

describe("creatorCoupons.pickCreatorCoupon", () => {
  const now = Date.parse("2026-10-19T00:00:00Z");
  const auto = (o: any) => ({ status: "active", auto_apply: true, applies_to: "creators", ...o });
  it("a saved code beats auto offers; best for creator wins inside a pool", () => {
    const coupons = [auto({ id: "z", type: "zero_fee" }), { id: "s", status: "active", type: "fee_rate_override", override_fee_rate: 10 }];
    const reds = [{ coupon_id: "s", user_id: "c1", payouts_consumed: 0 }];
    expect(pickCreatorCoupon(coupons, reds, "c1", now)!.id).toBe("s");
    expect(pickCreatorCoupon(coupons, [], "c1", now)!.id).toBe("z");
    const pool = [auto({ id: "f", type: "flat_discount", discount_amount: 500 }), auto({ id: "o", type: "fee_rate_override", override_fee_rate: 2 })];
    expect(pickCreatorCoupon(pool, [], "c1", now)!.id).toBe("o");
  });
  it("respects dates, status, audience, usage limit, per-user limit and min deal value", () => {
    const base = auto({ id: "a", type: "zero_fee" });
    expect(pickCreatorCoupon([{ ...base, valid_until: iso(now - 1) }], [], "c", now)).toBeNull();
    expect(pickCreatorCoupon([{ ...base, valid_from: iso(now + 1) }], [], "c", now)).toBeNull();
    expect(pickCreatorCoupon([{ ...base, status: "paused" }], [], "c", now)).toBeNull();
    expect(pickCreatorCoupon([{ ...base, applies_to: "brands" }], [], "c", now)).toBeNull();
    expect(pickCreatorCoupon([{ ...base, usage_limit: 5, used_count: 5 }], [], "c", now)).toBeNull();
    expect(pickCreatorCoupon([base], [{ coupon_id: "a", user_id: "c", payouts_consumed: 1 }], "c", now)).toBeNull();
    const firstN = { ...base, applies_to_first_n_payouts: 3 };
    const p = pickCreatorCoupon([firstN], [{ coupon_id: "a", user_id: "c", payouts_consumed: 2 }], "c", now)!;
    expect([p._dealNumber, p._dealsTotal]).toEqual([3, 3]);
    expect(pickCreatorCoupon([{ ...base, min_campaign_value: 10000 }], [], "c", now, 9999)).toBeNull();
    expect(pickCreatorCoupon([{ ...base, min_campaign_value: 10000 }], [], "c", now, 10000)!.id).toBe("a");
    // another creator's redemptions don't count against this one
    expect(pickCreatorCoupon([base], [{ coupon_id: "a", user_id: "other", payouts_consumed: 1 }], "c", now)!.id).toBe("a");
  });
  it("resolveCreatorCoupon: no client / no creator → null", async () => {
    expect(await resolveCreatorCoupon(null, "c")).toBeNull();
    expect(await resolveCreatorCoupon({}, null)).toBeNull();
  });
});

// ---------------------------------------------------------------- routes (missing_routes.ts)
async function serve(app: express.Express, fn: (base: string) => Promise<void>) {
  const srv = app.listen(0);
  await new Promise((r) => srv.once("listening", r));
  const port = (srv.address() as any).port;
  try { await fn(`http://127.0.0.1:${port}`); } finally { srv.close(); }
}
function mkApp(db: any, user: any) {
  const app = express(); app.use(express.json());
  const router = express.Router();
  setupMissingRoutes(app, router, { supabase: null, privilegedSupabase: null, getDb: () => db, parseAuthUser: async () => user } as any);
  app.use("/api", router);
  return app;
}
const post = (base: string, p: string, body: any) => fetch(base + p, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });

describe("routes: /coupons/validate + /referral/stats", () => {
  it("validate: needs sign-in and a code; code is case-insensitive; plural audience works", async () => {
    const db = { coupons: [{ id: "c1", code: "Save10", type: "flat_discount", discount_amount: "100", status: "ACTIVE", applies_to: "creators" }] };
    await serve(mkApp(db, null), async (base) => {
      expect((await post(base, "/api/coupons/validate", { code: "save10" })).status).toBe(401);
    });
    await serve(mkApp(db, { user_id: "u", role: "creator" }), async (base) => {
      expect((await post(base, "/api/coupons/validate", { code: "  " })).status).toBe(400);
      const r = await post(base, "/api/coupons/validate", { code: "save10" });
      expect(r.status).toBe(200);
      expect((await r.json()).discount_amount).toBe(100);
    });
    await serve(mkApp(db, { user_id: "b", role: "brand" }), async (base) => {
      expect((await post(base, "/api/coupons/validate", { code: "SAVE10" })).status).toBe(400);
    });
  });
  it("validate: min deal value with no amount sent is refused; used-up and not-yet-active codes refused", async () => {
    const db = { coupons: [
      { id: "m", code: "MIN", status: "active", min_campaign_value: 5000 },
      { id: "u", code: "USED", status: "active", usage_limit: 1, used_count: 1 },
      { id: "f", code: "SOON", status: "active", valid_from: iso(Date.now() + DAY) },
    ] };
    await serve(mkApp(db, { user_id: "u", role: "creator" }), async (base) => {
      expect((await post(base, "/api/coupons/validate", { code: "MIN" })).status).toBe(400);
      expect((await post(base, "/api/coupons/validate", { code: "MIN", campaign_amount: "5000" })).status).toBe(200);
      expect((await post(base, "/api/coupons/validate", { code: "USED" })).status).toBe(400);
      expect((await post(base, "/api/coupons/validate", { code: "SOON" })).status).toBe(400);
      expect((await post(base, "/api/coupons/validate", { code: "NOPE" })).status).toBe(404);
    });
  });
  it("referral stats: 401 when signed out; pending counted; reward amount from config", async () => {
    const db = { referrals: [{ id: "r1", referrer_id: "u1", referred_id: "f1", status: "PENDING" }], referral_program: { friend_reward: 50 } };
    await serve(mkApp(db, null), async (base) => {
      expect((await fetch(base + "/api/referral/stats")).status).toBe(401);
    });
    await serve(mkApp(db, { user_id: "u1", role: "creator" }), async (base) => {
      const d = await (await fetch(base + "/api/referral/stats")).json();
      expect(d.total_referred).toBe(1);
      expect(d.pending).toBe(1);
      expect(d.reward_amount).toBe(50);
      expect(d.rewards_earned).toBe(0);
    });
  });
});
