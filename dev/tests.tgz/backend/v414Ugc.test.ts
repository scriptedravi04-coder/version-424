// v414 — UGC lifecycle fixes (C1–C9). Runtime tests on the real handlers with a local store (no Supabase),
// plus source checks where a database race can't be run here.
import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";
import { createUgcLifecycleHandlers, setupUgcOrderRoutes, setupUgcBrowseRoutes } from "./ugc_routes";
import { createUgcLifecycleService } from "./services/ugcLifecycleService";
import { createCampaignLifecycleHandlers } from "./campaigns_routes";
import { brandCanCancelOrderAtMs, ugcStallNoticesDue, ugcStageStartMs, runUgcDeadlineChecks } from "./services/ugcDeadlineService";

const read = (f: string) => fs.readFileSync(path.join(__dirname, "..", f), "utf8");
const H = 3600000;
const BRAND = "b0000000-0000-4000-8000-000000000001";
const CREATOR = "c0000000-0000-4000-8000-000000000002";
const CREATOR2 = "e0000000-0000-4000-8000-000000000004";
const OID = "ugcord_v414_1";
const B = { user_id: BRAND, role: "brand" };
const C = { user_id: CREATOR, role: "creator" };
const C2 = { user_id: CREATOR2, role: "creator" };
const ADMIN = { user_id: "admin1", role: "admin" };

function mk(orderExtra: any = {}, briefExtra: any = {}, extraOrders: any[] = []) {
  const db: any = {
    ugc_briefs: [{ id: "brief_1", brand_id: BRAND, budget: 5000, max_creators: 3, claimed_count: 1, status: "OPEN", deliverable_type: "ugc_video_raw", is_collaboration: false, requires_live_link: false, created_at: new Date(Date.now() - 100 * H).toISOString(), ...briefExtra }],
    ugc_orders: [{ id: OID, brief_id: "brief_1", brand_id: BRAND, creator_id: CREATOR, status: "ACCEPTED", creator_payout: 5000, escrow_amount: 5000, deliverable_type: "ugc_video_raw", is_collaboration: false, requires_live_link: false, revision_count: 3, revisions_used: 0, payment_status: "ESCROW_HELD", ...orderExtra }, ...extraOrders],
    chat_threads: [{ id: `thread_ugc_${OID}`, deal_id: OID, ugc_order_id: OID, brand_id: BRAND, creator_id: CREATOR, is_ugc: true, status: "ACTIVE", flow_state: "ACTIVE" }],
    chat_messages: [], transactions: [], notifications: [], ugc_refunds: [], users: [],
  };
  let actor: any;
  const getDb = () => db, saveDb = () => {};
  const parseAuthUser = async () => actor;
  const svc = createUgcLifecycleService({ supabase: null, privilegedSupabase: null, getDb, saveDb, getIsoNow: () => new Date().toISOString(), ensureUGCChatThread: async (o: any) => db.chat_threads.find((t: any) => t.deal_id === o.id) || { id: o.id }, insertChatMessageToSupabase: async () => {} } as any);
  const camp = createCampaignLifecycleHandlers({ supabase: null, privilegedSupabase: null, getDb, saveDb, parseAuthUser, insertChatMessageToSupabase: async () => ({}) } as any);
  const h = createUgcLifecycleHandlers({ supabase: null, privilegedSupabase: null, getDb, parseAuthUser, syncUgcLifecycleEvent: svc, handleThreadApproveLiveLinks: camp.handleThreadApproveLiveLinks, handleThreadApproveContent: camp.handleThreadApproveContent, handleCampaignRevision: camp.handleCampaignRevision } as any);
  const routes: Record<string, any> = {};
  const router: any = {
    // Express: the first registration of a path wins — mirror that here.
    post: (p: any, fn: any) => (Array.isArray(p) ? p : [p]).forEach((x: string) => { if (!routes["POST " + x]) routes["POST " + x] = fn; }),
    get: (p: any, fn: any) => (Array.isArray(p) ? p : [p]).forEach((x: string) => { if (!routes["GET " + x]) routes["GET " + x] = fn; }),
  };
  setupUgcOrderRoutes({} as any, router, { handleThreadApproveContent: camp.handleThreadApproveContent, ...h } as any);
  setupUgcBrowseRoutes({} as any, router, { supabase: null, privilegedSupabase: null, getDb, saveDb, parseAuthUser, ensureUGCChatThread: async () => ({}), enrichBriefsWithBrandProfiles: async (b: any) => b } as any);
  const call = async (key: string, user: any, body: any = {}, params: any = { id: OID, threadId: OID }) => {
    actor = user; let status = 200; let json: any;
    const res: any = { status(s: number) { status = s; return this; }, json(j: any) { json = j; return this; }, setHeader() {} };
    await routes[key]({ params, body, query: {}, originalUrl: key, app: { get: () => null } }, res);
    return { status, json };
  };
  return { db, call };
}

const COLLAB = { deliverable_type: "collab_reel", is_collaboration: true, requires_live_link: true };

describe("C1 · no live link / payout before the draft is approved", () => {
  it("DISPUTED order without draft approval: live link refused", async () => {
    const { db, call } = mk({ ...COLLAB, status: "DISPUTED", video_url: "https://x/v.mp4" });
    const r = await call("POST /ugc/orders/:id/submit-live-link", C, { live_link: "https://instagram.com/p/abc" });
    expect(r.status).toBe(409);
    expect(r.json.code).toBe("DRAFT_NOT_APPROVED");
    expect(db.ugc_orders[0].live_link).toBeUndefined();
  });
  it("live link on file but draft never approved: approve does NOT pay out", async () => {
    const { db, call } = mk({ ...COLLAB, status: "LINKS_UNDER_REVIEW", video_url: "https://x/v.mp4", live_link: "https://instagram.com/p/abc" });
    const r = await call("POST /ugc/orders/:id/approve", B, {});
    expect(r.status).toBe(200);
    expect(r.json.code).toBe("DRAFT_APPROVED_ONLY");
    expect(db.ugc_orders[0].status).not.toBe("COMPLETED");
    expect(db.ugc_orders[0].payment_status).not.toBe("RELEASED");
    expect(db.transactions.length).toBe(0);
    const r2 = await call("POST /ugc/orders/:id/approve", B, { action: "approve_live_links" });
    // draft is approved now → the live-link approval is allowed
    expect([200]).toContain(r2.status);
  });
  it("explicit approve_live_links without draft approval → 409", async () => {
    const { db, call } = mk({ ...COLLAB, status: "LINKS_UNDER_REVIEW", video_url: "https://x/v.mp4", live_link: "https://instagram.com/p/abc" });
    const r = await call("POST /ugc/orders/:id/approve", B, { action: "approve_live_links" });
    expect(r.status).toBe(409);
    expect(r.json.code).toBe("DRAFT_NOT_APPROVED");
    expect(db.transactions.length).toBe(0);
  });
  it("approved draft: live link accepted as before", async () => {
    const { call } = mk({ ...COLLAB, status: "AWAITING_LIVE_LINK", video_url: "https://x/v.mp4", draft_approved_at: new Date().toISOString() });
    const r = await call("POST /ugc/orders/:id/submit-live-link", C, { live_link: "https://instagram.com/p/abc" });
    expect(r.status).toBe(200);
  });
});

describe("C2 · submit can't revive a cancelled / expired order", () => {
  it("expired order can't be approved", async () => {
    const { call } = mk({ status: "EXPIRED", video_url: "https://x/v.mp4" });
    const r = await call("POST /ugc/orders/:id/approve", B, {});
    expect(r.status).toBe(409);
  });
  it("submit write is conditional and brand cancel marks the money refunded", () => {
    const life = read("backend/services/ugcLifecycleService.ts");
    expect(life).toMatch(/action === 'SUBMIT_DELIVERABLE'\) \{\s*orderWriteQuery = orderWriteQuery\s*\.not\('status', 'in'/);
    expect(life).toContain(".is('cancelled_at', null)");
    expect(life).toContain("code: 'ORDER_CLOSED', _status: 409");
    expect(read("backend/services/ugcDeadlineService.ts")).toContain('status: "CANCELLED", payment_status: "REFUNDED", cancelled_at: nowIso');
  });
});

describe("C3 · legacy /ugc-orders/:orderId/submit goes through the normal submit", () => {
  it("brief id on a multi-slot brief → the caller's own order only", async () => {
    const other = { id: "ugcord_other", brief_id: "brief_1", brand_id: BRAND, creator_id: CREATOR2, status: "ACCEPTED", deliverable_type: "ugc_video_raw", requires_live_link: false, is_collaboration: false };
    const { db, call } = mk({}, {}, [other]);
    db.chat_threads.push({ id: "thread_ugc_ugcord_other", deal_id: "ugcord_other", brand_id: BRAND, creator_id: CREATOR2, is_ugc: true });
    const r = await call("POST /ugc-orders/:orderId/submit", C2, { video_url: "https://cdn.example.com/mine.mp4" }, { orderId: "brief_1" });
    expect(r.status).toBe(200);
    expect(db.ugc_orders.find((o: any) => o.id === "ugcord_other").status).toBe("SUBMITTED");
    expect(db.ugc_orders.find((o: any) => o.id === OID).video_url).toBeUndefined();
    // a real chat message was written (lifecycle ran)
    expect(db.chat_messages.some((m: any) => m.metadata?.action === "deliverable_submitted")).toBe(true);
  });
  it("closed order is refused", async () => {
    const { call } = mk({ status: "CANCELLED", payment_status: "REFUNDED" });
    const r = await call("POST /ugc-orders/:orderId/submit", C, { video_url: "https://cdn.example.com/v.mp4" }, { orderId: OID });
    expect(r.status).toBe(409);
  });
});

describe("C5 · brand cancel waits for the order's own deadline", () => {
  it("72h brief → 72h, 24h brief → 24h", () => {
    const T = Date.parse("2026-11-01T00:00:00Z");
    expect(brandCanCancelOrderAtMs({ created_at: new Date(T).toISOString(), internal_deadline: new Date(T + 72 * H).toISOString() }, 72)).toBe(T + 72 * H);
    expect(brandCanCancelOrderAtMs({ created_at: new Date(T).toISOString(), internal_deadline: new Date(T + 24 * H).toISOString() }, 24)).toBe(T + 24 * H);
    expect(brandCanCancelOrderAtMs({ created_at: new Date(T).toISOString() }, 48)).toBe(T + 48 * H);
    expect(brandCanCancelOrderAtMs({}, 48)).toBeNull();
  });
});

describe("C6 · stalled orders after the first draft", () => {
  const now = Date.parse("2026-11-07T06:30:00Z");
  it("pure rules", () => {
    const sub = { id: "o", status: "SUBMITTED" };
    expect(ugcStallNoticesDue(sub, 48, now - 47 * H, now)).toEqual([]);
    expect(ugcStallNoticesDue(sub, 48, now - 49 * H, now).map((n) => n.kind)).toEqual(["REVIEW_REMINDER"]);
    expect(ugcStallNoticesDue(sub, 48, now - 97 * H, now).map((n) => n.kind)).toEqual(["REVIEW_REMINDER", "REVIEW_ADMIN"]);
    const rev = { id: "o", status: "REVISION_REQUESTED" };
    expect(ugcStallNoticesDue(rev, 48, now - 47 * H, now)).toEqual([]);
    expect(ugcStallNoticesDue(rev, 48, now - 49 * H, now).map((n) => n.kind)).toEqual(["REVISION_OVERDUE"]);
    expect(ugcStallNoticesDue(rev, undefined, now - 71 * H, now)).toEqual([]); // unknown window → 72h
    expect(ugcStallNoticesDue({ id: "o", status: "CANCELLED" }, 48, now - 200 * H, now)).toEqual([]);
    expect(ugcStageStartMs({ status: "SUBMITTED", delivered_at: "2026-11-01T00:00:00Z" }, [
      { metadata: { action: "deliverable_submitted" }, created_at: "2026-11-03T00:00:00Z" },
      { metadata: { stall_key: "x" }, created_at: "2026-11-05T00:00:00Z" },
    ])).toBe(Date.parse("2026-11-03T00:00:00Z"));
  });
  it("cron: brand reminder once, admin alert after 96h, never moves money", async () => {
    const db: any = {
      ugc_orders: [{ id: "o1", brief_id: "b1", brand_id: BRAND, creator_id: CREATOR, status: "SUBMITTED", video_url: "https://x/v.mp4", payment_status: "ESCROW_HELD", delivered_at: new Date(now - 50 * H).toISOString(), created_at: new Date(now - 80 * H).toISOString() }],
      ugc_briefs: [{ id: "b1", brand_id: BRAND, title: "Serum", delivery_hours: 48 }],
      chat_threads: [{ id: "o1", deal_id: "o1" }], chat_messages: [], notifications: [], users: [],
    };
    const deps: any = { supabase: null, privilegedSupabase: null, getDb: () => db, saveDb: () => {}, releaseBriefSlot: async () => {}, now: () => new Date(now) };
    const r1 = await runUgcDeadlineChecks(deps);
    expect(r1.stall_notices_sent).toBe(1);
    expect(db.notifications.filter((n: any) => n.user_id === BRAND && n.type === "UGC_REVIEW_REMINDER").length).toBe(1);
    expect(db.chat_messages.filter((m: any) => m.metadata?.stall_kind === "REVIEW_REMINDER").length).toBe(1);
    const r2 = await runUgcDeadlineChecks(deps);
    expect(r2.stall_notices_sent).toBe(0);
    deps.now = () => new Date(now + 50 * H);
    const r3 = await runUgcDeadlineChecks(deps);
    expect(r3.stall_notices_sent).toBe(1);
    expect(db.notifications.some((n: any) => n.type === "UGC_REVIEW_OVERDUE_ADMIN")).toBe(true);
    expect(db.ugc_orders[0].status).toBe("SUBMITTED");
    expect(db.ugc_orders[0].payment_status).toBe("ESCROW_HELD");
  });
  it("cron: revision not re-uploaded in the window → brand + admin told once", async () => {
    const db: any = {
      ugc_orders: [{ id: "o2", brief_id: "b1", brand_id: BRAND, creator_id: CREATOR, status: "REVISION_REQUESTED", video_url: "https://x/v.mp4", updated_at: new Date(now - 30 * H).toISOString(), created_at: new Date(now - 80 * H).toISOString() }],
      ugc_briefs: [{ id: "b1", brand_id: BRAND, title: "Serum", delivery_hours: 24 }],
      chat_threads: [], chat_messages: [], notifications: [], users: [],
    };
    const deps: any = { supabase: null, privilegedSupabase: null, getDb: () => db, saveDb: () => {}, releaseBriefSlot: async () => {}, now: () => new Date(now) };
    expect((await runUgcDeadlineChecks(deps)).stall_notices_sent).toBe(1);
    expect((await runUgcDeadlineChecks(deps)).stall_notices_sent).toBe(0);
    expect(db.notifications.some((n: any) => n.user_id === BRAND && n.type === "UGC_REVISION_OVERDUE")).toBe(true);
    expect(db.notifications.some((n: any) => n.type === "UGC_REVISION_OVERDUE_ADMIN")).toBe(true);
  });
});

describe("C7 · admin actions notify creator and brand", () => {
  it("admin approves → both get a notification", async () => {
    const { db, call } = mk({ status: "SUBMITTED", video_url: "https://x/v.mp4" });
    const r = await call("POST /ugc/orders/:id/approve", ADMIN, {});
    expect(r.status).toBe(200);
    expect(db.notifications.some((n: any) => n.user_id === BRAND)).toBe(true);
    expect(db.notifications.some((n: any) => n.user_id === CREATOR)).toBe(true);
  });
  it("brand action still notifies only the creator", async () => {
    const { db, call } = mk({ status: "SUBMITTED", video_url: "https://x/v.mp4" });
    await call("POST /ugc/orders/:id/approve", B, {});
    expect(db.notifications.some((n: any) => n.user_id === CREATOR)).toBe(true);
    expect(db.notifications.some((n: any) => n.user_id === BRAND && n.type !== "payout_due")).toBe(false);
  });
});

describe("C8 · brief cancel never refunds an already-refunded slot", () => {
  it("an old order refund (CANCELLED + REFUNDED) is not an open slot", async () => {
    const refunded = { id: "ugcord_old", brief_id: "brief_1", brand_id: BRAND, creator_id: CREATOR2, status: "CANCELLED", payment_status: "REFUNDED" };
    const { call } = mk({}, { max_creators: 3, claimed_count: 1 }, [refunded]);
    const r = await call("GET /ugc/briefs/:id/cancel-quote", B, {}, { id: "brief_1" });
    expect(r.status).toBe(200);
    expect(r.json.open_slots).toBe(1); // 3 − 1 working − 1 already refunded
  });
  it("a brand order cancel whose slot close failed (claim kept) is not refunded again", async () => {
    const cancelled = { id: "ugcord_bc", brief_id: "brief_1", brand_id: BRAND, creator_id: CREATOR2, status: "CANCELLED", payment_status: "REFUNDED", expiry_reason: "BRAND_CANCELLED" };
    const { db, call } = mk({}, { max_creators: 3, claimed_count: 2 }, [cancelled]);
    db.ugc_refunds.push({ id: "ugcref_ord_ugcord_bc", brief_id: "brief_1", amount: 5000, slots: 1 });
    const r = await call("GET /ugc/briefs/:id/cancel-quote", B, {}, { id: "brief_1" });
    expect(r.json.open_slots).toBe(1);
  });
  it("normal brand order cancel (slot already removed) is unchanged", async () => {
    const cancelled = { id: "ugcord_bc", brief_id: "brief_1", brand_id: BRAND, creator_id: CREATOR2, status: "CANCELLED", payment_status: "REFUNDED", expiry_reason: "BRAND_CANCELLED" };
    const { db, call } = mk({}, { max_creators: 2, claimed_count: 1 }, [cancelled]);
    db.ugc_refunds.push({ id: "ugcref_ord_ugcord_bc", brief_id: "brief_1", amount: 5000, slots: 1 });
    const r = await call("GET /ugc/briefs/:id/cancel-quote", B, {}, { id: "brief_1" });
    expect(r.json.open_slots).toBe(1);
  });
});

describe("C4 / C9 · chat cards", () => {
  it("desktop draft card stays approved through the live-link steps and uses draft_approved_at", () => {
    const s = read("src/components/chat/ContentProofNotice.jsx");
    for (const st of ["PROOF_SUBMITTED", "LINKS_UNDER_REVIEW", "REVISION_REQUESTED_LINKS", "REVISION_DECLINED_LINKS", "AWAITING_LIVE_LINK"]) expect(s).toContain(`'${st}'`);
    expect(s).toContain("DRAFT_APPROVED_STEPS.includes(flowUpper)");
    expect(s).toContain("thread?.ugc_order?.draft_approved_at");
    expect(s).toContain("isOrderClosedCard");
  });
  it("mobile cards hide review / upload on closed orders", () => {
    expect(read("src/components/chat/mobile/MobileDeliverableCard.jsx")).toContain("!isSuperseded && !orderClosed");
    expect(read("src/components/chat/mobile/MobileBriefCards.jsx")).toContain("onOpenUpload && !orderClosed");
  });
});
