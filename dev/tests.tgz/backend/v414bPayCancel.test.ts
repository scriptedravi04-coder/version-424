import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";
import { isKnownLivePostUrl, livePostKey } from "./campaignGuards";

const read = (f: string) => fs.readFileSync(path.join(__dirname, f), "utf8");

describe("v414b #8 live post links", () => {
  it("accepts real post links", () => {
    for (const u of [
      "https://www.instagram.com/stories/someuser/3412345678901234567/",
      "https://www.threads.net/@someuser/post/C9abcDEF123",
      "https://www.threads.com/@some.user/post/C9abcDEF123",
      "https://www.facebook.com/share/1AbCdEf234/",
      "https://www.facebook.com/share/r/1AbCdEf234/",
      "https://www.facebook.com/share/v/1AbCdEf234/",
      "https://www.facebook.com/share/p/1AbCdEf234/",
      "https://www.instagram.com/share/reel/BAabc123xyz",
      "https://www.instagram.com/share/BAabc123xyz",
      "https://www.youtube.com/live/AbCdEfGhIjK",
      "https://www.instagram.com/reel/C1abc/",
      "https://youtu.be/AbCdEfGhIjK",
    ]) expect(isKnownLivePostUrl(u), u).toBe(true);
  });
  it("still rejects profiles and home pages", () => {
    for (const u of [
      "https://www.instagram.com/someuser/",
      "https://www.instagram.com/",
      "https://www.instagram.com/stories/someuser/",
      "https://www.threads.net/@someuser",
      "https://www.facebook.com/",
      "https://www.facebook.com/share/",
      "https://www.youtube.com/",
      "https://www.youtube.com/@channel",
      "https://example.com/post/1",
    ]) expect(isKnownLivePostUrl(u), u).toBe(false);
  });
});

describe("v414b #20 livePostKey", () => {
  it("one key per YouTube video", () => {
    const k = "yt:AbCdEfGhIjK";
    expect(livePostKey("https://youtu.be/AbCdEfGhIjK?si=xyz")).toBe(k);
    expect(livePostKey("https://www.youtube.com/watch?v=AbCdEfGhIjK&t=10")).toBe(k);
    expect(livePostKey("https://m.youtube.com/shorts/AbCdEfGhIjK/")).toBe(k);
    expect(livePostKey("https://youtube.com/live/AbCdEfGhIjK")).toBe(k);
  });
  it("one key per Instagram post", () => {
    const k = "ig:C1abc_X";
    expect(livePostKey("https://www.instagram.com/p/C1abc_X/")).toBe(k);
    expect(livePostKey("https://instagram.com/reel/C1abc_X?igsh=1")).toBe(k);
    expect(livePostKey("https://www.instagram.com/reels/C1abc_X")).toBe(k);
    expect(livePostKey("https://www.instagram.com/tv/C1abc_X")).toBe(k);
    expect(livePostKey("https://www.instagram.com/some.user/reel/C1abc_X/")).toBe(k);
  });
  it("others: host + path, no query / trailing slash", () => {
    expect(livePostKey("https://www.x.com/a/status/123?s=20")).toBe("x.com/a/status/123");
    expect(livePostKey("https://www.facebook.com/watch/?v=999")).toBe("facebook.com/watch?v=999");
  });
});

describe("v414b #1 paying a closed deal", () => {
  const src = read("payment_routes.ts");
  it("create-order refuses a closed deal", () => {
    expect(src).toMatch(/DEAL_CLOSED/);
    expect(src).toMatch(/select\('id, agreed_amount, status, brand_id'\)/);
  });
  it("persistEscrowPayment only revives open deals and alerts admins", () => {
    expect(src).toMatch(/\.not\('status', 'in', '\(CANCELLED,REFUNDED,COMPLETED\)'\)\.select\('id'\)/);
    expect(src).toMatch(/Payment received after the deal was cancelled — Ybex will refund the brand/);
    expect(src).toMatch(/let targetThreadId = dealClosedAfterPay \? null/);
  });
});

describe("v414b #14 / #15 slots and UGC refunds", () => {
  it("unfunded cancel and full refund cancel the campaign application", () => {
    expect(read("campaign_lifecycle.ts")).toMatch(/campaign_applications'\)\.update\(\{ status: 'CANCELLED' \}\)/);
    expect(read("payment_routes.ts")).toMatch(/campaign_applications'\)\.update\(\{ status: 'CANCELLED' \}\)/);
  });
  it("accept ignores closed threads", () => {
    const s = read("campaigns_routes.ts");
    expect(s).toMatch(/select\('id, status, flow_state'\)/);
    expect(s).toMatch(/\['CANCELLED', 'REFUNDED', 'COMPLETED'\]\.includes\(String\(t\?\.flow_state/);
  });
  it("full refund of a UGC payment closes the order", () => {
    const s = read("payment_routes.ts");
    expect(s).toMatch(/existingTx\.ugc_order_id && targetStatus === 'PROCESSED'/);
    expect(s).toMatch(/payment_status: 'REFUNDED', escrow_hold: false/);
    expect(s).toMatch(/\.neq\('status', 'COMPLETED'\)\.select\('id'\)/);
  });
});
