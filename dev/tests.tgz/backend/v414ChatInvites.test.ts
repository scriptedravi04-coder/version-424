// v414: chat + invite fixes (D1–D13). Runtime tests on the real routes with a local store.
import { describe, it, expect } from "vitest";
import express from "express";
import http from "http";
import {
  checkComprehensiveDisallowedContent as check, maskContactDetails, isAllowedLinkToken,
  splitNumberAcrossMessages, resetRecentMessageBuffer,
} from "./contactSecurityFilter";
import { setupChatCoreRoutes, userMessageType, isChatClosed, cleanClientMsgId, attachmentLabel } from "./chat_routes";
import { setupCreatorsRoutes } from "./creators_routes";
import { setupBlockRoutes } from "./blockUsers";
import { duplicateInvite, inviteViewStatus, isInviteExpired, WITHDRAWN_REASON } from "./directInvites";
import { checkChatAttachmentType, chatAttachmentThreadId } from "./misc_routes";

async function serve(app: express.Express, fn: (base: string) => Promise<void>) {
  const srv = http.createServer(app).listen(0);
  await new Promise((r) => srv.once("listening", r));
  const port = (srv.address() as any).port;
  try { await fn(`http://127.0.0.1:${port}/api`); } finally { srv.close(); }
}
const post = (url: string, body: any) => fetch(url, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });

// ------------------------------------------------------------------ filter table (D3, D4, D5)
describe("v414 contact filter", () => {
  const PASS = [
    "Please tag @qafoods in the reel", "Collab post with @qafoods.official", "thanks...", "Okay...", "Sure...",
    "1 IG - Reel, 2 stories", "FB - post", "No. of reels 2, budget 25000", "I'll mail the product, budget 150000",
    "Order id 2026110712345", "📎 Attached file: Screenshot_20261107-183045.png",
    "drive.google.com/file/d/abc", "https://www.instagram.com/reel/abc123/", "https://youtu.be/abc",
    "payment kab aayega?", "Ybex payment done", "paytm", "is gpay accepted?", "I paid via upi on ybex",
    "upi payment failed, retry?", "meet at icici office", "890000 followers, avg reach 2300000",
    "budget is ₹15,000 for 2 reels", "Who should I contact about shipping?", "my phone broke",
  ];
  const BLOCK: [string, string?][] = [
    ["call me 9876543210"], ["9 8 7 6 5 4 3 2 1 0"], ["nine eight seven six five four three two one zero"],
    ["number: 98765 43210"], ["insta id: ravi_k"], ["my insta is @ravi_k dm me"], ["mail me ravi.k@gmail.com"],
    ["wa.me/919876543210"], ["telegram @ravik"], ["whatsapp me on 98765-43210"], ["+91 98765 43210"],
    ["ravi@gmail.com/ybex.in"], ["wa.me/919876543210?drive.google.com/"], ["9876543210?ybex.club"],
    ["drive.google.com/file/d/9876543210/view"], ["📎 Attached file: 9876543210.png"],
    ["upi ravi at okaxis", "UPI"], ["gpay pe ravi okicici", "UPI"], ["ravi@okaxis", "UPI"], ["my upi id: ravi123@ybl", "UPI"],
    ["paytm karo bhai", "PAY_OUTSIDE"], ["pay me cash outside ybex", "PAY_OUTSIDE"], ["neft karo", "PAY_OUTSIDE"],
    ["send money on phonepe", "PAY_OUTSIDE"], ["tag me @ravi_k and dm me"], ["follow @ravi_k"], ["ravi_k"], ["ig - ravi_k"],
  ];
  for (const t of PASS) it(`passes: ${t}`, () => { resetRecentMessageBuffer(); expect(check(t).blocked, check(t).code).toBe(false); });
  for (const [t, code] of BLOCK) it(`blocks: ${t}`, () => {
    resetRecentMessageBuffer();
    const r = check(t);
    expect(r.blocked).toBe(true);
    if (code) expect(r.code).toBe(code);
  });
  it("PAY_OUTSIDE message", () => expect(check("paytm karo bhai").message).toBe("Payments must stay inside Ybex."));
  it("allowed links: exact host only", () => {
    expect(isAllowedLinkToken("https://www.instagram.com/reel/abc123/")).toBe(true);
    expect(isAllowedLinkToken("evil.com/drive.google.com/")).toBe(false);
    expect(isAllowedLinkToken("ybex.in.evil.com")).toBe(false);
  });
  it("mask hides UPI ids and phones, keeps order ids", () => {
    expect(maskContactDetails("Pay to ravi@okaxis or call 98765 43210, order 2026110712345"))
      .toBe("Pay to [hidden] or call [hidden], order 2026110712345");
  });
  it("split number across messages", () => {
    expect(splitNumberAcrossMessages("43210", ["98765"])).toBe(true);
    expect(splitNumberAcrossMessages("43210", ["98765", "budget is fine"])).toBe(false);
  });
});

// ------------------------------------------------------------------ chat route (D1, D2, D6, D7, D8, client_msg_id)
function chatApp(db: any, user: any, opts: any = {}) {
  const app = express(); app.use(express.json());
  const router = express.Router();
  setupChatCoreRoutes(app, router, {
    supabase: opts.client || null, privilegedSupabase: opts.client || null, getDb: () => db, saveDb: () => {},
    parseAuthUser: async () => user, ensureUGCChatThread: async () => null, populateThreadData: async (t: any[]) => t,
    insertChatMessageToSupabase: opts.insert || (async () => ({ data: null, error: null })),
  } as any);
  app.use("/api", router);
  return app;
}
const mkDb = (status = "NEGOTIATING") => ({ chat_threads: [{ id: "thread_camp_1", creator_id: "c1", brand_id: "b1", status, flow_state: status }], chat_messages: [] as any[], user_violations: [] });

describe("v414 chat route", () => {
  it("helpers", () => {
    expect(userMessageType("attachment", false)).toBe("text");
    expect(userMessageType("attachment", true)).toBe("attachment");
    expect(userMessageType("payment_funded", true)).toBe("text");
    expect(isChatClosed({ status: "COMPLETED" })).toBe(false);
    for (const s of ["CANCELLED", "DECLINED", "REFUNDED", "EXPIRED"]) expect(isChatClosed({ status: s })).toBe(true);
    expect(cleanClientMsgId(" abc_1-2 ")).toBe("abc_1-2");
    expect(cleanClientMsgId("a b")).toBe(null);
    expect(cleanClientMsgId("x".repeat(65))).toBe(null);
    expect(attachmentLabel("Payment released", "chat-attachments/t-1730000000000.pdf")).toBe("📎 Attached file (.pdf)");
  });

  it("D1: a fake 'attachment' with no file is saved as text; metadata from the body is never kept", async () => {
    const db = mkDb();
    await serve(chatApp(db, { user_id: "c1", role: "creator" }), async (base) => {
      const r = await post(`${base}/chat/v2/threads/thread_camp_1/messages`, { text: "Payment released", message_type: "attachment", metadata: { action: "payment_released", isPayment: true } });
      expect(r.status).toBe(200);
    });
    expect(db.chat_messages[0].message_type).toBe("text");
    expect(db.chat_messages[0].metadata).toBeUndefined();
  });

  it("D1: a real attachment keeps its type and the text becomes the file label", async () => {
    const db = mkDb();
    await serve(chatApp(db, { user_id: "c1", role: "creator" }), async (base) => {
      await post(`${base}/chat/v2/threads/thread_camp_1/messages`, { text: "Payment released", message_type: "attachment", attachment_url: "chat-attachments/thread_camp_1-1730000000000.png" });
    });
    expect(db.chat_messages[0].message_type).toBe("attachment");
    expect(db.chat_messages[0].text).toBe("📎 Attached file (.png)");
    expect(db.chat_messages[0].metadata).toEqual({ attachment_url: "chat-attachments/thread_camp_1-1730000000000.png" });
  });

  it("client_msg_id is stored in metadata and returned top-level", async () => {
    const db = mkDb();
    await serve(chatApp(db, { user_id: "c1", role: "creator" }), async (base) => {
      const r = await post(`${base}/chat/v2/threads/thread_camp_1/messages`, { text: "hello", client_msg_id: "tmp_123" });
      const j = await r.json();
      expect(j.client_msg_id).toBe("tmp_123");
    });
    expect(db.chat_messages[0].metadata).toEqual({ client_msg_id: "tmp_123" });
  });

  it("D2: a failed save answers 503 MESSAGE_NOT_SAVED", async () => {
    const db = mkDb();
    const client: any = { from: () => { const q: any = {}; for (const m of ["select", "eq", "or", "order", "limit", "update", "in", "not"]) q[m] = () => q; q.maybeSingle = async () => ({ data: db.chat_threads[0], error: null }); q.then = (ok: any) => Promise.resolve({ data: [], error: null }).then(ok); return q; } };
    await serve(chatApp(db, { user_id: "c1", role: "creator" }, { client, insert: async () => ({ data: null, error: { message: "down" } }) }), async (base) => {
      const r = await post(`${base}/chat/v2/threads/thread_camp_1/messages`, { text: "hello" });
      expect(r.status).toBe(503);
      expect((await r.json()).code).toBe("MESSAGE_NOT_SAVED");
    });
    expect(db.chat_messages.length).toBe(0);
  });

  it("D8: cancelled chat → 409 CHAT_CLOSED; completed chat still open", async () => {
    for (const [st, code] of [["CANCELLED", 409], ["REFUNDED", 409], ["COMPLETED", 200]] as const) {
      const db = mkDb(st);
      await serve(chatApp(db, { user_id: "c1", role: "creator" }), async (base) => {
        expect((await post(`${base}/chat/v2/threads/thread_camp_1/messages`, { text: "thanks" })).status).toBe(code);
      });
    }
  });

  it("D8: a stranger gets 403 before any moderation record (contact text)", async () => {
    const db: any = mkDb();
    await serve(chatApp(db, { user_id: "x9", role: "creator" }), async (base) => {
      expect((await post(`${base}/chat/v2/threads/thread_camp_1/messages`, { text: "call me 9876543210" })).status).toBe(403);
    });
    expect(db.chat_moderation_events || []).toEqual([]);
  });

  it("D6: a number split over messages (saved history) → PHONE_SPLIT", async () => {
    resetRecentMessageBuffer();
    const db = mkDb();
    db.chat_messages.push({ id: "m1", thread_id: "thread_camp_1", sender_user_id: "c1", message_type: "text", text: "98765", created_at: new Date(Date.now() - 60e3).toISOString() }); // v414: within the 10-min window
    await serve(chatApp(db, { user_id: "c1", role: "creator" }), async (base) => {
      const r = await post(`${base}/chat/v2/threads/thread_camp_1/messages`, { text: "43210" });
      expect(r.status).toBe(400);
      expect((await r.json()).code).toBe("PHONE_SPLIT");
    });
  });

  it("D2: local-only rows with the same text are both returned", async () => {
    const db = mkDb();
    db.chat_messages.push(
      { id: "m1", thread_id: "thread_camp_1", sender_user_id: "c1", text: "ok", created_at: "2026-11-07T10:00:00Z" },
      { id: "m2", thread_id: "thread_camp_1", sender_user_id: "c1", text: "ok", created_at: "2026-11-07T10:01:00Z" },
    );
    await serve(chatApp(db, { user_id: "b1", role: "brand" }), async (base) => {
      const j = await (await fetch(`${base}/chat/v2/threads/thread_camp_1/messages`)).json();
      expect(j.map((m: any) => m.id)).toEqual(["m1", "m2"]);
    });
  });

  it("D7: an admin reading someone's chat does not mark it read", async () => {
    const db = mkDb();
    const updates: any[] = [];
    const client: any = {
      from: (table: string) => {
        const q: any = {};
        for (const m of ["select", "eq", "or", "order", "limit", "in", "not", "neq"]) q[m] = () => q;
        q.update = (p: any) => { updates.push({ table, p }); return q; };
        q.then = (ok: any) => Promise.resolve({ data: table === "chat_threads" ? db.chat_threads : [{ message_id: "m1", thread_id: "thread_camp_1", sender_user_id: "c1", read: false, text: "hi" }], error: null }).then(ok);
        return q;
      },
    };
    await serve(chatApp(db, { user_id: "a1", role: "admin" }, { client }), async (base) => {
      await fetch(`${base}/chat/v2/threads/thread_camp_1/messages`);
    });
    expect(updates).toEqual([]);
    await serve(chatApp(db, { user_id: "b1", role: "brand" }, { client }), async (base) => {
      await fetch(`${base}/chat/v2/threads/thread_camp_1/messages`);
    });
    expect(updates.length).toBe(1);
  });
});

// ------------------------------------------------------------------ invites (D9–D12)
function invApp(db: any, user: any) {
  const app = express(); app.use(express.json());
  const router = express.Router();
  setupBlockRoutes(router, { supabase: null, privilegedSupabase: null, getDb: () => db, saveDb: () => {}, parseAuthUser: async () => user, getActingBrandId: (u: any) => u.parent_brand_id || u.user_id });
  setupCreatorsRoutes(app, router, {
    supabase: null, privilegedSupabase: null, getDb: () => db, saveDb: () => {}, parseAuthUser: async () => user,
    syncEntityTags: () => {}, processBase64Image: () => {}, getSettings: () => ({}), markupForRole: () => 0,
    getActingBrandId: (u: any) => u.parent_brand_id || u.user_id, logTeamActivity: () => {}, sanitizeCreatorProfile: (p: any) => p,
    fetchCreatorReviews: async () => [], broadcastAdminNotification: () => {}, insertChatMessageToSupabase: async () => ({}),
  } as any);
  app.use("/api", router);
  return app;
}
const brand = { user_id: "b1", role: "brand", name: "QA Foods" };
const creator = { user_id: "c1", role: "creator", name: "Ravi", email: "c1@x.in" };
const baseDb = () => ({ users: [{ user_id: "c1", name: "Ravi", email: "c1@x.in" }], creator_profiles: [{ user_id: "c1", name: "Ravi" }], brief_requests: [] as any[], chat_threads: [] as any[], chat_messages: [] as any[], notifications: [], deals: [] as any[], campaigns: [{ campaign_id: "camp1", title: "Diwali Reel", brand_user_id: "b1" }], blocked_users: [] as any[] });
const invite = (extra: any = {}) => ({ campaign_title: "Diwali Reel", budget_range: "15000", deliverables: "1 reel", timeline: "7", message: "Hi! call me 9876543210", ...extra });

describe("v414 invites", () => {
  it("D9: pitch saved and returned masked; offer card masked", async () => {
    const db = baseDb();
    await serve(invApp(db, brand), async (base) => { expect((await post(`${base}/creators/c1/invite`, invite())).status).toBe(200); });
    expect(db.brief_requests[0].pitch).toBe("Hi! call me [hidden]");
    expect(db.brief_requests[0].message).toBe("Hi! call me [hidden]");
    db.brief_requests[0].pitch = "raw ravi@gmail.com"; // an old raw row
    await serve(invApp(db, creator), async (base) => {
      const j = await (await fetch(`${base}/creators/invitations`)).json();
      expect(j.invitations[0].pitch).not.toContain("ravi@gmail.com");
      expect((await post(`${base}/creators/invitations/${db.brief_requests[0].id}/accept`, {})).status).toBe(200);
    });
    const card = db.chat_messages.find((m: any) => m.message_type === "brand_invitation_offer");
    expect(card.metadata.pitch).not.toContain("ravi@gmail.com");
  });

  it("D10: a second invite for the same campaign → 409 ALREADY_INVITED; accept stores campaign_id", async () => {
    const db = baseDb();
    await serve(invApp(db, brand), async (base) => {
      expect((await post(`${base}/creators/c1/invite`, invite({ message: "hi" }))).status).toBe(200);
      const r = await post(`${base}/creators/c1/invite`, invite({ message: "hi again" }));
      expect(r.status).toBe(409);
      expect((await r.json()).code).toBe("ALREADY_INVITED");
    });
    await serve(invApp(db, creator), async (base) => {
      expect((await post(`${base}/creators/invitations/${db.brief_requests[0].id}/accept`, {})).status).toBe(200);
    });
    expect(db.deals[0].campaign_id).toBe("camp1");
    expect(db.chat_threads[0].campaign_id).toBe("camp1");
  });

  it("D10: accept returns the existing open chat for the same campaign", async () => {
    const db = baseDb();
    db.chat_threads.push({ id: "thread_camp_old", deal_id: "old", campaign_id: "camp1", creator_id: "c1", brand_id: "b1", status: "NEGOTIATING" });
    db.brief_requests.push({ id: "inv1", brand_id: "b1", creator_id: "c1", campaign_title: "Diwali Reel", amount: 15000, status: "pending_creator_acceptance", created_at: new Date().toISOString() });
    await serve(invApp(db, creator), async (base) => {
      const j = await (await post(`${base}/creators/invitations/inv1/accept`, {})).json();
      expect(j.thread_id).toBe("thread_camp_old");
    });
    expect(db.deals.length).toBe(0);
  });

  it("D11: expired invite → 410; list says expired", async () => {
    const db = baseDb();
    db.brief_requests.push({ id: "inv1", brand_id: "b1", creator_id: "c1", campaign_title: "X", amount: 15000, status: "pending_creator_acceptance", created_at: new Date(Date.now() - 15 * 864e5).toISOString() });
    await serve(invApp(db, creator), async (base) => {
      expect((await post(`${base}/creators/invitations/inv1/accept`, {})).status).toBe(410);
      const j = await (await fetch(`${base}/creators/invitations`)).json();
      expect(j.invitations[0].status).toBe("expired");
      expect(j.pending_count).toBe(0);
    });
  });

  it("D11: brand withdraws a pending invite; accept → 409; another brand can't", async () => {
    const db = baseDb();
    db.brief_requests.push({ id: "inv1", brand_id: "b1", creator_id: "c1", campaign_title: "X", amount: 15000, status: "pending_creator_acceptance", created_at: new Date().toISOString() });
    await serve(invApp(db, { user_id: "b2", role: "brand" }), async (base) => {
      expect((await post(`${base}/brands/invitations/inv1/withdraw`, {})).status).toBe(403);
    });
    await serve(invApp(db, { user_id: "t1", role: "brand", parent_brand_id: "b1" }), async (base) => {
      expect((await post(`${base}/brands/invitations/inv1/withdraw`, {})).status).toBe(200);
    });
    expect(db.brief_requests[0].decline_reason).toBe(WITHDRAWN_REASON);
    await serve(invApp(db, creator), async (base) => {
      const r = await post(`${base}/creators/invitations/inv1/accept`, {});
      expect(r.status).toBe(409);
      expect((await r.json()).code).toBe("INVITE_WITHDRAWN");
    });
  });

  it("D12: accepting an invite from a blocked brand → 403 BLOCKED", async () => {
    const db = baseDb();
    db.blocked_users.push({ blocker_id: "c1", blocked_id: "b1" });
    db.brief_requests.push({ id: "inv1", brand_id: "b1", creator_id: "c1", campaign_title: "X", amount: 15000, status: "pending_creator_acceptance", created_at: new Date().toISOString() });
    await serve(invApp(db, creator), async (base) => {
      const r = await post(`${base}/creators/invitations/inv1/accept`, {});
      expect(r.status).toBe(403);
      expect((await r.json()).code).toBe("BLOCKED");
    });
  });

  it("D9: decline reason sent to the brand is masked", async () => {
    const db: any = baseDb();
    db.brief_requests.push({ id: "inv1", brand_id: "b1", creator_id: "c1", campaign_title: "X", amount: 15000, status: "pending_creator_acceptance", created_at: new Date().toISOString() });
    await serve(invApp(db, creator), async (base) => {
      await post(`${base}/creators/invitations/inv1/decline`, { reason: "busy, whatsapp 9876543210" });
    });
    expect(db.notifications[0].message).not.toContain("9876543210");
  });

  it("helpers", () => {
    const now = Date.now();
    const p = { id: "a", status: "pending_creator_acceptance", campaign_title: "Diwali", created_at: new Date(now).toISOString() };
    expect(duplicateInvite([p], { campaign_title: "diwali" }, now)?.id).toBe("a");
    expect(duplicateInvite([p], { campaign_title: "Holi", has_campaign: true }, now)).toBe(null);
    expect(duplicateInvite([p], { campaign_title: "Campaign Collaboration" }, now)?.id).toBe("a");
    expect(isInviteExpired({ ...p, created_at: new Date(now - 15 * 864e5).toISOString() }, now)).toBe(true);
    expect(inviteViewStatus({ status: "creator_declined", decline_reason: WITHDRAWN_REASON })).toBe("withdrawn");
  });
});

// ------------------------------------------------------------------ D13 attachment signing helpers
describe("v414 chat attachment upload", () => {
  it("only allowed types", () => {
    expect(checkChatAttachmentType("chat-attachments/t1-1730000000000.png").ok).toBe(true);
    expect(checkChatAttachmentType("chat-attachments/t1-1730000000000.pdf").ok).toBe(true);
    expect(checkChatAttachmentType("chat-attachments/t1-1730000000000.zip").ok).toBe(false);
    expect(checkChatAttachmentType("ugc-videos/t1-1730000000000.bin").ok).toBe(true);
  });
  it("thread id from the path", () => {
    expect(chatAttachmentThreadId("chat-attachments/thread_camp_a-b-1730000000000.png")).toBe("thread_camp_a-b");
    expect(chatAttachmentThreadId("chat-attachments/whatever.png")).toBe(null);
  });
});
