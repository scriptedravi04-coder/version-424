// v417 (agent A, backend): staff marker, offer floor by deal type, team unread, attachment checks, delete draft, revision limit copy.
import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";
import { isStaffMessage, staffMarker, STAFF_SENDER_LABEL } from "./chat_routes";
import { offerMinimumFor, isBarterDeal, CAMPAIGN_MIN_OFFER, UGC_MIN_OFFER, offerMinimumMessage } from "./deals_chat_routes";
import { mySideHas } from "./inboxLean";
import { chatAttachmentProblem, fileLooksLike, sniffType, isHeicBytes, CHAT_ATTACHMENT_MAX_BYTES } from "./fileMagic";
import { checkChatAttachmentType } from "./misc_routes";
import { REVISION_LIMIT_MESSAGE } from "./campaignGuards";
import { setupCampaignManageRoutes } from "./campaignManage";

function manage(user: any, camps: any[], deals: any[] = []) {
  const db: any = { campaigns: camps, deals, campaign_applications: [{ campaign_id: "D1" }, { campaign_id: "L1" }] };
  const routes: Record<string, any> = {};
  const reg = (m: string) => (p: string, h: any) => { routes[m + " " + p] = h; };
  setupCampaignManageRoutes({ get: reg("GET"), post: reg("POST"), delete: reg("DELETE") } as any, {
    supabase: null, privilegedSupabase: null, getDb: () => db, saveDb: () => {},
    parseAuthUser: async () => user, getActingBrandId: (u: any) => u.parent_brand_id || u.user_id,
  });
  const del = async (id: string) => {
    let status = 200, json: any = null;
    const res: any = { status: (s: number) => { status = s; return res; }, json: (j: any) => { json = j; return res; } };
    await routes["DELETE /campaigns/:id"]({ params: { id }, body: {} }, res, () => {});
    return { status, json };
  };
  return { db, del };
}

const read = (f: string) => fs.readFileSync(path.join(__dirname, f), "utf8");

describe("v417 #1 staff messages", () => {
  it("marks admin / old admin_injection / Platform Admin rows", () => {
    expect(isStaffMessage({ sender_role: "admin" })).toBe(true);
    expect(isStaffMessage({ metadata: { sender_role: "sub_admin" } })).toBe(true);
    expect(isStaffMessage({ message_type: "admin_injection", sender_role: "system" })).toBe(true);
    expect(isStaffMessage({ from_name: "Platform Admin" })).toBe(true);
    expect(isStaffMessage({ sender_role: "brand" })).toBe(false);
    expect(isStaffMessage({ sender_role: "system" })).toBe(false);
  });
  it("marker shape", () => {
    const m = staffMarker({ sender_role: "admin", metadata: { a: 1 } });
    expect(m).toEqual({ sender_role: "admin", is_staff: true, sender_label: STAFF_SENDER_LABEL, metadata: { a: 1, sender_role: "admin", is_staff: true } });
    expect(staffMarker({ sender_role: "creator" })).toEqual({});
    expect(STAFF_SENDER_LABEL).toBe("Ybex Support");
  });
});

describe("v417 #2 offer floor by deal type", () => {
  it("campaign / unknown 3000, UGC 500, barter none", () => {
    expect(offerMinimumFor({ id: "thread_x", deal_id: "deal_x" })).toBe(CAMPAIGN_MIN_OFFER);
    expect(offerMinimumFor({ id: "thread_camp_abc" })).toBe(2000); // v420 special offer
    expect(UGC_MIN_OFFER).toBe(2000);
    expect(offerMinimumMessage(2000)).toBe("The minimum offer for this deal is ₹2,000 (special offer — usually ₹3,000).");
    expect(offerMinimumMessage(500)).toBe("The minimum offer for this deal is ₹500.");
    expect(offerMinimumFor({ id: "thread_ugc_ugcord_1" })).toBe(UGC_MIN_OFFER);
    expect(offerMinimumFor({ id: "t1" }, { is_barter: true })).toBe(0);
    expect(offerMinimumFor({ id: "t1" }, { collab_mode: "Barter" })).toBe(0);
    expect(isBarterDeal({ collab_mode: "paid" })).toBe(false);
  });
  it("routes use the deal-type floor (not the URL)", () => {
    const s = read("deals_chat_routes.ts");
    expect(s).toMatch(/await campaignMinimumFails\(thread\)/);
    expect(s).not.toMatch(/isCampaignThread\(t\) && counterNum < 3000/);
    expect(read("campaigns_routes.ts")).toMatch(/BELOW_MIN_OFFER/);
  });
});

describe("v417 #4 brand side unread", () => {
  it("any id on my side is mine", () => {
    expect(mySideHas(["owner", "member"], "owner")).toBe(true);
    expect(mySideHas(["owner", "member"], "creator")).toBe(false);
    expect(mySideHas("me", "me")).toBe(true);
  });
  it("count + list + mark-read use mySideIds", () => {
    const s = read("chat_routes.ts");
    expect(s).toMatch(/\.not\('sender_user_id', 'in', `\(\$\{\(await mySideIds\(user\)\)\.join/);
    expect(s).toMatch(/populateThreadData\(threads, await mySideIds\(user\)\)/);
    expect(s).toMatch(/eq\('parent_brand_id', brandId\)/);
  });
});

describe("v417 #5 attachments", () => {
  it("allow-list + 50 MB", () => {
    expect(chatAttachmentProblem({ path: "chat-attachments/t-1234567890.jpg", contentType: "image/jpeg", size: 1000 })).toBeNull();
    expect(chatAttachmentProblem({ path: "chat-attachments/t-1234567890.heic" })).toBeNull();
    expect(chatAttachmentProblem({ path: "chat-attachments/t-1234567890.mov", contentType: "video/quicktime" })).toBeNull();
    expect(chatAttachmentProblem({ path: "chat-attachments/t-1234567890.docx" })).toMatch(/photos/);
    expect(chatAttachmentProblem({ path: "chat-attachments/t-1234567890.webm" })).toMatch(/photos/);
    expect(chatAttachmentProblem({ path: "chat-attachments/t-1234567890.pdf", contentType: "text/html" })).toMatch(/photos/);
    expect(chatAttachmentProblem({ path: "chat-attachments/t-1234567890.mp4", size: CHAT_ATTACHMENT_MAX_BYTES + 1 })).toMatch(/50 MB/);
    expect(checkChatAttachmentType("chat-attachments/t-1234567890.exe").ok).toBe(false);
    expect(checkChatAttachmentType("chat-attachments/t-1234567890.png", "image/png", 10).ok).toBe(true);
    expect(checkChatAttachmentType("chat-attachments/t-1234567890.png", "image/png", 60 * 1024 * 1024).ok).toBe(false);
  });
  it("HEIC bytes pass the base64 magic check", () => {
    const heic = Buffer.from("000000186674797068656963000000006d69663168656963", "hex"); // ....ftypheic
    const mif1 = Buffer.concat([Buffer.from([0, 0, 0, 0x18]), Buffer.from("ftypmif1heic0000", "latin1")]);
    expect(isHeicBytes(heic)).toBe(true);
    expect(isHeicBytes(mif1)).toBe(true);
    expect(fileLooksLike({ buffer: heic, mimetype: "image/heic" })).toBe(true);
    expect(fileLooksLike({ buffer: mif1, mimetype: "image/heif" })).toBe(true);
    expect(fileLooksLike({ buffer: Buffer.from("MZ\x90\x00garbage!!", "latin1"), mimetype: "image/heic" })).toBe(false);
    expect(sniffType(heic)).toBe("image/heic");
  });
  it("message route checks type + stored size", () => {
    const s = read("chat_routes.ts");
    expect(s).toMatch(/code: "BAD_ATTACHMENT"/);
    expect(s).toMatch(/storedAttachmentSize\(attachmentPath\)/);
  });
});

describe("v417 #6 delete draft", () => {
  const camps = () => [{ campaign_id: "D1", brand_user_id: "B1", status: "draft" }, { campaign_id: "L1", brand_user_id: "B1", status: "live" }, { campaign_id: "D2", brand_user_id: "B1", status: "draft" }];
  it("owner / team member deletes a draft → { ok: true }, applications removed", async () => {
    const h = manage({ user_id: "M1", role: "brand", parent_brand_id: "B1" }, camps());
    expect(await h.del("D1")).toEqual({ status: 200, json: { ok: true } });
    expect(h.db.campaigns.map((c: any) => c.campaign_id)).toEqual(["L1", "D2"]);
    expect(h.db.campaign_applications.map((a: any) => a.campaign_id)).toEqual(["L1"]);
  });
  it("409 not a draft, 403 other brand / creator, 404 missing, 409 with deals", async () => {
    expect((await manage({ user_id: "B1", role: "brand" }, camps()).del("L1")).status).toBe(409);
    expect((await manage({ user_id: "B2", role: "brand" }, camps()).del("D1")).status).toBe(403);
    expect((await manage({ user_id: "B1", role: "creator" }, camps()).del("D1")).status).toBe(403);
    expect((await manage({ user_id: "B1", role: "agency" }, camps()).del("D1")).status).toBe(200);
    expect((await manage({ user_id: "B1", role: "brand" }, camps()).del("NOPE")).status).toBe(404);
    expect((await manage({ user_id: "B1", role: "brand" }, camps(), [{ campaign_id: "D2" }]).del("D2")).status).toBe(409);
  });
  it("route exists with draft / owner checks", () => {
    const s = read("campaignManage.ts");
    expect(s).toMatch(/router\.delete\("\/campaigns\/:id"/);
    expect(s).toMatch(/code: "NOT_A_DRAFT"/);
    expect(s).toMatch(/code: "NOT_OWNER"/);
    expect(s).toMatch(/res\.json\(\{ ok: true \}\)/);
  });
});

describe("v417 #7 revision limit copy", () => {
  it("points to Support, never cancel", () => {
    expect(REVISION_LIMIT_MESSAGE).toBe("Revision limit reached. Need more changes? Contact Ybex Support from the deal menu.");
    expect(REVISION_LIMIT_MESSAGE).not.toMatch(/cancel/i);
    for (const f of ["campaign_lifecycle.ts", "content_submissions_routes.ts", "services/ugcLifecycleService.ts"]) expect(read(f)).toMatch(/REVISION_LIMIT_MESSAGE/);
  });
});
