// v416 (B2): UGC / payments / deals backend fixes
import { describe, it, expect } from "vitest";
import fs from "fs";
import { ugcBudgetProblem, refundDestinationText, isPlainId, safeOrId, brandIdsOf, ownsBrandRow, actingBrandIdOf, UGC_MIN_BUDGET_PER_CREATOR, UGC_MAX_BUDGET_PER_CREATOR } from "./ugc_routes";
import { ugcBriefMoney } from "./brandPayments";
import { toBrandUgcRefund, toBrandRefund } from "./campaignRefunds";

const read = (p: string) => fs.readFileSync(p, "utf8");

describe("v416 B2 · pure helpers", () => {
  it("CR19: real UGC budget range (₹500–₹5,00,000 per creator)", () => {
    expect(UGC_MIN_BUDGET_PER_CREATOR).toBe(2000); // v420 special offer
    expect(UGC_MAX_BUDGET_PER_CREATOR).toBe(500000);
    expect(ugcBudgetProblem(1)).toMatch(/minimum/);
    expect(ugcBudgetProblem("")).toMatch(/Enter/);
    expect(ugcBudgetProblem(999999)).toMatch(/maximum/);
    expect(ugcBudgetProblem(1999)).toMatch(/₹2,000 per creator \(special offer/);
    expect(ugcBudgetProblem(2000)).toBeNull();
    expect(ugcBudgetProblem(500, 500)).toBeNull(); // v420: Ybex in-house brands keep ₹500
    expect(ugcBudgetProblem(500000)).toBeNull();
  });
  it("U6: refund destination never says 'account ending bank'", () => {
    expect(refundDestinationText({ method_type: "UPI", upi_id: "ravi@okbank", account_last4: "bank" })).toBe("your UPI ID ra***@okbank");
    expect(refundDestinationText({ method_type: "BANK", account_last4: "1234" })).toBe("your account ending 1234");
    expect(refundDestinationText(null)).toBe("your saved refund account");
  });
  it("CR25: ids with filter characters never reach .or()", () => {
    expect(isPlainId("thread_ugc_abc-123")).toBe(true);
    expect(isPlainId("zz,id.neq.zz")).toBe(false);
    expect(safeOrId("a,b")).toBe("__invalid_id__");
    expect(safeOrId("ord_1")).toBe("ord_1");
  });
  it("CR5: a team member acts for the brand; old own-id rows still count", () => {
    const m = { user_id: "member1", parent_brand_id: "brand1" };
    expect(actingBrandIdOf(m)).toBe("brand1");
    expect(brandIdsOf(m)).toEqual(["brand1", "member1"]);
    expect(ownsBrandRow(m, "brand1")).toBe(true);
    expect(ownsBrandRow(m, "member1")).toBe(true);
    expect(ownsBrandRow(m, "other")).toBe(false);
  });
  it("U1/U2: UGC brief money — open paid slots are held, approved orders released, refunds apart", () => {
    const brief = { budget: 3000, max_creators: 2 };
    const orders = [{ status: "COMPLETED", payment_status: "RELEASED" }, { status: "IN_PROGRESS" }];
    const refunds = [{ status: "PENDING", amount: 12000, slots: 4, reason: "Brand cancelled" }];
    const dep = { gross_amount: 18000, brand_paid_amount: 19700, brand_fee_amount: 1440, brand_fee_gst: 260 };
    const m = ugcBriefMoney(brief, orders, refunds, dep);
    expect(m.released).toBe(3000);
    expect(m.refund_pending).toBe(12000);
    expect(m.held).toBe(3000);
    expect(m.brand_paid).toBe(19700);
    expect(m.service_fee_gst).toBe(260);
    // a paid brief with no claims yet is fully held
    expect(ugcBriefMoney({ budget: 2000, max_creators: 6 }, [], [], null).held).toBe(12000);
  });
  it("U2: UGC refunds come in the brand refunds list shape", () => {
    const r = toBrandUgcRefund({ id: "x", brief_id: "b1", amount: 12000, status: "PROCESSED", utr: "UTR1", processed_at: "2026-11-01" }, "Brief A");
    expect(r).toMatchObject({ id: "ugc_x", kind: "ugc", status: "PROCESSED", reference: "UTR1", amount: 12000, title: "Brief A" });
    expect(toBrandRefund({ id: "t", refund_amount: 5, refund_status: "PENDING" }).kind).toBe("campaign");
  });
});

describe("v416 B2 · source checks", () => {
  const ugc = read("backend/ugc_routes.ts");
  it("CR2: brand briefs / orders lists answer 503 on a DB error", () => {
    expect(ugc).toMatch(/BRIEFS_LOAD_FAILED/);
    expect(ugc).toMatch(/ORDERS_LOAD_FAILED/);
  });
  it("CR4: brief posting + refund account use isBrandLike", () => {
    expect(ugc).toMatch(/import \{ isBrandLike \} from "\.\/roleGuards"/);
    expect(ugc).not.toMatch(/\['brand', 'admin'\]\.includes/);
  });
  it("U7: cancel quote carries the refund breakdown", () => {
    expect(ugc).toMatch(/refund_breakdown: q\.breakdown/);
    expect(ugc).toMatch(/service_fee_refunded: 0/);
  });
  it("cross-note: approve message never uses a stored 0 amount", () => {
    expect(read("backend/services/ugcLifecycleService.ts")).toMatch(/let grossAmount = firstPositive\(/);
  });
  it("CR10: uploads accept real HEIC photos", () => {
    const s = read("backend/server.ts");
    expect(s).toMatch(/'image\/heic', 'image\/heif'/);
    expect(s).toMatch(/isRealHeic/);
  });
  it("U1: payments overview has clearly named totals", () => {
    const s = read("backend/brandPayments.ts");
    for (const k of ["held_now", "released_total", "refunded_total", "paid_this_year"]) expect(s).toContain(k);
  });
});
