// v419 (Ravi): Ybex in-house brands — ₹500 floor and "Pay" funded by Ybex.
import { describe, it, expect } from "vitest";
import fs from "fs";
import { campaignPayoutProblem, isInhouseOrderId, INHOUSE_MIN_OFFER, MIN_INVITE_AMOUNT } from "./directInvites";
const read = (p: string) => fs.readFileSync(p, "utf8");

describe("v419 in-house brands", () => {
  it("payout floor takes the brand's own minimum", () => {
    expect(campaignPayoutProblem(1500, "paid", false)).toMatch(/2,000/); // v420
    expect(campaignPayoutProblem(1500, "paid", false, INHOUSE_MIN_OFFER)).toBeNull();
    expect(campaignPayoutProblem(400, "paid", false, INHOUSE_MIN_OFFER)).toMatch(/500/);
    expect(MIN_INVITE_AMOUNT).toBe(2000);
    expect(isInhouseOrderId("order_inhouse_abc")).toBe(true);
    expect(isInhouseOrderId("order_test_abc")).toBe(false);
  });
  it("every floor and the payment path read the in-house list", () => {
    expect(read("backend/campaigns_routes.ts")).toMatch(/campaignPayoutProblem\([^\n]*await minPayoutFor\(actingId\)\)/);
    expect(read("backend/creators_routes.ts")).toMatch(/minPayoutFor\(user\?\.parent_brand_id \|\| user\?\.user_id\)/);
    expect(read("backend/deals_chat_routes.ts")).toMatch(/isInhouseBrand\(t\?\.brand_id/);
    const pay = read("backend/payment_routes.ts");
    expect(pay).toMatch(/order_inhouse_/);
    expect(pay).toMatch(/brand_paid_amount: 0, brand_fee_amount: 0/);
    expect(read("backend/adminMoney.ts")).toMatch(/order_inhouse_/);
    const admin = read("backend/admin_users_enforcement_routes.ts");
    expect(admin).toMatch(/router\.post\("\/admin\/brands\/:id\/inhouse"[\s\S]{0,200}isFullAdmin\(user\)/);
  });
  it("no fee percent on the brand's payment screens", () => {
    expect(read("src/components/payments/BrandFeeSummary.jsx")).not.toMatch(/Service fee \(\$\{quote\.brandFeeBasePercent\}%\)/);
    expect(read("src/components/payments/InvoiceModal.jsx")).not.toMatch(/brand_fee_pct\)\}%\)/);
  });
});

describe("v419 in-house security layer", () => {
  it("marking needs the admin password; marking on also sets a pay PIN", () => {
    const admin = read("backend/admin_users_enforcement_routes.ts");
    expect(admin).toMatch(/PASSWORD_REQUIRED/);
    expect(admin).toMatch(/passwordMatches\(password, adminRow\)/);
    expect(admin).toMatch(/PIN_INVALID/);
  });
  it("the ₹0 payment checks the PIN before recording anything", () => {
    const pay = read("backend/payment_routes.ts");
    const i = pay.indexOf("checkInhousePin(");
    expect(i).toBeGreaterThan(0);
    expect(i).toBeLessThan(pay.indexOf("persistEscrowPayment({ razorpay_order_id: inhouseOrderId"));
  });
  it("PIN rules", async () => {
    const { inhousePinProblem } = await import("./directInvites");
    expect(inhousePinProblem("1234")).toBe("");
    expect(inhousePinProblem("12")).not.toBe("");
    expect(inhousePinProblem("abcd")).not.toBe("");
  });
});
