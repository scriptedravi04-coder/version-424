// v418 (QA v406 M-3): after the whole DEAL amount was refunded, the brand's service fee (split model) could not be
// refunded — the NOT_FUNDED guard had no fee exception. Fee refund must work; nothing beyond what the brand paid.
import { describe, it, expect } from "vitest";
import { refundBlock } from "./adminMoney";
const fullDealRefunded = {
  status: "REFUNDED", refund_status: "PROCESSED", refund_amount: 25000,
  gross_amount: 25000, creator_net_amount: 25000, brand_fee_amount: 2000, brand_fee_gst: 360, brand_paid_amount: 27360,
  payout_status: null, payout_reference: null,
};
describe("v418 · M-3 service fee refund after a full deal refund", () => {
  it("₹2,360 fee refund is allowed after the full ₹25,000 deal refund", () => {
    expect(refundBlock(fullDealRefunded as any, 2360, "PROCESSED", "fee")).toBeNull();
  });
  it("more than the fee left is still refused", () => {
    expect(refundBlock(fullDealRefunded as any, 2361, "PROCESSED", "fee")?.status).toBe(400);
  });
  it("a deal refund after a full deal refund is still refused", () => {
    expect(refundBlock(fullDealRefunded as any, 100, "PROCESSED", "deal")?.code).toBe("ALREADY_REFUNDED");
  });
  it("once the fee is also refunded, nothing more", () => {
    const all = { ...fullDealRefunded, refund_amount: 27360, fee_correction_note: "[service-fee refund] fee ₹2,360" };
    expect(refundBlock(all as any, 1, "PROCESSED", "fee")).not.toBeNull();
  });
  it("an unfunded payment still can't be fee-refunded", () => {
    expect(refundBlock({ status: "PENDING", gross_amount: 25000, brand_fee_amount: 2000, brand_fee_gst: 360, brand_paid_amount: 27360 } as any, 100, "PROCESSED", "fee")).not.toBeNull();
  });
});
